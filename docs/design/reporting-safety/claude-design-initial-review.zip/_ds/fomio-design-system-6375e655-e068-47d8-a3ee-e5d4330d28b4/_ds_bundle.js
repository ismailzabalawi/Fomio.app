/* @ds-bundle: {"format":4,"namespace":"FomioDesignSystem_6375e6","components":[{"name":"CategoryPermission","sourcePath":"uploads/CATEGORIES_TYPES.ts"},{"name":"NotificationLevel","sourcePath":"uploads/CATEGORIES_TYPES.ts"},{"name":"TopicFilter","sourcePath":"uploads/HUB_PAGE_TYPES.ts"},{"name":"TopPeriod","sourcePath":"uploads/HUB_PAGE_TYPES.ts"}],"sourceHashes":{"auth-flow-app.jsx":"678f239b8b35","auth-flow-data.js":"9ba76b7d85f5","auth-flow-diagram.jsx":"3d22f0304349","auth-flow-icons.jsx":"d67f911faf60","auth-flow-screens.jsx":"ad0bc9ac8744","composer-preview.jsx":"2a99a1cbb405","composer.jsx":"02caa6a5f17a","content-tweaks.jsx":"b72a62925f77","controls-tweaks.jsx":"851b58937cec","design-canvas.jsx":"862a6db59c7c","home-app.jsx":"06c8196dc564","home-data.js":"cccdba20b2d0","home-feed.jsx":"9aafd9b544fe","home-icons.jsx":"4e46a9a2496d","home-nav.jsx":"24d7d9ecb001","hubs-app.jsx":"230336174e52","hubs-data.js":"0048f2c5bb2e","hubs-detail-data.js":"9ccdf204b960","hubs-detail-screen.jsx":"e85eba159a19","hubs-detail.jsx":"c571d7eac881","hubs-directory.jsx":"ee8019dfb51b","il3-tweaks.jsx":"891e27cbb8be","list-component/list-icons.js":"eb32a981b07c","mobile-composer-data.js":"70210f4145f0","mobile-composer-icons.jsx":"6c56a534cf48","mobile-composer-screen.jsx":"1eb004c3f8c4","mobile-composer-sheets.jsx":"4e84ee41b341","np-components-v2.jsx":"f7932522c83f","search-app.jsx":"ebb7743539b5","search-data.js":"63522fd3039f","search-filters.jsx":"3d6995beff03","search-icons.jsx":"d3272640c08a","search-results.jsx":"f1e1a226cd55","search-views.jsx":"0a4d6ac4ee32","topics-app.jsx":"e5b9ce1e71c8","topics-arch.jsx":"4aec9d94b0d0","topics-data.js":"4096433fa354","topics-feed.jsx":"19e516256685","topics-icons.jsx":"ecc5b72ebff9","topics-nav.jsx":"c062322b7a02","topics-reader.jsx":"0a8fefb8c4bb","tweaks-panel.jsx":"ea982af775f0","ui_kits/mobile/ios-frame.jsx":"d67eb3ffe562","ui_kits/mobile/screens.jsx":"8ecb8f07a065","uploads/CATEGORIES_TYPES.ts":"4ef9c5f1d7c8","uploads/HUB_PAGE_TYPES.ts":"a9c7e46cef83","user-profile-app.jsx":"627ed44f9313","user-profile-data.js":"adaf86d076dc","user-profile-panels.jsx":"63f71fdb1c9d","user-profile-ui.jsx":"eb1460ff0b60"},"inlinedExternals":[],"unexposedExports":[{"name":"unwrap","sourcePath":"uploads/CATEGORIES_TYPES.ts"}]} */

(() => {

const __ds_ns = (window.FomioDesignSystem_6375e6 = window.FomioDesignSystem_6375e6 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// auth-flow-app.jsx
try { (() => {
/* Fomio auth flow — app shell: layout, scrubber, autoplay, tweaks. */
(function () {
  const I = window.AF.Icons;
  const STEPS = window.AUTH_STEPS;
  const ERRORS = window.AUTH_ERRORS;
  function StepDots({
    n,
    current,
    maxReach,
    errAt,
    onPick
  }) {
    return /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 7
      }
    }, Array.from({
      length: n
    }).map((_, i) => {
      const reachable = i <= maxReach;
      const isErr = errAt === i;
      const active = i === current;
      return /*#__PURE__*/React.createElement("button", {
        key: i,
        onClick: () => reachable && onPick(i),
        "aria-label": `Step ${i + 1}`,
        style: {
          width: active ? 26 : 9,
          height: 9,
          borderRadius: 9999,
          border: 'none',
          padding: 0,
          cursor: reachable ? 'pointer' : 'default',
          background: active ? isErr ? 'var(--fomio-danger)' : 'var(--fomio-primary)' : i < current ? 'var(--fomio-fg-secondary)' : reachable ? 'var(--fomio-border)' : 'var(--fomio-border)',
          opacity: reachable ? 1 : 0.4,
          transition: 'width 220ms var(--fomio-ease), background 200ms'
        }
      });
    }));
  }
  function CtrlBtn({
    children,
    onClick,
    disabled,
    primary,
    label
  }) {
    return /*#__PURE__*/React.createElement("button", {
      onClick: onClick,
      disabled: disabled,
      "aria-label": label,
      style: {
        width: 44,
        height: 44,
        borderRadius: 9999,
        flex: 'none',
        border: '1px solid ' + (primary ? 'var(--fomio-primary)' : 'var(--fomio-border)'),
        background: primary ? 'var(--fomio-primary)' : 'var(--fomio-card)',
        color: primary ? '#fff' : 'var(--fomio-fg)',
        display: 'grid',
        placeItems: 'center',
        cursor: disabled ? 'default' : 'pointer',
        opacity: disabled ? 0.4 : 1,
        transition: 'background 160ms, opacity 160ms'
      }
    }, children);
  }
  window.AuthFlowApp = function AuthFlowApp({
    tweaks
  }) {
    const errKey = tweaks.errorState;
    const err = errKey && errKey !== 'none' ? ERRORS[errKey] : null;
    const maxReach = err ? err.atStep : STEPS.length - 1;
    const [current, setCurrent] = React.useState(0);
    const [playing, setPlaying] = React.useState(false);

    // clamp current when the error branch shortens the flow
    React.useEffect(() => {
      setCurrent(c => Math.min(c, maxReach));
    }, [maxReach]);
    const atEnd = current >= maxReach;
    const go = React.useCallback(n => setCurrent(Math.max(0, Math.min(maxReach, n))), [maxReach]);

    // autoplay
    React.useEffect(() => {
      if (!playing) return;
      if (atEnd) {
        setPlaying(false);
        return;
      }
      const t = setTimeout(() => setCurrent(c => Math.min(maxReach, c + 1)), 2400);
      return () => clearTimeout(t);
    }, [playing, current, atEnd, maxReach]);

    // keyboard
    React.useEffect(() => {
      const h = e => {
        if (e.key === 'ArrowRight') {
          setPlaying(false);
          go(current + 1);
        }
        if (e.key === 'ArrowLeft') {
          setPlaying(false);
          go(current - 1);
        }
      };
      window.addEventListener('keydown', h);
      return () => window.removeEventListener('keydown', h);
    }, [current, go]);
    const showErr = err && current === err.atStep;
    const step = STEPS[current];
    const cap = showErr ? {
      kicker: err.kicker,
      title: err.title,
      body: err.body
    } : {
      kicker: `Step ${current + 1} of ${STEPS.length}`,
      title: step.title,
      body: step.caption
    };
    return /*#__PURE__*/React.createElement("div", {
      style: {
        minHeight: '100vh',
        background: 'var(--fomio-surface)',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        padding: '30px 24px 40px'
      }
    }, /*#__PURE__*/React.createElement("header", {
      style: {
        width: '100%',
        maxWidth: 980,
        marginBottom: 22
      }
    }, /*#__PURE__*/React.createElement("div", {
      className: "fomio-label",
      style: {
        color: 'var(--fomio-primary)',
        fontSize: 11
      }
    }, "Auth \xB7 user-api-key handshake"), /*#__PURE__*/React.createElement("h1", {
      className: "fomio-display",
      style: {
        fontSize: 32,
        marginTop: 6
      }
    }, "How fomio gets a token, ", /*#__PURE__*/React.createElement("em", {
      style: {
        fontStyle: 'italic',
        color: 'var(--fomio-primary)'
      }
    }, "without ever seeing your password")), /*#__PURE__*/React.createElement("p", {
      style: {
        fontFamily: 'var(--fomio-serif)',
        fontSize: 15,
        lineHeight: '24px',
        color: 'var(--fomio-fg-secondary)',
        marginTop: 8,
        maxWidth: 620
      }
    }, "The app opens a browser to your Discourse site, you sign in and authorize there, and an encrypted token comes back that only your phone can open. Step through it below.")), /*#__PURE__*/React.createElement("div", {
      style: {
        width: '100%',
        maxWidth: 980,
        display: 'flex',
        gap: 34,
        alignItems: 'flex-start',
        flexWrap: 'wrap'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 'none',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        gap: 14
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        position: 'relative'
      }
    }, /*#__PURE__*/React.createElement(SurfaceTag, {
      surface: showErr ? err.surface : step.surface
    }), /*#__PURE__*/React.createElement("div", {
      key: current + (showErr ? 'e' : '') + errKey,
      style: {
        animation: 'af-fade 240ms var(--fomio-ease)'
      }
    }, /*#__PURE__*/React.createElement(window.AF.Stage, {
      step: step,
      error: showErr ? err : null
    })))), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        minWidth: 480,
        display: 'flex',
        flexDirection: 'column',
        gap: 20
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        background: 'var(--fomio-card)',
        border: '1px solid var(--fomio-border)',
        borderRadius: 20,
        padding: '22px 20px 14px'
      }
    }, /*#__PURE__*/React.createElement(window.AF.Diagram, {
      steps: STEPS,
      current: current,
      errorAtStep: err ? err.atStep : -1
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        background: 'var(--fomio-card)',
        border: '1px solid var(--fomio-border)',
        borderRadius: 18,
        padding: '18px 20px',
        minHeight: 118
      }
    }, /*#__PURE__*/React.createElement("div", {
      key: current + (showErr ? 'e' : ''),
      style: {
        animation: 'af-fade 240ms var(--fomio-ease)'
      }
    }, /*#__PURE__*/React.createElement("div", {
      className: "fomio-label",
      style: {
        color: showErr ? 'var(--fomio-danger)' : 'var(--fomio-primary)',
        fontSize: 10.5
      }
    }, cap.kicker), /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--fomio-serif)',
        fontWeight: 700,
        fontSize: 19,
        color: 'var(--fomio-fg)',
        marginTop: 6
      }
    }, cap.title), /*#__PURE__*/React.createElement("p", {
      style: {
        fontFamily: 'var(--fomio-serif)',
        fontSize: 14.5,
        lineHeight: '23px',
        color: 'var(--fomio-fg-secondary)',
        marginTop: 6
      }
    }, cap.body))), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 16,
        flexWrap: 'wrap'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        gap: 9
      }
    }, /*#__PURE__*/React.createElement(CtrlBtn, {
      label: "Previous",
      onClick: () => {
        setPlaying(false);
        go(current - 1);
      },
      disabled: current === 0
    }, /*#__PURE__*/React.createElement("svg", {
      width: "18",
      height: "18",
      viewBox: "0 0 24 24",
      fill: "none",
      stroke: "currentColor",
      strokeWidth: "1.9",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }, /*#__PURE__*/React.createElement("path", {
      d: "M15 6 9 12l6 6"
    }))), /*#__PURE__*/React.createElement(CtrlBtn, {
      label: playing ? 'Pause' : 'Play',
      primary: true,
      onClick: () => {
        if (atEnd) {
          go(0);
          setPlaying(true);
        } else setPlaying(p => !p);
      }
    }, playing ? /*#__PURE__*/React.createElement("svg", {
      width: "17",
      height: "17",
      viewBox: "0 0 24 24",
      fill: "currentColor"
    }, /*#__PURE__*/React.createElement("rect", {
      x: "6",
      y: "5",
      width: "4",
      height: "14",
      rx: "1"
    }), /*#__PURE__*/React.createElement("rect", {
      x: "14",
      y: "5",
      width: "4",
      height: "14",
      rx: "1"
    })) : atEnd ? /*#__PURE__*/React.createElement(I.Refresh, {
      size: 18
    }) : /*#__PURE__*/React.createElement("svg", {
      width: "17",
      height: "17",
      viewBox: "0 0 24 24",
      fill: "currentColor"
    }, /*#__PURE__*/React.createElement("path", {
      d: "M7 5.5v13l11-6.5-11-6.5Z"
    }))), /*#__PURE__*/React.createElement(CtrlBtn, {
      label: "Next",
      onClick: () => {
        setPlaying(false);
        go(current + 1);
      },
      disabled: atEnd
    }, /*#__PURE__*/React.createElement("svg", {
      width: "18",
      height: "18",
      viewBox: "0 0 24 24",
      fill: "none",
      stroke: "currentColor",
      strokeWidth: "1.9",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }, /*#__PURE__*/React.createElement("path", {
      d: "M9 6l6 6-6 6"
    })))), /*#__PURE__*/React.createElement(StepDots, {
      n: STEPS.length,
      current: current,
      maxReach: maxReach,
      errAt: err ? err.atStep : -1,
      onPick: i => {
        setPlaying(false);
        go(i);
      }
    })))));
  };
  function SurfaceTag({
    surface
  }) {
    const web = surface === 'web';
    return /*#__PURE__*/React.createElement("div", {
      style: {
        position: 'absolute',
        top: -11,
        left: '50%',
        transform: 'translateX(-50%)',
        zIndex: 2,
        display: 'inline-flex',
        alignItems: 'center',
        gap: 6,
        padding: '4px 12px',
        borderRadius: 9999,
        background: 'var(--fomio-fg)',
        color: 'var(--fomio-bg)',
        fontFamily: 'var(--fomio-sans)',
        fontSize: 10.5,
        fontWeight: 700,
        letterSpacing: '0.04em',
        textTransform: 'uppercase',
        whiteSpace: 'nowrap'
      }
    }, web ? /*#__PURE__*/React.createElement(I.Globe, {
      size: 12
    }) : /*#__PURE__*/React.createElement(I.Phone, {
      size: 12
    }), web ? 'In-app browser' : 'fomio app');
  }
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "auth-flow-app.jsx", error: String((e && e.message) || e) }); }

// auth-flow-data.js
try { (() => {
/* Fomio auth handshake — step data.
   The Discourse user-api-key RSA handshake, told conceptually.
   Three actors: the Expo app, the in-app WebView (browser), the Discourse backend.
   Each step names the message that moves between two actors and the screen the user sees. */

window.AUTH_ACTORS = [{
  id: 'app',
  label: 'fomio app',
  sub: 'Expo · your phone'
}, {
  id: 'web',
  label: 'in-app browser',
  sub: 'WebView'
}, {
  id: 'disc',
  label: 'Discourse',
  sub: 'meta.fomio.app'
}];

/* Each step:
   from / to    — actor ids the message travels between (same id = internal work)
   msg          — the conceptual message (mono)
   note         — tiny sub-label under the arrow
   title        — caption headline
   caption      — one editorial sentence
   screen       — which screen renders on the stage
   surface      — 'app' | 'web' (drives the frame chrome)
   busy         — screen shows a processing state
*/
window.AUTH_STEPS = [{
  id: 'connect',
  from: 'app',
  to: 'app',
  msg: 'generate keypair + nonce',
  note: 'stays on device',
  title: 'You start the connection',
  caption: 'The app mints a fresh keypair and a one-time nonce on your phone. The private key never leaves the device.',
  screen: 'landing',
  surface: 'app'
}, {
  id: 'open',
  from: 'app',
  to: 'web',
  msg: 'open /user-api-key/new',
  note: 'public key · nonce · scopes · redirect',
  title: 'A secure browser opens',
  caption: 'The app hands the browser its public key, the nonce, the scopes it wants, and where to return. No password is ever seen by the app.',
  screen: 'waiting',
  surface: 'app'
}, {
  id: 'login',
  from: 'web',
  to: 'disc',
  msg: 'POST /session',
  note: 'credentials + 2FA',
  title: 'You sign in to Discourse',
  caption: 'Login happens on Discourse\u2019s own page inside the browser \u2014 the app cannot read what you type.',
  screen: 'login',
  surface: 'web'
}, {
  id: 'session',
  from: 'disc',
  to: 'web',
  msg: 'session established',
  note: 'httponly cookie',
  title: 'Discourse knows it\u2019s you',
  caption: 'A session cookie is set inside the browser. You\u2019re authenticated to the site, but the app still has nothing.',
  screen: 'login',
  surface: 'web',
  busy: true
}, {
  id: 'consent',
  from: 'web',
  to: 'disc',
  msg: 'POST /user-api-key',
  note: 'you tap Authorize',
  title: 'You approve the access',
  caption: 'Discourse shows exactly what fomio is asking for. Nothing is granted until you authorize it.',
  screen: 'consent',
  surface: 'web'
}, {
  id: 'encrypt',
  from: 'disc',
  to: 'disc',
  msg: 'issue key + encrypt payload',
  note: 'sealed with your public key',
  title: 'A token is sealed for you',
  caption: 'Discourse creates the API token and encrypts it with your public key, tucking the nonce back inside. Only your device can open it.',
  screen: 'consent',
  surface: 'web',
  busy: true
}, {
  id: 'redirect',
  from: 'disc',
  to: 'app',
  msg: 'fomio://auth_redirect',
  note: 'deep link · encrypted token',
  title: 'The browser hands back',
  caption: 'Discourse redirects to the app\u2019s deep link carrying the encrypted payload. The browser closes itself.',
  screen: 'returning',
  surface: 'app',
  busy: true
}, {
  id: 'store',
  from: 'app',
  to: 'app',
  msg: 'decrypt + verify nonce',
  note: 'private key · store token',
  title: 'You\u2019re connected',
  caption: 'The app decrypts the payload, checks the nonce matches the one it made, and stores the token in the secure keychain.',
  screen: 'success',
  surface: 'app'
}];

/* Error branches, keyed by the errorState tweak value.
   atStep — the step index where the branch diverges.
   screen — error screen shown on the stage. */
window.AUTH_ERRORS = {
  denied: {
    atStep: 4,
    surface: 'app',
    title: 'You declined the request',
    kicker: 'Access not granted',
    body: 'You tapped Deny on the consent screen. No token was issued and nothing changed on your account.',
    hint: 'Try again'
  },
  mismatch: {
    atStep: 7,
    surface: 'app',
    title: 'The response didn\u2019t check out',
    kicker: 'Nonce mismatch',
    body: 'The nonce inside the token didn\u2019t match the one this device created. The app rejected the token to prevent a replay.',
    hint: 'Start over'
  },
  expired: {
    atStep: 2,
    surface: 'web',
    title: 'This link has expired',
    kicker: 'Request timed out',
    body: 'The authorization request sat too long before you signed in. Head back to the app to begin a fresh handshake.',
    hint: 'Return to fomio'
  }
};

/* Scopes shown on the consent form. */
window.AUTH_SCOPES = [{
  name: 'read',
  desc: 'See your bytes, hubs, and reading history'
}, {
  name: 'write',
  desc: 'Post and reply on your behalf'
}, {
  name: 'notifications',
  desc: 'Read and clear your notifications'
}];
})(); } catch (e) { __ds_ns.__errors.push({ path: "auth-flow-data.js", error: String((e && e.message) || e) }); }

// auth-flow-diagram.jsx
try { (() => {
/* Fomio auth flow — the sequence diagram.
   Three lifelines (app · browser · Discourse) with a message per step.
   Active message is terracotta with a travelling packet; done messages are
   inked; upcoming ones are faint and dashed. */
window.AF = window.AF || {};
(function () {
  const ACTORS = window.AUTH_ACTORS;
  const I = window.AF.Icons;
  const W = 520,
    HEAD = 8,
    ROW = 62,
    PADX = 16;
  const LANE_X = {
    app: 78,
    web: 260,
    disc: 442
  };
  const R = 6; // arrowhead

  function Arrowhead({
    x,
    y,
    dir,
    color
  }) {
    // dir: 1 => pointing right (head at x), -1 => pointing left
    const d = dir * R;
    return /*#__PURE__*/React.createElement("path", {
      d: `M ${x} ${y} L ${x - d} ${y - R} L ${x - d} ${y + R} Z`,
      fill: color
    });
  }
  window.AF.Diagram = function Diagram({
    steps,
    current,
    errorAtStep
  }) {
    const bodyH = steps.length * ROW + 14;
    return /*#__PURE__*/React.createElement("div", {
      style: {
        width: W,
        userSelect: 'none'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        position: 'relative',
        height: 62,
        marginBottom: HEAD
      }
    }, ACTORS.map(a => {
      const active = steps[current] && (steps[current].from === a.id || steps[current].to === a.id);
      return /*#__PURE__*/React.createElement("div", {
        key: a.id,
        style: {
          position: 'absolute',
          left: LANE_X[a.id],
          transform: 'translateX(-50%)',
          width: 150,
          textAlign: 'center'
        }
      }, /*#__PURE__*/React.createElement("div", {
        style: {
          display: 'inline-flex',
          flexDirection: 'column',
          alignItems: 'center',
          gap: 3,
          padding: '9px 14px',
          borderRadius: 14,
          background: active ? 'var(--fomio-primary)' : 'var(--fomio-card)',
          border: '1px solid ' + (active ? 'var(--fomio-primary)' : 'var(--fomio-border)'),
          transition: 'background 200ms var(--fomio-ease), border-color 200ms',
          minWidth: 128
        }
      }, /*#__PURE__*/React.createElement("span", {
        style: {
          fontFamily: 'var(--fomio-sans)',
          fontWeight: 700,
          fontSize: 13,
          color: active ? '#fff' : 'var(--fomio-fg)'
        }
      }, a.label), /*#__PURE__*/React.createElement("span", {
        style: {
          fontFamily: 'var(--fomio-mono)',
          fontSize: 9.5,
          color: active ? 'rgba(255,255,255,0.82)' : 'var(--fomio-fg-muted)',
          letterSpacing: '0.01em'
        }
      }, a.sub)));
    })), /*#__PURE__*/React.createElement("svg", {
      width: W,
      height: bodyH,
      style: {
        display: 'block',
        overflow: 'visible'
      }
    }, ACTORS.map(a => {
      const active = steps[current] && (steps[current].from === a.id || steps[current].to === a.id);
      return /*#__PURE__*/React.createElement("line", {
        key: a.id,
        x1: LANE_X[a.id],
        y1: 0,
        x2: LANE_X[a.id],
        y2: bodyH,
        stroke: active ? 'var(--fomio-primary)' : 'var(--fomio-border)',
        strokeWidth: active ? 1.5 : 1,
        strokeDasharray: "2 5",
        style: {
          transition: 'stroke 200ms'
        },
        opacity: active ? 0.55 : 1
      });
    }), steps.map((s, i) => {
      const y = 18 + i * ROW;
      const state = i < current ? 'done' : i === current ? 'active' : 'future';
      const isErr = errorAtStep === i;
      const color = isErr && state === 'active' ? 'var(--fomio-danger)' : state === 'active' ? 'var(--fomio-primary)' : state === 'done' ? 'var(--fomio-fg-secondary)' : 'var(--fomio-border)';
      const txtColor = state === 'future' ? 'var(--fomio-fg-muted)' : state === 'active' ? 'var(--fomio-fg)' : 'var(--fomio-fg-secondary)';
      const sw = state === 'active' ? 2.2 : 1.4;
      const fromX = LANE_X[s.from],
        toX = LANE_X[s.to];
      const self = s.from === s.to;
      let line, head, label;
      const opacity = state === 'future' ? 0.5 : 1;
      if (self) {
        const lx = fromX;
        const loopH = 20;
        const ld = s.from === 'disc' ? -1 : 1; // mirror the rightmost lane so the label stays on-canvas
        const loopW = 34 * ld;
        line = /*#__PURE__*/React.createElement("path", {
          d: `M ${lx} ${y - loopH / 2} h ${loopW} a 6 6 0 0 1 ${6 * ld} 6 v ${loopH - 12} a 6 6 0 0 1 ${-6 * ld} 6 h ${-loopW}`,
          fill: "none",
          stroke: color,
          strokeWidth: sw,
          strokeDasharray: state === 'future' ? '4 4' : 'none',
          style: {
            transition: 'stroke 200ms'
          }
        });
        head = /*#__PURE__*/React.createElement(Arrowhead, {
          x: lx,
          y: y + loopH / 2,
          dir: -ld,
          color: color
        });
        label = {
          x: lx + loopW + 16 * ld,
          anchor: ld === 1 ? 'start' : 'end',
          y
        };
      } else {
        const dir = toX > fromX ? 1 : -1;
        const x2 = toX - dir * (R + 1);
        line = /*#__PURE__*/React.createElement("line", {
          x1: fromX,
          y1: y,
          x2: x2,
          y2: y,
          stroke: color,
          strokeWidth: sw,
          strokeDasharray: state === 'future' ? '4 4' : 'none',
          style: {
            transition: 'stroke 200ms'
          }
        });
        head = /*#__PURE__*/React.createElement(Arrowhead, {
          x: toX,
          y: y,
          dir: dir,
          color: color
        });
        label = {
          x: (fromX + toX) / 2,
          anchor: 'middle',
          y
        };
      }
      return /*#__PURE__*/React.createElement("g", {
        key: s.id,
        opacity: opacity,
        style: {
          transition: 'opacity 200ms'
        }
      }, /*#__PURE__*/React.createElement("circle", {
        cx: PADX + 2,
        cy: y,
        r: 9,
        fill: state === 'active' ? color : 'var(--fomio-card)',
        stroke: state === 'future' ? 'var(--fomio-border)' : color,
        strokeWidth: "1.4"
      }), /*#__PURE__*/React.createElement("text", {
        x: PADX + 2,
        y: y + 3.5,
        textAnchor: "middle",
        fontFamily: "var(--fomio-mono)",
        fontSize: "10",
        fill: state === 'active' ? '#fff' : state === 'done' ? 'var(--fomio-fg-secondary)' : 'var(--fomio-fg-muted)'
      }, i + 1), line, head, state === 'active' && !self && /*#__PURE__*/React.createElement("circle", {
        r: "4",
        fill: color
      }, /*#__PURE__*/React.createElement("animate", {
        attributeName: "cx",
        from: fromX,
        to: toX,
        dur: "1.15s",
        repeatCount: "indefinite"
      }), /*#__PURE__*/React.createElement("animate", {
        attributeName: "opacity",
        values: "0;1;1;0",
        keyTimes: "0;0.15;0.85;1",
        dur: "1.15s",
        repeatCount: "indefinite"
      }), /*#__PURE__*/React.createElement("animate", {
        attributeName: "cy",
        values: `${y};${y}`,
        dur: "1.15s",
        repeatCount: "indefinite"
      })), state === 'active' && self && /*#__PURE__*/React.createElement("circle", {
        cx: s.from === 'disc' ? fromX - 40 : fromX + 40,
        cy: y,
        r: "4",
        fill: color
      }, /*#__PURE__*/React.createElement("animate", {
        attributeName: "opacity",
        values: "0.2;1;0.2",
        dur: "1.1s",
        repeatCount: "indefinite"
      })), /*#__PURE__*/React.createElement("text", {
        x: label.x,
        y: label.y - 9,
        textAnchor: label.anchor,
        fontFamily: "var(--fomio-mono)",
        fontSize: "11",
        fontWeight: "400",
        fill: txtColor,
        style: {
          transition: 'fill 200ms'
        }
      }, s.msg), /*#__PURE__*/React.createElement("text", {
        x: label.x,
        y: label.y + 15,
        textAnchor: label.anchor,
        fontFamily: "var(--fomio-sans)",
        fontSize: "9.5",
        fontWeight: "600",
        letterSpacing: "0.02em",
        fill: "var(--fomio-fg-muted)"
      }, s.note));
    })));
  };
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "auth-flow-diagram.jsx", error: String((e && e.message) || e) }); }

// auth-flow-icons.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* Fomio auth flow — inline SVG icons. Stroke = currentColor, 1.6 weight, calm. */
window.AF = window.AF || {};
const afIcon = (paths, vb = 24) => ({
  size = 20,
  style,
  ...p
}) => /*#__PURE__*/React.createElement("svg", _extends({
  viewBox: `0 0 ${vb} ${vb}`,
  width: size,
  height: size,
  fill: "none",
  stroke: "currentColor",
  strokeWidth: "1.6",
  strokeLinecap: "round",
  strokeLinejoin: "round",
  style: style
}, p), paths);
window.AF.Icons = {
  Lock: afIcon(/*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("rect", {
    x: "5",
    y: "11",
    width: "14",
    height: "9",
    rx: "2.2"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M8 11V8a4 4 0 0 1 8 0v3"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "12",
    cy: "15.4",
    r: "1",
    fill: "currentColor",
    stroke: "none"
  }))),
  Key: afIcon(/*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("circle", {
    cx: "8",
    cy: "8",
    r: "3.4"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M10.4 10.4 20 20M16.5 16.5l2-2M14 14l2.2-2.2"
  }))),
  Globe: afIcon(/*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("circle", {
    cx: "12",
    cy: "12",
    r: "8.2"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M3.8 12h16.4M12 3.8c2.4 2.2 2.4 14 0 16.4M12 3.8c-2.4 2.2-2.4 14 0 16.4"
  }))),
  Shield: afIcon(/*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("path", {
    d: "M12 3.2 5 6v5.2c0 4.3 2.9 7.3 7 9.6 4.1-2.3 7-5.3 7-9.6V6l-7-2.8Z"
  }), /*#__PURE__*/React.createElement("path", {
    d: "m9.2 12 2 2 3.6-3.8"
  }))),
  Check: afIcon(/*#__PURE__*/React.createElement("path", {
    d: "m5 12.5 4.5 4.5L19 6.5"
  })),
  Arrow: afIcon(/*#__PURE__*/React.createElement("path", {
    d: "M4 12h15m-6-6 6 6-6 6"
  })),
  Alert: afIcon(/*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("path", {
    d: "M12 4 2.6 20h18.8L12 4Z"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M12 10v4.4"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "12",
    cy: "17.4",
    r: "0.9",
    fill: "currentColor",
    stroke: "none"
  }))),
  Phone: afIcon(/*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("rect", {
    x: "7",
    y: "3",
    width: "10",
    height: "18",
    rx: "2.4"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M11 18h2"
  }))),
  Fingerprint: afIcon(/*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("path", {
    d: "M6.5 10a6 6 0 0 1 11 0"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M8.5 11.5a3.5 3.5 0 0 1 7 0c0 3-.6 5-1.3 6.4"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M12 11.6v2.2c0 2.2-.5 4-1.2 5.4"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M9.7 19.4c.6-1.2 1-2.6 1-4.2"
  }))),
  Refresh: afIcon(/*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("path", {
    d: "M20 6.5A8 8 0 1 0 21 12"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M20 4v3.5h-3.5"
  }))),
  Spinner: ({
    size = 20,
    style,
    ...p
  }) => /*#__PURE__*/React.createElement("svg", _extends({
    viewBox: "0 0 24 24",
    width: size,
    height: size,
    style: style
  }, p), /*#__PURE__*/React.createElement("circle", {
    cx: "12",
    cy: "12",
    r: "8.4",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2",
    opacity: "0.18"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M12 3.6a8.4 8.4 0 0 1 8.4 8.4",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2",
    strokeLinecap: "round"
  }, /*#__PURE__*/React.createElement("animateTransform", {
    attributeName: "transform",
    type: "rotate",
    from: "0 12 12",
    to: "360 12 12",
    dur: "0.85s",
    repeatCount: "indefinite"
  })))
};
})(); } catch (e) { __ds_ns.__errors.push({ path: "auth-flow-icons.jsx", error: String((e && e.message) || e) }); }

// auth-flow-screens.jsx
try { (() => {
/* Fomio auth flow — the screens shown on the stage.
   Plain screens (no device bezel). App surfaces get a soft status bar;
   web surfaces get a minimal browser address bar. */
window.AF = window.AF || {};
(function () {
  const I = window.AF.Icons;
  const SCOPES = window.AUTH_SCOPES;
  const FW = 300; // screen width
  const FH = 600; // screen height

  // ── shared frame ───────────────────────────────────────────────────
  function Frame({
    surface,
    children,
    tone
  }) {
    const web = surface === 'web';
    return /*#__PURE__*/React.createElement("div", {
      style: {
        width: FW,
        height: FH,
        flex: 'none',
        borderRadius: 26,
        overflow: 'hidden',
        background: 'var(--fomio-bg)',
        border: '1px solid var(--fomio-border)',
        boxShadow: '0 24px 60px -30px var(--fomio-shadow)',
        display: 'flex',
        flexDirection: 'column',
        position: 'relative'
      }
    }, web ? /*#__PURE__*/React.createElement(BrowserBar, null) : /*#__PURE__*/React.createElement(StatusBar, null), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        minHeight: 0,
        display: 'flex',
        flexDirection: 'column',
        position: 'relative'
      }
    }, children));
  }
  function StatusBar() {
    return /*#__PURE__*/React.createElement("div", {
      style: {
        height: 44,
        flex: 'none',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: '0 20px',
        fontFamily: 'var(--fomio-sans)',
        fontSize: 12,
        fontWeight: 600,
        color: 'var(--fomio-fg)',
        letterSpacing: '0.02em'
      }
    }, /*#__PURE__*/React.createElement("span", null, "9:41"), /*#__PURE__*/React.createElement("span", {
      style: {
        display: 'flex',
        gap: 5,
        alignItems: 'center',
        opacity: 0.85
      }
    }, /*#__PURE__*/React.createElement(Bars, null), /*#__PURE__*/React.createElement(Wifi, null), /*#__PURE__*/React.createElement(Batt, null)));
  }
  const Bars = () => /*#__PURE__*/React.createElement("svg", {
    width: "17",
    height: "11",
    viewBox: "0 0 17 11",
    fill: "currentColor"
  }, /*#__PURE__*/React.createElement("rect", {
    x: "0",
    y: "7",
    width: "3",
    height: "4",
    rx: "1"
  }), /*#__PURE__*/React.createElement("rect", {
    x: "4.5",
    y: "5",
    width: "3",
    height: "6",
    rx: "1"
  }), /*#__PURE__*/React.createElement("rect", {
    x: "9",
    y: "2.5",
    width: "3",
    height: "8.5",
    rx: "1"
  }), /*#__PURE__*/React.createElement("rect", {
    x: "13.5",
    y: "0",
    width: "3",
    height: "11",
    rx: "1"
  }));
  const Wifi = () => /*#__PURE__*/React.createElement("svg", {
    width: "16",
    height: "11",
    viewBox: "0 0 16 11",
    fill: "currentColor"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M8 2.2c2.7 0 5.2 1 7 2.8l-1.4 1.4A7.7 7.7 0 0 0 8 4.2 7.7 7.7 0 0 0 2.4 6.4L1 5C2.8 3.2 5.3 2.2 8 2.2Zm0 3.4c1.5 0 2.9.6 3.9 1.6l-1.4 1.4A3.4 3.4 0 0 0 8 7.6c-.9 0-1.8.4-2.5 1L4.1 7.2A5.4 5.4 0 0 1 8 5.6Zm0 3.3 1.6 1.6-1.6 1.5-1.6-1.5L8 8.9Z"
  }));
  const Batt = () => /*#__PURE__*/React.createElement("svg", {
    width: "25",
    height: "12",
    viewBox: "0 0 25 12",
    fill: "none"
  }, /*#__PURE__*/React.createElement("rect", {
    x: "0.6",
    y: "0.6",
    width: "21",
    height: "10.8",
    rx: "2.8",
    stroke: "currentColor",
    opacity: "0.4"
  }), /*#__PURE__*/React.createElement("rect", {
    x: "2.2",
    y: "2.2",
    width: "16",
    height: "7.6",
    rx: "1.6",
    fill: "currentColor"
  }), /*#__PURE__*/React.createElement("rect", {
    x: "23",
    y: "4",
    width: "1.6",
    height: "4",
    rx: "0.8",
    fill: "currentColor",
    opacity: "0.4"
  }));
  function BrowserBar() {
    return /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 'none',
        background: 'var(--fomio-surface)',
        borderBottom: '1px solid var(--fomio-border)'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        height: 34,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: '0 18px',
        fontFamily: 'var(--fomio-sans)',
        fontSize: 11,
        fontWeight: 600,
        color: 'var(--fomio-fg)'
      }
    }, /*#__PURE__*/React.createElement("span", null, "9:41"), /*#__PURE__*/React.createElement("span", {
      style: {
        display: 'flex',
        gap: 5,
        opacity: 0.85
      }
    }, /*#__PURE__*/React.createElement(Bars, null), /*#__PURE__*/React.createElement(Wifi, null), /*#__PURE__*/React.createElement(Batt, null))), /*#__PURE__*/React.createElement("div", {
      style: {
        padding: '0 12px 10px',
        display: 'flex',
        alignItems: 'center',
        gap: 8
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        height: 30,
        borderRadius: 9,
        background: 'var(--fomio-card)',
        border: '1px solid var(--fomio-border)',
        display: 'flex',
        alignItems: 'center',
        gap: 6,
        padding: '0 11px'
      }
    }, /*#__PURE__*/React.createElement(I.Lock, {
      size: 12,
      style: {
        color: 'var(--fomio-fg-muted)'
      }
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--fomio-mono)',
        fontSize: 11,
        color: 'var(--fomio-fg-secondary)'
      }
    }, "meta.fomio.app")), /*#__PURE__*/React.createElement("div", {
      style: {
        width: 26,
        height: 26,
        borderRadius: 8,
        display: 'grid',
        placeItems: 'center',
        color: 'var(--fomio-fg-muted)'
      }
    }, /*#__PURE__*/React.createElement("svg", {
      width: "15",
      height: "15",
      viewBox: "0 0 24 24",
      fill: "none",
      stroke: "currentColor",
      strokeWidth: "1.8",
      strokeLinecap: "round"
    }, /*#__PURE__*/React.createElement("path", {
      d: "M6 6l12 12M18 6 6 18"
    })))));
  }

  // small stacked-content helper
  const Pad = ({
    children,
    style
  }) => /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minHeight: 0,
      display: 'flex',
      flexDirection: 'column',
      padding: '24px 22px',
      ...style
    }
  }, children);
  const Wordmark = ({
    size = 22
  }) => /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--fomio-serif)',
      fontWeight: 700,
      fontSize: size,
      letterSpacing: '-0.02em',
      color: 'var(--fomio-fg)'
    }
  }, "fomio", /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--fomio-primary)'
    }
  }, "."));
  const Pill = ({
    children,
    primary,
    ghost,
    onClick
  }) => /*#__PURE__*/React.createElement("button", {
    onClick: onClick,
    style: {
      height: 48,
      borderRadius: 9999,
      border: primary ? 'none' : '1px solid var(--fomio-border)',
      background: primary ? 'var(--fomio-primary)' : ghost ? 'transparent' : 'var(--fomio-card)',
      color: primary ? '#fff' : 'var(--fomio-fg)',
      fontFamily: 'var(--fomio-sans)',
      fontWeight: 700,
      fontSize: 14,
      letterSpacing: '0.02em',
      cursor: 'pointer',
      width: '100%',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 8
    }
  }, children);

  // ── individual screens ─────────────────────────────────────────────
  function Landing() {
    return /*#__PURE__*/React.createElement(Pad, null, /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'center',
        gap: 22
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        width: 60,
        height: 60,
        borderRadius: 18,
        background: 'var(--fomio-primary)',
        display: 'grid',
        placeItems: 'center',
        color: '#fff'
      }
    }, /*#__PURE__*/React.createElement(I.Key, {
      size: 28
    })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      className: "fomio-display",
      style: {
        fontSize: 30,
        lineHeight: '38px'
      }
    }, "Connect your", /*#__PURE__*/React.createElement("br", null), "account"), /*#__PURE__*/React.createElement("p", {
      style: {
        fontFamily: 'var(--fomio-serif)',
        fontSize: 15,
        lineHeight: '24px',
        color: 'var(--fomio-fg-secondary)',
        marginTop: 12
      }
    }, "Sign in through your Discourse site. fomio never sees your password \u2014 only a token you can revoke anytime."))), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        flexDirection: 'column',
        gap: 10
      }
    }, /*#__PURE__*/React.createElement(Pill, {
      primary: true
    }, /*#__PURE__*/React.createElement(I.Lock, {
      size: 17
    }), "Connect securely"), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        gap: 7,
        color: 'var(--fomio-fg-muted)',
        fontFamily: 'var(--fomio-sans)',
        fontSize: 11.5,
        fontWeight: 600
      }
    }, /*#__PURE__*/React.createElement(I.Shield, {
      size: 14
    }), "End-to-end encrypted handshake")));
  }
  function Waiting() {
    return /*#__PURE__*/React.createElement(Pad, {
      style: {
        alignItems: 'center',
        textAlign: 'center',
        justifyContent: 'center',
        gap: 26
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        position: 'relative',
        width: 96,
        height: 96,
        display: 'grid',
        placeItems: 'center'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        position: 'absolute',
        inset: 0,
        borderRadius: 9999,
        border: '1px solid var(--fomio-border)'
      }
    }), /*#__PURE__*/React.createElement(I.Spinner, {
      size: 96,
      style: {
        position: 'absolute',
        inset: 0,
        color: 'var(--fomio-primary)'
      }
    }), /*#__PURE__*/React.createElement(I.Globe, {
      size: 36,
      style: {
        color: 'var(--fomio-fg)'
      }
    })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      className: "fomio-title",
      style: {
        fontSize: 22
      }
    }, "Opening secure browser"), /*#__PURE__*/React.createElement("p", {
      style: {
        fontFamily: 'var(--fomio-serif)',
        fontSize: 14.5,
        lineHeight: '23px',
        color: 'var(--fomio-fg-secondary)',
        marginTop: 8,
        maxWidth: 230
      }
    }, "Finish signing in on the Discourse page. We\u2019ll bring you right back.")), /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--fomio-mono)',
        fontSize: 10.5,
        color: 'var(--fomio-fg-muted)',
        letterSpacing: '0.02em'
      }
    }, "keypair ready \xB7 awaiting redirect"));
  }
  function Login({
    busy
  }) {
    return /*#__PURE__*/React.createElement(Pad, {
      style: {
        gap: 18
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        flexDirection: 'column',
        gap: 4
      }
    }, /*#__PURE__*/React.createElement(Wordmark, {
      size: 20
    }), /*#__PURE__*/React.createElement("div", {
      className: "fomio-caption",
      style: {
        fontSize: 12
      }
    }, "Sign in to continue")), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        flexDirection: 'column',
        gap: 12,
        marginTop: 4
      }
    }, /*#__PURE__*/React.createElement(Field, {
      label: "Username or email",
      value: "alice_smith"
    }), /*#__PURE__*/React.createElement(Field, {
      label: "Password",
      value: "\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022",
      mono: true
    })), /*#__PURE__*/React.createElement("button", {
      style: {
        height: 46,
        borderRadius: 9999,
        border: 'none',
        background: busy ? 'var(--fomio-primary-dark)' : 'var(--fomio-primary)',
        color: '#fff',
        fontFamily: 'var(--fomio-sans)',
        fontWeight: 700,
        fontSize: 14,
        cursor: 'pointer',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        gap: 8,
        marginTop: 2
      }
    }, busy ? /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(I.Spinner, {
      size: 16
    }), "Verifying\u2026") : 'Log in'), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 8,
        color: 'var(--fomio-fg-muted)',
        fontFamily: 'var(--fomio-sans)',
        fontSize: 11.5,
        fontWeight: 600,
        marginTop: 2
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        height: 1,
        background: 'var(--fomio-border)'
      }
    }), /*#__PURE__*/React.createElement("span", null, "or"), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        height: 1,
        background: 'var(--fomio-border)'
      }
    })), /*#__PURE__*/React.createElement("button", {
      style: {
        height: 44,
        borderRadius: 9999,
        border: '1px solid var(--fomio-border)',
        background: 'var(--fomio-card)',
        color: 'var(--fomio-fg)',
        fontFamily: 'var(--fomio-sans)',
        fontWeight: 600,
        fontSize: 13,
        cursor: 'pointer',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        gap: 8
      }
    }, /*#__PURE__*/React.createElement(I.Fingerprint, {
      size: 17,
      style: {
        color: 'var(--fomio-primary)'
      }
    }), "Email me a login link"), busy && /*#__PURE__*/React.createElement("div", {
      style: {
        marginTop: 'auto',
        display: 'flex',
        alignItems: 'center',
        gap: 8,
        color: 'var(--fomio-success)',
        fontFamily: 'var(--fomio-sans)',
        fontSize: 12,
        fontWeight: 700
      }
    }, /*#__PURE__*/React.createElement(I.Check, {
      size: 16
    }), "Session established"));
  }
  const Field = ({
    label,
    value,
    mono
  }) => /*#__PURE__*/React.createElement("label", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 6
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "fomio-label",
    style: {
      fontSize: 10
    }
  }, label), /*#__PURE__*/React.createElement("div", {
    style: {
      height: 44,
      borderRadius: 12,
      border: '1px solid var(--fomio-border)',
      background: 'var(--fomio-card)',
      display: 'flex',
      alignItems: 'center',
      padding: '0 13px',
      fontFamily: mono ? 'var(--fomio-mono)' : 'var(--fomio-sans)',
      fontSize: 13.5,
      color: 'var(--fomio-fg)'
    }
  }, value));
  function Consent({
    busy
  }) {
    return /*#__PURE__*/React.createElement(Pad, {
      style: {
        gap: 16
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 11
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        width: 40,
        height: 40,
        borderRadius: 12,
        background: 'var(--fomio-primary)',
        display: 'grid',
        placeItems: 'center',
        color: '#fff',
        flex: 'none'
      }
    }, /*#__PURE__*/React.createElement(I.Key, {
      size: 20
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        minWidth: 0
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--fomio-serif)',
        fontWeight: 700,
        fontSize: 17,
        color: 'var(--fomio-fg)'
      }
    }, "Authorize fomio"), /*#__PURE__*/React.createElement("div", {
      className: "fomio-caption",
      style: {
        fontSize: 11.5
      }
    }, "wants access to your account"))), /*#__PURE__*/React.createElement("div", {
      style: {
        height: 1,
        background: 'var(--fomio-border)'
      }
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        flexDirection: 'column',
        gap: 12
      }
    }, SCOPES.map(s => /*#__PURE__*/React.createElement("div", {
      key: s.name,
      style: {
        display: 'flex',
        gap: 11
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        width: 22,
        height: 22,
        borderRadius: 7,
        background: 'var(--fomio-primary-soft)',
        color: 'var(--fomio-primary-dark)',
        display: 'grid',
        placeItems: 'center',
        flex: 'none',
        marginTop: 1
      }
    }, /*#__PURE__*/React.createElement(I.Check, {
      size: 14
    })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--fomio-mono)',
        fontSize: 12.5,
        color: 'var(--fomio-fg)',
        fontWeight: 400
      }
    }, s.name), /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--fomio-serif)',
        fontSize: 13,
        lineHeight: '18px',
        color: 'var(--fomio-fg-secondary)',
        marginTop: 2
      }
    }, s.desc))))), /*#__PURE__*/React.createElement("div", {
      style: {
        marginTop: 'auto',
        display: 'flex',
        flexDirection: 'column',
        gap: 9
      }
    }, /*#__PURE__*/React.createElement("button", {
      style: {
        height: 48,
        borderRadius: 9999,
        border: 'none',
        background: 'var(--fomio-primary)',
        color: '#fff',
        fontFamily: 'var(--fomio-sans)',
        fontWeight: 700,
        fontSize: 14,
        cursor: 'pointer',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        gap: 8
      }
    }, busy ? /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(I.Spinner, {
      size: 16
    }), "Issuing token\u2026") : /*#__PURE__*/React.createElement(React.Fragment, null, "Authorize")), /*#__PURE__*/React.createElement("button", {
      style: {
        height: 42,
        borderRadius: 9999,
        border: 'none',
        background: 'transparent',
        color: 'var(--fomio-fg-muted)',
        fontFamily: 'var(--fomio-sans)',
        fontWeight: 600,
        fontSize: 13,
        cursor: 'pointer'
      }
    }, "Deny")));
  }
  function Returning() {
    return /*#__PURE__*/React.createElement(Pad, {
      style: {
        alignItems: 'center',
        textAlign: 'center',
        justifyContent: 'center',
        gap: 24
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        position: 'relative',
        width: 90,
        height: 90,
        display: 'grid',
        placeItems: 'center'
      }
    }, /*#__PURE__*/React.createElement(I.Spinner, {
      size: 90,
      style: {
        position: 'absolute',
        inset: 0,
        color: 'var(--fomio-primary)'
      }
    }), /*#__PURE__*/React.createElement(I.Shield, {
      size: 34,
      style: {
        color: 'var(--fomio-fg)'
      }
    })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      className: "fomio-title",
      style: {
        fontSize: 21
      }
    }, "Returning to fomio"), /*#__PURE__*/React.createElement("p", {
      style: {
        fontFamily: 'var(--fomio-serif)',
        fontSize: 14.5,
        lineHeight: '23px',
        color: 'var(--fomio-fg-secondary)',
        marginTop: 8,
        maxWidth: 220
      }
    }, "Unsealing the token and checking it\u2019s really yours.")), /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--fomio-mono)',
        fontSize: 10.5,
        color: 'var(--fomio-fg-muted)'
      }
    }, "decrypting \xB7 verifying nonce"));
  }
  function Success() {
    return /*#__PURE__*/React.createElement(Pad, {
      style: {
        alignItems: 'center',
        textAlign: 'center',
        justifyContent: 'center',
        gap: 24
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        width: 88,
        height: 88,
        borderRadius: 9999,
        background: 'var(--fomio-primary)',
        display: 'grid',
        placeItems: 'center',
        color: '#fff'
      }
    }, /*#__PURE__*/React.createElement(I.Check, {
      size: 44
    })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      className: "fomio-display",
      style: {
        fontSize: 28
      }
    }, "You\u2019re connected"), /*#__PURE__*/React.createElement("p", {
      style: {
        fontFamily: 'var(--fomio-serif)',
        fontSize: 15,
        lineHeight: '24px',
        color: 'var(--fomio-fg-secondary)',
        marginTop: 10,
        maxWidth: 230
      }
    }, "fomio is linked to your account with a token stored safely on this device.")), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 8,
        padding: '9px 14px',
        borderRadius: 9999,
        background: 'var(--fomio-surface)',
        border: '1px solid var(--fomio-border)',
        color: 'var(--fomio-fg-secondary)',
        fontFamily: 'var(--fomio-sans)',
        fontSize: 11.5,
        fontWeight: 600
      }
    }, /*#__PURE__*/React.createElement(I.Shield, {
      size: 14,
      style: {
        color: 'var(--fomio-primary)'
      }
    }), "Revoke anytime in settings"), /*#__PURE__*/React.createElement("div", {
      style: {
        marginTop: 4,
        width: '100%'
      }
    }, /*#__PURE__*/React.createElement(Pill, {
      primary: true
    }, "Start reading", /*#__PURE__*/React.createElement(I.Arrow, {
      size: 17
    }))));
  }
  function ErrorScreen({
    err
  }) {
    return /*#__PURE__*/React.createElement(Pad, {
      style: {
        alignItems: 'center',
        textAlign: 'center',
        justifyContent: 'center',
        gap: 22
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        width: 84,
        height: 84,
        borderRadius: 9999,
        background: 'var(--fomio-card)',
        border: '1px solid var(--fomio-danger)',
        display: 'grid',
        placeItems: 'center',
        color: 'var(--fomio-danger)'
      }
    }, /*#__PURE__*/React.createElement(I.Alert, {
      size: 38
    })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      className: "fomio-label",
      style: {
        color: 'var(--fomio-danger)',
        fontSize: 10.5
      }
    }, err.kicker), /*#__PURE__*/React.createElement("div", {
      className: "fomio-title",
      style: {
        fontSize: 22,
        marginTop: 8
      }
    }, err.title), /*#__PURE__*/React.createElement("p", {
      style: {
        fontFamily: 'var(--fomio-serif)',
        fontSize: 14.5,
        lineHeight: '23px',
        color: 'var(--fomio-fg-secondary)',
        marginTop: 10,
        maxWidth: 236
      }
    }, err.body)), /*#__PURE__*/React.createElement("div", {
      style: {
        marginTop: 4,
        width: '100%'
      }
    }, /*#__PURE__*/React.createElement(Pill, null, /*#__PURE__*/React.createElement(I.Refresh, {
      size: 16
    }), err.hint)));
  }
  const SCREENS = {
    landing: Landing,
    waiting: Waiting,
    login: Login,
    consent: Consent,
    returning: Returning,
    success: Success
  };
  window.AF.Stage = function Stage({
    step,
    error
  }) {
    if (error) {
      return /*#__PURE__*/React.createElement(Frame, {
        surface: error.surface
      }, /*#__PURE__*/React.createElement(ErrorScreen, {
        err: error
      }));
    }
    const Screen = SCREENS[step.screen] || Landing;
    return /*#__PURE__*/React.createElement(Frame, {
      surface: step.surface
    }, /*#__PURE__*/React.createElement(Screen, {
      busy: step.busy
    }));
  };
  window.AF.FW = FW;
  window.AF.FH = FH;
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "auth-flow-screens.jsx", error: String((e && e.message) || e) }); }

// composer-preview.jsx
try { (() => {
/* Fomio Composer — design-system preview page.
   Mounts ComposerScreen from the compiled bundle with mode / viewport / theme controls. */

const {
  useState,
  useEffect
} = React;
const ComposerScreen = window.ComposerScreen;
const previewStyles = document.createElement('style');
previewStyles.textContent = `
/* ── Control bar ── */
.pv-bar {
  flex-shrink: 0; height: 52px;
  display: flex; align-items: center; gap: 20px;
  padding: 0 24px;
  background: color-mix(in oklab, var(--fomio-bg) 88%, transparent);
  backdrop-filter: blur(14px); -webkit-backdrop-filter: blur(14px);
  border-bottom: 1px solid var(--fomio-border);
  z-index: 10;
}
.pv-title { font-size: 12px; font-weight: 700; letter-spacing: 0.06em; text-transform: uppercase; color: var(--fomio-fg-muted); }
.pv-spacer { flex: 1; }
.pv-seg { display: inline-flex; background: var(--fomio-surface); border: 1px solid var(--fomio-border); border-radius: var(--fomio-radius-pill); padding: 3px; gap: 2px; }
.pv-seg button {
  border: none; background: transparent; cursor: pointer;
  font-family: var(--fomio-sans); font-size: 11px; font-weight: 600;
  letter-spacing: 0.05em; text-transform: uppercase;
  padding: 5px 12px; border-radius: var(--fomio-radius-pill);
  color: var(--fomio-fg-muted);
  transition: all var(--fomio-dur-fast) var(--fomio-ease);
}
.pv-seg button:hover { color: var(--fomio-fg); }
.pv-seg button.active { background: var(--fomio-card); color: var(--fomio-fg); box-shadow: 0 1px 3px rgba(0,0,0,0.09); }

/* ── Stage ── */
.pv-stage { flex: 1; min-height: 0; display: flex; align-items: stretch; justify-content: center; overflow: hidden; }
.pv-frame { position: relative; width: 100%; height: 100%; overflow: hidden; background: var(--fomio-bg); display: flex; flex-direction: column; }
.pv-frame.viewport-mobile {
  align-self: center;
  width: 390px; height: 780px; max-height: calc(100% - 48px);
  border: 1px solid var(--fomio-border);
  border-radius: 28px;
  box-shadow: 0 24px 60px -24px var(--fomio-shadow);
}
.pv-frame .cm-main { flex: 1; min-height: 0; overflow-y: auto; }
`;
document.head.appendChild(previewStyles);
const MODES = [{
  id: 'create',
  label: 'Create'
}, {
  id: 'reply',
  label: 'Reply'
}, {
  id: 'edit',
  label: 'Edit'
}];
const THEMES = [{
  id: 'light',
  label: 'Light'
}, {
  id: 'dark',
  label: 'Dark'
}];
const VIEWPORTS = [{
  id: 'desktop',
  label: 'Desktop'
}, {
  id: 'mobile',
  label: 'Mobile'
}];
const Seg = ({
  options,
  value,
  onChange
}) => /*#__PURE__*/React.createElement("div", {
  className: "pv-seg"
}, options.map(o => /*#__PURE__*/React.createElement("button", {
  key: o.id,
  className: o.id === value ? 'active' : '',
  onClick: () => onChange(o.id)
}, o.label)));
const App = () => {
  const persisted = (() => {
    try {
      return JSON.parse(localStorage.getItem('fomio-composer-preview') || '{}');
    } catch {
      return {};
    }
  })();
  const [mode, setMode] = useState(persisted.mode || 'create');
  const [theme, setTheme] = useState(persisted.theme || 'light');
  const [viewport, setViewport] = useState(persisted.viewport || 'desktop');
  useEffect(() => {
    document.documentElement.dataset.theme = theme;
    localStorage.setItem('fomio-composer-preview', JSON.stringify({
      mode,
      theme,
      viewport
    }));
  }, [mode, theme, viewport]);
  const opts = {
    titleFilled: true,
    bodyFilled: true,
    quoteReply: true,
    editorState: 'idle'
  };
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    className: "pv-bar"
  }, /*#__PURE__*/React.createElement("span", {
    className: "pv-title"
  }, "Composer"), /*#__PURE__*/React.createElement("div", {
    className: "pv-spacer"
  }), /*#__PURE__*/React.createElement(Seg, {
    options: MODES,
    value: mode,
    onChange: setMode
  }), /*#__PURE__*/React.createElement(Seg, {
    options: VIEWPORTS,
    value: viewport,
    onChange: setViewport
  }), /*#__PURE__*/React.createElement(Seg, {
    options: THEMES,
    value: theme,
    onChange: setTheme
  })), /*#__PURE__*/React.createElement("div", {
    className: "pv-stage"
  }, /*#__PURE__*/React.createElement("div", {
    className: 'pv-frame cm-shell viewport-' + viewport,
    "data-screen-label": 'Composer — ' + mode
  }, /*#__PURE__*/React.createElement(ComposerScreen, {
    key: mode + viewport,
    mode: mode,
    theme: theme,
    opts: opts,
    viewport: viewport
  }))));
};
ReactDOM.createRoot(document.getElementById('root')).render(/*#__PURE__*/React.createElement(App, null));
})(); } catch (e) { __ds_ns.__errors.push({ path: "composer-preview.jsx", error: String((e && e.message) || e) }); }

// composer.jsx
try { (() => {
/* Fomio Composer — three modes (create / reply / edit)
   Revised per design audit: block-editor fiction removed; surface reflects
   only what a Discourse theme can actually own. ProseMirror is rendered as a
   single bare editor surface; toolbars trimmed to wired marks (Bold/Italic/Link). */

const CmGlyph = ({
  d,
  size = 16
}) => /*#__PURE__*/React.createElement("svg", {
  viewBox: "0 0 24 24",
  width: size,
  height: size,
  fill: "none",
  stroke: "currentColor",
  strokeWidth: "1.75",
  strokeLinecap: "round",
  strokeLinejoin: "round"
}, Array.isArray(d) ? d.map((p, i) => /*#__PURE__*/React.createElement("path", {
  key: i,
  d: p
})) : /*#__PURE__*/React.createElement("path", {
  d: d
}));
const ICON = {
  bold: "M7 4h6a4 4 0 010 8H7zM7 12h7a4 4 0 010 8H7z",
  italic: "M11 4h8M5 20h8M14 4l-4 16",
  link: "M10 14a4 4 0 015.66 0l3 3a4 4 0 01-5.66 5.66l-1.5-1.5M14 10a4 4 0 01-5.66 0l-3-3a4 4 0 015.66-5.66L12.5 2.83",
  image: "M3 5h18v14H3zM3 16l5-5 4 4 3-3 6 6",
  back: "M15 18l-6-6 6-6",
  close: "M6 6l12 12M18 6L6 18",
  chev: "M6 9l6 6 6-6",
  check: "M5 12l4 4L19 7",
  edit: "M4 20h4l11-11-4-4L4 16zM14 5l4 4",
  arrow: "M5 12h14M13 5l7 7-7 7",
  quote: "M6 15a3 3 0 003-3V7H4v5h3a1 1 0 01-1 1zM17 15a3 3 0 003-3V7h-5v5h3a1 1 0 01-1 1z",
  list: ["M8 6h13M8 12h13M8 18h13", "M3 6h.01M3 12h.01M3 18h.01"],
  shift: "M12 5l7 7h-4v6H9v-6H5z",
  del: ["M20 6H9l-5 6 5 6h11a1 1 0 001-1V7a1 1 0 00-1-1z", "M17 9l-4 6M13 9l4 6"]
};

/* ──────────────────────────────────────────────────────────
   Touch keyboard dock — tablet + mobile.
   Formatting accessory bar (the wired marks + quote/list/image)
   pinned directly above a mock on-screen keyboard, with the
   primary submit action anchored at the toolbar's right edge.
   ────────────────────────────────────────────────────────── */
const KB_ROWS = [['q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p'], ['a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l'], ['z', 'x', 'c', 'v', 'b', 'n', 'm']];
const KeyboardDock = ({
  action
}) => /*#__PURE__*/React.createElement("div", {
  className: "cm-kbd"
}, /*#__PURE__*/React.createElement("div", {
  className: "cm-kbd-bar"
}, /*#__PURE__*/React.createElement("div", {
  className: "cm-kbd-tools"
}, /*#__PURE__*/React.createElement("span", {
  className: "kbd-tool active",
  title: "Bold \u2318B"
}, /*#__PURE__*/React.createElement(CmGlyph, {
  d: ICON.bold,
  size: 17
})), /*#__PURE__*/React.createElement("span", {
  className: "kbd-tool",
  title: "Italic \u2318I"
}, /*#__PURE__*/React.createElement(CmGlyph, {
  d: ICON.italic,
  size: 17
})), /*#__PURE__*/React.createElement("span", {
  className: "kbd-tool",
  title: "Link \u2318K"
}, /*#__PURE__*/React.createElement(CmGlyph, {
  d: ICON.link,
  size: 17
})), /*#__PURE__*/React.createElement("span", {
  className: "kbd-tool-div"
}), /*#__PURE__*/React.createElement("span", {
  className: "kbd-tool",
  title: "Quote"
}, /*#__PURE__*/React.createElement(CmGlyph, {
  d: ICON.quote,
  size: 17
})), /*#__PURE__*/React.createElement("span", {
  className: "kbd-tool",
  title: "List"
}, /*#__PURE__*/React.createElement(CmGlyph, {
  d: ICON.list,
  size: 17
})), /*#__PURE__*/React.createElement("span", {
  className: "kbd-tool",
  title: "Insert image"
}, /*#__PURE__*/React.createElement(CmGlyph, {
  d: ICON.image,
  size: 17
}))), /*#__PURE__*/React.createElement("button", {
  className: "cm-btn cm-btn-primary cm-kbd-send"
}, action, /*#__PURE__*/React.createElement(CmGlyph, {
  d: ICON.arrow,
  size: 13
}))), /*#__PURE__*/React.createElement("div", {
  className: "cm-kbd-keys"
}, KB_ROWS.map((row, i) => /*#__PURE__*/React.createElement("div", {
  className: "kbd-row kr" + i,
  key: i
}, i === 2 && /*#__PURE__*/React.createElement("span", {
  className: "kbd-key kbd-mod"
}, /*#__PURE__*/React.createElement(CmGlyph, {
  d: ICON.shift,
  size: 16
})), row.map(k => /*#__PURE__*/React.createElement("span", {
  className: "kbd-key",
  key: k
}, k)), i === 2 && /*#__PURE__*/React.createElement("span", {
  className: "kbd-key kbd-mod"
}, /*#__PURE__*/React.createElement(CmGlyph, {
  d: ICON.del,
  size: 16
})))), /*#__PURE__*/React.createElement("div", {
  className: "kbd-row kr3"
}, /*#__PURE__*/React.createElement("span", {
  className: "kbd-key kbd-mod kbd-alt"
}, "123"), /*#__PURE__*/React.createElement("span", {
  className: "kbd-key kbd-space"
}, "space"), /*#__PURE__*/React.createElement("span", {
  className: "kbd-key kbd-return"
}, "return"))));

/* ──────────────────────────────────────────────────────────
   Topbar — back + mode label, single close affordance on the right.
   (Source-view / edit-history / help icons removed: not theme-accessible.)
   ────────────────────────────────────────────────────────── */
const Topbar = ({
  mode
}) => {
  const label = mode === 'create' ? 'Create byte' : mode === 'reply' ? 'Replying to byte' : 'Editing byte';
  return /*#__PURE__*/React.createElement("div", {
    className: "cm-topbar"
  }, /*#__PURE__*/React.createElement("div", {
    className: "back"
  }, /*#__PURE__*/React.createElement(CmGlyph, {
    d: ICON.back,
    size: 14
  }), /*#__PURE__*/React.createElement("span", null, mode === 'create' ? 'Letters' : 'Back')), /*#__PURE__*/React.createElement("div", {
    className: "mode"
  }, "Mode \xB7 ", /*#__PURE__*/React.createElement("b", null, label)), /*#__PURE__*/React.createElement("div", {
    className: "right"
  }, /*#__PURE__*/React.createElement("div", {
    className: "icon-btn",
    title: "Close"
  }, /*#__PURE__*/React.createElement(CmGlyph, {
    d: ICON.close,
    size: 16
  }))));
};

/* ──────────────────────────────────────────────────────────
   Floating selection toolbar — Bold / Italic / Link only.
   These are the marks wired in the ProseMirror extension today.
   ────────────────────────────────────────────────────────── */
const SelectionPop = ({
  style
}) => /*#__PURE__*/React.createElement("div", {
  className: "cm-pop",
  style: style
}, /*#__PURE__*/React.createElement("span", {
  className: "pop-tool active",
  title: "Bold \u2318B"
}, /*#__PURE__*/React.createElement(CmGlyph, {
  d: ICON.bold,
  size: 12
})), /*#__PURE__*/React.createElement("span", {
  className: "pop-tool",
  title: "Italic \u2318I"
}, /*#__PURE__*/React.createElement(CmGlyph, {
  d: ICON.italic,
  size: 12
})), /*#__PURE__*/React.createElement("span", {
  className: "pop-divider"
}), /*#__PURE__*/React.createElement("span", {
  className: "pop-tool",
  title: "Link \u2318K"
}, /*#__PURE__*/React.createElement(CmGlyph, {
  d: ICON.link,
  size: 12
})));

/* ──────────────────────────────────────────────────────────
   Right rail — shared by create + edit.
   Word count + read time + progress, outline (doc headings), checks.
   All readable from the ProseMirror doc + outlet args.
   ────────────────────────────────────────────────────────── */
const ComposerRail = () => /*#__PURE__*/React.createElement("aside", {
  className: "cm-rail"
}, /*#__PURE__*/React.createElement("div", {
  className: "cm-rail-section"
}, /*#__PURE__*/React.createElement("h4", null, "Draft"), /*#__PURE__*/React.createElement("div", {
  className: "cm-rail-meter"
}, /*#__PURE__*/React.createElement("div", {
  className: "cm-rail-stat"
}, /*#__PURE__*/React.createElement("b", null, "312"), /*#__PURE__*/React.createElement("span", null, "words")), /*#__PURE__*/React.createElement("div", {
  className: "cm-rail-stat"
}, /*#__PURE__*/React.createElement("b", null, "2 min"), /*#__PURE__*/React.createElement("span", null, "read")), /*#__PURE__*/React.createElement("div", {
  className: "cm-rail-bar"
}, /*#__PURE__*/React.createElement("div", {
  className: "cm-rail-bar-fill",
  style: {
    width: '38%'
  }
})), /*#__PURE__*/React.createElement("div", {
  style: {
    fontSize: 11,
    color: 'var(--fomio-fg-muted)',
    fontFamily: 'var(--fomio-sans)'
  }
}, "recommended 600\u20131200"))), /*#__PURE__*/React.createElement("div", {
  className: "cm-rail-section"
}, /*#__PURE__*/React.createElement("h4", null, "Outline"), /*#__PURE__*/React.createElement("div", {
  className: "cm-rail-outline"
}, /*#__PURE__*/React.createElement("span", {
  className: "cm-rail-out h2 cur"
}, "Three small rituals"), /*#__PURE__*/React.createElement("span", {
  className: "cm-rail-out h3"
}, "A notebook"), /*#__PURE__*/React.createElement("span", {
  className: "cm-rail-out h3"
}, "Reading aloud"), /*#__PURE__*/React.createElement("span", {
  className: "cm-rail-out h3"
}, "Closing the tab"))), /*#__PURE__*/React.createElement("div", {
  className: "cm-rail-section"
}, /*#__PURE__*/React.createElement("h4", null, "Checks"), /*#__PURE__*/React.createElement("div", {
  style: {
    display: 'flex',
    flexDirection: 'column',
    gap: 6,
    fontFamily: 'var(--fomio-sans)',
    fontSize: 11,
    color: 'var(--fomio-fg-muted)'
  }
}, /*#__PURE__*/React.createElement("span", {
  style: {
    color: 'var(--fomio-success)'
  }
}, "\u2713 Title set"), /*#__PURE__*/React.createElement("span", {
  style: {
    color: 'var(--fomio-success)'
  }
}, "\u2713 Teret chosen"), /*#__PURE__*/React.createElement("span", null, "\u25CB Min 280 chars met"))));

/* ──────────────────────────────────────────────────────────
   CREATE BYTE
   ────────────────────────────────────────────────────────── */
const CreateByte = ({
  opts,
  touch
}) => {
  const showPop = opts.editorState === 'select' && !touch;
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Topbar, {
    mode: "create"
  }), /*#__PURE__*/React.createElement("div", {
    className: "cm-create-page"
  }, /*#__PURE__*/React.createElement("div", {
    className: "cm-with-rail"
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "cm-crumbs"
  }, /*#__PURE__*/React.createElement("span", null, "Letters"), /*#__PURE__*/React.createElement("span", {
    className: "sep"
  }, "/"), /*#__PURE__*/React.createElement("span", {
    className: "here"
  }, "New byte")), /*#__PURE__*/React.createElement("header", {
    className: "cm-header"
  }, /*#__PURE__*/React.createElement("input", {
    className: "cm-title-input",
    defaultValue: opts.titleFilled ? "The quiet rituals of reading slowly" : "",
    placeholder: "Untitled byte"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 14,
      marginTop: 14,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement("button", {
    className: "cm-teret-trigger",
    type: "button",
    style: {
      width: 'auto',
      flex: '0 1 320px'
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "hub"
  }, "Letters"), /*#__PURE__*/React.createElement("span", {
    className: "swatch",
    style: {
      background: 'var(--fomio-primary)'
    }
  }), /*#__PURE__*/React.createElement("span", {
    className: "label"
  }, "Slow reading"), /*#__PURE__*/React.createElement("span", {
    className: "chev"
  }, /*#__PURE__*/React.createElement(CmGlyph, {
    d: ICON.chev,
    size: 14
  }))), /*#__PURE__*/React.createElement("div", {
    className: "cm-tags-row",
    style: {
      marginTop: 0
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "cm-tag"
  }, "reading ", /*#__PURE__*/React.createElement("span", {
    className: "x"
  }, "\xD7")), /*#__PURE__*/React.createElement("span", {
    className: "cm-tag"
  }, "attention ", /*#__PURE__*/React.createElement("span", {
    className: "x"
  }, "\xD7")), /*#__PURE__*/React.createElement("span", {
    className: "cm-tag add"
  }, "+ tag")))), /*#__PURE__*/React.createElement("div", {
    className: "cm-body-wrap"
  }, opts.bodyFilled ? /*#__PURE__*/React.createElement("div", {
    className: "cm-body-content"
  }, /*#__PURE__*/React.createElement("h2", null, "Three small rituals"), /*#__PURE__*/React.createElement("p", null, "There is a particular ", /*#__PURE__*/React.createElement("span", {
    className: "cm-mark"
  }, "kind of attention"), " that only arrives when nothing demands it. Not the focused attention of work, nor the diffuse drift of scrolling \u2014 something gentler."), /*#__PURE__*/React.createElement("p", {
    style: {
      position: 'relative'
    }
  }, "I have started keeping a ", /*#__PURE__*/React.createElement("span", {
    className: "cm-sel"
  }, "notebook beside whatever I'm reading"), ". Not for ", /*#__PURE__*/React.createElement("strong", null, "highlights"), " or ideas to act on later, but for sentences that have ", /*#__PURE__*/React.createElement("em", null, "done something"), " I cannot yet name", /*#__PURE__*/React.createElement("span", {
    className: "cm-caret"
  }), showPop && /*#__PURE__*/React.createElement(SelectionPop, {
    style: {
      left: 88,
      top: -42
    }
  })), /*#__PURE__*/React.createElement("blockquote", null, "The reader's job is not to hurry the writer."), /*#__PURE__*/React.createElement("p", null, "The link below opens a related letter. Fomio renders it inline as a quiet card."), /*#__PURE__*/React.createElement("div", {
    className: "cm-onebox"
  }, /*#__PURE__*/React.createElement("div", {
    className: "cm-onebox-thumb"
  }), /*#__PURE__*/React.createElement("div", {
    className: "cm-onebox-body"
  }, /*#__PURE__*/React.createElement("span", {
    className: "cm-onebox-site"
  }, "meta.fomio.app"), /*#__PURE__*/React.createElement("span", {
    className: "cm-onebox-title"
  }, "On writing without an audience"), /*#__PURE__*/React.createElement("span", {
    className: "cm-onebox-desc"
  }, "There's a specific pleasure in opening an app and finding it unchanged \u2014 no new tab, no pulsing dot.")))) : /*#__PURE__*/React.createElement("div", {
    className: "cm-body-content cm-body-empty"
  }, /*#__PURE__*/React.createElement("p", null, "Tell the story. \u2318K to link, drag a file to attach.")))), /*#__PURE__*/React.createElement(ComposerRail, null)), /*#__PURE__*/React.createElement("div", {
    className: "cm-submit"
  }, /*#__PURE__*/React.createElement("div", {
    className: "left"
  }, /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement("span", {
    className: "key"
  }, "\u2318"), /*#__PURE__*/React.createElement("span", {
    className: "key"
  }, "\u21B5"), " publish"), /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement("span", {
    className: "key"
  }, "esc"), " close")), /*#__PURE__*/React.createElement("button", {
    className: "cm-btn cm-btn-tertiary"
  }, "Cancel"), /*#__PURE__*/React.createElement("button", {
    className: "cm-btn cm-btn-primary"
  }, "Publish byte", /*#__PURE__*/React.createElement(CmGlyph, {
    d: ICON.arrow,
    size: 14
  })))), /*#__PURE__*/React.createElement("div", {
    className: "cm-status-bar"
  }, /*#__PURE__*/React.createElement("span", {
    className: "seg ok"
  }, /*#__PURE__*/React.createElement(CmGlyph, {
    d: ICON.check,
    size: 10
  }), "Draft saved \xB7 4s ago"), /*#__PURE__*/React.createElement("span", {
    className: "sep"
  }, "\xB7"), /*#__PURE__*/React.createElement("span", {
    className: "seg"
  }, "312 words \xB7 1,847 chars"), /*#__PURE__*/React.createElement("div", {
    className: "right"
  }, /*#__PURE__*/React.createElement("span", {
    className: "seg"
  }, "\u2318\u21B5 publish"))), !touch && /*#__PURE__*/React.createElement("div", {
    className: "cm-mobile-bar"
  }, /*#__PURE__*/React.createElement("button", {
    className: "cm-btn cm-btn-tertiary",
    style: {
      height: 36,
      padding: '0 14px'
    }
  }, "Cancel"), /*#__PURE__*/React.createElement("button", {
    className: "cm-btn cm-btn-primary",
    style: {
      flex: 1,
      height: 44
    }
  }, "Publish")));
};

/* ──────────────────────────────────────────────────────────
   REPLY
   ────────────────────────────────────────────────────────── */
const ReplyComposer = ({
  opts,
  touch
}) => {
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Topbar, {
    mode: "reply"
  }), /*#__PURE__*/React.createElement("div", {
    className: "cm-reply-page"
  }, /*#__PURE__*/React.createElement("article", {
    className: "cm-byte-context minimal"
  }, /*#__PURE__*/React.createElement("div", {
    className: "meta"
  }, /*#__PURE__*/React.createElement("span", {
    className: "tag"
  }, "Slow reading")), /*#__PURE__*/React.createElement("h2", null, "On writing without an audience")), /*#__PURE__*/React.createElement("div", {
    className: "cm-reply-card focused"
  }, /*#__PURE__*/React.createElement("div", {
    className: "cm-reply-head"
  }, /*#__PURE__*/React.createElement("div", {
    className: "av"
  }), /*#__PURE__*/React.createElement("div", {
    className: "who"
  }, "Ismail Z.", /*#__PURE__*/React.createElement("span", {
    className: "replying"
  }, "replying to ", /*#__PURE__*/React.createElement("b", null, "@lena"), " \xB7 in Letters / Slow reading")), /*#__PURE__*/React.createElement("div", {
    className: "close",
    title: "Close"
  }, /*#__PURE__*/React.createElement(CmGlyph, {
    d: ICON.close,
    size: 14
  }))), opts.quoteReply && /*#__PURE__*/React.createElement("div", {
    className: "cm-quote-chip"
  }, /*#__PURE__*/React.createElement("span", {
    className: "from"
  }, "Quoting Lena Marsh"), "\"A clock that trusts you to arrive when you arrive.\""), /*#__PURE__*/React.createElement("div", {
    className: "cm-reply-body"
  }, /*#__PURE__*/React.createElement("div", {
    className: "cm-body-wrap"
  }, /*#__PURE__*/React.createElement("div", {
    className: "cm-body-content"
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      position: 'relative',
      fontSize: 16
    }
  }, "Yes \u2014 and the corollary is that the absence of urgency has to be designed for. A timeline that is merely chronological still carries the residue of ", /*#__PURE__*/React.createElement("em", null, "recency"), "; even quiet platforms reward the new", /*#__PURE__*/React.createElement("span", {
    className: "cm-caret"
  }))))), !touch && /*#__PURE__*/React.createElement("div", {
    className: "cm-reply-foot"
  }, /*#__PURE__*/React.createElement("div", {
    className: "tools"
  }, /*#__PURE__*/React.createElement("span", {
    className: "cm-tool",
    title: "Bold \u2318B"
  }, /*#__PURE__*/React.createElement(CmGlyph, {
    d: ICON.bold,
    size: 14
  })), /*#__PURE__*/React.createElement("span", {
    className: "cm-tool",
    title: "Italic \u2318I"
  }, /*#__PURE__*/React.createElement(CmGlyph, {
    d: ICON.italic,
    size: 14
  })), /*#__PURE__*/React.createElement("span", {
    className: "cm-tool",
    title: "Link \u2318K"
  }, /*#__PURE__*/React.createElement(CmGlyph, {
    d: ICON.link,
    size: 14
  })), /*#__PURE__*/React.createElement("span", {
    className: "cm-tool-divider"
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--fomio-mono)',
      fontSize: 10,
      color: 'var(--fomio-fg-muted)',
      padding: '0 8px'
    }
  }, "42 words \xB7 \u2318\u21B5 to send")), /*#__PURE__*/React.createElement("div", {
    className: "actions"
  }, /*#__PURE__*/React.createElement("button", {
    className: "cm-btn cm-btn-tertiary",
    style: {
      height: 36,
      padding: '0 14px'
    }
  }, "Cancel"), /*#__PURE__*/React.createElement("button", {
    className: "cm-btn cm-btn-primary",
    style: {
      height: 36,
      padding: '0 18px'
    }
  }, "Reply"))))));
};

/* ──────────────────────────────────────────────────────────
   EDIT — same shell + rail as create, with a refinement banner
   ────────────────────────────────────────────────────────── */
const EditByte = ({
  opts,
  touch
}) => {
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Topbar, {
    mode: "edit"
  }), /*#__PURE__*/React.createElement("div", {
    className: "cm-create-page"
  }, /*#__PURE__*/React.createElement("div", {
    className: "cm-edit-banner"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ico"
  }, /*#__PURE__*/React.createElement(CmGlyph, {
    d: ICON.edit,
    size: 14
  })), /*#__PURE__*/React.createElement("div", {
    className: "txt"
  }, /*#__PURE__*/React.createElement("b", null, "Editing your byte"), /*#__PURE__*/React.createElement("span", null, "Published 2 days ago \xB7 readers will see an edited indicator"))), /*#__PURE__*/React.createElement("div", {
    className: "cm-with-rail"
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("header", {
    className: "cm-header"
  }, /*#__PURE__*/React.createElement("input", {
    className: "cm-title-input",
    defaultValue: "The quiet rituals of reading slowly"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 14,
      marginTop: 14,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement("button", {
    className: "cm-teret-trigger",
    type: "button",
    style: {
      width: 'auto',
      flex: '0 1 320px'
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "hub"
  }, "Letters"), /*#__PURE__*/React.createElement("span", {
    className: "swatch",
    style: {
      background: 'var(--fomio-primary)'
    }
  }), /*#__PURE__*/React.createElement("span", {
    className: "label"
  }, "Slow reading"), /*#__PURE__*/React.createElement("span", {
    className: "chev"
  }, /*#__PURE__*/React.createElement(CmGlyph, {
    d: ICON.chev,
    size: 14
  }))), /*#__PURE__*/React.createElement("div", {
    className: "cm-tags-row",
    style: {
      marginTop: 0
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "cm-tag"
  }, "reading ", /*#__PURE__*/React.createElement("span", {
    className: "x"
  }, "\xD7")), /*#__PURE__*/React.createElement("span", {
    className: "cm-tag"
  }, "attention ", /*#__PURE__*/React.createElement("span", {
    className: "x"
  }, "\xD7"))))), /*#__PURE__*/React.createElement("div", {
    className: "cm-body-wrap"
  }, /*#__PURE__*/React.createElement("div", {
    className: "cm-body-content"
  }, /*#__PURE__*/React.createElement("h2", null, "Three small rituals"), /*#__PURE__*/React.createElement("p", null, "There is a particular kind of attention that only arrives when nothing demands it. Not the focused attention of work, nor the diffuse drift of scrolling \u2014 something gentler."), /*#__PURE__*/React.createElement("p", {
    style: {
      position: 'relative'
    }
  }, "I have started keeping a notebook beside whatever I'm reading. Not for highlights or ideas to act on later, but for sentences that have ", /*#__PURE__*/React.createElement("em", null, "done something"), " I cannot yet name", /*#__PURE__*/React.createElement("span", {
    className: "cm-caret"
  })), /*#__PURE__*/React.createElement("blockquote", null, "The reader's job is not to hurry the writer."), /*#__PURE__*/React.createElement("p", null, "Three rituals have begun to feel essential \u2014 and the strange part is how little they ask of me.")))), /*#__PURE__*/React.createElement(ComposerRail, null)), /*#__PURE__*/React.createElement("div", {
    className: "cm-submit"
  }, /*#__PURE__*/React.createElement("div", {
    className: "left"
  }, /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement("span", {
    className: "key"
  }, "\u2318"), /*#__PURE__*/React.createElement("span", {
    className: "key"
  }, "\u21B5"), " save changes"), /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement("span", {
    className: "key"
  }, "esc"), " close")), /*#__PURE__*/React.createElement("button", {
    className: "cm-btn cm-btn-tertiary"
  }, "Cancel"), /*#__PURE__*/React.createElement("button", {
    className: "cm-btn cm-btn-primary"
  }, "Save changes"))), /*#__PURE__*/React.createElement("div", {
    className: "cm-status-bar"
  }, /*#__PURE__*/React.createElement("span", {
    className: "seg ok"
  }, /*#__PURE__*/React.createElement(CmGlyph, {
    d: ICON.check,
    size: 10
  }), "Saved \xB7 4s ago"), /*#__PURE__*/React.createElement("span", {
    className: "sep"
  }, "\xB7"), /*#__PURE__*/React.createElement("span", {
    className: "seg"
  }, "418 words \xB7 2,140 chars"), /*#__PURE__*/React.createElement("div", {
    className: "right"
  }, /*#__PURE__*/React.createElement("span", {
    className: "seg"
  }, "\u2318\u21B5 save changes"))), !touch && /*#__PURE__*/React.createElement("div", {
    className: "cm-mobile-bar"
  }, /*#__PURE__*/React.createElement("button", {
    className: "cm-btn cm-btn-tertiary",
    style: {
      height: 36,
      padding: '0 14px'
    }
  }, "Cancel"), /*#__PURE__*/React.createElement("button", {
    className: "cm-btn cm-btn-primary",
    style: {
      flex: 1,
      height: 44
    }
  }, "Save changes")));
};

/* ──────────────────────────────────────────────────────────
   Mode router — composer owns the topbar downward; the sidebar
   renders independently (fomio-sidebar.gjs), so it is not part of
   this surface.
   ────────────────────────────────────────────────────────── */
const ComposerScreen = ({
  mode,
  theme,
  opts,
  viewport
}) => {
  const touch = viewport === 'tablet' || viewport === 'mobile';
  const action = mode === 'create' ? 'Publish' : mode === 'reply' ? 'Reply' : 'Save';
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("main", {
    className: "cm-main" + (touch ? " has-kbd" : "")
  }, mode === 'create' && /*#__PURE__*/React.createElement(CreateByte, {
    opts: opts,
    touch: touch
  }), mode === 'reply' && /*#__PURE__*/React.createElement(ReplyComposer, {
    opts: opts,
    touch: touch
  }), mode === 'edit' && /*#__PURE__*/React.createElement(EditByte, {
    opts: opts,
    touch: touch
  })), touch && /*#__PURE__*/React.createElement(KeyboardDock, {
    action: action
  }));
};
Object.assign(window, {
  ComposerScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "composer.jsx", error: String((e && e.message) || e) }); }

// content-tweaks.jsx
try { (() => {
// content-tweaks.jsx
// Tweaks panel for the Content layer (Layer 2) reference page.
// Modifies CSS custom properties so canonical display components update live.

const CONTENT_ACCENT_PALETTES = {
  terracotta: {
    primary: '#C44536',
    soft: '#F5D0CC',
    dark: '#9E3326'
  },
  slate: {
    primary: '#52525B',
    soft: '#E4E4E7',
    dark: '#3F3F46'
  },
  ocean: {
    primary: '#2563EB',
    soft: '#DBEAFE',
    dark: '#1D4ED8'
  },
  sage: {
    primary: '#4A7C59',
    soft: '#D1E7D7',
    dark: '#2D5A3A'
  }
};
const CONTENT_RADIUS_MAP = {
  sharp: {
    card: '8px',
    md: '6px',
    sm: '4px',
    pill: '6px'
  },
  rounded: {
    card: '14px',
    md: '10px',
    sm: '6px',
    pill: '9999px'
  },
  soft: {
    card: '18px',
    md: '12px',
    sm: '8px',
    pill: '9999px'
  }
};
const CONTENT_DENSITY_MAP = {
  compact: {
    cardPad: '16px',
    sectionGap: '48px',
    panelGap: '10px',
    listPad: '10px 18px'
  },
  default: {
    cardPad: '24px',
    sectionGap: '72px',
    panelGap: '14px',
    listPad: '13px 22px'
  },
  spacious: {
    cardPad: '32px',
    sectionGap: '88px',
    panelGap: '18px',
    listPad: '16px 26px'
  }
};
const CONTENT_AVATAR_SCALE = {
  sm: {
    base: '28px',
    lg: '36px',
    xl: '48px',
    font: '11px',
    fontLg: '14px',
    fontXl: '18px'
  },
  md: {
    base: '32px',
    lg: '42px',
    xl: '56px',
    font: '12px',
    fontLg: '16px',
    fontXl: '20px'
  },
  lg: {
    base: '38px',
    lg: '48px',
    xl: '64px',
    font: '14px',
    fontLg: '18px',
    fontXl: '24px'
  }
};
const CONTENT_TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "accent": "terracotta",
  "radius": "soft",
  "density": "default",
  "avatarScale": "md",
  "badgeShape": "pill",
  "contentMax": 42,
  "uppercase": true
} /*EDITMODE-END*/;
function ContentTweaks() {
  const [t, setTweak] = useTweaks(CONTENT_TWEAK_DEFAULTS);
  React.useEffect(() => {
    const s = document.documentElement.style;

    // Accent
    if (t.accent !== 'terracotta') {
      const pal = CONTENT_ACCENT_PALETTES[t.accent];
      s.setProperty('--fomio-primary', pal.primary);
      s.setProperty('--fomio-primary-soft', pal.soft);
      s.setProperty('--fomio-primary-dark', pal.dark);
    } else {
      s.removeProperty('--fomio-primary');
      s.removeProperty('--fomio-primary-soft');
      s.removeProperty('--fomio-primary-dark');
    }

    // Radius
    const r = CONTENT_RADIUS_MAP[t.radius] || CONTENT_RADIUS_MAP.soft;
    s.setProperty('--fomio-radius-card', r.card);
    s.setProperty('--fomio-radius-md', r.md);
    s.setProperty('--fomio-radius-sm', r.sm);
    s.setProperty('--content-badge-radius', t.badgeShape === 'pill' ? '9999px' : r.sm);

    // Density
    const d = CONTENT_DENSITY_MAP[t.density] || CONTENT_DENSITY_MAP.default;
    s.setProperty('--content-card-pad', d.cardPad);
    s.setProperty('--content-section-gap', d.sectionGap);
    s.setProperty('--content-panel-gap', d.panelGap);
    s.setProperty('--content-list-pad', d.listPad);

    // Avatar scale
    const a = CONTENT_AVATAR_SCALE[t.avatarScale] || CONTENT_AVATAR_SCALE.md;
    s.setProperty('--content-avatar-base', a.base);
    s.setProperty('--content-avatar-lg', a.lg);
    s.setProperty('--content-avatar-xl', a.xl);
    s.setProperty('--content-avatar-font', a.font);
    s.setProperty('--content-avatar-font-lg', a.fontLg);
    s.setProperty('--content-avatar-font-xl', a.fontXl);

    // Content max
    s.setProperty('--content-prose-max', t.contentMax + 'rem');

    // Label case
    s.setProperty('--fomio-label-case', t.uppercase ? 'uppercase' : 'none');
  }, [t]);
  return /*#__PURE__*/React.createElement(TweaksPanel, {
    title: "Content"
  }, /*#__PURE__*/React.createElement(TweakSection, {
    label: "Color"
  }), /*#__PURE__*/React.createElement(TweakRadio, {
    label: "Accent",
    value: t.accent,
    options: ['terracotta', 'slate', 'ocean', 'sage'],
    onChange: v => setTweak('accent', v)
  }), /*#__PURE__*/React.createElement(TweakSection, {
    label: "Shape"
  }), /*#__PURE__*/React.createElement(TweakRadio, {
    label: "Card radius",
    value: t.radius,
    options: ['sharp', 'rounded', 'soft'],
    onChange: v => setTweak('radius', v)
  }), /*#__PURE__*/React.createElement(TweakRadio, {
    label: "Badge shape",
    value: t.badgeShape,
    options: ['pill', 'rounded'],
    onChange: v => setTweak('badgeShape', v)
  }), /*#__PURE__*/React.createElement(TweakSection, {
    label: "Density"
  }), /*#__PURE__*/React.createElement(TweakRadio, {
    label: "Spacing",
    value: t.density,
    options: ['compact', 'default', 'spacious'],
    onChange: v => setTweak('density', v)
  }), /*#__PURE__*/React.createElement(TweakRadio, {
    label: "Avatar size",
    value: t.avatarScale,
    options: ['sm', 'md', 'lg'],
    onChange: v => setTweak('avatarScale', v)
  }), /*#__PURE__*/React.createElement(TweakSlider, {
    label: "Prose width",
    value: t.contentMax,
    min: 32,
    max: 56,
    step: 2,
    unit: "rem",
    onChange: v => setTweak('contentMax', v)
  }), /*#__PURE__*/React.createElement(TweakSection, {
    label: "Typography"
  }), /*#__PURE__*/React.createElement(TweakToggle, {
    label: "Uppercase labels",
    value: t.uppercase,
    onChange: v => setTweak('uppercase', v)
  }));
}
ReactDOM.createRoot(document.getElementById('tweaks-root')).render(/*#__PURE__*/React.createElement(ContentTweaks, null));
})(); } catch (e) { __ds_ns.__errors.push({ path: "content-tweaks.jsx", error: String((e && e.message) || e) }); }

// controls-tweaks.jsx
try { (() => {
// controls-tweaks.jsx
// Tweaks panel for the Controls layer reference page.
// Modifies CSS custom properties so canonical component styles update live.

const ACCENT_PALETTES = {
  terracotta: {
    primary: '#C44536',
    soft: '#F5D0CC',
    dark: '#9E3326'
  },
  slate: {
    primary: '#52525B',
    soft: '#E4E4E7',
    dark: '#3F3F46'
  },
  ocean: {
    primary: '#2563EB',
    soft: '#DBEAFE',
    dark: '#1D4ED8'
  },
  sage: {
    primary: '#4A7C59',
    soft: '#D1E7D7',
    dark: '#2D5A3A'
  }
};
const SCALE_MAP = {
  compact: {
    sm: '28px',
    md: '34px',
    lg: '40px',
    input: '34px'
  },
  default: {
    sm: '32px',
    md: '40px',
    lg: '48px',
    input: '40px'
  },
  spacious: {
    sm: '36px',
    md: '44px',
    lg: '52px',
    input: '44px'
  }
};
const SHAPE_MAP = {
  pill: {
    btn: '9999px',
    icon: '12px',
    input: '12px',
    search: '9999px'
  },
  rounded: {
    btn: '12px',
    icon: '12px',
    input: '12px',
    search: '12px'
  },
  sharp: {
    btn: '6px',
    icon: '6px',
    input: '6px',
    search: '6px'
  }
};
const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "shape": "pill",
  "accent": "terracotta",
  "scale": "default",
  "fontWeight": "600",
  "uppercase": true
} /*EDITMODE-END*/;
function ControlsTweaks() {
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);
  React.useEffect(() => {
    const s = document.documentElement.style;

    // Shape
    const sh = SHAPE_MAP[t.shape] || SHAPE_MAP.pill;
    s.setProperty('--fomio-btn-radius', sh.btn);
    s.setProperty('--fomio-btn-icon-radius', sh.icon);
    s.setProperty('--fomio-input-radius', sh.input);
    s.setProperty('--fomio-search-radius', sh.search);

    // Accent — only override when non-default so theme cascade works
    if (t.accent !== 'terracotta') {
      const pal = ACCENT_PALETTES[t.accent];
      s.setProperty('--fomio-primary', pal.primary);
      s.setProperty('--fomio-primary-soft', pal.soft);
      s.setProperty('--fomio-primary-dark', pal.dark);
    } else {
      s.removeProperty('--fomio-primary');
      s.removeProperty('--fomio-primary-soft');
      s.removeProperty('--fomio-primary-dark');
    }

    // Scale
    const sc = SCALE_MAP[t.scale] || SCALE_MAP.default;
    s.setProperty('--fomio-btn-sm', sc.sm);
    s.setProperty('--fomio-btn-md', sc.md);
    s.setProperty('--fomio-btn-lg', sc.lg);
    s.setProperty('--fomio-input-h', sc.input);

    // Font weight
    s.setProperty('--fomio-btn-weight', t.fontWeight);

    // Label case
    s.setProperty('--fomio-label-case', t.uppercase ? 'uppercase' : 'none');

    // Update size labels if they exist
    const scLabels = {
      compact: ['28', '34', '40', '34'],
      default: ['32', '40', '48', '40'],
      spacious: ['36', '44', '52', '44']
    };
    const vals = scLabels[t.scale] || scLabels.default;
    document.querySelectorAll('[data-size-sm]').forEach(el => {
      el.textContent = 'Small · ' + vals[0] + 'px';
    });
    document.querySelectorAll('[data-size-md]').forEach(el => {
      el.textContent = 'Default · ' + vals[1] + 'px';
    });
    document.querySelectorAll('[data-size-lg]').forEach(el => {
      el.textContent = 'Large · ' + vals[2] + 'px';
    });
  }, [t]);
  return /*#__PURE__*/React.createElement(TweaksPanel, {
    title: "Controls"
  }, /*#__PURE__*/React.createElement(TweakSection, {
    label: "Shape"
  }), /*#__PURE__*/React.createElement(TweakRadio, {
    label: "Button shape",
    value: t.shape,
    options: ['pill', 'rounded', 'sharp'],
    onChange: v => setTweak('shape', v)
  }), /*#__PURE__*/React.createElement(TweakSection, {
    label: "Color"
  }), /*#__PURE__*/React.createElement(TweakRadio, {
    label: "Accent",
    value: t.accent,
    options: ['terracotta', 'slate', 'ocean', 'sage'],
    onChange: v => setTweak('accent', v)
  }), /*#__PURE__*/React.createElement(TweakSection, {
    label: "Scale"
  }), /*#__PURE__*/React.createElement(TweakRadio, {
    label: "Density",
    value: t.scale,
    options: ['compact', 'default', 'spacious'],
    onChange: v => setTweak('scale', v)
  }), /*#__PURE__*/React.createElement(TweakSection, {
    label: "Typography"
  }), /*#__PURE__*/React.createElement(TweakRadio, {
    label: "Button weight",
    value: t.fontWeight,
    options: [{
      value: '500',
      label: '500'
    }, {
      value: '600',
      label: '600'
    }, {
      value: '700',
      label: '700'
    }],
    onChange: v => setTweak('fontWeight', v)
  }), /*#__PURE__*/React.createElement(TweakToggle, {
    label: "Uppercase labels",
    value: t.uppercase,
    onChange: v => setTweak('uppercase', v)
  }));
}
ReactDOM.createRoot(document.getElementById('tweaks-root')).render(/*#__PURE__*/React.createElement(ControlsTweaks, null));
})(); } catch (e) { __ds_ns.__errors.push({ path: "controls-tweaks.jsx", error: String((e && e.message) || e) }); }

// design-canvas.jsx
try { (() => {
// DesignCanvas.jsx — Figma-ish design canvas wrapper
// Warm gray grid bg + Sections + Artboards + PostIt notes.
// Artboards are reorderable (grip-drag), deletable, labels/titles are
// inline-editable, and any artboard can be opened in a fullscreen focus
// overlay (←/→/Esc). State persists to a .design-canvas.state.json sidecar
// via the host bridge. No assets, no deps.
//
// Usage:
//   <DesignCanvas>
//     <DCSection id="onboarding" title="Onboarding" subtitle="First-run variants">
//       <DCArtboard id="a" label="A · Dusk" width={260} height={480}>…</DCArtboard>
//       <DCArtboard id="b" label="B · Minimal" width={260} height={480}>…</DCArtboard>
//     </DCSection>
//   </DesignCanvas>

const DC = {
  bg: '#f0eee9',
  grid: 'rgba(0,0,0,0.06)',
  label: 'rgba(60,50,40,0.7)',
  title: 'rgba(40,30,20,0.85)',
  subtitle: 'rgba(60,50,40,0.6)',
  postitBg: '#fef4a8',
  postitText: '#5a4a2a',
  font: '-apple-system, BlinkMacSystemFont, "Segoe UI", system-ui, sans-serif'
};

// One-time CSS injection (classes are dc-prefixed so they don't collide with
// the hosted design's own styles).
if (typeof document !== 'undefined' && !document.getElementById('dc-styles')) {
  const s = document.createElement('style');
  s.id = 'dc-styles';
  s.textContent = ['.dc-editable{cursor:text;outline:none;white-space:nowrap;border-radius:3px;padding:0 2px;margin:0 -2px}', '.dc-editable:focus{background:#fff;box-shadow:0 0 0 1.5px #c96442}', '[data-dc-slot]{transition:transform .18s cubic-bezier(.2,.7,.3,1)}', '[data-dc-slot].dc-dragging{transition:none;z-index:10;pointer-events:none}', '[data-dc-slot].dc-dragging .dc-card{box-shadow:0 12px 40px rgba(0,0,0,.25),0 0 0 2px #c96442;transform:scale(1.02)}',
  // isolation:isolate contains artboard content's z-indexes so a
  // z-indexed child (sticky navbar etc.) can't paint over .dc-header or
  // the .dc-menu popover that drops into the top of the card.
  '.dc-card{isolation:isolate;transition:box-shadow .15s,transform .15s}', '.dc-card *{scrollbar-width:none}', '.dc-card *::-webkit-scrollbar{display:none}',
  // Per-artboard header: grip + label on the left, delete/expand on the
  // right. Single flex row; when the artboard's on-screen width is too
  // narrow for both the label yields (ellipsis, then hidden entirely below
  // ~4ch via the container query) and the buttons stay on the row.
  '.dc-header{position:absolute;bottom:100%;left:-4px;margin-bottom:calc(4px * var(--dc-inv-zoom,1));z-index:2;', '  display:flex;align-items:center;container-type:inline-size}', '.dc-labelrow{display:flex;align-items:center;gap:4px;height:24px;flex:1 1 auto;min-width:0}', '.dc-grip{flex:0 0 auto;cursor:grab;display:flex;align-items:center;padding:5px 4px;border-radius:4px;transition:background .12s,opacity .12s}', '.dc-grip:hover{background:rgba(0,0,0,.08)}', '.dc-grip:active{cursor:grabbing}', '.dc-labeltext{flex:1 1 auto;min-width:0;cursor:pointer;border-radius:4px;padding:3px 6px;', '  display:flex;align-items:center;transition:background .12s;overflow:hidden}',
  // Below ~4ch of label room: hide the label entirely, and drop the grip to
  // hover-only (same reveal rule as .dc-btns) so a narrow header is clean
  // until the card is moused.
  '@container (max-width: 110px){', '  .dc-labeltext{display:none}', '  .dc-grip{opacity:0}', '  [data-dc-slot]:hover .dc-grip{opacity:1}', '}', '.dc-labeltext:hover{background:rgba(0,0,0,.05)}', '.dc-labeltext .dc-editable{overflow:hidden;text-overflow:ellipsis;max-width:100%}', '.dc-labeltext .dc-editable:focus{overflow:visible;text-overflow:clip}', '.dc-btns{flex:0 0 auto;margin-left:auto;display:flex;gap:2px;opacity:0;transition:opacity .12s}', '[data-dc-slot]:hover .dc-btns,.dc-btns:has(.dc-menu){opacity:1}', '.dc-expand,.dc-kebab{width:22px;height:22px;border-radius:5px;border:none;cursor:pointer;padding:0;', '  background:transparent;color:rgba(60,50,40,.7);display:flex;align-items:center;justify-content:center;', '  font:inherit;transition:background .12s,color .12s}', '.dc-expand:hover,.dc-kebab:hover{background:rgba(0,0,0,.06);color:#2a251f}',
  // Slot hosting an open menu floats above later siblings (which otherwise
  // paint on top — same z-index:auto, later DOM order) so the popup isn't
  // clipped by the next card.
  '[data-dc-slot]:has(.dc-menu){z-index:10}', '.dc-menu{position:absolute;top:100%;right:0;margin-top:4px;background:#fff;border-radius:8px;', '  box-shadow:0 8px 28px rgba(0,0,0,.18),0 0 0 1px rgba(0,0,0,.05);padding:4px;min-width:160px;z-index:10}', '.dc-menu button{display:block;width:100%;padding:7px 10px;border:0;background:transparent;', '  border-radius:5px;font-family:inherit;font-size:13px;font-weight:500;line-height:1.2;', '  color:#29261b;cursor:pointer;text-align:left;transition:background .12s;white-space:nowrap}', '.dc-menu button:hover{background:rgba(0,0,0,.05)}', '.dc-menu hr{border:0;border-top:1px solid rgba(0,0,0,.08);margin:4px 2px}', '.dc-menu .dc-danger{color:#c96442}', '.dc-menu .dc-danger:hover{background:rgba(201,100,66,.1)}',
  // Chrome (titles / labels / buttons) counter-scales against the viewport
  // zoom so it stays a constant on-screen size. --dc-inv-zoom is set by
  // DCViewport on every transform update and inherits to all descendants —
  // any overlay inside the world (e.g. a TweaksPanel on an artboard) can use
  // it the same way.
  //
  // The header uses transform:scale (out-of-flow, so layout impact doesn't
  // matter) with its world-space width set to card-width / inv-zoom so that
  // after counter-scaling its on-screen width exactly matches the card's —
  // that's what lets the container query + text-overflow behave against the
  // card's visible edge at every zoom level.
  //
  // The section head uses CSS zoom instead of transform so its layout box
  // grows with the counter-scale, pushing the card row down — otherwise the
  // constant-screen-size title would overflow into the (shrinking) world-
  // space gap and overlap the artboard headers at low zoom.
  '.dc-header{width:calc((100% + 4px) / var(--dc-inv-zoom,1));', '  transform:scale(var(--dc-inv-zoom,1));transform-origin:bottom left}', '.dc-sectionhead{zoom:var(--dc-inv-zoom,1)}'].join('\n');
  document.head.appendChild(s);
}
const DCCtx = React.createContext(null);

// ─────────────────────────────────────────────────────────────
// DesignCanvas — stateful wrapper around the pan/zoom viewport.
// Owns runtime state (per-section order, renamed titles/labels, hidden
// artboards, focused artboard). Order/titles/labels/hidden persist to a
// .design-canvas.state.json
// sidecar next to the HTML. Reads go via plain fetch() so the saved
// arrangement is visible anywhere the HTML + sidecar are served together
// (omelette preview, direct link, downloaded zip). Writes go through the
// host's window.omelette bridge — editing requires the omelette runtime.
// Focus is ephemeral.
// ─────────────────────────────────────────────────────────────
const DC_STATE_FILE = '.design-canvas.state.json';
function DesignCanvas({
  children,
  minScale,
  maxScale,
  style
}) {
  const [state, setState] = React.useState({
    sections: {},
    focus: null
  });
  // Hold rendering until the sidecar read settles so the saved order/titles
  // appear on first paint (no source-order flash). didRead gates writes until
  // the read settles so the empty initial state can't clobber a slow read;
  // skipNextWrite suppresses the one echo-write that would otherwise follow
  // hydration.
  const [ready, setReady] = React.useState(false);
  const didRead = React.useRef(false);
  const skipNextWrite = React.useRef(false);
  React.useEffect(() => {
    let off = false;
    fetch('./' + DC_STATE_FILE).then(r => r.ok ? r.json() : null).then(saved => {
      if (off || !saved || !saved.sections) return;
      skipNextWrite.current = true;
      setState(s => ({
        ...s,
        sections: saved.sections
      }));
    }).catch(() => {}).finally(() => {
      didRead.current = true;
      if (!off) setReady(true);
    });
    const t = setTimeout(() => {
      if (!off) setReady(true);
    }, 150);
    return () => {
      off = true;
      clearTimeout(t);
    };
  }, []);
  React.useEffect(() => {
    if (!didRead.current) return;
    if (skipNextWrite.current) {
      skipNextWrite.current = false;
      return;
    }
    const t = setTimeout(() => {
      window.omelette?.writeFile(DC_STATE_FILE, JSON.stringify({
        sections: state.sections
      })).catch(() => {});
    }, 250);
    return () => clearTimeout(t);
  }, [state.sections]);

  // Build registries synchronously from children so FocusOverlay can read
  // them in the same render. Only direct DCSection > DCArtboard children are
  // walked — wrapping them in other elements opts out of focus/reorder.
  const registry = {}; // slotId -> { sectionId, artboard }
  const sectionMeta = {}; // sectionId -> { title, subtitle, slotIds[] }
  const sectionOrder = [];
  React.Children.forEach(children, sec => {
    if (!sec || sec.type !== DCSection) return;
    const sid = sec.props.id ?? sec.props.title;
    if (!sid) return;
    sectionOrder.push(sid);
    const persisted = state.sections[sid] || {};
    const abs = [];
    React.Children.forEach(sec.props.children, ab => {
      if (!ab || ab.type !== DCArtboard) return;
      const aid = ab.props.id ?? ab.props.label;
      if (aid) abs.push([aid, ab]);
    });
    // hidden is scoped to one source revision — when the agent regenerates
    // (artboard-ID set changes), prior deletes don't apply to new content.
    const srcKey = abs.map(([k]) => k).join('\x1f');
    const hidden = persisted.srcKey === srcKey ? persisted.hidden || [] : [];
    const srcIds = [];
    abs.forEach(([aid, ab]) => {
      if (hidden.includes(aid)) return;
      registry[`${sid}/${aid}`] = {
        sectionId: sid,
        artboard: ab
      };
      srcIds.push(aid);
    });
    const kept = (persisted.order || []).filter(k => srcIds.includes(k));
    sectionMeta[sid] = {
      title: persisted.title ?? sec.props.title,
      subtitle: sec.props.subtitle,
      slotIds: [...kept, ...srcIds.filter(k => !kept.includes(k))]
    };
  });
  const api = React.useMemo(() => ({
    state,
    section: id => state.sections[id] || {},
    patchSection: (id, p) => setState(s => ({
      ...s,
      sections: {
        ...s.sections,
        [id]: {
          ...s.sections[id],
          ...(typeof p === 'function' ? p(s.sections[id] || {}) : p)
        }
      }
    })),
    setFocus: slotId => setState(s => ({
      ...s,
      focus: slotId
    }))
  }), [state]);

  // Esc exits focus; any outside pointerdown commits an in-progress rename.
  React.useEffect(() => {
    const onKey = e => {
      if (e.key === 'Escape') api.setFocus(null);
    };
    const onPd = e => {
      const ae = document.activeElement;
      if (ae && ae.isContentEditable && !ae.contains(e.target)) ae.blur();
    };
    document.addEventListener('keydown', onKey);
    document.addEventListener('pointerdown', onPd, true);
    return () => {
      document.removeEventListener('keydown', onKey);
      document.removeEventListener('pointerdown', onPd, true);
    };
  }, [api]);
  return /*#__PURE__*/React.createElement(DCCtx.Provider, {
    value: api
  }, /*#__PURE__*/React.createElement(DCViewport, {
    minScale: minScale,
    maxScale: maxScale,
    style: style
  }, ready && children), state.focus && registry[state.focus] && /*#__PURE__*/React.createElement(DCFocusOverlay, {
    entry: registry[state.focus],
    sectionMeta: sectionMeta,
    sectionOrder: sectionOrder
  }));
}

// ─────────────────────────────────────────────────────────────
// DCViewport — transform-based pan/zoom (internal)
//
// Input mapping (Figma-style):
//   • trackpad pinch  → zoom   (ctrlKey wheel; Safari gesture* events)
//   • trackpad scroll → pan    (two-finger)
//   • mouse wheel     → zoom   (notched; distinguished from trackpad scroll)
//   • middle-drag / primary-drag-on-bg → pan
//
// Transform state lives in a ref and is written straight to the DOM
// (translate3d + will-change) so wheel ticks don't go through React —
// keeps pans at 60fps on dense canvases.
// ─────────────────────────────────────────────────────────────
function DCViewport({
  children,
  minScale = 0.1,
  maxScale = 8,
  style = {}
}) {
  const vpRef = React.useRef(null);
  const worldRef = React.useRef(null);
  const tf = React.useRef({
    x: 0,
    y: 0,
    scale: 1
  });
  // Persist viewport across reloads so the user lands back where they were
  // after an agent edit or browser refresh. The sandbox origin is already
  // per-project; pathname keeps multiple canvas files in one project apart.
  const tfKey = 'dc-viewport:' + location.pathname;
  const saveT = React.useRef(0);
  const lastPostedScale = React.useRef();
  const apply = React.useCallback(() => {
    const {
      x,
      y,
      scale
    } = tf.current;
    const el = worldRef.current;
    if (!el) return;
    el.style.transform = `translate3d(${x}px, ${y}px, 0) scale(${scale})`;
    // Exposed for zoom-invariant chrome (labels, buttons, TweaksPanel).
    el.style.setProperty('--dc-inv-zoom', String(1 / scale));
    // Keep the host toolbar's % readout in sync with the canvas scale. Pan
    // ticks leave scale unchanged — skip the cross-frame post for those.
    if (lastPostedScale.current !== scale) {
      lastPostedScale.current = scale;
      window.parent.postMessage({
        type: '__dc_zoom',
        scale
      }, '*');
    }
    clearTimeout(saveT.current);
    saveT.current = setTimeout(() => {
      try {
        localStorage.setItem(tfKey, JSON.stringify(tf.current));
      } catch {}
    }, 200);
  }, [tfKey]);
  React.useLayoutEffect(() => {
    const flush = () => {
      clearTimeout(saveT.current);
      try {
        localStorage.setItem(tfKey, JSON.stringify(tf.current));
      } catch {}
    };
    try {
      const s = JSON.parse(localStorage.getItem(tfKey) || 'null');
      if (s && Number.isFinite(s.x) && Number.isFinite(s.y) && Number.isFinite(s.scale)) {
        tf.current = {
          x: s.x,
          y: s.y,
          scale: Math.min(maxScale, Math.max(minScale, s.scale))
        };
        apply();
      }
    } catch {}
    // Flush on pagehide and unmount so a reload within the 200ms debounce
    // window doesn't drop the last pan/zoom.
    window.addEventListener('pagehide', flush);
    return () => {
      window.removeEventListener('pagehide', flush);
      flush();
    };
  }, []);
  React.useEffect(() => {
    const vp = vpRef.current;
    if (!vp) return;
    const zoomAt = (cx, cy, factor) => {
      const r = vp.getBoundingClientRect();
      const px = cx - r.left,
        py = cy - r.top;
      const t = tf.current;
      const next = Math.min(maxScale, Math.max(minScale, t.scale * factor));
      const k = next / t.scale;
      // keep the world point under the cursor fixed
      t.x = px - (px - t.x) * k;
      t.y = py - (py - t.y) * k;
      t.scale = next;
      apply();
    };

    // Mouse-wheel vs trackpad-scroll heuristic. A physical wheel sends
    // line-mode deltas (Firefox) or large integer pixel deltas with no X
    // component (Chrome/Safari, typically multiples of 100/120). Trackpad
    // two-finger scroll sends small/fractional pixel deltas, often with
    // non-zero deltaX. ctrlKey is set by the browser for trackpad pinch.
    const isMouseWheel = e => e.deltaMode !== 0 || e.deltaX === 0 && Number.isInteger(e.deltaY) && Math.abs(e.deltaY) >= 40;
    const onWheel = e => {
      e.preventDefault();
      if (isGesturing) return; // Safari: gesture* owns the pinch — discard concurrent wheels
      if ((e.ctrlKey || e.metaKey) && !isMouseWheel(e)) {
        // trackpad pinch, or ctrl/cmd + smooth-scroll mouse. Notched
        // wheels fall through to the fixed-step branch below.
        zoomAt(e.clientX, e.clientY, Math.exp(-e.deltaY * 0.01));
      } else if (isMouseWheel(e)) {
        // notched mouse wheel — fixed-ratio step per click
        zoomAt(e.clientX, e.clientY, Math.exp(-Math.sign(e.deltaY) * 0.18));
      } else {
        // trackpad two-finger scroll — pan
        tf.current.x -= e.deltaX;
        tf.current.y -= e.deltaY;
        apply();
      }
    };

    // Safari sends native gesture* events for trackpad pinch with a smooth
    // e.scale; preferring these over the ctrl+wheel fallback gives a much
    // better feel there. No-ops on other browsers. Safari also fires
    // ctrlKey wheel events during the same pinch — isGesturing makes
    // onWheel drop those entirely so they neither zoom nor pan.
    let gsBase = 1;
    let isGesturing = false;
    const onGestureStart = e => {
      e.preventDefault();
      isGesturing = true;
      gsBase = tf.current.scale;
    };
    const onGestureChange = e => {
      e.preventDefault();
      zoomAt(e.clientX, e.clientY, gsBase * e.scale / tf.current.scale);
    };
    const onGestureEnd = e => {
      e.preventDefault();
      isGesturing = false;
    };

    // Drag-pan: middle button anywhere, or primary button on canvas
    // background (anything that isn't an artboard or an inline editor).
    let drag = null;
    const onPointerDown = e => {
      const onBg = !e.target.closest('[data-dc-slot], .dc-editable');
      if (!(e.button === 1 || e.button === 0 && onBg)) return;
      e.preventDefault();
      vp.setPointerCapture(e.pointerId);
      drag = {
        id: e.pointerId,
        lx: e.clientX,
        ly: e.clientY
      };
      vp.style.cursor = 'grabbing';
    };
    const onPointerMove = e => {
      if (!drag || e.pointerId !== drag.id) return;
      tf.current.x += e.clientX - drag.lx;
      tf.current.y += e.clientY - drag.ly;
      drag.lx = e.clientX;
      drag.ly = e.clientY;
      apply();
    };
    const onPointerUp = e => {
      if (!drag || e.pointerId !== drag.id) return;
      vp.releasePointerCapture(e.pointerId);
      drag = null;
      vp.style.cursor = '';
    };

    // Host-driven zoom (toolbar % menu). Zooms around viewport centre so the
    // visible midpoint stays fixed — matching the host's iframe-zoom feel.
    const onHostMsg = e => {
      const d = e.data;
      if (d && d.type === '__dc_set_zoom' && typeof d.scale === 'number') {
        const r = vp.getBoundingClientRect();
        zoomAt(r.left + r.width / 2, r.top + r.height / 2, d.scale / tf.current.scale);
      } else if (d && d.type === '__dc_probe') {
        // Host's [readyGen] reset asks whether a canvas is present; it
        // fires on the iframe's native 'load', which for canvases with
        // images/fonts is after our mount-time announce, so re-announce.
        // Clear the pan-tick guard so apply() re-posts the current scale
        // even if it's unchanged — the host just reset dcScale to 1.
        window.parent.postMessage({
          type: '__dc_present'
        }, '*');
        lastPostedScale.current = undefined;
        apply();
      }
    };
    window.addEventListener('message', onHostMsg);
    // Announce canvas mode so the host toolbar proxies its % control here
    // instead of scaling the iframe element (which would just shrink the
    // viewport window of an infinite canvas). The apply() that follows emits
    // the initial __dc_zoom so the toolbar % is correct before first pinch.
    // lastPostedScale reset mirrors the __dc_probe handler: the layout
    // effect's restore-path apply() may already have posted the restored
    // scale (before __dc_present), so clear the guard to re-post it in order.
    window.parent.postMessage({
      type: '__dc_present'
    }, '*');
    lastPostedScale.current = undefined;
    apply();
    vp.addEventListener('wheel', onWheel, {
      passive: false
    });
    vp.addEventListener('gesturestart', onGestureStart, {
      passive: false
    });
    vp.addEventListener('gesturechange', onGestureChange, {
      passive: false
    });
    vp.addEventListener('gestureend', onGestureEnd, {
      passive: false
    });
    vp.addEventListener('pointerdown', onPointerDown);
    vp.addEventListener('pointermove', onPointerMove);
    vp.addEventListener('pointerup', onPointerUp);
    vp.addEventListener('pointercancel', onPointerUp);
    return () => {
      window.removeEventListener('message', onHostMsg);
      vp.removeEventListener('wheel', onWheel);
      vp.removeEventListener('gesturestart', onGestureStart);
      vp.removeEventListener('gesturechange', onGestureChange);
      vp.removeEventListener('gestureend', onGestureEnd);
      vp.removeEventListener('pointerdown', onPointerDown);
      vp.removeEventListener('pointermove', onPointerMove);
      vp.removeEventListener('pointerup', onPointerUp);
      vp.removeEventListener('pointercancel', onPointerUp);
    };
  }, [apply, minScale, maxScale]);
  const gridSvg = `url("data:image/svg+xml,%3Csvg width='120' height='120' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M120 0H0v120' fill='none' stroke='${encodeURIComponent(DC.grid)}' stroke-width='1'/%3E%3C/svg%3E")`;
  return /*#__PURE__*/React.createElement("div", {
    ref: vpRef,
    className: "design-canvas",
    style: {
      height: '100vh',
      width: '100vw',
      background: DC.bg,
      overflow: 'hidden',
      overscrollBehavior: 'none',
      touchAction: 'none',
      position: 'relative',
      fontFamily: DC.font,
      boxSizing: 'border-box',
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    ref: worldRef,
    style: {
      position: 'absolute',
      top: 0,
      left: 0,
      transformOrigin: '0 0',
      willChange: 'transform',
      width: 'max-content',
      minWidth: '100%',
      minHeight: '100%',
      padding: '60px 0 80px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: -6000,
      backgroundImage: gridSvg,
      backgroundSize: '120px 120px',
      pointerEvents: 'none',
      zIndex: -1
    }
  }), children));
}

// ─────────────────────────────────────────────────────────────
// DCSection — editable title + h-row of artboards in persisted order
// ─────────────────────────────────────────────────────────────
function DCSection({
  id,
  title,
  subtitle,
  children,
  gap = 48
}) {
  const ctx = React.useContext(DCCtx);
  const sid = id ?? title;
  const all = React.Children.toArray(children);
  const artboards = all.filter(c => c && c.type === DCArtboard);
  const rest = all.filter(c => !(c && c.type === DCArtboard));
  const sec = ctx && sid && ctx.section(sid) || {};
  // Must match DesignCanvas's srcKey computation exactly (it filters falsy
  // IDs), or onDelete persists a srcKey that DesignCanvas never recognizes.
  const allIds = artboards.map(a => a.props.id ?? a.props.label).filter(Boolean);
  const srcKey = allIds.join('\x1f');
  const hidden = sec.srcKey === srcKey ? sec.hidden || [] : [];
  const srcOrder = allIds.filter(k => !hidden.includes(k));
  const order = React.useMemo(() => {
    const kept = (sec.order || []).filter(k => srcOrder.includes(k));
    return [...kept, ...srcOrder.filter(k => !kept.includes(k))];
  }, [sec.order, srcOrder.join('|')]);
  const byId = Object.fromEntries(artboards.map(a => [a.props.id ?? a.props.label, a]));

  // marginBottom counter-scales so the on-screen gap between sections stays
  // constant — otherwise at low zoom the (world-space) gap collapses while
  // the screen-constant sectionhead below it doesn't, and the title reads as
  // belonging to the section above. paddingBottom below is just enough for
  // the 24px artboard-header (abs-positioned above each card) plus ~8px, so
  // the title sits tight against its own row at every zoom.
  return /*#__PURE__*/React.createElement("div", {
    "data-dc-section": sid,
    style: {
      marginBottom: 'calc(80px * var(--dc-inv-zoom, 1))',
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '0 60px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "dc-sectionhead",
    style: {
      paddingBottom: 36
    }
  }, /*#__PURE__*/React.createElement(DCEditable, {
    tag: "div",
    value: sec.title ?? title,
    onChange: v => ctx && sid && ctx.patchSection(sid, {
      title: v
    }),
    style: {
      fontSize: 28,
      fontWeight: 600,
      color: DC.title,
      letterSpacing: -0.4,
      marginBottom: 6,
      display: 'inline-block'
    }
  }), subtitle && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 16,
      color: DC.subtitle
    }
  }, subtitle))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap,
      padding: '0 60px',
      alignItems: 'flex-start',
      width: 'max-content'
    }
  }, order.map(k => /*#__PURE__*/React.createElement(DCArtboardFrame, {
    key: k,
    sectionId: sid,
    artboard: byId[k],
    order: order,
    label: (sec.labels || {})[k] ?? byId[k].props.label,
    onRename: v => ctx && ctx.patchSection(sid, x => ({
      labels: {
        ...x.labels,
        [k]: v
      }
    })),
    onReorder: next => ctx && ctx.patchSection(sid, {
      order: next
    }),
    onDelete: () => ctx && ctx.patchSection(sid, x => ({
      hidden: [...(x.srcKey === srcKey ? x.hidden || [] : []), k],
      srcKey
    })),
    onFocus: () => ctx && ctx.setFocus(`${sid}/${k}`)
  }))), rest);
}

// DCArtboard — marker; rendered by DCArtboardFrame via DCSection.
function DCArtboard() {
  return null;
}

// Per-artboard export (kind: 'png' | 'html'). Both paths share the same
// self-contained clone: computed styles baked in, @font-face / <img> /
// inline-style background-image urls inlined as data URIs. PNG wraps the
// clone in foreignObject→canvas at 3× the artboard's natural width×height
// (same pipeline the host uses for page captures); HTML wraps it in a
// minimal standalone document. Both are independent of viewport zoom.
async function dcExport(node, w, h, name, kind) {
  try {
    await document.fonts.ready;
  } catch {}
  const toDataURL = url => fetch(url).then(r => r.blob()).then(b => new Promise(res => {
    const fr = new FileReader();
    fr.onload = () => res(fr.result);
    fr.onerror = () => res(url);
    fr.readAsDataURL(b);
  })).catch(() => url);

  // Collect @font-face rules. ss.cssRules throws SecurityError on
  // cross-origin sheets (e.g. fonts.googleapis.com) — in that case fetch
  // the CSS text directly (those endpoints send ACAO:*) and regex-extract
  // the blocks. @import and @media/@supports are walked so nested
  // @font-face rules aren't missed.
  const fontRules = [],
    pending = [],
    seen = new Set();
  const scrapeCss = href => {
    if (seen.has(href)) return;
    seen.add(href);
    pending.push(fetch(href).then(r => r.text()).then(css => {
      for (const m of css.match(/@font-face\s*{[^}]*}/g) || []) fontRules.push({
        css: m,
        base: href
      });
      for (const m of css.matchAll(/@import\s+(?:url\()?['"]?([^'")\s;]+)/g)) scrapeCss(new URL(m[1], href).href);
    }).catch(() => {}));
  };
  const walk = (rules, base) => {
    for (const r of rules) {
      if (r.type === CSSRule.FONT_FACE_RULE) fontRules.push({
        css: r.cssText,
        base
      });else if (r.type === CSSRule.IMPORT_RULE && r.styleSheet) {
        const ibase = r.styleSheet.href || base;
        try {
          walk(r.styleSheet.cssRules, ibase);
        } catch {
          scrapeCss(ibase);
        }
      } else if (r.cssRules) walk(r.cssRules, base);
    }
  };
  for (const ss of document.styleSheets) {
    const base = ss.href || location.href;
    try {
      walk(ss.cssRules, base);
    } catch {
      if (ss.href) scrapeCss(ss.href);
    }
  }
  while (pending.length) await pending.shift();
  const fontCss = (await Promise.all(fontRules.map(async rule => {
    let out = rule.css,
      m;
    const re = /url\((['"]?)([^'")]+)\1\)/g;
    while (m = re.exec(rule.css)) {
      if (m[2].indexOf('data:') === 0) continue;
      let abs;
      try {
        abs = new URL(m[2], rule.base).href;
      } catch {
        continue;
      }
      out = out.split(m[0]).join('url("' + (await toDataURL(abs)) + '")');
    }
    return out;
  }))).join('\n');
  const cloneStyled = src => {
    if (src.nodeType === 8 || src.nodeType === 1 && src.tagName === 'SCRIPT') return document.createTextNode('');
    const dst = src.cloneNode(false);
    if (src.nodeType === 1) {
      const cs = getComputedStyle(src);
      let txt = '';
      for (let i = 0; i < cs.length; i++) txt += cs[i] + ':' + cs.getPropertyValue(cs[i]) + ';';
      dst.setAttribute('style', txt + 'animation:none;transition:none;');
      if (src.tagName === 'CANVAS') try {
        const im = document.createElement('img');
        im.src = src.toDataURL();
        im.setAttribute('style', txt);
        return im;
      } catch {}
    }
    for (let c = src.firstChild; c; c = c.nextSibling) dst.appendChild(cloneStyled(c));
    return dst;
  };
  const clone = cloneStyled(node);
  clone.setAttribute('xmlns', 'http://www.w3.org/1999/xhtml');
  // Drop the card's own shadow/radius so the export is a flush w×h rect;
  // the artboard's own background (if any) is already in the computed style.
  clone.style.boxShadow = 'none';
  clone.style.borderRadius = '0';
  const jobs = [];
  clone.querySelectorAll('img').forEach(el => {
    const s = el.getAttribute('src');
    if (s && s.indexOf('data:') !== 0) jobs.push(toDataURL(el.src).then(d => el.setAttribute('src', d)));
  });
  [clone, ...clone.querySelectorAll('*')].forEach(el => {
    const bg = el.style.backgroundImage;
    if (!bg) return;
    let m;
    const re = /url\(["']?([^"')]+)["']?\)/g;
    while (m = re.exec(bg)) {
      const tok = m[0],
        url = m[1];
      if (url.indexOf('data:') === 0) continue;
      jobs.push(toDataURL(url).then(d => {
        el.style.backgroundImage = el.style.backgroundImage.split(tok).join('url("' + d + '")');
      }));
    }
  });
  await Promise.all(jobs);
  const xml = new XMLSerializer().serializeToString(clone);
  const save = (blob, ext) => {
    if (!blob) return;
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = name + '.' + ext;
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 1000);
  };
  if (kind === 'html') {
    const html = '<!doctype html><html><head><meta charset="utf-8"><title>' + name + '</title>' + (fontCss ? '<style>' + fontCss + '</style>' : '') + '</head><body style="margin:0">' + xml + '</body></html>';
    return save(new Blob([html], {
      type: 'text/html'
    }), 'html');
  }

  // PNG: the SVG's own width/height must be the output resolution — an
  // <img>-loaded SVG rasterizes at its intrinsic size, so sizing it at 1×
  // and ctx.scale()-ing up would just upscale a 1× bitmap. viewBox maps the
  // w×h foreignObject onto the px·w × px·h SVG canvas so the browser renders
  // the HTML at full resolution.
  const px = 3;
  const svg = '<svg xmlns="http://www.w3.org/2000/svg" width="' + w * px + '" height="' + h * px + '" viewBox="0 0 ' + w + ' ' + h + '"><foreignObject width="' + w + '" height="' + h + '">' + (fontCss ? '<style><![CDATA[' + fontCss + ']]></style>' : '') + xml + '</foreignObject></svg>';
  const img = new Image();
  await new Promise((res, rej) => {
    img.onload = res;
    img.onerror = () => rej(new Error('svg load failed'));
    img.src = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg);
  });
  const cv = document.createElement('canvas');
  cv.width = w * px;
  cv.height = h * px;
  cv.getContext('2d').drawImage(img, 0, 0);
  cv.toBlob(blob => save(blob, 'png'), 'image/png');
}
function DCArtboardFrame({
  sectionId,
  artboard,
  label,
  order,
  onRename,
  onReorder,
  onFocus,
  onDelete
}) {
  const {
    id: rawId,
    label: rawLabel,
    width = 260,
    height = 480,
    children,
    style = {}
  } = artboard.props;
  const id = rawId ?? rawLabel;
  const ref = React.useRef(null);
  const cardRef = React.useRef(null);
  const menuRef = React.useRef(null);
  const [menuOpen, setMenuOpen] = React.useState(false);
  const [confirming, setConfirming] = React.useState(false);

  // ⋯ menu: close on any outside pointerdown. Two-click delete lives inside
  // the menu — first click arms the row, second commits; closing disarms.
  React.useEffect(() => {
    if (!menuOpen) {
      setConfirming(false);
      return;
    }
    const off = e => {
      if (!menuRef.current || !menuRef.current.contains(e.target)) setMenuOpen(false);
    };
    document.addEventListener('pointerdown', off, true);
    return () => document.removeEventListener('pointerdown', off, true);
  }, [menuOpen]);
  const doExport = kind => {
    setMenuOpen(false);
    if (!cardRef.current) return;
    const name = String(label || id || 'artboard').replace(/[^\w\s.-]+/g, '_');
    dcExport(cardRef.current, width, height, name, kind).catch(e => console.error('[design-canvas] export failed:', e));
  };

  // Live drag-reorder: dragged card sticks to cursor; siblings slide into
  // their would-be slots in real time via transforms. DOM order only
  // changes on drop.
  const onGripDown = e => {
    e.preventDefault();
    e.stopPropagation();
    const me = ref.current;
    // translateX is applied in local (pre-scale) space but pointer deltas and
    // getBoundingClientRect().left are screen-space — divide by the viewport's
    // current scale so the dragged card tracks the cursor at any zoom level.
    const scale = me.getBoundingClientRect().width / me.offsetWidth || 1;
    const peers = Array.from(document.querySelectorAll(`[data-dc-section="${sectionId}"] [data-dc-slot]`));
    const homes = peers.map(el => ({
      el,
      id: el.dataset.dcSlot,
      x: el.getBoundingClientRect().left
    }));
    const slotXs = homes.map(h => h.x);
    const startIdx = order.indexOf(id);
    const startX = e.clientX;
    let liveOrder = order.slice();
    me.classList.add('dc-dragging');
    const layout = () => {
      for (const h of homes) {
        if (h.id === id) continue;
        const slot = liveOrder.indexOf(h.id);
        h.el.style.transform = `translateX(${(slotXs[slot] - h.x) / scale}px)`;
      }
    };
    const move = ev => {
      const dx = ev.clientX - startX;
      me.style.transform = `translateX(${dx / scale}px)`;
      const cur = homes[startIdx].x + dx;
      let nearest = 0,
        best = Infinity;
      for (let i = 0; i < slotXs.length; i++) {
        const d = Math.abs(slotXs[i] - cur);
        if (d < best) {
          best = d;
          nearest = i;
        }
      }
      if (liveOrder.indexOf(id) !== nearest) {
        liveOrder = order.filter(k => k !== id);
        liveOrder.splice(nearest, 0, id);
        layout();
      }
    };
    const up = () => {
      document.removeEventListener('pointermove', move);
      document.removeEventListener('pointerup', up);
      const finalSlot = liveOrder.indexOf(id);
      me.classList.remove('dc-dragging');
      me.style.transform = `translateX(${(slotXs[finalSlot] - homes[startIdx].x) / scale}px)`;
      // After the settle transition, kill transitions + clear transforms +
      // commit the reorder in the same frame so there's no visual snap-back.
      setTimeout(() => {
        for (const h of homes) {
          h.el.style.transition = 'none';
          h.el.style.transform = '';
        }
        if (liveOrder.join('|') !== order.join('|')) onReorder(liveOrder);
        requestAnimationFrame(() => requestAnimationFrame(() => {
          for (const h of homes) h.el.style.transition = '';
        }));
      }, 180);
    };
    document.addEventListener('pointermove', move);
    document.addEventListener('pointerup', up);
  };
  return /*#__PURE__*/React.createElement("div", {
    ref: ref,
    "data-dc-slot": id,
    style: {
      position: 'relative',
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "dc-header",
    style: {
      color: DC.label
    },
    onPointerDown: e => e.stopPropagation()
  }, /*#__PURE__*/React.createElement("div", {
    className: "dc-labelrow"
  }, /*#__PURE__*/React.createElement("div", {
    className: "dc-grip",
    onPointerDown: onGripDown,
    title: "Drag to reorder"
  }, /*#__PURE__*/React.createElement("svg", {
    width: "9",
    height: "13",
    viewBox: "0 0 9 13",
    fill: "currentColor"
  }, /*#__PURE__*/React.createElement("circle", {
    cx: "2",
    cy: "2",
    r: "1.1"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "7",
    cy: "2",
    r: "1.1"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "2",
    cy: "6.5",
    r: "1.1"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "7",
    cy: "6.5",
    r: "1.1"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "2",
    cy: "11",
    r: "1.1"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "7",
    cy: "11",
    r: "1.1"
  }))), /*#__PURE__*/React.createElement("div", {
    className: "dc-labeltext",
    onClick: onFocus,
    title: "Click to focus"
  }, /*#__PURE__*/React.createElement(DCEditable, {
    value: label,
    onChange: onRename,
    onClick: e => e.stopPropagation(),
    style: {
      fontSize: 15,
      fontWeight: 500,
      color: DC.label,
      lineHeight: 1
    }
  }))), /*#__PURE__*/React.createElement("div", {
    className: "dc-btns"
  }, /*#__PURE__*/React.createElement("div", {
    ref: menuRef,
    style: {
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement("button", {
    className: "dc-kebab",
    title: "More",
    onClick: () => setMenuOpen(o => !o)
  }, /*#__PURE__*/React.createElement("svg", {
    width: "12",
    height: "12",
    viewBox: "0 0 12 12",
    fill: "currentColor"
  }, /*#__PURE__*/React.createElement("circle", {
    cx: "2.5",
    cy: "6",
    r: "1.1"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "6",
    cy: "6",
    r: "1.1"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "9.5",
    cy: "6",
    r: "1.1"
  }))), menuOpen && /*#__PURE__*/React.createElement("div", {
    className: "dc-menu",
    onPointerDown: e => e.stopPropagation()
  }, /*#__PURE__*/React.createElement("button", {
    onClick: () => doExport('png')
  }, "Download PNG"), /*#__PURE__*/React.createElement("button", {
    onClick: () => doExport('html')
  }, "Download HTML"), /*#__PURE__*/React.createElement("hr", null), /*#__PURE__*/React.createElement("button", {
    className: "dc-danger",
    onClick: () => {
      if (confirming) {
        setMenuOpen(false);
        onDelete();
      } else setConfirming(true);
    }
  }, confirming ? 'Click again to delete' : 'Delete'))), /*#__PURE__*/React.createElement("button", {
    className: "dc-expand",
    onClick: onFocus,
    title: "Focus"
  }, /*#__PURE__*/React.createElement("svg", {
    width: "12",
    height: "12",
    viewBox: "0 0 12 12",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "1.6",
    strokeLinecap: "round"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M7 1h4v4M5 11H1V7M11 1L7.5 4.5M1 11l3.5-3.5"
  }))))), /*#__PURE__*/React.createElement("div", {
    ref: cardRef,
    className: "dc-card",
    style: {
      borderRadius: 2,
      boxShadow: '0 1px 3px rgba(0,0,0,.08),0 4px 16px rgba(0,0,0,.06)',
      overflow: 'hidden',
      width,
      height,
      background: '#fff',
      ...style
    }
  }, children || /*#__PURE__*/React.createElement("div", {
    style: {
      height: '100%',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      color: '#bbb',
      fontSize: 13,
      fontFamily: DC.font
    }
  }, id)));
}

// Inline rename — commits on blur or Enter.
function DCEditable({
  value,
  onChange,
  style,
  tag = 'span',
  onClick
}) {
  const T = tag;
  return /*#__PURE__*/React.createElement(T, {
    className: "dc-editable",
    contentEditable: true,
    suppressContentEditableWarning: true,
    onClick: onClick,
    onPointerDown: e => e.stopPropagation(),
    onBlur: e => onChange && onChange(e.currentTarget.textContent),
    onKeyDown: e => {
      if (e.key === 'Enter') {
        e.preventDefault();
        e.currentTarget.blur();
      }
    },
    style: style
  }, value);
}

// ─────────────────────────────────────────────────────────────
// Focus mode — overlay one artboard; ←/→ within section, ↑/↓ across
// sections, Esc or backdrop click to exit.
// ─────────────────────────────────────────────────────────────
function DCFocusOverlay({
  entry,
  sectionMeta,
  sectionOrder
}) {
  const ctx = React.useContext(DCCtx);
  const {
    sectionId,
    artboard
  } = entry;
  const sec = ctx.section(sectionId);
  const meta = sectionMeta[sectionId];
  const peers = meta.slotIds;
  const aid = artboard.props.id ?? artboard.props.label;
  const idx = peers.indexOf(aid);
  const secIdx = sectionOrder.indexOf(sectionId);
  const go = d => {
    const n = peers[(idx + d + peers.length) % peers.length];
    if (n) ctx.setFocus(`${sectionId}/${n}`);
  };
  const goSection = d => {
    // Sections whose artboards are all deleted have slotIds:[] — step past
    // them to the next non-empty section so ↑/↓ doesn't dead-end.
    const n = sectionOrder.length;
    for (let i = 1; i < n; i++) {
      const ns = sectionOrder[((secIdx + d * i) % n + n) % n];
      const first = sectionMeta[ns] && sectionMeta[ns].slotIds[0];
      if (first) {
        ctx.setFocus(`${ns}/${first}`);
        return;
      }
    }
  };
  React.useEffect(() => {
    const k = e => {
      if (e.key === 'ArrowLeft') {
        e.preventDefault();
        go(-1);
      }
      if (e.key === 'ArrowRight') {
        e.preventDefault();
        go(1);
      }
      if (e.key === 'ArrowUp') {
        e.preventDefault();
        goSection(-1);
      }
      if (e.key === 'ArrowDown') {
        e.preventDefault();
        goSection(1);
      }
    };
    document.addEventListener('keydown', k);
    return () => document.removeEventListener('keydown', k);
  });
  const {
    width = 260,
    height = 480,
    children
  } = artboard.props;
  const [vp, setVp] = React.useState({
    w: window.innerWidth,
    h: window.innerHeight
  });
  React.useEffect(() => {
    const r = () => setVp({
      w: window.innerWidth,
      h: window.innerHeight
    });
    window.addEventListener('resize', r);
    return () => window.removeEventListener('resize', r);
  }, []);
  const scale = Math.max(0.1, Math.min((vp.w - 200) / width, (vp.h - 260) / height, 2));
  const [ddOpen, setDd] = React.useState(false);
  const Arrow = ({
    dir,
    onClick
  }) => /*#__PURE__*/React.createElement("button", {
    onClick: e => {
      e.stopPropagation();
      onClick();
    },
    style: {
      position: 'absolute',
      top: '50%',
      [dir]: 28,
      transform: 'translateY(-50%)',
      border: 'none',
      background: 'rgba(255,255,255,.08)',
      color: 'rgba(255,255,255,.9)',
      width: 44,
      height: 44,
      borderRadius: 22,
      fontSize: 18,
      cursor: 'pointer',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      transition: 'background .15s'
    },
    onMouseEnter: e => e.currentTarget.style.background = 'rgba(255,255,255,.18)',
    onMouseLeave: e => e.currentTarget.style.background = 'rgba(255,255,255,.08)'
  }, /*#__PURE__*/React.createElement("svg", {
    width: "18",
    height: "18",
    viewBox: "0 0 18 18",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2",
    strokeLinecap: "round"
  }, /*#__PURE__*/React.createElement("path", {
    d: dir === 'left' ? 'M11 3L5 9l6 6' : 'M7 3l6 6-6 6'
  })));

  // Portal to body so position:fixed is the real viewport regardless of any
  // transform on DesignCanvas's ancestors (including the canvas zoom itself).
  return ReactDOM.createPortal(/*#__PURE__*/React.createElement("div", {
    onClick: () => ctx.setFocus(null),
    onWheel: e => e.preventDefault(),
    style: {
      position: 'fixed',
      inset: 0,
      zIndex: 100,
      background: 'rgba(24,20,16,.6)',
      backdropFilter: 'blur(14px)',
      fontFamily: DC.font,
      color: '#fff'
    }
  }, /*#__PURE__*/React.createElement("div", {
    onClick: e => e.stopPropagation(),
    style: {
      position: 'absolute',
      top: 0,
      left: 0,
      right: 0,
      height: 72,
      display: 'flex',
      alignItems: 'flex-start',
      padding: '16px 20px 0',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement("button", {
    onClick: () => setDd(o => !o),
    style: {
      border: 'none',
      background: 'transparent',
      color: '#fff',
      cursor: 'pointer',
      padding: '6px 8px',
      borderRadius: 6,
      textAlign: 'left',
      fontFamily: 'inherit'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 18,
      fontWeight: 600,
      letterSpacing: -0.3
    }
  }, meta.title), /*#__PURE__*/React.createElement("svg", {
    width: "11",
    height: "11",
    viewBox: "0 0 11 11",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "1.8",
    strokeLinecap: "round",
    style: {
      opacity: .7
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M2 4l3.5 3.5L9 4"
  }))), meta.subtitle && /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'block',
      fontSize: 13,
      opacity: .6,
      fontWeight: 400,
      marginTop: 2
    }
  }, meta.subtitle)), ddOpen && /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: '100%',
      left: 0,
      marginTop: 4,
      background: '#2a251f',
      borderRadius: 8,
      boxShadow: '0 8px 32px rgba(0,0,0,.4)',
      padding: 4,
      minWidth: 200,
      zIndex: 10
    }
  }, sectionOrder.filter(sid => sectionMeta[sid].slotIds.length).map(sid => /*#__PURE__*/React.createElement("button", {
    key: sid,
    onClick: () => {
      setDd(false);
      const f = sectionMeta[sid].slotIds[0];
      if (f) ctx.setFocus(`${sid}/${f}`);
    },
    style: {
      display: 'block',
      width: '100%',
      textAlign: 'left',
      border: 'none',
      cursor: 'pointer',
      background: sid === sectionId ? 'rgba(255,255,255,.1)' : 'transparent',
      color: '#fff',
      padding: '8px 12px',
      borderRadius: 5,
      fontSize: 14,
      fontWeight: sid === sectionId ? 600 : 400,
      fontFamily: 'inherit'
    }
  }, sectionMeta[sid].title)))), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }), /*#__PURE__*/React.createElement("button", {
    onClick: () => ctx.setFocus(null),
    onMouseEnter: e => e.currentTarget.style.background = 'rgba(255,255,255,.12)',
    onMouseLeave: e => e.currentTarget.style.background = 'transparent',
    style: {
      border: 'none',
      background: 'transparent',
      color: 'rgba(255,255,255,.7)',
      width: 32,
      height: 32,
      borderRadius: 16,
      fontSize: 20,
      cursor: 'pointer',
      lineHeight: 1,
      transition: 'background .12s'
    }
  }, "\xD7")), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: 64,
      bottom: 56,
      left: 100,
      right: 100,
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    onClick: e => e.stopPropagation(),
    style: {
      width: width * scale,
      height: height * scale,
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width,
      height,
      transform: `scale(${scale})`,
      transformOrigin: 'top left',
      background: '#fff',
      borderRadius: 2,
      overflow: 'hidden',
      boxShadow: '0 20px 80px rgba(0,0,0,.4)'
    }
  }, children || /*#__PURE__*/React.createElement("div", {
    style: {
      height: '100%',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      color: '#bbb'
    }
  }, aid))), /*#__PURE__*/React.createElement("div", {
    onClick: e => e.stopPropagation(),
    style: {
      fontSize: 14,
      fontWeight: 500,
      opacity: .85,
      textAlign: 'center'
    }
  }, (sec.labels || {})[aid] ?? artboard.props.label, /*#__PURE__*/React.createElement("span", {
    style: {
      opacity: .5,
      marginLeft: 10,
      fontVariantNumeric: 'tabular-nums'
    }
  }, idx + 1, " / ", peers.length))), /*#__PURE__*/React.createElement(Arrow, {
    dir: "left",
    onClick: () => go(-1)
  }), /*#__PURE__*/React.createElement(Arrow, {
    dir: "right",
    onClick: () => go(1)
  }), /*#__PURE__*/React.createElement("div", {
    onClick: e => e.stopPropagation(),
    style: {
      position: 'absolute',
      bottom: 20,
      left: '50%',
      transform: 'translateX(-50%)',
      display: 'flex',
      gap: 8
    }
  }, peers.map((p, i) => /*#__PURE__*/React.createElement("button", {
    key: p,
    onClick: () => ctx.setFocus(`${sectionId}/${p}`),
    style: {
      border: 'none',
      padding: 0,
      cursor: 'pointer',
      width: 6,
      height: 6,
      borderRadius: 3,
      background: i === idx ? '#fff' : 'rgba(255,255,255,.3)'
    }
  })))), document.body);
}

// ─────────────────────────────────────────────────────────────
// Post-it — absolute-positioned sticky note
// ─────────────────────────────────────────────────────────────
function DCPostIt({
  children,
  top,
  left,
  right,
  bottom,
  rotate = -2,
  width = 180
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top,
      left,
      right,
      bottom,
      width,
      background: DC.postitBg,
      padding: '14px 16px',
      fontFamily: '"Comic Sans MS", "Marker Felt", "Segoe Print", cursive',
      fontSize: 14,
      lineHeight: 1.4,
      color: DC.postitText,
      boxShadow: '0 2px 8px rgba(0,0,0,0.12), 0 1px 2px rgba(0,0,0,0.08)',
      transform: `rotate(${rotate}deg)`,
      zIndex: 5
    }
  }, children);
}
Object.assign(window, {
  DesignCanvas,
  DCSection,
  DCArtboard,
  DCPostIt
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "design-canvas.jsx", error: String((e && e.message) || e) }); }

// home-app.jsx
try { (() => {
/* home-app.jsx — responsive shell, navigation orchestration, build-notes drawer.
 * Exports: FomioHomeApp.
 */
const {
  useState,
  useEffect,
  useRef,
  useCallback
} = React;
const {
  Sidebar,
  BottomTabBar,
  TouchHeader,
  FloatingProfile,
  FilterBar,
  Feed,
  FeedSkeleton,
  FeedEmpty,
  GatedNotice,
  ByteReader,
  HIc,
  FomioMark,
  Avatar
} = window;

/* ── Surface mode (matches the project convention) ───────────── */
function useSurfaceMode(forced) {
  const [mode, setMode] = useState('expanded');
  useEffect(() => {
    if (forced && forced !== 'auto') {
      setMode(forced);
      return;
    }
    const update = () => {
      const w = window.innerWidth;
      if (w >= 1280) setMode('expanded');else if (w >= 1024) setMode('compact-desktop');else if (w >= 768) setMode('rail');else setMode('touch');
    };
    update();
    window.addEventListener('resize', update);
    return () => window.removeEventListener('resize', update);
  }, [forced]);
  return mode;
}
const TAB_TITLES = {
  search: 'Search',
  notifications: 'Notifications',
  write: 'Write',
  bookmarks: 'Bookmarks',
  messages: 'Messages',
  profile: 'Profile'
};
const TAB_ICONS = {
  search: 'search',
  notifications: 'bell',
  write: 'feather',
  bookmarks: 'bookmark',
  messages: 'mail',
  profile: 'user'
};
function Placeholder({
  tab,
  data
}) {
  const isTeret = tab.indexOf('teret:') === 0;
  let title = TAB_TITLES[tab] || 'Section';
  let icon = TAB_ICONS[tab] || 'home';
  let line = 'This surface is stubbed in the prototype — Home is the focus of this build.';
  if (isTeret) {
    const t = data.pinnedTerets.find(x => x.key === tab.split(':')[1]);
    title = t ? t.label : 'Teret';
    icon = 'home';
    line = t ? `${t.count} bytes in ${t.hub} → ${t.label}. Opens a filtered chronological feed.` : line;
  }
  return /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'center',
      padding: '72px 24px',
      maxWidth: 420,
      margin: '0 auto'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 56,
      height: 56,
      borderRadius: 16,
      background: 'var(--fomio-surface)',
      border: '1px solid var(--fomio-border)',
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      marginBottom: 18
    }
  }, /*#__PURE__*/React.createElement(HIc, {
    name: icon,
    size: 26,
    color: "var(--fomio-fg-muted)",
    stroke: 1.6
  })), /*#__PURE__*/React.createElement("h3", {
    style: {
      margin: '0 0 8px',
      fontFamily: 'var(--fomio-serif)',
      fontWeight: 700,
      fontSize: 24,
      letterSpacing: '-0.02em',
      color: 'var(--fomio-fg)'
    }
  }, title), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontFamily: 'var(--fomio-serif)',
      fontSize: 15,
      lineHeight: 1.6,
      color: 'var(--fomio-fg-muted)'
    }
  }, line));
}

/* ── Build notes drawer (Expo tree + micro-interactions) ─────── */
const EXPO_TREE = [['<HomeScreen>', 0, 'SafeAreaView · useWindowDimensions → surface mode'], ['<NavigationShell>', 1, 'switches Sidebar ⇆ BottomTabBar by breakpoint'], ['<Sidebar>  (≥768)', 2, 'Animated.View, width 72⇆252 spring'], ['<BrandMark> + <RailToggle>', 3, ''], ['<NavSection primary>', 3, 'Home · Search · Notifications · Write'], ['<NavSection user="sidebar_sections.json">', 3, 'reorderable: Bookmarks · Messages'], ['<PinnedTerets>', 3, 'FlatList of category links'], ['<FloatingProfile>', 3, 'elevated, presence dot — session/current.json'], ['<BottomTabBar>  (<768)', 2, 'BlurView · Reanimated translateY on scroll'], ['<ComposeFAB center>', 3, 'terracotta, haptic on press'], ['<ProfileTab>', 3, 'avatar + presence, ring when active'], ['<FeedScreen>', 1, 'FlashList · pull-to-refresh · chronological'], ['<FilterChips>', 2, 'Latest · Hot · Unread (gated when logged out)'], ['<FeedLayout variant>', 2, 'DenseList | Newspaper | Masonry'], ['<ByteRow> / <ByteCard>', 3, 'press → navigation.navigate("Byte")'], ['<FeedStates>', 2, 'Skeleton · Empty · PermissionNotice']];
const MICRO_NOTES = [['Rail ⇆ full', 'Sidebar width springs 72→252 (cubic-bezier 0.22,0.61,0.36,1, ~220ms). Labels cross-fade in after 60ms; icons hold position so the eye tracks one anchor. Active item keeps its 3px terracotta marker through the transition.'], ['Tab bar on scroll', 'Scroll down → bar translates +140% off-screen (300ms); scroll up or settle → springs back. Touch header mirrors it upward. Reading gets the full height; chrome returns the instant you reach for it.'], ['Floating profile', 'Rests on a soft shadow, not a flat row. Press lifts it 2px and deepens the shadow; the green presence dot is the only always-on color besides the brand arc. Long-press → quick account switch.'], ['Compose FAB', 'Single terracotta moment in the tab bar. Light haptic on press, scales to 0.94, opens the composer as a sheet (not a route push) so the feed stays warm underneath.'], ['Filter chips', 'Active chip fills terracotta; switching cross-fades the list (FadeIn.delay(i*50)). Unread while logged out shows a lock and routes to the permission notice instead of an empty list.'], ['Reduced motion', 'prefers-reduced-motion swaps every spring/translate for an instant state change. Nothing decorative survives the switch — motion only ever confirmed a cause.']];
function BuildNotes({
  open,
  onClose
}) {
  const [view, setView] = useState('tree');
  if (!open) return null;
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    onClick: onClose,
    style: {
      position: 'fixed',
      inset: 0,
      zIndex: 200,
      background: 'rgba(20,14,10,0.32)',
      backdropFilter: 'blur(2px)'
    }
  }), /*#__PURE__*/React.createElement("aside", {
    style: {
      position: 'fixed',
      top: 0,
      right: 0,
      bottom: 0,
      width: 'min(440px, 92vw)',
      zIndex: 201,
      background: 'var(--fomio-bg)',
      borderLeft: '1px solid var(--fomio-border)',
      boxShadow: '-24px 0 80px -36px rgba(0,0,0,0.4)',
      display: 'flex',
      flexDirection: 'column'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12,
      padding: '20px 22px 16px',
      borderBottom: '1px solid var(--fomio-border)'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--fomio-serif)',
      fontWeight: 700,
      fontSize: 19,
      fontStyle: 'italic',
      letterSpacing: '-0.02em',
      color: 'var(--fomio-fg)'
    }
  }, "Build notes"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--fomio-sans)',
      fontSize: 11.5,
      color: 'var(--fomio-fg-muted)',
      marginTop: 2
    }
  }, "Expo hierarchy & micro-interactions")), /*#__PURE__*/React.createElement("button", {
    onClick: onClose,
    style: {
      marginLeft: 'auto',
      width: 32,
      height: 32,
      borderRadius: 9,
      border: 'none',
      cursor: 'pointer',
      background: 'var(--fomio-surface)',
      color: 'var(--fomio-fg-muted)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center'
    }
  }, /*#__PURE__*/React.createElement(HIc, {
    name: "x",
    size: 16,
    color: "currentColor"
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 0,
      padding: '12px 22px 0'
    }
  }, [['tree', 'Expo tree', 'code'], ['micro', 'Micro-interactions', 'sparkle']].map(([k, l, ic]) => /*#__PURE__*/React.createElement("button", {
    key: k,
    onClick: () => setView(k),
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 7,
      height: 36,
      padding: '0 14px',
      background: 'transparent',
      border: 'none',
      borderBottom: view === k ? '2px solid var(--fomio-primary)' : '2px solid transparent',
      marginBottom: -1,
      cursor: 'pointer',
      fontFamily: 'var(--fomio-sans)',
      fontSize: 13,
      fontWeight: view === k ? 700 : 500,
      color: view === k ? 'var(--fomio-primary)' : 'var(--fomio-fg-muted)'
    }
  }, /*#__PURE__*/React.createElement(HIc, {
    name: ic,
    size: 15,
    color: "currentColor",
    stroke: 1.8
  }), " ", l))), /*#__PURE__*/React.createElement("div", {
    style: {
      borderTop: '1px solid var(--fomio-border)',
      flex: 1,
      overflowY: 'auto',
      padding: '20px 22px 32px'
    }
  }, view === 'tree' ? /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--fomio-mono)',
      fontSize: 12.5,
      lineHeight: 1.5
    }
  }, EXPO_TREE.map(([name, depth, note], i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      display: 'flex',
      flexDirection: 'column',
      padding: '5px 0 5px',
      paddingLeft: depth * 16,
      borderLeft: depth > 0 ? '1px solid var(--fomio-border)' : 'none',
      marginLeft: depth > 0 ? 4 : 0
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: name.indexOf('Floating') > -1 || name.indexOf('FAB') > -1 || name.indexOf('BlurView') > -1 || name.indexOf('Compose') > -1 ? 'var(--fomio-primary-dark)' : 'var(--fomio-fg)',
      fontWeight: 700
    }
  }, name), note && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--fomio-sans)',
      fontSize: 11.5,
      color: 'var(--fomio-fg-muted)',
      marginTop: 2
    }
  }, note)))) : /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 18
    }
  }, MICRO_NOTES.map(([title, body], i) => /*#__PURE__*/React.createElement("div", {
    key: i
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      marginBottom: 5
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 6,
      height: 6,
      borderRadius: '50%',
      background: 'var(--fomio-primary)'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--fomio-sans)',
      fontWeight: 700,
      fontSize: 13.5,
      color: 'var(--fomio-fg)'
    }
  }, title)), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      paddingLeft: 14,
      fontFamily: 'var(--fomio-serif)',
      fontSize: 14,
      lineHeight: 1.6,
      color: 'var(--fomio-fg-muted)'
    }
  }, body)))))));
}

/* ── Main app ────────────────────────────────────────────────── */
function FomioHomeApp({
  tweaks
}) {
  const data = window.HOME_DATA;
  const forced = tweaks.surfaceMode || 'auto';
  const mode = useSurfaceMode(forced);
  const isDark = !!tweaks.darkMode;
  const layout = tweaks.feedLayout || 'dense';
  const feedState = tweaks.feedState || 'populated';
  const loggedOut = (tweaks.auth || 'in') === 'out';
  const [tab, setTab] = useState('home');
  const [openByte, setOpenByte] = useState(null);
  const [filter, setFilter] = useState('latest');
  const [railManual, setRailManual] = useState(false);
  const [chromeHidden, setChromeHidden] = useState(false);
  const [notesOpen, setNotesOpen] = useState(false);
  const lastScroll = useRef(0);
  useEffect(() => {
    document.documentElement.setAttribute('data-theme', isDark ? 'dark' : 'light');
  }, [isDark]);

  // Gated unread when logged out
  const gatedUnread = loggedOut;
  const showGate = filter === 'unread' && loggedOut;
  const onNav = useCallback(key => {
    setOpenByte(null);
    if (key === 'write') {
      setTab('write');
      return;
    }
    setTab(key);
  }, []);
  const onOpenByte = useCallback(b => {
    setOpenByte(b);
    window.scrollTo(0, 0);
  }, []);

  // Touch scroll → hide chrome
  const onScroll = useCallback(e => {
    const y = e.target.scrollTop;
    const dy = y - lastScroll.current;
    if (Math.abs(dy) > 6) {
      setChromeHidden(dy > 0 && y > 40);
      lastScroll.current = y;
    }
  }, []);
  const isTouch = mode === 'touch';
  const rail = !isTouch && (mode === 'rail' || railManual);
  const canToggleRail = mode === 'compact-desktop' || mode === 'expanded';

  // ── Main content (feed or reader or placeholder) ──
  let body;
  if (openByte) {
    body = /*#__PURE__*/React.createElement(ByteReader, {
      byte: openByte,
      onBack: () => setOpenByte(null),
      narrow: isTouch || mode === 'rail'
    });
  } else if (tab !== 'home' && tab.indexOf('teret:') !== 0) {
    body = /*#__PURE__*/React.createElement(Placeholder, {
      tab: tab,
      data: data
    });
  } else {
    const header = /*#__PURE__*/React.createElement("div", {
      style: {
        marginBottom: 22
      }
    }, !isTouch && /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'baseline',
        gap: 12,
        marginBottom: 4
      }
    }, /*#__PURE__*/React.createElement("h1", {
      style: {
        margin: 0,
        fontFamily: 'var(--fomio-serif)',
        fontWeight: 700,
        fontSize: mode === 'expanded' ? 30 : 26,
        letterSpacing: '-0.025em',
        color: 'var(--fomio-fg)'
      }
    }, tab.indexOf('teret:') === 0 ? (data.pinnedTerets.find(t => t.key === tab.split(':')[1]) || {}).label : 'Latest'), /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--fomio-sans)',
        fontSize: 12,
        fontWeight: 600,
        letterSpacing: '0.04em',
        textTransform: 'uppercase',
        color: 'var(--fomio-fg-muted)'
      }
    }, "Your hub \xB7 Monday morning")));
    const chips = /*#__PURE__*/React.createElement("div", {
      style: {
        marginBottom: 24,
        position: 'sticky',
        top: isTouch ? 0 : 0,
        zIndex: 5
      }
    }, /*#__PURE__*/React.createElement(FilterBar, {
      filter: filter,
      setFilter: setFilter,
      gatedUnread: gatedUnread,
      onMarkRead: () => {}
    }));
    let feedBody;
    if (showGate) feedBody = /*#__PURE__*/React.createElement(GatedNotice, null);else if (feedState === 'loading') feedBody = /*#__PURE__*/React.createElement(FeedSkeleton, {
      layout: layout,
      mode: mode
    });else if (feedState === 'empty') feedBody = /*#__PURE__*/React.createElement(FeedEmpty, {
      onCompose: () => setTab('write')
    });else feedBody = /*#__PURE__*/React.createElement(Feed, {
      layout: layout,
      bytes: data.bytes,
      onOpen: onOpenByte,
      mode: mode
    });
    body = /*#__PURE__*/React.createElement(React.Fragment, null, header, chips, feedBody);
  }
  const maxW = layout === 'newspaper' ? 940 : layout === 'masonry' ? 1040 : 720;
  const pad = mode === 'expanded' ? '40px 56px' : mode === 'compact-desktop' ? '36px 40px' : '28px 28px';

  // ── Touch layout ──
  if (isTouch) {
    return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
      style: {
        position: 'fixed',
        inset: 0,
        background: 'var(--fomio-bg)',
        display: 'flex',
        flexDirection: 'column'
      }
    }, /*#__PURE__*/React.createElement(TouchHeader, {
      subtitle: openByte ? null : 'Your hub · Monday morning',
      hidden: chromeHidden && !openByte
    }), /*#__PURE__*/React.createElement("main", {
      onScroll: onScroll,
      style: {
        flex: 1,
        overflowY: 'auto',
        padding: '18px 20px 110px',
        WebkitOverflowScrolling: 'touch'
      }
    }, body), /*#__PURE__*/React.createElement(BottomTabBar, {
      tab: openByte ? 'home' : tab,
      onNav: onNav,
      user: data.user,
      hidden: chromeHidden && !openByte,
      loggedOut: loggedOut
    })), /*#__PURE__*/React.createElement(BuildNotesButton, {
      onClick: () => setNotesOpen(true)
    }), /*#__PURE__*/React.createElement(BuildNotes, {
      open: notesOpen,
      onClose: () => setNotesOpen(false)
    }));
  }

  // ── Desktop / rail layout ──
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      minHeight: '100vh',
      background: 'var(--fomio-bg)'
    }
  }, /*#__PURE__*/React.createElement(Sidebar, {
    data: data,
    rail: rail,
    tab: openByte ? 'home' : tab,
    onNav: onNav,
    onToggleRail: () => setRailManual(v => !v),
    loggedOut: loggedOut,
    canToggle: canToggleRail
  }), /*#__PURE__*/React.createElement("main", {
    style: {
      flex: 1,
      minWidth: 0,
      padding: pad,
      boxSizing: 'border-box'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: maxW,
      margin: '0 auto'
    }
  }, body))), /*#__PURE__*/React.createElement(BuildNotesButton, {
    onClick: () => setNotesOpen(true)
  }), /*#__PURE__*/React.createElement(BuildNotes, {
    open: notesOpen,
    onClose: () => setNotesOpen(false)
  }));
}
function BuildNotesButton({
  onClick
}) {
  return /*#__PURE__*/React.createElement("button", {
    onClick: onClick,
    className: "fh-notesbtn",
    style: {
      position: 'fixed',
      top: 16,
      right: 16,
      zIndex: 150,
      height: 36,
      padding: '0 14px',
      borderRadius: 9999,
      cursor: 'pointer',
      background: 'color-mix(in srgb, var(--fomio-card) 82%, transparent)',
      backdropFilter: 'blur(12px)',
      WebkitBackdropFilter: 'blur(12px)',
      border: '1px solid var(--fomio-border)',
      boxShadow: '0 6px 18px -8px var(--fomio-shadow)',
      display: 'inline-flex',
      alignItems: 'center',
      gap: 7,
      fontFamily: 'var(--fomio-sans)',
      fontSize: 12.5,
      fontWeight: 700,
      color: 'var(--fomio-fg)'
    }
  }, /*#__PURE__*/React.createElement(HIc, {
    name: "code",
    size: 15,
    color: "var(--fomio-primary)",
    stroke: 2
  }), " Build notes");
}
window.FomioHomeApp = FomioHomeApp;
})(); } catch (e) { __ds_ns.__errors.push({ path: "home-app.jsx", error: String((e && e.message) || e) }); }

// home-data.js
try { (() => {
/* home-data.js — Fomio Home screen data
 * Mirrors the shapes the Expo app reads from headless Discourse:
 *   /site.json + /session/current.json  → SITE, USER
 *   /sidebar_sections.json              → NAV (primary) + USER_SECTIONS + PINNED_TERETS
 *   /latest.json | /categories_and_latest.json → BYTES
 * No invented chromatic colors — avatar fills are desaturated earth tones only;
 * teret accents resolve to the single terracotta family per the brand.
 */
window.HOME_DATA = {
  site: {
    name: 'fomio',
    tagline: 'A quiet place to read and write'
  },
  user: {
    name: 'Ismail Z.',
    username: 'ismail',
    initials: 'IZ',
    avatarBg: '#D6C9A8',
    avatarFg: '#5C4A1E',
    unreadNotifs: 3,
    unreadMsgs: 1
  },
  /* /sidebar_sections.json — primary nav (Fomio nouns, not SaaS defaults) */
  navPrimary: [{
    key: 'home',
    label: 'Home',
    icon: 'home'
  }, {
    key: 'search',
    label: 'Search',
    icon: 'search'
  }, {
    key: 'notifications',
    label: 'Notifications',
    icon: 'bell',
    badgeKey: 'unreadNotifs'
  }, {
    key: 'write',
    label: 'Write',
    icon: 'feather',
    accent: true
  }],
  /* User-customizable section — links + pinned terets, reorderable */
  userSections: [{
    key: 'bookmarks',
    label: 'Bookmarks',
    icon: 'bookmark'
  }, {
    key: 'messages',
    label: 'Messages',
    icon: 'mail',
    badgeKey: 'unreadMsgs'
  }],
  pinnedTerets: [{
    key: 'essays',
    label: 'Essays',
    hub: 'Writing',
    count: 128
  }, {
    key: 'quiet',
    label: 'Quiet internet',
    hub: 'Ideas',
    count: 64
  }, {
    key: 'craft',
    label: 'Craft',
    hub: 'Writing',
    count: 211
  }],
  /* /latest.json — chronological, algorithm-free */
  bytes: [{
    id: 1284,
    init: 'JN',
    author: 'Jun Nakamura',
    teret: 'Quiet internet',
    avatarBg: '#C9D6C2',
    avatarFg: '#3E5C3E',
    title: 'The case for chronological feeds',
    excerpt: 'A soft polemic against recommendation engines and why a clock beats a score. The most neutral editor we have is the one that simply puts one thing after another.',
    likes: 127,
    replies: 34,
    views: 902,
    time: '1d',
    read: 9,
    unread: true,
    lead: true,
    cover: true,
    body: ["A clock is a modest instrument. It doesn't know you, doesn't care what you've read before, doesn't try. It puts one thing after another.", "That modesty is a rare posture in software right now. Most feeds lean in. They guess. They correct. They produce the inevitable small hum of being watched.", "We forget that chronology is a choice. It is the most neutral editor we have."]
  }, {
    id: 1283,
    init: 'LM',
    author: 'Lena Marsh',
    teret: 'Essays',
    avatarBg: '#D6C9A8',
    avatarFg: '#5C4A1E',
    title: 'On writing without an audience',
    excerpt: "There's a specific pleasure in opening an app and finding it unchanged — no new tab, no pulsing dot, no urgent nothing.",
    likes: 42,
    replies: 8,
    views: 214,
    time: '3d',
    read: 6,
    unread: true,
    cover: false,
    body: ["There's a specific pleasure in opening an app and finding it unchanged.", "No new tab. No pulsing dot. No urgent nothing demanding to be cleared."]
  }, {
    id: 1280,
    init: 'AR',
    author: 'Ada Reyes',
    teret: 'Craft',
    avatarBg: '#D6BFC9',
    avatarFg: '#5C3E4D',
    title: 'Letters to no one',
    excerpt: 'Notes from a year of writing things only I would read. What changes when the count goes away.',
    likes: 89,
    replies: 12,
    views: 412,
    time: '5h',
    read: 7,
    unread: false,
    cover: true,
    body: ["Notes from a year of writing things only I would read.", "What changes when the count goes away? The sentence slows down. It stops performing."]
  }, {
    id: 1278,
    init: 'PH',
    author: 'Priya Hart',
    teret: 'Essays',
    avatarBg: '#BFCAD6',
    avatarFg: '#3E4A5C',
    title: 'A small pause in a loud year',
    excerpt: "I uninstalled everything. I kept fomio. Here's what a week looked like afterwards.",
    likes: 61,
    replies: 19,
    views: 301,
    time: '2d',
    read: 5,
    unread: false,
    cover: false,
    body: ["I uninstalled everything. I kept fomio.", "Here's what a week looked like afterwards — quieter, and somehow longer."]
  }, {
    id: 1275,
    init: 'TM',
    author: 'Theo Mendez',
    teret: 'Quiet internet',
    avatarBg: '#D6C2C2',
    avatarFg: '#5C3E3E',
    title: 'Notifications are a design failure',
    excerpt: 'Every red dot is a decision someone else made about your attention. A modest proposal for fewer of them.',
    likes: 53,
    replies: 21,
    views: 488,
    time: '4d',
    read: 8,
    unread: false,
    cover: false,
    body: ["Every red dot is a decision someone else made about your attention.", "A modest proposal: fewer of them, and only the ones you asked for."]
  }, {
    id: 1271,
    init: 'SO',
    author: 'Sofia Okonkwo',
    teret: 'Craft',
    avatarBg: '#C7C9D6',
    avatarFg: '#3E3E5C',
    title: 'The paragraph as a unit of thought',
    excerpt: 'Sentences are easy. Paragraphs are where the argument actually lives — and where most drafts quietly fall apart.',
    likes: 74,
    replies: 16,
    views: 357,
    time: '6d',
    read: 11,
    unread: false,
    cover: true,
    body: ["Sentences are easy. Paragraphs are where the argument actually lives.", "It is also where most drafts quietly fall apart."]
  }]
};
})(); } catch (e) { __ds_ns.__errors.push({ path: "home-data.js", error: String((e && e.message) || e) }); }

// home-feed.jsx
try { (() => {
/* home-feed.jsx — the main feed: three editorial layouts, filter bar,
 * complete states (loading / empty / gated), and the byte reading view.
 * Exports: FilterBar, Feed, FeedSkeleton, FeedEmpty, GatedNotice, ByteReader.
 */
const {
  HIc,
  Avatar,
  TeretBadge,
  Chip,
  MetaDot,
  CoverPlaceholder,
  Stat,
  FomioMark
} = window;

/* ── Filter bar: Latest / Hot / Unread + Mark read ───────────── */
function FilterBar({
  filter,
  setFilter,
  gatedUnread,
  onMarkRead
}) {
  const chips = [{
    key: 'latest',
    label: 'Latest'
  }, {
    key: 'hot',
    label: 'Hot'
  }, {
    key: 'unread',
    label: 'Unread',
    gated: gatedUnread
  }];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8,
      overflowX: 'auto',
      scrollbarWidth: 'none',
      flex: 1,
      minWidth: 0
    }
  }, chips.map(c => /*#__PURE__*/React.createElement(Chip, {
    key: c.key,
    label: c.label,
    active: filter === c.key,
    gated: c.gated,
    onClick: () => setFilter(c.key)
  }))), /*#__PURE__*/React.createElement("button", {
    onClick: onMarkRead,
    style: {
      background: 'none',
      border: 'none',
      cursor: 'pointer',
      padding: '0 4px',
      fontFamily: 'var(--fomio-sans)',
      fontSize: 11,
      fontWeight: 700,
      letterSpacing: '0.04em',
      textTransform: 'uppercase',
      color: 'var(--fomio-primary)',
      display: 'inline-flex',
      alignItems: 'center',
      gap: 5,
      whiteSpace: 'nowrap'
    }
  }, /*#__PURE__*/React.createElement(HIc, {
    name: "check",
    size: 15,
    color: "var(--fomio-primary)",
    stroke: 1.8
  }), " Mark read"));
}

/* ── Byte meta row (author · teret · time) ───────────────────── */
function ByteMeta({
  b
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement(Avatar, {
    user: b,
    size: 22
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--fomio-sans)',
      fontWeight: 600,
      fontSize: 12.5,
      color: 'var(--fomio-fg)',
      whiteSpace: 'nowrap'
    }
  }, b.author), /*#__PURE__*/React.createElement(MetaDot, null), /*#__PURE__*/React.createElement(TeretBadge, {
    label: b.teret
  }), /*#__PURE__*/React.createElement(MetaDot, null), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--fomio-sans)',
      fontSize: 12,
      color: 'var(--fomio-fg-muted)'
    }
  }, b.time));
}
function ByteStats({
  b
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement(Stat, {
    icon: "heart",
    value: b.likes,
    active: b.unread
  }), /*#__PURE__*/React.createElement(Stat, {
    icon: "reply",
    value: b.replies
  }), /*#__PURE__*/React.createElement(Stat, {
    icon: "eye",
    value: b.views
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--fomio-sans)',
      fontSize: 12,
      fontWeight: 600,
      color: 'var(--fomio-fg-muted)'
    }
  }, b.read, " min read"));
}

/* ════════════ LAYOUT 1 — Dense editorial list ════════════════ */
function DenseList({
  bytes,
  onOpen
}) {
  return /*#__PURE__*/React.createElement("div", null, bytes.map((b, i) => {
    const lead = i === 0;
    return /*#__PURE__*/React.createElement("article", {
      key: b.id,
      className: "fh-row",
      onClick: () => onOpen(b),
      style: {
        display: 'flex',
        gap: 18,
        alignItems: 'flex-start',
        padding: lead ? '4px 0 26px' : '22px 0',
        borderBottom: '1px solid var(--fomio-border)'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        width: 6,
        paddingTop: 7,
        flexShrink: 0
      }
    }, b.unread && /*#__PURE__*/React.createElement("span", {
      style: {
        width: 7,
        height: 7,
        borderRadius: '50%',
        background: 'var(--fomio-primary)',
        display: 'block'
      }
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        minWidth: 0
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        marginBottom: 9
      }
    }, /*#__PURE__*/React.createElement(ByteMeta, {
      b: b
    })), /*#__PURE__*/React.createElement("h3", {
      className: "fh-title",
      style: {
        margin: '0 0 6px',
        fontFamily: 'var(--fomio-serif)',
        fontWeight: 700,
        fontSize: lead ? 27 : 20,
        lineHeight: 1.25,
        letterSpacing: '-0.02em',
        color: 'var(--fomio-fg)',
        textWrap: 'pretty'
      }
    }, b.title), /*#__PURE__*/React.createElement("p", {
      style: {
        margin: '0 0 13px',
        fontFamily: 'var(--fomio-serif)',
        fontSize: lead ? 16 : 14.5,
        lineHeight: 1.55,
        color: 'var(--fomio-fg-muted)',
        display: '-webkit-box',
        WebkitLineClamp: lead ? 3 : 2,
        WebkitBoxOrient: 'vertical',
        overflow: 'hidden',
        textWrap: 'pretty'
      }
    }, b.excerpt), /*#__PURE__*/React.createElement(ByteStats, {
      b: b
    })), lead && b.cover && /*#__PURE__*/React.createElement("div", {
      style: {
        width: 168,
        flexShrink: 0
      }
    }, /*#__PURE__*/React.createElement(CoverPlaceholder, {
      height: 132,
      radius: 14
    })));
  }));
}

/* ════════════ LAYOUT 2 — Newspaper column flow ═══════════════ */
function Newspaper({
  bytes,
  onOpen,
  twoCol
}) {
  const lead = bytes[0];
  const rest = bytes.slice(1);
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("article", {
    className: "fh-row",
    onClick: () => onOpen(lead),
    style: {
      paddingBottom: 26,
      marginBottom: 8,
      borderBottom: '2px solid var(--fomio-fg)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 12
    }
  }, /*#__PURE__*/React.createElement(ByteMeta, {
    b: lead
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 28,
      alignItems: 'flex-start',
      flexWrap: twoCol ? 'nowrap' : 'wrap'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("h2", {
    className: "fh-title",
    style: {
      margin: '0 0 12px',
      fontFamily: 'var(--fomio-serif)',
      fontWeight: 700,
      fontSize: twoCol ? 38 : 30,
      lineHeight: 1.12,
      letterSpacing: '-0.03em',
      color: 'var(--fomio-fg)',
      textWrap: 'balance'
    }
  }, lead.title), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '0 0 14px',
      fontFamily: 'var(--fomio-serif)',
      fontSize: 17,
      lineHeight: 1.6,
      color: 'var(--fomio-fg-secondary)',
      textWrap: 'pretty',
      columnCount: twoCol ? 2 : 1,
      columnGap: 28
    }
  }, lead.excerpt), /*#__PURE__*/React.createElement(ByteStats, {
    b: lead
  })), lead.cover && /*#__PURE__*/React.createElement("div", {
    style: {
      width: twoCol ? 280 : '100%',
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement(CoverPlaceholder, {
    height: twoCol ? 200 : 160,
    radius: 14,
    label: "lead image"
  })))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: twoCol ? '1fr 1fr' : '1fr',
      columnGap: 32,
      rowGap: 0
    }
  }, rest.map((b, i) => /*#__PURE__*/React.createElement("article", {
    key: b.id,
    className: "fh-row",
    onClick: () => onOpen(b),
    style: {
      padding: '20px 0',
      borderBottom: '1px solid var(--fomio-border)',
      borderTop: twoCol && i < 2 ? 'none' : undefined
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      marginBottom: 8
    }
  }, /*#__PURE__*/React.createElement(TeretBadge, {
    label: b.teret
  }), b.unread && /*#__PURE__*/React.createElement("span", {
    style: {
      width: 6,
      height: 6,
      borderRadius: '50%',
      background: 'var(--fomio-primary)'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      marginLeft: 'auto',
      fontFamily: 'var(--fomio-sans)',
      fontSize: 11.5,
      color: 'var(--fomio-fg-muted)'
    }
  }, b.author, " \xB7 ", b.time)), /*#__PURE__*/React.createElement("h3", {
    className: "fh-title",
    style: {
      margin: '0 0 6px',
      fontFamily: 'var(--fomio-serif)',
      fontWeight: 700,
      fontSize: 19,
      lineHeight: 1.28,
      letterSpacing: '-0.02em',
      color: 'var(--fomio-fg)',
      textWrap: 'pretty'
    }
  }, b.title), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '0 0 10px',
      fontFamily: 'var(--fomio-serif)',
      fontSize: 14,
      lineHeight: 1.5,
      color: 'var(--fomio-fg-muted)',
      display: '-webkit-box',
      WebkitLineClamp: 2,
      WebkitBoxOrient: 'vertical',
      overflow: 'hidden'
    }
  }, b.excerpt), /*#__PURE__*/React.createElement(Stat, {
    icon: "reply",
    value: `${b.replies} replies`
  })))));
}

/* ════════════ LAYOUT 3 — Mixed-weight masonry ════════════════ */
function MasonryCard({
  b,
  feature,
  onOpen
}) {
  return /*#__PURE__*/React.createElement("article", {
    className: "fh-card",
    onClick: () => onOpen(b),
    style: {
      background: 'var(--fomio-card)',
      border: '1px solid var(--fomio-border)',
      borderRadius: 18,
      padding: 18,
      cursor: 'pointer',
      boxSizing: 'border-box'
    }
  }, b.cover && /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 14
    }
  }, /*#__PURE__*/React.createElement(CoverPlaceholder, {
    height: feature ? 150 : 96,
    radius: 12,
    label: feature ? 'cover image' : 'image'
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      marginBottom: 10
    }
  }, /*#__PURE__*/React.createElement(TeretBadge, {
    label: b.teret
  }), b.unread && /*#__PURE__*/React.createElement("span", {
    style: {
      width: 7,
      height: 7,
      borderRadius: '50%',
      background: 'var(--fomio-primary)',
      marginLeft: 'auto'
    }
  })), /*#__PURE__*/React.createElement("h3", {
    className: "fh-title",
    style: {
      margin: '0 0 8px',
      fontFamily: 'var(--fomio-serif)',
      fontWeight: 700,
      fontSize: feature ? 22 : 18,
      lineHeight: 1.25,
      letterSpacing: '-0.02em',
      color: 'var(--fomio-fg)'
    }
  }, b.title), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '0 0 14px',
      fontFamily: 'var(--fomio-serif)',
      fontSize: 14,
      lineHeight: 1.55,
      color: 'var(--fomio-fg-muted)',
      display: '-webkit-box',
      WebkitLineClamp: feature ? 4 : 2,
      WebkitBoxOrient: 'vertical',
      overflow: 'hidden'
    }
  }, b.excerpt), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      paddingTop: 12,
      borderTop: '1px solid var(--fomio-border-soft)'
    }
  }, /*#__PURE__*/React.createElement(Avatar, {
    user: b,
    size: 20
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--fomio-sans)',
      fontSize: 11.5,
      fontWeight: 600,
      color: 'var(--fomio-fg-muted)'
    }
  }, b.author), /*#__PURE__*/React.createElement("span", {
    style: {
      marginLeft: 'auto'
    }
  }, /*#__PURE__*/React.createElement(Stat, {
    icon: "heart",
    value: b.likes
  }))));
}
function Masonry({
  bytes,
  onOpen,
  cols
}) {
  // Distribute into column buckets (round-robin) — avoids CSS-columns quirks.
  const buckets = Array.from({
    length: cols
  }, () => []);
  bytes.forEach((b, i) => buckets[i % cols].push({
    b,
    i
  }));
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 18,
      alignItems: 'flex-start'
    }
  }, buckets.map((bucket, c) => /*#__PURE__*/React.createElement("div", {
    key: c,
    style: {
      flex: 1,
      minWidth: 0,
      display: 'flex',
      flexDirection: 'column',
      gap: 18
    }
  }, bucket.map(({
    b,
    i
  }) => /*#__PURE__*/React.createElement(MasonryCard, {
    key: b.id,
    b: b,
    feature: i === 0,
    onOpen: onOpen
  })))));
}
function Feed({
  layout,
  bytes,
  onOpen,
  mode
}) {
  const expanded = mode === 'expanded';
  const compact = mode === 'compact-desktop';
  const touch = mode === 'touch';
  if (layout === 'newspaper') return /*#__PURE__*/React.createElement(Newspaper, {
    bytes: bytes,
    onOpen: onOpen,
    twoCol: expanded || compact
  });
  if (layout === 'masonry') {
    const cols = touch ? 1 : expanded ? 3 : 2;
    return /*#__PURE__*/React.createElement(Masonry, {
      bytes: bytes,
      onOpen: onOpen,
      cols: cols
    });
  }
  return /*#__PURE__*/React.createElement(DenseList, {
    bytes: bytes,
    onOpen: onOpen
  });
}

/* ════════════ STATES ═════════════════════════════════════════ */
function SkelLine({
  w,
  h = 14,
  mt = 0
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "fh-shimmer",
    style: {
      width: w,
      height: h,
      borderRadius: 6,
      marginTop: mt,
      background: 'var(--fomio-surface)'
    }
  });
}
function FeedSkeleton({
  layout,
  mode
}) {
  const rows = layout === 'masonry' ? Array.from({
    length: 6
  }) : Array.from({
    length: 5
  });
  if (layout === 'masonry') {
    const cols = mode === 'touch' ? 1 : mode === 'expanded' ? 3 : 2;
    return /*#__PURE__*/React.createElement("div", {
      style: {
        columnCount: cols,
        columnGap: 18
      },
      "aria-busy": "true",
      "aria-label": "Loading bytes"
    }, rows.map((_, i) => /*#__PURE__*/React.createElement("div", {
      key: i,
      style: {
        breakInside: 'avoid',
        marginBottom: 18,
        background: 'var(--fomio-card)',
        border: '1px solid var(--fomio-border)',
        borderRadius: 18,
        padding: 18
      }
    }, /*#__PURE__*/React.createElement(SkelLine, {
      w: "40%",
      h: 12
    }), /*#__PURE__*/React.createElement(SkelLine, {
      w: "92%",
      h: 20,
      mt: 14
    }), /*#__PURE__*/React.createElement(SkelLine, {
      w: "100%",
      h: 13,
      mt: 12
    }), /*#__PURE__*/React.createElement(SkelLine, {
      w: "70%",
      h: 13,
      mt: 8
    }))));
  }
  return /*#__PURE__*/React.createElement("div", {
    "aria-busy": "true",
    "aria-label": "Loading bytes"
  }, rows.map((_, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      display: 'flex',
      gap: 18,
      padding: '22px 0',
      borderBottom: '1px solid var(--fomio-border)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 6
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement(SkelLine, {
    w: "46%",
    h: 12
  }), /*#__PURE__*/React.createElement(SkelLine, {
    w: "78%",
    h: 22,
    mt: 14
  }), /*#__PURE__*/React.createElement(SkelLine, {
    w: "100%",
    h: 14,
    mt: 12
  }), /*#__PURE__*/React.createElement(SkelLine, {
    w: "64%",
    h: 14,
    mt: 8
  })))));
}
function FeedEmpty({
  onCompose
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'center',
      padding: '64px 24px',
      maxWidth: 420,
      margin: '0 auto'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 56,
      height: 56,
      borderRadius: 16,
      background: 'var(--fomio-surface)',
      border: '1px solid var(--fomio-border)',
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      marginBottom: 20
    }
  }, /*#__PURE__*/React.createElement(HIc, {
    name: "inbox",
    size: 26,
    color: "var(--fomio-fg-muted)",
    stroke: 1.6
  })), /*#__PURE__*/React.createElement("h3", {
    style: {
      margin: '0 0 8px',
      fontFamily: 'var(--fomio-serif)',
      fontWeight: 700,
      fontSize: 22,
      letterSpacing: '-0.02em',
      color: 'var(--fomio-fg)'
    }
  }, "Nothing new to read"), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '0 0 24px',
      fontFamily: 'var(--fomio-serif)',
      fontSize: 15,
      lineHeight: 1.6,
      color: 'var(--fomio-fg-muted)'
    }
  }, "You're all caught up. No clever feed will conjure more \u2014 that's the point. Write something instead."), /*#__PURE__*/React.createElement("button", {
    onClick: onCompose,
    style: {
      height: 44,
      padding: '0 22px',
      borderRadius: 9999,
      background: 'var(--fomio-primary)',
      color: '#fff',
      border: 'none',
      cursor: 'pointer',
      fontFamily: 'var(--fomio-sans)',
      fontWeight: 700,
      fontSize: 14,
      letterSpacing: '0.01em',
      display: 'inline-flex',
      alignItems: 'center',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement(HIc, {
    name: "feather",
    size: 17,
    color: "#fff",
    stroke: 1.9
  }), " Create byte"));
}
function GatedNotice({
  onDismiss
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 14,
      alignItems: 'flex-start',
      padding: '18px 20px',
      background: 'var(--fomio-card)',
      border: '1px solid var(--fomio-border)',
      borderRadius: 16,
      marginTop: 4
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 38,
      height: 38,
      borderRadius: 11,
      background: 'var(--fomio-primary-soft)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement(HIc, {
    name: "lock",
    size: 18,
    color: "var(--fomio-primary-dark)",
    stroke: 1.8
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--fomio-sans)',
      fontWeight: 700,
      fontSize: 14,
      color: 'var(--fomio-fg)',
      marginBottom: 3
    }
  }, "Log in to use Unread"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--fomio-serif)',
      fontSize: 14,
      lineHeight: 1.5,
      color: 'var(--fomio-fg-muted)'
    }
  }, "Unread tracks what you've already read across devices. It needs an account to remember.")), /*#__PURE__*/React.createElement("button", {
    style: {
      height: 36,
      padding: '0 16px',
      borderRadius: 9999,
      background: 'var(--fomio-primary)',
      color: '#fff',
      border: 'none',
      cursor: 'pointer',
      fontFamily: 'var(--fomio-sans)',
      fontWeight: 700,
      fontSize: 13,
      flexShrink: 0
    }
  }, "Log in"));
}

/* ════════════ BYTE READING VIEW ══════════════════════════════ */
function ByteReader({
  byte,
  onBack,
  narrow
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 680,
      margin: '0 auto'
    }
  }, /*#__PURE__*/React.createElement("button", {
    onClick: onBack,
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 7,
      background: 'none',
      border: 'none',
      cursor: 'pointer',
      padding: '0 0 22px',
      fontFamily: 'var(--fomio-sans)',
      fontSize: 13,
      fontWeight: 600,
      color: 'var(--fomio-fg-muted)'
    }
  }, /*#__PURE__*/React.createElement(HIc, {
    name: "arrowLeft",
    size: 17,
    color: "var(--fomio-fg-muted)"
  }), " Back to feed"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      marginBottom: 18
    }
  }, /*#__PURE__*/React.createElement(TeretBadge, {
    label: byte.teret
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      marginLeft: 'auto',
      fontFamily: 'var(--fomio-sans)',
      fontSize: 12,
      fontWeight: 600,
      color: 'var(--fomio-fg-muted)'
    }
  }, "Byte #", byte.id.toLocaleString())), /*#__PURE__*/React.createElement("h1", {
    style: {
      margin: '0 0 18px',
      fontFamily: 'var(--fomio-serif)',
      fontWeight: 700,
      fontSize: narrow ? 30 : 38,
      lineHeight: 1.14,
      letterSpacing: '-0.03em',
      color: 'var(--fomio-fg)',
      textWrap: 'balance'
    }
  }, byte.title), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12,
      marginBottom: 26,
      paddingBottom: 22,
      borderBottom: '1px solid var(--fomio-border)'
    }
  }, /*#__PURE__*/React.createElement(Avatar, {
    user: byte,
    size: 42
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--fomio-sans)',
      fontWeight: 700,
      fontSize: 14,
      color: 'var(--fomio-fg)'
    }
  }, byte.author), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--fomio-sans)',
      fontSize: 12,
      color: 'var(--fomio-fg-muted)',
      marginTop: 2
    }
  }, "Posted ", byte.time, " ago \xB7 ", byte.read, " min read"))), byte.cover && /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 26
    }
  }, /*#__PURE__*/React.createElement(CoverPlaceholder, {
    height: narrow ? 180 : 280,
    radius: 16
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--fomio-serif)',
      fontSize: 18,
      lineHeight: 1.72,
      color: 'var(--fomio-fg)'
    }
  }, byte.body.map((p, i) => /*#__PURE__*/React.createElement("p", {
    key: i,
    style: {
      margin: i ? '0 0 20px' : '0 0 20px',
      fontStyle: i === byte.body.length - 1 ? 'italic' : 'normal',
      color: i === byte.body.length - 1 ? 'var(--fomio-fg-secondary)' : 'var(--fomio-fg)'
    }
  }, p))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 20,
      marginTop: 32,
      paddingTop: 22,
      borderTop: '1px solid var(--fomio-border)'
    }
  }, /*#__PURE__*/React.createElement(Stat, {
    icon: "heart",
    value: byte.likes,
    active: true
  }), /*#__PURE__*/React.createElement(Stat, {
    icon: "reply",
    value: byte.replies
  }), /*#__PURE__*/React.createElement(Stat, {
    icon: "eye",
    value: byte.views
  }), /*#__PURE__*/React.createElement("button", {
    style: {
      marginLeft: 'auto',
      height: 40,
      padding: '0 20px',
      borderRadius: 9999,
      background: 'var(--fomio-primary)',
      color: '#fff',
      border: 'none',
      cursor: 'pointer',
      fontFamily: 'var(--fomio-sans)',
      fontWeight: 700,
      fontSize: 14
    }
  }, "Reply")));
}
Object.assign(window, {
  FilterBar,
  Feed,
  FeedSkeleton,
  FeedEmpty,
  GatedNotice,
  ByteReader
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "home-feed.jsx", error: String((e && e.message) || e) }); }

// home-icons.jsx
try { (() => {
/* home-icons.jsx — Lucide-style icon set + shared primitives for Fomio Home.
 * Icons are single-path/stroke Lucide glyphs (24x24, 2px stroke, round caps).
 * Exports to window: HIc, FomioMark, Avatar, TeretBadge, Chip, MetaDot,
 *   PresenceDot, CoverPlaceholder, Stat.
 */
const HOME_ICONS = {
  home: 'M3 9.5 12 3l9 6.5V20a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1z',
  search: 'M11 19a8 8 0 1 0 0-16 8 8 0 0 0 0 16z M21 21l-4.3-4.3',
  bell: 'M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9 M13.7 21a2 2 0 0 1-3.4 0',
  feather: 'M20.2 3.8a5.4 5.4 0 0 0-7.6 0L4 12.4V20h7.6l8.6-8.6a5.4 5.4 0 0 0 0-7.6z M16 8 2 22 M17.5 15H9',
  bookmark: 'M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z',
  mail: 'M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z M22 6l-10 7L2 6',
  user: 'M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2 M12 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8z',
  plus: 'M12 5v14 M5 12h14',
  heart: 'M19 14c1.5-1.5 3-3.3 3-5.5A4.5 4.5 0 0 0 12 5 4.5 4.5 0 0 0 2 8.5c0 2.2 1.5 4 3 5.5l7 7z',
  reply: 'M21 11.5a8.4 8.4 0 0 1-9 8.5 8.5 8.5 0 0 1-3.9-.9L3 21l1.9-5.1A8.5 8.5 0 0 1 3 11.5a8.5 8.5 0 0 1 9-8.5 8.4 8.4 0 0 1 9 8.5z',
  eye: 'M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6z',
  check: 'M22 11.1V12a10 10 0 1 1-5.9-9.1 M22 4 12 14.1l-3-3',
  chevronLeft: 'M15 18l-6-6 6-6',
  chevronRight: 'M9 18l6-6-6-6',
  chevronsLeft: 'M11 17l-5-5 5-5 M18 17l-5-5 5-5',
  arrowLeft: 'M19 12H5 M12 19l-7-7 7-7',
  panelLeft: 'M3 4h18v16H3z M9 4v16',
  layout: 'M3 4h18v16H3z M3 9h18 M9 9v11',
  settings: 'M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6z M19.4 15a1.6 1.6 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.6 1.6 0 0 0-2.7 1.2V21a2 2 0 0 1-4 0v-.1A1.6 1.6 0 0 0 9 19.4a1.6 1.6 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.6 1.6 0 0 0-1.2-2.7H3a2 2 0 0 1 0-4h.1A1.6 1.6 0 0 0 4.6 9a1.6 1.6 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.6 1.6 0 0 0 1.8.3H9a1.6 1.6 0 0 0 1-1.5V3a2 2 0 0 1 4 0v.1a1.6 1.6 0 0 0 2.7 1.2l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.6 1.6 0 0 0-.3 1.8V9a1.6 1.6 0 0 0 1.5 1H21a2 2 0 0 1 0 4h-.1a1.6 1.6 0 0 0-1.5 1z',
  plusCircle: 'M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20z M12 8v8 M8 12h8',
  lock: 'M5 11h14v10H5z M8 11V7a4 4 0 0 1 8 0v4',
  edit: 'M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7 M18.5 2.5a2.1 2.1 0 0 1 3 3L12 15l-4 1 1-4z',
  x: 'M18 6 6 18 M6 6l12 12',
  code: 'M16 18l6-6-6-6 M8 6l-6 6 6 6',
  sparkle: 'M12 3v4 M12 17v4 M3 12h4 M17 12h4 M6.3 6.3l2.8 2.8 M14.9 14.9l2.8 2.8 M17.7 6.3l-2.8 2.8 M9.1 14.9l-2.8 2.8',
  inbox: 'M22 12h-6l-2 3h-4l-2-3H2 M5.5 5.1 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.5-6.9A2 2 0 0 0 16.7 4H7.3a2 2 0 0 0-1.8 1.1z'
};
function HIc({
  name,
  size = 20,
  color = 'currentColor',
  stroke = 2,
  fill = 'none',
  style
}) {
  const d = HOME_ICONS[name] || '';
  return /*#__PURE__*/React.createElement("svg", {
    width: size,
    height: size,
    viewBox: "0 0 24 24",
    fill: fill,
    stroke: color,
    strokeWidth: stroke,
    strokeLinecap: "round",
    strokeLinejoin: "round",
    style: {
      display: 'block',
      flexShrink: 0,
      ...style
    },
    "aria-hidden": "true"
  }, d.split(' M').map((seg, i) => /*#__PURE__*/React.createElement("path", {
    key: i,
    d: (i ? 'M' : '') + seg
  })));
}

/* fomio italic-serif wordmark with the single terracotta arc */
function FomioMark({
  size = 24,
  mark = false,
  color = 'var(--fomio-fg)'
}) {
  if (mark) {
    return /*#__PURE__*/React.createElement("span", {
      style: {
        position: 'relative',
        display: 'inline-flex',
        alignItems: 'flex-end'
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--fomio-serif)',
        fontWeight: 700,
        fontStyle: 'italic',
        fontSize: size,
        lineHeight: 1,
        letterSpacing: '-0.03em',
        color
      }
    }, "f"), /*#__PURE__*/React.createElement("svg", {
      width: size * 0.7,
      height: size * 0.28,
      viewBox: "0 0 22 8",
      style: {
        position: 'absolute',
        left: '4%',
        bottom: -size * 0.12
      }
    }, /*#__PURE__*/React.createElement("path", {
      d: "M1 2 Q11 9 21 2",
      stroke: "var(--fomio-primary)",
      strokeWidth: "2.4",
      strokeLinecap: "round",
      fill: "none"
    })));
  }
  return /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'relative',
      display: 'inline-flex',
      alignItems: 'flex-end'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--fomio-serif)',
      fontWeight: 700,
      fontStyle: 'italic',
      fontSize: size,
      lineHeight: 1,
      letterSpacing: '-0.03em',
      color
    }
  }, "fomio"), /*#__PURE__*/React.createElement("svg", {
    width: size * 1.05,
    height: size * 0.3,
    viewBox: "0 0 44 10",
    style: {
      position: 'absolute',
      right: 0,
      bottom: -size * 0.1
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M2 3 Q22 11 42 3",
    stroke: "var(--fomio-primary)",
    strokeWidth: "2.6",
    strokeLinecap: "round",
    fill: "none"
  })));
}
function Avatar({
  user,
  size = 32,
  ring
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      width: size,
      height: size,
      borderRadius: '50%',
      background: user.avatarBg,
      color: user.avatarFg,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontFamily: 'var(--fomio-serif)',
      fontWeight: 700,
      fontStyle: 'italic',
      fontSize: Math.round(size * 0.38),
      flexShrink: 0,
      boxShadow: ring ? '0 0 0 2px var(--fomio-bg), 0 0 0 3.5px var(--fomio-primary)' : 'none'
    }
  }, user.initials || user.init);
}
function PresenceDot({
  size = 10
}) {
  return /*#__PURE__*/React.createElement("span", {
    style: {
      width: size,
      height: size,
      borderRadius: '50%',
      background: '#22C55E',
      border: '2px solid var(--fomio-card)',
      flexShrink: 0
    }
  });
}
function TeretBadge({
  label,
  dim
}) {
  return /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--fomio-sans)',
      fontWeight: 700,
      fontSize: 10,
      letterSpacing: '0.06em',
      textTransform: 'uppercase',
      padding: '3px 9px',
      borderRadius: 9999,
      background: dim ? 'transparent' : 'var(--fomio-primary-soft)',
      color: dim ? 'var(--fomio-fg-muted)' : 'var(--fomio-primary-dark)',
      border: dim ? '1px solid var(--fomio-border)' : 'none',
      whiteSpace: 'nowrap'
    }
  }, label);
}
function Chip({
  label,
  active,
  onClick,
  gated
}) {
  return /*#__PURE__*/React.createElement("button", {
    onClick: onClick,
    style: {
      fontFamily: 'var(--fomio-sans)',
      fontWeight: 600,
      fontSize: 13,
      letterSpacing: '0.01em',
      height: 34,
      padding: '0 15px',
      borderRadius: 9999,
      border: `1.5px solid ${active ? 'var(--fomio-primary)' : 'var(--fomio-border)'}`,
      background: active ? 'var(--fomio-primary)' : 'transparent',
      color: active ? '#fff' : 'var(--fomio-fg)',
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6,
      whiteSpace: 'nowrap',
      cursor: 'pointer',
      transition: 'background 150ms, border-color 150ms'
    }
  }, label, gated && /*#__PURE__*/React.createElement(HIc, {
    name: "lock",
    size: 12,
    color: active ? '#fff' : 'var(--fomio-fg-muted)',
    stroke: 2
  }));
}
function MetaDot() {
  return /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--fomio-fg-muted)',
      fontSize: 11,
      lineHeight: 1
    }
  }, "\xB7");
}

/* Striped placeholder — never a hand-drawn illustration */
function CoverPlaceholder({
  height = 120,
  radius = 12,
  label = 'cover image'
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      height,
      borderRadius: radius,
      overflow: 'hidden',
      position: 'relative',
      background: 'var(--fomio-surface)',
      border: '1px solid var(--fomio-border)',
      backgroundImage: 'repeating-linear-gradient(135deg, transparent, transparent 9px, var(--fomio-border-soft) 9px, var(--fomio-border-soft) 10px)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--fomio-mono)',
      fontSize: 11,
      color: 'var(--fomio-fg-muted)',
      letterSpacing: '0.04em',
      background: 'var(--fomio-bg)',
      padding: '2px 8px',
      borderRadius: 6
    }
  }, label));
}
function Stat({
  icon,
  value,
  active
}) {
  const c = active ? 'var(--fomio-primary)' : 'var(--fomio-fg-muted)';
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 5,
      fontFamily: 'var(--fomio-sans)',
      fontSize: 12,
      fontWeight: 600,
      color: c
    }
  }, /*#__PURE__*/React.createElement(HIc, {
    name: icon,
    size: 15,
    color: c,
    stroke: 1.8,
    fill: active ? c : 'none'
  }), " ", value);
}
Object.assign(window, {
  HIc,
  FomioMark,
  Avatar,
  PresenceDot,
  TeretBadge,
  Chip,
  MetaDot,
  CoverPlaceholder,
  Stat
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "home-icons.jsx", error: String((e && e.message) || e) }); }

// home-nav.jsx
try { (() => {
/* home-nav.jsx — navigation surfaces: collapsible sidebar (full + rail),
 * the floating profile entry point, the touch bottom tab bar, and headers.
 * Exports: Sidebar, FloatingProfile, BottomTabBar, TouchHeader, RailExpandToggle.
 */
const {
  HIc,
  Avatar,
  PresenceDot,
  FomioMark
} = window;

/* ── Floating profile — the distinct, lifted entry point ─────── */
function FloatingProfile({
  user,
  rail,
  loggedOut,
  active,
  onNav
}) {
  if (loggedOut) {
    if (rail) {
      return /*#__PURE__*/React.createElement("button", {
        onClick: () => onNav('profile'),
        title: "Log in",
        className: "fh-profile",
        style: {
          margin: '0 auto',
          width: 44,
          height: 44,
          borderRadius: '50%',
          cursor: 'pointer',
          background: 'var(--fomio-card)',
          border: '1px solid var(--fomio-border)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          boxShadow: '0 6px 18px -6px var(--fomio-shadow)'
        }
      }, /*#__PURE__*/React.createElement(HIc, {
        name: "user",
        size: 20,
        color: "var(--fomio-fg-muted)",
        stroke: 1.8
      }));
    }
    return /*#__PURE__*/React.createElement("button", {
      onClick: () => onNav('profile'),
      className: "fh-profile",
      style: {
        width: '100%',
        textAlign: 'left',
        cursor: 'pointer',
        borderRadius: 16,
        padding: '12px 14px',
        background: 'var(--fomio-card)',
        border: '1px solid var(--fomio-border)',
        boxShadow: '0 10px 28px -12px var(--fomio-shadow)',
        display: 'flex',
        alignItems: 'center',
        gap: 11,
        fontFamily: 'var(--fomio-sans)'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        width: 36,
        height: 36,
        borderRadius: '50%',
        background: 'var(--fomio-surface)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        flexShrink: 0
      }
    }, /*#__PURE__*/React.createElement(HIc, {
      name: "user",
      size: 18,
      color: "var(--fomio-fg-muted)",
      stroke: 1.8
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        minWidth: 0
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 13,
        fontWeight: 700,
        color: 'var(--fomio-fg)'
      }
    }, "Log in"), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 11.5,
        color: 'var(--fomio-fg-muted)'
      }
    }, "Read freely \xB7 write when ready")));
  }
  if (rail) {
    return /*#__PURE__*/React.createElement("button", {
      onClick: () => onNav('profile'),
      title: user.name,
      className: "fh-profile",
      style: {
        position: 'relative',
        margin: '0 auto',
        width: 44,
        height: 44,
        borderRadius: '50%',
        cursor: 'pointer',
        border: 'none',
        padding: 0,
        background: 'transparent',
        boxShadow: active ? '0 0 0 2px var(--fomio-bg), 0 0 0 3.5px var(--fomio-primary)' : '0 8px 20px -6px var(--fomio-shadow)'
      }
    }, /*#__PURE__*/React.createElement(Avatar, {
      user: user,
      size: 44
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        position: 'absolute',
        right: -1,
        bottom: -1
      }
    }, /*#__PURE__*/React.createElement(PresenceDot, {
      size: 12
    })));
  }
  return /*#__PURE__*/React.createElement("button", {
    onClick: () => onNav('profile'),
    className: "fh-profile",
    style: {
      width: '100%',
      textAlign: 'left',
      cursor: 'pointer',
      borderRadius: 16,
      padding: '11px 13px',
      background: 'var(--fomio-card)',
      border: `1px solid ${active ? 'var(--fomio-primary)' : 'var(--fomio-border)'}`,
      boxShadow: '0 12px 30px -14px var(--fomio-shadow)',
      display: 'flex',
      alignItems: 'center',
      gap: 11,
      fontFamily: 'var(--fomio-sans)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement(Avatar, {
    user: user,
    size: 38
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      right: -1,
      bottom: -1
    }
  }, /*#__PURE__*/React.createElement(PresenceDot, {
    size: 12
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13.5,
      fontWeight: 700,
      color: 'var(--fomio-fg)',
      overflow: 'hidden',
      textOverflow: 'ellipsis',
      whiteSpace: 'nowrap'
    }
  }, user.name), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 11.5,
      color: 'var(--fomio-fg-muted)'
    }
  }, "@", user.username)), /*#__PURE__*/React.createElement(HIc, {
    name: "settings",
    size: 16,
    color: "var(--fomio-fg-muted)",
    stroke: 1.7
  }));
}

/* ── Sidebar nav item ────────────────────────────────────────── */
function NavItem({
  icon,
  label,
  active,
  accent,
  badge,
  rail,
  dot,
  onClick
}) {
  const color = accent ? 'var(--fomio-primary)' : active ? 'var(--fomio-fg)' : 'var(--fomio-fg-muted)';
  return /*#__PURE__*/React.createElement("button", {
    onClick: onClick,
    className: "fh-navitem",
    title: rail ? label : undefined,
    style: {
      position: 'relative',
      display: 'flex',
      alignItems: 'center',
      gap: 12,
      width: '100%',
      padding: rail ? '11px 0' : '9px 12px',
      borderRadius: 10,
      cursor: 'pointer',
      border: 'none',
      justifyContent: rail ? 'center' : 'flex-start',
      background: active && !rail ? 'var(--fomio-surface)' : 'transparent',
      color,
      fontFamily: 'var(--fomio-sans)',
      fontSize: 14,
      fontWeight: active ? 600 : 500,
      transition: 'background 120ms'
    }
  }, active && rail && /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      left: 6,
      top: '50%',
      transform: 'translateY(-50%)',
      width: 3,
      height: 20,
      borderRadius: 2,
      background: 'var(--fomio-primary)'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'relative',
      display: 'flex'
    }
  }, /*#__PURE__*/React.createElement(HIc, {
    name: icon,
    size: 19,
    color: accent ? 'var(--fomio-primary)' : 'currentColor',
    stroke: 1.9,
    fill: active && !accent && icon === 'home' ? 'currentColor' : 'none'
  }), dot && /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      top: -2,
      right: -2,
      width: 8,
      height: 8,
      borderRadius: '50%',
      background: 'var(--fomio-primary)',
      border: '1.5px solid var(--fomio-bg)'
    }
  })), !rail && /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      textAlign: 'left'
    }
  }, label), !rail && badge ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--fomio-mono)',
      fontSize: 11,
      fontWeight: 700,
      color: '#fff',
      background: 'var(--fomio-primary)',
      padding: '1px 6px',
      borderRadius: 9999,
      minWidth: 18,
      textAlign: 'center'
    }
  }, badge) : null);
}
function SectionHeading({
  label,
  action
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      padding: '18px 12px 6px'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--fomio-sans)',
      fontSize: 10.5,
      fontWeight: 700,
      letterSpacing: '0.08em',
      textTransform: 'uppercase',
      color: 'var(--fomio-fg-muted)'
    }
  }, label), action && /*#__PURE__*/React.createElement("button", {
    className: "fh-edit",
    style: {
      background: 'none',
      border: 'none',
      cursor: 'pointer',
      padding: 2,
      display: 'flex',
      color: 'var(--fomio-fg-muted)'
    },
    title: "Customize sections"
  }, /*#__PURE__*/React.createElement(HIc, {
    name: "edit",
    size: 13,
    color: "currentColor",
    stroke: 1.8
  })));
}

/* ── Sidebar (full + rail) ───────────────────────────────────── */
function Sidebar({
  data,
  rail,
  tab,
  onNav,
  onToggleRail,
  loggedOut,
  canToggle
}) {
  const {
    user,
    navPrimary,
    userSections,
    pinnedTerets
  } = data;
  const W = rail ? 72 : 252;
  return /*#__PURE__*/React.createElement("aside", {
    style: {
      width: W,
      flexShrink: 0,
      height: '100vh',
      position: 'sticky',
      top: 0,
      background: 'var(--fomio-bg)',
      borderRight: '1px solid var(--fomio-border)',
      display: 'flex',
      flexDirection: 'column',
      boxSizing: 'border-box',
      padding: rail ? '20px 12px' : '20px 14px',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: rail ? 'center' : 'space-between',
      padding: rail ? '2px 0 18px' : '4px 8px 20px'
    }
  }, /*#__PURE__*/React.createElement(FomioMark, {
    size: rail ? 24 : 25,
    mark: rail
  }), !rail && canToggle && /*#__PURE__*/React.createElement("button", {
    onClick: onToggleRail,
    className: "fh-navitem",
    title: "Collapse to rail",
    style: {
      width: 28,
      height: 28,
      borderRadius: 8,
      border: 'none',
      cursor: 'pointer',
      background: 'transparent',
      color: 'var(--fomio-fg-muted)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center'
    }
  }, /*#__PURE__*/React.createElement(HIc, {
    name: "chevronsLeft",
    size: 17,
    color: "currentColor",
    stroke: 1.9
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minHeight: 0,
      overflowY: 'auto',
      overflowX: 'hidden',
      display: 'flex',
      flexDirection: 'column',
      gap: 2,
      scrollbarWidth: 'none'
    }
  }, navPrimary.map(n => /*#__PURE__*/React.createElement(NavItem, {
    key: n.key,
    icon: n.icon,
    label: n.label,
    accent: n.accent,
    rail: rail,
    active: !n.accent && tab === n.key,
    badge: !loggedOut && n.badgeKey ? user[n.badgeKey] : null,
    dot: rail && !loggedOut && n.badgeKey && user[n.badgeKey] > 0,
    onClick: () => onNav(n.key)
  })), !rail && /*#__PURE__*/React.createElement(SectionHeading, {
    label: "Your sections",
    action: true
  }), rail && /*#__PURE__*/React.createElement("div", {
    style: {
      height: 1,
      background: 'var(--fomio-border-soft)',
      margin: '10px 8px'
    }
  }), userSections.map(s => /*#__PURE__*/React.createElement(NavItem, {
    key: s.key,
    icon: s.icon,
    label: s.label,
    rail: rail,
    active: tab === s.key,
    badge: !loggedOut && s.badgeKey ? user[s.badgeKey] : null,
    dot: rail && !loggedOut && s.badgeKey && user[s.badgeKey] > 0,
    onClick: () => onNav(s.key)
  })), !rail && /*#__PURE__*/React.createElement(SectionHeading, {
    label: "Pinned terets"
  }), pinnedTerets.map(t => rail ? /*#__PURE__*/React.createElement("button", {
    key: t.key,
    onClick: () => onNav('teret:' + t.key),
    className: "fh-navitem",
    title: t.label,
    style: {
      display: 'flex',
      justifyContent: 'center',
      padding: '10px 0',
      borderRadius: 10,
      border: 'none',
      cursor: 'pointer',
      background: 'transparent'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 7,
      height: 7,
      borderRadius: '50%',
      background: 'var(--fomio-primary)'
    }
  })) : /*#__PURE__*/React.createElement("button", {
    key: t.key,
    onClick: () => onNav('teret:' + t.key),
    className: "fh-navitem",
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 11,
      width: '100%',
      padding: '9px 12px',
      borderRadius: 10,
      cursor: 'pointer',
      border: 'none',
      background: 'transparent',
      fontFamily: 'var(--fomio-sans)',
      fontSize: 13.5,
      fontWeight: 500,
      color: 'var(--fomio-fg-muted)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 7,
      height: 7,
      borderRadius: '50%',
      background: 'var(--fomio-primary)',
      flexShrink: 0
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      textAlign: 'left',
      color: 'var(--fomio-fg)'
    }
  }, t.label), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--fomio-mono)',
      fontSize: 11,
      color: 'var(--fomio-fg-muted)'
    }
  }, t.count)))), /*#__PURE__*/React.createElement("div", {
    style: {
      paddingTop: 14
    }
  }, /*#__PURE__*/React.createElement(FloatingProfile, {
    user: user,
    rail: rail,
    loggedOut: loggedOut,
    active: tab === 'profile',
    onNav: onNav
  })), rail && canToggle && /*#__PURE__*/React.createElement("button", {
    onClick: onToggleRail,
    className: "fh-navitem",
    title: "Expand sidebar",
    style: {
      marginTop: 12,
      width: '100%',
      height: 36,
      borderRadius: 10,
      border: 'none',
      cursor: 'pointer',
      background: 'transparent',
      color: 'var(--fomio-fg-muted)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center'
    }
  }, /*#__PURE__*/React.createElement(HIc, {
    name: "chevronRight",
    size: 18,
    color: "currentColor",
    stroke: 1.9
  })));
}

/* ── Touch top header ────────────────────────────────────────── */
function TouchHeader({
  subtitle,
  hidden
}) {
  return /*#__PURE__*/React.createElement("header", {
    style: {
      position: 'sticky',
      top: 0,
      zIndex: 40,
      background: 'color-mix(in srgb, var(--fomio-bg) 88%, transparent)',
      backdropFilter: 'blur(12px)',
      WebkitBackdropFilter: 'blur(12px)',
      borderBottom: '1px solid var(--fomio-border-soft)',
      padding: '14px 20px 12px',
      transform: hidden ? 'translateY(-100%)' : 'translateY(0)',
      transition: 'transform 260ms var(--fomio-ease, ease)'
    }
  }, /*#__PURE__*/React.createElement(FomioMark, {
    size: 26
  }), subtitle && /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 7,
      fontFamily: 'var(--fomio-sans)',
      fontSize: 11,
      fontWeight: 700,
      letterSpacing: '0.08em',
      textTransform: 'uppercase',
      color: 'var(--fomio-fg-muted)'
    }
  }, subtitle));
}

/* ── Bottom tab bar (BlurView glass) — hides on scroll down ──── */
function BottomTabBar({
  tab,
  onNav,
  user,
  hidden,
  loggedOut
}) {
  const items = [{
    key: 'home',
    label: 'Home',
    icon: 'home'
  }, {
    key: 'search',
    label: 'Search',
    icon: 'search'
  }, {
    key: 'write',
    label: 'Write',
    icon: 'feather',
    center: true
  }, {
    key: 'notifications',
    label: 'Alerts',
    icon: 'bell',
    badge: loggedOut ? 0 : user.unreadNotifs
  }, {
    key: 'profile',
    label: 'You',
    icon: 'user',
    avatar: true
  }];
  return /*#__PURE__*/React.createElement("nav", {
    style: {
      position: 'fixed',
      left: 14,
      right: 14,
      bottom: 16,
      height: 66,
      zIndex: 60,
      borderRadius: 26,
      overflow: 'hidden',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-around',
      padding: '0 8px',
      background: 'color-mix(in srgb, var(--fomio-card) 74%, transparent)',
      backdropFilter: 'blur(22px) saturate(180%)',
      WebkitBackdropFilter: 'blur(22px) saturate(180%)',
      border: '1px solid var(--fomio-border-soft)',
      boxShadow: '0 12px 34px -10px var(--fomio-shadow)',
      transform: hidden ? 'translateY(140%)' : 'translateY(0)',
      transition: 'transform 300ms var(--fomio-ease, ease)'
    }
  }, items.map(it => {
    const active = it.key === tab;
    const col = active ? 'var(--fomio-primary)' : 'var(--fomio-fg-muted)';
    if (it.center) {
      return /*#__PURE__*/React.createElement("button", {
        key: it.key,
        onClick: () => onNav(it.key),
        "aria-label": "Write",
        style: {
          width: 48,
          height: 48,
          borderRadius: 24,
          border: 'none',
          cursor: 'pointer',
          background: 'var(--fomio-primary)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          boxShadow: '0 6px 16px -3px color-mix(in srgb, var(--fomio-primary) 55%, transparent)'
        }
      }, /*#__PURE__*/React.createElement(HIc, {
        name: "feather",
        size: 22,
        color: "#fff",
        stroke: 2
      }));
    }
    if (it.avatar) {
      return /*#__PURE__*/React.createElement("button", {
        key: it.key,
        onClick: () => onNav(it.key),
        "aria-label": "You",
        style: {
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          gap: 3,
          background: 'none',
          border: 'none',
          cursor: 'pointer',
          padding: '0 8px'
        }
      }, /*#__PURE__*/React.createElement("span", {
        style: {
          position: 'relative',
          display: 'flex'
        }
      }, loggedOut ? /*#__PURE__*/React.createElement("span", {
        style: {
          width: 26,
          height: 26,
          borderRadius: '50%',
          background: 'var(--fomio-surface)',
          border: '1px solid var(--fomio-border)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center'
        }
      }, /*#__PURE__*/React.createElement(HIc, {
        name: "user",
        size: 16,
        color: col,
        stroke: 1.8
      })) : /*#__PURE__*/React.createElement("span", {
        style: {
          borderRadius: '50%',
          boxShadow: active ? '0 0 0 2px var(--fomio-card), 0 0 0 3.5px var(--fomio-primary)' : 'none'
        }
      }, /*#__PURE__*/React.createElement(Avatar, {
        user: user,
        size: 26
      })), !loggedOut && /*#__PURE__*/React.createElement("span", {
        style: {
          position: 'absolute',
          right: -2,
          bottom: -2
        }
      }, /*#__PURE__*/React.createElement(PresenceDot, {
        size: 9
      }))), /*#__PURE__*/React.createElement("span", {
        style: {
          fontFamily: 'var(--fomio-sans)',
          fontSize: 10,
          fontWeight: active ? 700 : 600,
          color: col
        }
      }, it.label));
    }
    return /*#__PURE__*/React.createElement("button", {
      key: it.key,
      onClick: () => onNav(it.key),
      "aria-label": it.label,
      style: {
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        gap: 3,
        background: 'none',
        border: 'none',
        cursor: 'pointer',
        padding: '0 8px',
        position: 'relative'
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        position: 'relative',
        display: 'flex'
      }
    }, /*#__PURE__*/React.createElement(HIc, {
      name: it.icon,
      size: 22,
      color: col,
      stroke: 1.9,
      fill: active && it.icon === 'home' ? col : 'none'
    }), it.badge > 0 && /*#__PURE__*/React.createElement("span", {
      style: {
        position: 'absolute',
        top: -5,
        right: -8,
        minWidth: 16,
        height: 16,
        borderRadius: 8,
        background: 'var(--fomio-primary)',
        color: '#fff',
        fontFamily: 'var(--fomio-sans)',
        fontSize: 9,
        fontWeight: 700,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '0 4px',
        border: '1.5px solid var(--fomio-card)'
      }
    }, it.badge)), /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--fomio-sans)',
        fontSize: 10,
        fontWeight: active ? 700 : 600,
        color: col
      }
    }, it.label));
  }));
}
Object.assign(window, {
  Sidebar,
  FloatingProfile,
  BottomTabBar,
  TouchHeader
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "home-nav.jsx", error: String((e && e.message) || e) }); }

// hubs-app.jsx
try { (() => {
/* hubs-app.jsx — Hubs (directory) screen: responsive shell (reuses the Home
 * Sidebar / BottomTabBar / TouchHeader), surface-mode logic, search + drill-down
 * orchestration, notification state, and the Tweaks-driven states.
 * Exports: FomioHubsApp.
 */
const {
  useState,
  useEffect,
  useRef,
  useMemo,
  useCallback
} = React;
const {
  Sidebar,
  BottomTabBar,
  TouchHeader,
  HIc,
  FomioMark,
  HubIc,
  HubsSearch,
  Directory,
  HubsSkeleton,
  HubsEmpty,
  InlineExpand,
  HubSheet,
  SearchResults,
  HubDetailScreen,
  TeretDetailScreen
} = window;

/* ── Surface mode (matches project convention) ───────────────── */
function useSurfaceMode(forced) {
  const [mode, setMode] = useState('expanded');
  useEffect(() => {
    if (forced && forced !== 'auto') {
      setMode(forced);
      return;
    }
    const update = () => {
      const w = window.innerWidth;
      if (w >= 1280) setMode('expanded');else if (w >= 1024) setMode('compact-desktop');else if (w >= 768) setMode('rail');else setMode('touch');
    };
    update();
    window.addEventListener('resize', update);
    return () => window.removeEventListener('resize', update);
  }, [forced]);
  return mode;
}

/* ── Placeholder for non-Hubs nav targets ────────────────────── */
function NavPlaceholder({
  label,
  icon
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'center',
      padding: '72px 24px',
      maxWidth: 420,
      margin: '0 auto'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 56,
      height: 56,
      borderRadius: 16,
      background: 'var(--fomio-surface)',
      border: '1px solid var(--fomio-border)',
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      marginBottom: 18
    }
  }, /*#__PURE__*/React.createElement(HIc, {
    name: icon,
    size: 26,
    color: "var(--fomio-fg-muted)",
    stroke: 1.6
  })), /*#__PURE__*/React.createElement("h3", {
    style: {
      margin: '0 0 8px',
      fontFamily: 'var(--fomio-serif)',
      fontWeight: 700,
      fontSize: 24,
      letterSpacing: '-0.02em',
      color: 'var(--fomio-fg)'
    }
  }, label), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontFamily: 'var(--fomio-serif)',
      fontSize: 15,
      lineHeight: 1.6,
      color: 'var(--fomio-fg-muted)'
    }
  }, "This surface is stubbed in the prototype \u2014 Hubs is the focus of this build."));
}

/* ── Main app ────────────────────────────────────────────────── */
function FomioHubsApp({
  tweaks
}) {
  const data = window.HUBS_DATA;
  const forced = tweaks.surfaceMode || 'auto';
  const mode = useSurfaceMode(forced);
  const isDark = !!tweaks.darkMode;
  const isTouch = mode === 'touch';
  const layout = tweaks.layout || 'index';
  const drilldown = tweaks.drilldown || 'screen';
  const colorMode = tweaks.hubColor || 'brand';
  const showTerets = tweaks.showTerets !== false;
  const showBytes = tweaks.showBytes !== false;
  const feedState = tweaks.feedState || 'populated';
  const loggedOut = (tweaks.auth || 'in') === 'out';
  const defaultFilter = tweaks.defaultFilter || 'latest';
  const topicLayout = tweaks.topicLayout || 'comfortable';
  const showCovers = tweaks.showCovers !== false;
  const [tab, setTab] = useState('hubs');
  const [query, setQuery] = useState('');
  const [expandedId, setExpandedId] = useState(null);
  const [sheetHub, setSheetHub] = useState(null);
  const [chromeHidden, setChromeHidden] = useState(false);
  const lastScroll = useRef(0);

  // Detail-screen routing: 'directory' | 'hub' | 'teret'
  const [view, setView] = useState('directory');
  const [activeHubId, setActiveHubId] = useState(null);
  const [activeTeretSlug, setActiveTeretSlug] = useState(null);
  const [teretNotif, setTeretNotif] = useState({});
  const scrollRef = useRef(null);

  // Notification level state (seeded from data)
  const [notif, setNotif] = useState(() => Object.fromEntries(data.hubs.map(h => [h.id, h.notif])));
  useEffect(() => {
    document.documentElement.setAttribute('data-theme', isDark ? 'dark' : 'light');
  }, [isDark]);

  // Reset transient drill state when key tweaks change
  useEffect(() => {
    setExpandedId(null);
    setSheetHub(null);
  }, [layout, drilldown, feedState]);

  // Jump straight to a screen when the reviewer picks a starting point
  useEffect(() => {
    const s = tweaks.startOn || 'directory';
    setTab('hubs');
    setSheetHub(null);
    if (s === 'hub') {
      setActiveHubId(data.hubs[0].id);
      setActiveTeretSlug(null);
      setView('hub');
    } else if (s === 'teret') {
      const h = data.hubs[0];
      setActiveHubId(h.id);
      setActiveTeretSlug(h.terets[0].slug);
      setView('teret');
    } else setView('directory');
  }, [tweaks.startOn]);

  // Reset scroll to top on any screen change
  useEffect(() => {
    window.scrollTo(0, 0);
    if (scrollRef.current) scrollRef.current.scrollTop = 0;
  }, [view, activeHubId, activeTeretSlug, tab]);
  const hubsWithNotif = useMemo(() => data.hubs.map(h => ({
    ...h,
    _notif: loggedOut ? 1 : notif[h.id] ?? 1
  })), [data.hubs, notif, loggedOut]);
  const opts = {
    layout,
    mode,
    colorMode,
    showTerets,
    showBytes,
    gated: loggedOut,
    drilldown,
    query,
    defaultFilter,
    topicLayout,
    showCovers
  };

  // ── Search: build hub + teret results with breadcrumbs ──
  const results = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return null;
    const out = [];
    hubsWithNotif.forEach(h => {
      if (h.name.toLowerCase().includes(q) || h.description.toLowerCase().includes(q)) out.push({
        type: 'hub',
        hub: h
      });
      h.terets.forEach(t => {
        if (t.name.toLowerCase().includes(q)) out.push({
          type: 'teret',
          hub: h,
          teret: t
        });
      });
    });
    return out;
  }, [query, hubsWithNotif]);
  const onCycleNotif = useCallback(hub => {
    if (loggedOut) return;
    setNotif(m => ({
      ...m,
      [hub.id]: ((m[hub.id] ?? 1) + 1) % 4
    }));
  }, [loggedOut]);
  const onSetNotif = useCallback((hub, lvl) => {
    if (loggedOut) return;
    setNotif(m => ({
      ...m,
      [hub.id]: lvl
    }));
  }, [loggedOut]);
  const onOpenHub = useCallback(hub => {
    if (drilldown === 'inline' && layout !== 'gallery') {
      setExpandedId(id => id === hub.id ? null : hub.id);
      return;
    }
    if (drilldown === 'sheet') {
      setSheetHub(hub);
      return;
    }
    setActiveHubId(hub.id);
    setActiveTeretSlug(null);
    setSheetHub(null);
    setView('hub');
  }, [drilldown, layout]);
  const onOpenTeret = useCallback((hub, teret) => {
    // Routes to /c/:hub/:teret — the full Teret detail screen.
    setActiveHubId(hub.id);
    setActiveTeretSlug(teret.slug);
    setSheetHub(null);
    setView('teret');
  }, []);
  const onSetTeretNotif = useCallback((key, lvl) => {
    if (loggedOut) return;
    setTeretNotif(m => ({
      ...m,
      [key]: lvl
    }));
  }, [loggedOut]);
  const onBackToDirectory = useCallback(() => {
    setView('directory');
    setActiveTeretSlug(null);
  }, []);
  const onBackToHub = useCallback(teret => {
    if (teret && teret.slug) {
      setActiveTeretSlug(teret.slug);
      setView('teret');
    } else {
      setActiveTeretSlug(null);
      setView('hub');
    }
  }, []);
  const onNav = useCallback(key => {
    setSheetHub(null);
    setView('directory');
    setTab(key);
  }, []);
  const onScroll = useCallback(e => {
    const y = e.target.scrollTop;
    const dy = y - lastScroll.current;
    if (Math.abs(dy) > 6) {
      setChromeHidden(dy > 0 && y > 40);
      lastScroll.current = y;
    }
  }, []);

  // ── Active hub / teret for detail views ──
  const activeHub = hubsWithNotif.find(h => h.id === activeHubId) || null;
  const activeTeret = activeHub && activeTeretSlug ? activeHub.terets.find(t => t.slug === activeTeretSlug) : null;

  // ── Body ──
  let body;
  if (tab !== 'hubs') {
    const meta = {
      home: ['Home', 'home'],
      search: ['Search', 'search'],
      notifications: ['Notifications', 'bell'],
      write: ['Write', 'feather'],
      bookmarks: ['Bookmarks', 'bookmark'],
      messages: ['Messages', 'mail'],
      profile: ['Profile', 'user']
    }[tab] || ['Section', 'home'];
    body = /*#__PURE__*/React.createElement(NavPlaceholder, {
      label: meta[0],
      icon: meta[1]
    });
  } else if (view === 'hub' && activeHub) {
    body = /*#__PURE__*/React.createElement(HubDetailScreen, {
      hub: activeHub,
      opts: opts,
      feedState: feedState,
      notifLevel: activeHub._notif,
      onSetNotif: lvl => onSetNotif(activeHub, lvl),
      onBack: onBackToDirectory,
      onOpenTeret: onOpenTeret
    });
  } else if (view === 'teret' && activeHub && activeTeret) {
    const tkey = activeHub.id + ':' + activeTeret.slug;
    const tlevel = loggedOut ? 1 : teretNotif[tkey] != null ? teretNotif[tkey] : activeHub._notif != null ? activeHub._notif : 1;
    body = /*#__PURE__*/React.createElement(TeretDetailScreen, {
      hub: activeHub,
      teret: activeTeret,
      opts: opts,
      feedState: feedState,
      notifLevel: tlevel,
      onSetNotif: lvl => onSetTeretNotif(tkey, lvl),
      onBack: onBackToDirectory,
      onBackToHub: onBackToHub
    });
  } else {
    const heading = /*#__PURE__*/React.createElement("div", {
      style: {
        marginBottom: 20
      }
    }, !isTouch && /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'baseline',
        gap: 12,
        marginBottom: 6
      }
    }, /*#__PURE__*/React.createElement("h1", {
      style: {
        margin: 0,
        fontFamily: 'var(--fomio-serif)',
        fontWeight: 700,
        fontSize: mode === 'expanded' ? 32 : 27,
        letterSpacing: '-0.03em',
        color: 'var(--fomio-fg)'
      }
    }, "Hubs"), /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--fomio-sans)',
        fontSize: 12,
        fontWeight: 600,
        letterSpacing: '0.04em',
        textTransform: 'uppercase',
        color: 'var(--fomio-fg-muted)'
      }
    }, data.hubs.length, " places to read and write")), !isTouch && /*#__PURE__*/React.createElement("p", {
      style: {
        margin: 0,
        fontFamily: 'var(--fomio-serif)',
        fontSize: 15.5,
        lineHeight: 1.5,
        color: 'var(--fomio-fg-muted)',
        maxWidth: 560
      }
    }, "Every hub is a room with its own terets. Browse, follow the ones you care about, and mute the rest."));
    const searchBar = /*#__PURE__*/React.createElement("div", {
      style: {
        marginBottom: 24
      }
    }, /*#__PURE__*/React.createElement(HubsSearch, {
      value: query,
      onChange: setQuery,
      mode: mode
    }));
    let listing;
    if (feedState === 'loading') {
      listing = /*#__PURE__*/React.createElement(HubsSkeleton, {
        layout: layout,
        mode: mode
      });
    } else if (feedState === 'empty') {
      listing = /*#__PURE__*/React.createElement(HubsEmpty, null);
    } else if (results) {
      listing = results.length ? /*#__PURE__*/React.createElement(SearchResults, {
        results: results,
        query: query.trim(),
        onOpen: onOpenHub,
        onOpenTeret: onOpenTeret
      }) : /*#__PURE__*/React.createElement(HubsEmpty, {
        query: query.trim(),
        onClear: () => setQuery('')
      });
    } else {
      listing = /*#__PURE__*/React.createElement(Directory, {
        hubs: hubsWithNotif,
        opts: opts,
        onOpen: onOpenHub,
        onCycleNotif: onCycleNotif,
        onOpenTeret: onOpenTeret,
        expandedId: expandedId,
        renderExpand: hub => /*#__PURE__*/React.createElement(InlineExpand, {
          hub: hub,
          opts: opts,
          onSetNotif: onSetNotif,
          onOpenTeret: onOpenTeret,
          onOpenByte: () => {}
        })
      });
    }
    body = /*#__PURE__*/React.createElement(React.Fragment, null, heading, searchBar, listing);
  }
  const inDetail = tab === 'hubs' && view !== 'directory';
  const maxW = !inDetail && layout === 'gallery' ? 1080 : 780;
  const pad = mode === 'expanded' ? '40px 56px' : mode === 'compact-desktop' ? '36px 40px' : '28px 28px';
  const sheet = /*#__PURE__*/React.createElement(HubSheet, {
    hub: sheetHub,
    opts: opts,
    touch: isTouch,
    onClose: () => setSheetHub(null),
    onSetNotif: onSetNotif,
    onOpenTeret: onOpenTeret,
    onOpenByte: () => {}
  });

  // ── Touch layout ──
  if (isTouch) {
    return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
      style: {
        position: 'fixed',
        inset: 0,
        background: 'var(--fomio-bg)',
        display: 'flex',
        flexDirection: 'column'
      }
    }, /*#__PURE__*/React.createElement(TouchHeader, {
      subtitle: tab === 'hubs' ? view === 'hub' && activeHub ? activeHub.name : view === 'teret' && activeTeret ? activeTeret.name : 'Hubs · Browse the directory' : null,
      hidden: chromeHidden
    }), /*#__PURE__*/React.createElement("main", {
      ref: scrollRef,
      onScroll: onScroll,
      style: {
        flex: 1,
        overflowY: 'auto',
        padding: '18px 20px 110px',
        WebkitOverflowScrolling: 'touch'
      }
    }, body), /*#__PURE__*/React.createElement(BottomTabBar, {
      tab: tab === 'hubs' ? 'home' : tab,
      onNav: onNav,
      user: data.user,
      hidden: chromeHidden,
      loggedOut: loggedOut
    })), sheet);
  }

  // ── Desktop / rail layout ──
  const rail = mode === 'rail';
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      minHeight: '100vh',
      background: 'var(--fomio-bg)'
    }
  }, /*#__PURE__*/React.createElement(Sidebar, {
    data: data,
    rail: rail,
    tab: tab,
    onNav: onNav,
    onToggleRail: () => {},
    loggedOut: loggedOut,
    canToggle: false
  }), /*#__PURE__*/React.createElement("main", {
    style: {
      flex: 1,
      minWidth: 0,
      padding: pad,
      boxSizing: 'border-box'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: maxW,
      margin: '0 auto'
    }
  }, body))), sheet);
}
window.FomioHubsApp = FomioHubsApp;
})(); } catch (e) { __ds_ns.__errors.push({ path: "hubs-app.jsx", error: String((e && e.message) || e) }); }

// hubs-data.js
try { (() => {
/* hubs-data.js — Fomio Hubs (category directory) screen data.
 * Mirrors the shapes the app reads from headless Discourse:
 *   /categories.json                                  → HUBS (top-level categories)
 *   /categories/:id?include_topics&include_subcategories → terets + featured bytes
 *   /session/current.json + /sidebar_sections.json    → USER + NAV
 * Brand rule: no invented chromatic UI. Per-hub `hue` exists ONLY so the
 * "hub color" tweak can explore accents; strict brand ignores it (terracotta only).
 */
window.HUBS_DATA = {
  site: {
    name: 'fomio',
    tagline: 'A quiet place to read and write'
  },
  user: {
    name: 'Ismail Z.',
    username: 'ismail',
    initials: 'IZ',
    avatarBg: '#D6C9A8',
    avatarFg: '#5C4A1E',
    unreadNotifs: 3,
    unreadMsgs: 1
  },
  /* Primary nav — Hubs is a peer surface to Home */
  navPrimary: [{
    key: 'home',
    label: 'Home',
    icon: 'home'
  }, {
    key: 'hubs',
    label: 'Hubs',
    icon: 'layout'
  }, {
    key: 'search',
    label: 'Search',
    icon: 'search'
  }, {
    key: 'notifications',
    label: 'Notifications',
    icon: 'bell',
    badgeKey: 'unreadNotifs'
  }, {
    key: 'write',
    label: 'Write',
    icon: 'feather',
    accent: true
  }],
  userSections: [{
    key: 'bookmarks',
    label: 'Bookmarks',
    icon: 'bookmark'
  }, {
    key: 'messages',
    label: 'Messages',
    icon: 'mail',
    badgeKey: 'unreadMsgs'
  }],
  pinnedTerets: [{
    key: 'essays',
    label: 'Essays',
    hub: 'Writing',
    count: 128
  }, {
    key: 'quiet',
    label: 'Quiet internet',
    hub: 'Ideas',
    count: 64
  }, {
    key: 'craft',
    label: 'Craft',
    hub: 'Writing',
    count: 211
  }],
  /* Prototype cap for the condensed rail catalog (real value: FOMIO_TOP_LEVEL_HUB_LIMIT) */
  topLevelHubLimit: 6,
  /* notif levels: 0 muted · 1 normal · 2 tracking · 3 watching */
  hubs: [{
    id: 3,
    slug: 'writing',
    name: 'Writing',
    hue: 18,
    description: 'Craft, drafts, and the daily practice of putting words down.',
    byteCount: 1284,
    members: 4120,
    active: 38,
    notif: 3,
    terets: [{
      slug: 'essays',
      name: 'Essays',
      count: 128
    }, {
      slug: 'craft',
      name: 'Craft',
      count: 211
    }, {
      slug: 'drafts',
      name: 'Drafts',
      count: 74
    }, {
      slug: 'first-lines',
      name: 'First lines',
      count: 46
    }],
    bytes: [{
      author: 'Lena Marsh',
      init: 'LM',
      avatarBg: '#D6C9A8',
      avatarFg: '#5C4A1E',
      teret: 'Essays',
      title: 'On writing without an audience',
      time: '3h',
      replies: 8
    }, {
      author: 'Ada Reyes',
      init: 'AR',
      avatarBg: '#D6BFC9',
      avatarFg: '#5C3E4D',
      teret: 'Craft',
      title: 'The paragraph as a unit of thought',
      time: '9h',
      replies: 16
    }]
  }, {
    id: 5,
    slug: 'ideas',
    name: 'Ideas',
    hue: 250,
    description: 'Slow thinking about technology, attention, and the quiet internet.',
    byteCount: 906,
    members: 3180,
    active: 24,
    notif: 2,
    terets: [{
      slug: 'quiet-internet',
      name: 'Quiet internet',
      count: 64
    }, {
      slug: 'attention',
      name: 'Attention',
      count: 52
    }, {
      slug: 'futures',
      name: 'Futures',
      count: 39
    }],
    bytes: [{
      author: 'Jun Nakamura',
      init: 'JN',
      avatarBg: '#C9D6C2',
      avatarFg: '#3E5C3E',
      teret: 'Quiet internet',
      title: 'The case for chronological feeds',
      time: '1d',
      replies: 34
    }, {
      author: 'Theo Mendez',
      init: 'TM',
      avatarBg: '#D6C2C2',
      avatarFg: '#5C3E3E',
      teret: 'Attention',
      title: 'Notifications are a design failure',
      time: '2d',
      replies: 21
    }]
  }, {
    id: 8,
    slug: 'reading',
    name: 'Reading',
    hue: 140,
    description: 'What we are reading, and why it stayed with us.',
    byteCount: 642,
    members: 2740,
    active: 19,
    notif: 1,
    terets: [{
      slug: 'marginalia',
      name: 'Marginalia',
      count: 88
    }, {
      slug: 'rereads',
      name: 'Rereads',
      count: 41
    }, {
      slug: 'poetry',
      name: 'Poetry',
      count: 57
    }],
    bytes: [{
      author: 'Priya Hart',
      init: 'PH',
      avatarBg: '#BFCAD6',
      avatarFg: '#3E4A5C',
      teret: 'Marginalia',
      title: 'Notes in the margins of a borrowed book',
      time: '6h',
      replies: 11
    }, {
      author: 'Sofia Okonkwo',
      init: 'SO',
      avatarBg: '#C7C9D6',
      avatarFg: '#3E3E5C',
      teret: 'Poetry',
      title: 'A line I have carried for ten years',
      time: '1d',
      replies: 7
    }]
  }, {
    id: 11,
    slug: 'photography',
    name: 'Photography',
    hue: 40,
    description: 'Light, patience, and the frame — images and the words around them.',
    byteCount: 528,
    members: 2210,
    active: 15,
    notif: 0,
    terets: [{
      slug: 'film',
      name: 'Film',
      count: 63
    }, {
      slug: 'street',
      name: 'Street',
      count: 49
    }, {
      slug: 'stillness',
      name: 'Stillness',
      count: 34
    }],
    bytes: [{
      author: 'Marco Vitale',
      init: 'MV',
      avatarBg: '#D6CBB8',
      avatarFg: '#5C4E2E',
      teret: 'Film',
      title: 'Why I still develop at home',
      time: '5h',
      replies: 9
    }, {
      author: 'Ines Roy',
      init: 'IR',
      avatarBg: '#C2D0D6',
      avatarFg: '#3E525C',
      teret: 'Street',
      title: 'Standing on one corner for an hour',
      time: '2d',
      replies: 13
    }]
  }, {
    id: 14,
    slug: 'craft-making',
    name: 'Craft & making',
    hue: 90,
    description: 'Working with hands. Type, print, wood, and code as material.',
    byteCount: 411,
    members: 1680,
    active: 11,
    notif: 1,
    terets: [{
      slug: 'letterpress',
      name: 'Letterpress',
      count: 37
    }, {
      slug: 'woodwork',
      name: 'Woodwork',
      count: 28
    }, {
      slug: 'tools',
      name: 'Tools',
      count: 45
    }],
    bytes: [{
      author: 'Hana K900',
      init: 'HK',
      avatarBg: '#CDD6C2',
      avatarFg: '#455C3E',
      teret: 'Letterpress',
      title: 'Setting a poem by hand, one slug at a time',
      time: '8h',
      replies: 6
    }, {
      author: 'Owen Frost',
      init: 'OF',
      avatarBg: '#D6C7BF',
      avatarFg: '#5C453E',
      teret: 'Tools',
      title: 'The three tools I would keep',
      time: '3d',
      replies: 18
    }]
  }, {
    id: 17,
    slug: 'field-notes',
    name: 'Field notes',
    hue: 200,
    description: 'Dispatches from walks, cities, and slow travel.',
    byteCount: 372,
    members: 1490,
    active: 9,
    notif: 0,
    terets: [{
      slug: 'walks',
      name: 'Walks',
      count: 51
    }, {
      slug: 'cities',
      name: 'Cities',
      count: 44
    }, {
      slug: 'weather',
      name: 'Weather',
      count: 22
    }],
    bytes: [{
      author: 'Nadia Bell',
      init: 'NB',
      avatarBg: '#C2C9D6',
      avatarFg: '#3E455C',
      teret: 'Walks',
      title: 'The same loop, a hundred mornings',
      time: '4h',
      replies: 10
    }, {
      author: 'Cyrus Vane',
      init: 'CV',
      avatarBg: '#D6C2CE',
      avatarFg: '#5C3E52',
      teret: 'Cities',
      title: 'A quiet block in a loud district',
      time: '2d',
      replies: 5
    }]
  }, {
    id: 20,
    slug: 'sound',
    name: 'Sound',
    hue: 300,
    description: 'Records, rooms, and the practice of listening closely.',
    byteCount: 298,
    members: 1220,
    active: 7,
    notif: 1,
    terets: [{
      slug: 'records',
      name: 'Records',
      count: 40
    }, {
      slug: 'ambient',
      name: 'Ambient',
      count: 31
    }, {
      slug: 'live',
      name: 'Live',
      count: 19
    }],
    bytes: [{
      author: 'Rae Solis',
      init: 'RS',
      avatarBg: '#D0C9D6',
      avatarFg: '#4D3E5C',
      teret: 'Ambient',
      title: 'Music for a room with one window',
      time: '7h',
      replies: 12
    }, {
      author: 'Bo Ling',
      init: 'BL',
      avatarBg: '#C9D6D3',
      avatarFg: '#3E5C56',
      teret: 'Records',
      title: 'The record I keep coming back to',
      time: '3d',
      replies: 8
    }]
  }, {
    id: 23,
    slug: 'the-commons',
    name: 'The commons',
    hue: 0,
    description: 'How this place runs — norms, care, and keeping it calm.',
    byteCount: 164,
    members: 5300,
    active: 6,
    notif: 2,
    terets: [{
      slug: 'guidelines',
      name: 'Guidelines',
      count: 12
    }, {
      slug: 'feedback',
      name: 'Feedback',
      count: 58
    }, {
      slug: 'meta',
      name: 'Meta',
      count: 41
    }],
    bytes: [{
      author: 'fomio team',
      init: 'f',
      avatarBg: '#E7D3CE',
      avatarFg: '#9E3326',
      teret: 'Guidelines',
      title: 'What we mean by a sanctuary',
      time: '1d',
      replies: 27
    }, {
      author: 'Vera Ost',
      init: 'VO',
      avatarBg: '#D6D0C2',
      avatarFg: '#5C563E',
      teret: 'Feedback',
      title: 'A slower way to disagree',
      time: '4d',
      replies: 19
    }]
  }]
};

/* Notification level presentation (label + icon + tone) */
window.HUBS_NOTIF = [{
  key: 0,
  label: 'Muted',
  icon: 'bellOff',
  hint: 'Nothing from this hub'
}, {
  key: 1,
  label: 'Normal',
  icon: 'bell',
  hint: 'Notify on @mentions and replies'
}, {
  key: 2,
  label: 'Tracking',
  icon: 'bell',
  hint: 'Count new bytes; notify on interaction'
}, {
  key: 3,
  label: 'Watching',
  icon: 'bellRing',
  hint: 'Notify on every new byte'
}];
})(); } catch (e) { __ds_ns.__errors.push({ path: "hubs-data.js", error: String((e && e.message) || e) }); }

// hubs-detail-data.js
try { (() => {
/* hubs-detail-data.js — per-hub byte (topic) feeds for the Hub-detail and
 * Teret-detail screens. Shapes mirror TopicListItem from the Hub Page API:
 *   id, title, excerpt, teret, posters(→author), reply_count, views, likes,
 *   read-time, last_posted_at(→relative), unseen(→unread), pinned, cover.
 * Exports on window:
 *   HUBS_FEED[hubId]         → array of expanded byte objects (newest-authored first)
 *   getHubTopics(hubId, {teret, filter, page, perPage}) → { topics, more, total, page }
 *   sortTopics(list, filter) → new sorted array
 */
(function () {
  /* Recurring author identities (avatar colours match hubs-data featured bytes) */
  const A = {
    lena: {
      author: 'Lena Marsh',
      init: 'LM',
      avatarBg: '#D6C9A8',
      avatarFg: '#5C4A1E'
    },
    ada: {
      author: 'Ada Reyes',
      init: 'AR',
      avatarBg: '#D6BFC9',
      avatarFg: '#5C3E4D'
    },
    theo: {
      author: 'Theo Mendez',
      init: 'TM',
      avatarBg: '#D6C2C2',
      avatarFg: '#5C3E3E'
    },
    jun: {
      author: 'Jun Nakamura',
      init: 'JN',
      avatarBg: '#C9D6C2',
      avatarFg: '#3E5C3E'
    },
    priya: {
      author: 'Priya Hart',
      init: 'PH',
      avatarBg: '#BFCAD6',
      avatarFg: '#3E4A5C'
    },
    sofia: {
      author: 'Sofia Okonkwo',
      init: 'SO',
      avatarBg: '#C7C9D6',
      avatarFg: '#3E3E5C'
    },
    marco: {
      author: 'Marco Vitale',
      init: 'MV',
      avatarBg: '#D6CBB8',
      avatarFg: '#5C4E2E'
    },
    ines: {
      author: 'Ines Roy',
      init: 'IR',
      avatarBg: '#C2D0D6',
      avatarFg: '#3E525C'
    },
    hana: {
      author: 'Hana Kimura',
      init: 'HK',
      avatarBg: '#CDD6C2',
      avatarFg: '#455C3E'
    },
    owen: {
      author: 'Owen Frost',
      init: 'OF',
      avatarBg: '#D6C7BF',
      avatarFg: '#5C453E'
    },
    nadia: {
      author: 'Nadia Bell',
      init: 'NB',
      avatarBg: '#C2C9D6',
      avatarFg: '#3E455C'
    },
    cyrus: {
      author: 'Cyrus Vane',
      init: 'CV',
      avatarBg: '#D6C2CE',
      avatarFg: '#5C3E52'
    },
    rae: {
      author: 'Rae Solis',
      init: 'RS',
      avatarBg: '#D0C9D6',
      avatarFg: '#4D3E5C'
    },
    bo: {
      author: 'Bo Ling',
      init: 'BL',
      avatarBg: '#C9D6D3',
      avatarFg: '#3E5C56'
    },
    vera: {
      author: 'Vera Ost',
      init: 'VO',
      avatarBg: '#D6D0C2',
      avatarFg: '#5C563E'
    },
    team: {
      author: 'fomio team',
      init: 'f',
      avatarBg: '#E7D3CE',
      avatarFg: '#9E3326'
    },
    iris: {
      author: 'Iris Waller',
      init: 'IW',
      avatarBg: '#D6D0C2',
      avatarFg: '#5C4A2E'
    },
    dov: {
      author: 'Dov Aaron',
      init: 'DA',
      avatarBg: '#C2D6CC',
      avatarFg: '#3E5C4E'
    }
  };

  /* Raw feeds keyed by hub id. Each: [teret, authorKey, hoursAgo, replies, likes, views, readMin, cover] + title/excerpt */
  const RAW = {
    3: [/* Writing */
    {
      teret: 'Essays',
      a: 'lena',
      hrs: 3,
      rep: 8,
      lk: 42,
      vw: 410,
      rd: 6,
      cover: true,
      unread: true,
      pinned: true,
      t: 'On writing without an audience',
      ex: 'The first draft is a conversation with no one. That is the only reason it stays honest.'
    }, {
      teret: 'Craft',
      a: 'ada',
      hrs: 9,
      rep: 16,
      lk: 61,
      vw: 720,
      rd: 8,
      t: 'The paragraph as a unit of thought',
      ex: 'Sentences are moves. Paragraphs are the arguments those moves add up to — treat them that way.'
    }, {
      teret: 'Drafts',
      a: 'iris',
      hrs: 20,
      rep: 4,
      lk: 19,
      vw: 180,
      rd: 4,
      unread: true,
      t: 'Everything I cut from the opening',
      ex: 'A public graveyard of first lines that were too clever to survive the second read.'
    }, {
      teret: 'First lines',
      a: 'theo',
      hrs: 33,
      rep: 27,
      lk: 88,
      vw: 1240,
      rd: 3,
      t: 'Collecting the sentences that made me keep reading',
      ex: 'Not the famous ones. The quiet openings that earned the next paragraph.'
    }, {
      teret: 'Craft',
      a: 'sofia',
      hrs: 52,
      rep: 11,
      lk: 37,
      vw: 490,
      rd: 7,
      t: 'Revision is not editing',
      ex: 'Editing tidies. Revision re-sees. Most drafts die from too much of the first and none of the second.'
    }, {
      teret: 'Essays',
      a: 'dov',
      hrs: 96,
      rep: 6,
      lk: 24,
      vw: 300,
      rd: 9,
      cover: true,
      t: 'Against the hot take',
      ex: 'A slower argument for arguments that take their time and risk being wrong out loud.'
    }],
    5: [/* Ideas */
    {
      teret: 'Quiet internet',
      a: 'jun',
      hrs: 24,
      rep: 34,
      lk: 120,
      vw: 2100,
      rd: 7,
      cover: true,
      pinned: true,
      t: 'The case for chronological feeds',
      ex: 'An ordering you can trust is worth more than an ordering that is optimally engaging.'
    }, {
      teret: 'Attention',
      a: 'theo',
      hrs: 48,
      rep: 21,
      lk: 96,
      vw: 1580,
      rd: 6,
      unread: true,
      t: 'Notifications are a design failure',
      ex: 'Every badge is a decision the product made on your behalf. Most of them it should not have.'
    }, {
      teret: 'Futures',
      a: 'ada',
      hrs: 12,
      rep: 9,
      lk: 44,
      vw: 610,
      rd: 10,
      t: 'What a calm platform owes its readers',
      ex: 'Not more features. Fewer reasons to open the app when you did not mean to.'
    }, {
      teret: 'Quiet internet',
      a: 'nadia',
      hrs: 70,
      rep: 15,
      lk: 58,
      vw: 840,
      rd: 5,
      t: 'I turned off every red dot for a month',
      ex: 'Field notes from removing the color red from my phone entirely. It went better than expected.'
    }, {
      teret: 'Attention',
      a: 'lena',
      hrs: 5,
      rep: 3,
      lk: 17,
      vw: 190,
      rd: 4,
      unread: true,
      t: 'Reading is the last single-tasking app',
      ex: 'You cannot skim your way to having read something. That constraint is a feature.'
    }, {
      teret: 'Futures',
      a: 'dov',
      hrs: 130,
      rep: 41,
      lk: 150,
      vw: 3200,
      rd: 12,
      cover: true,
      t: 'Small internets, on purpose',
      ex: 'A directory of communities that chose to stay small and got better for it.'
    }],
    8: [/* Reading */
    {
      teret: 'Marginalia',
      a: 'priya',
      hrs: 6,
      rep: 11,
      lk: 39,
      vw: 520,
      rd: 5,
      cover: true,
      unread: true,
      t: 'Notes in the margins of a borrowed book',
      ex: 'Someone underlined the same sentence I would have. We have never met. We have met exactly here.'
    }, {
      teret: 'Poetry',
      a: 'sofia',
      hrs: 24,
      rep: 7,
      lk: 51,
      vw: 680,
      rd: 3,
      pinned: true,
      t: 'A line I have carried for ten years',
      ex: 'On the poems that arrive early and stay, and how you cannot choose which ones do.'
    }, {
      teret: 'Rereads',
      a: 'lena',
      hrs: 40,
      rep: 18,
      lk: 62,
      vw: 910,
      rd: 8,
      t: 'The book changed because I did',
      ex: 'Rereading at forty what I loved at twenty. The words held still. Everything else moved.'
    }, {
      teret: 'Marginalia',
      a: 'theo',
      hrs: 15,
      rep: 5,
      lk: 22,
      vw: 240,
      rd: 4,
      t: 'In defense of writing in books',
      ex: 'A clean book is a book you did not argue with. I want the argument on the page.'
    }, {
      teret: 'Poetry',
      a: 'iris',
      hrs: 88,
      rep: 9,
      lk: 33,
      vw: 400,
      rd: 2,
      unread: true,
      t: 'Reading a poem out loud, alone',
      ex: 'It is a different text at speaking speed. Try it once in an empty room.'
    }],
    11: [/* Photography */
    {
      teret: 'Film',
      a: 'marco',
      hrs: 5,
      rep: 9,
      lk: 47,
      vw: 560,
      rd: 6,
      cover: true,
      unread: true,
      pinned: true,
      t: 'Why I still develop at home',
      ex: 'The forty minutes at the sink are the part of photography that has not been automated away.'
    }, {
      teret: 'Street',
      a: 'ines',
      hrs: 48,
      rep: 13,
      lk: 55,
      vw: 730,
      rd: 5,
      t: 'Standing on one corner for an hour',
      ex: 'The frame does not change. The light and the strangers do. Patience is the lens.'
    }, {
      teret: 'Stillness',
      a: 'priya',
      hrs: 26,
      rep: 6,
      lk: 28,
      vw: 310,
      rd: 4,
      cover: true,
      t: 'A photograph of nothing happening',
      ex: 'The hardest images to make and the ones I return to. An argument for the uneventful.'
    }, {
      teret: 'Film',
      a: 'cyrus',
      hrs: 72,
      rep: 20,
      lk: 74,
      vw: 1100,
      rd: 7,
      t: 'One roll, one week, no chimping',
      ex: 'Thirty-six frames and no reviewing until the roll was done. What the constraint gave back.'
    }, {
      teret: 'Street',
      a: 'nadia',
      hrs: 14,
      rep: 4,
      lk: 18,
      vw: 210,
      rd: 3,
      unread: true,
      t: 'Asking before the shutter',
      ex: 'On consent, eye contact, and the pictures I did not take and do not regret.'
    }],
    14: [/* Craft & making */
    {
      teret: 'Letterpress',
      a: 'hana',
      hrs: 8,
      rep: 6,
      lk: 31,
      vw: 360,
      rd: 6,
      cover: true,
      unread: true,
      pinned: true,
      t: 'Setting a poem by hand, one slug at a time',
      ex: 'Composing metal type is reading in reverse and slow motion. You notice every comma.'
    }, {
      teret: 'Tools',
      a: 'owen',
      hrs: 72,
      rep: 18,
      lk: 66,
      vw: 980,
      rd: 5,
      t: 'The three tools I would keep',
      ex: 'If the workshop burned and I could save three things. The list surprised me.'
    }, {
      teret: 'Woodwork',
      a: 'dov',
      hrs: 30,
      rep: 8,
      lk: 40,
      vw: 470,
      rd: 7,
      cover: true,
      t: 'The joint you never see',
      ex: 'On making the hidden parts well anyway — the drawer bottom, the back of the case.'
    }, {
      teret: 'Tools',
      a: 'iris',
      hrs: 50,
      rep: 5,
      lk: 21,
      vw: 250,
      rd: 4,
      unread: true,
      t: 'Sharpening is the whole craft',
      ex: 'A dull tool teaches bad habits. Twenty minutes on the stone fixes more than technique.'
    }, {
      teret: 'Letterpress',
      a: 'lena',
      hrs: 120,
      rep: 11,
      lk: 44,
      vw: 600,
      rd: 8,
      t: 'Impression, and knowing when to stop',
      ex: 'A little bite in the paper reads as care. Too much reads as a machine trying too hard.'
    }],
    17: [/* Field notes */
    {
      teret: 'Walks',
      a: 'nadia',
      hrs: 4,
      rep: 10,
      lk: 38,
      vw: 440,
      rd: 5,
      cover: true,
      unread: true,
      pinned: true,
      t: 'The same loop, a hundred mornings',
      ex: 'One route walked until it stopped being a route and became a way of paying attention.'
    }, {
      teret: 'Cities',
      a: 'cyrus',
      hrs: 48,
      rep: 5,
      lk: 26,
      vw: 300,
      rd: 4,
      t: 'A quiet block in a loud district',
      ex: 'Every noisy neighborhood keeps one calm street. Here is how I find them.'
    }, {
      teret: 'Weather',
      a: 'priya',
      hrs: 22,
      rep: 7,
      lk: 30,
      vw: 350,
      rd: 3,
      unread: true,
      t: 'Walking in the rain on purpose',
      ex: 'The city empties and softens. The best hour to be outside is the one everyone avoids.'
    }, {
      teret: 'Walks',
      a: 'theo',
      hrs: 90,
      rep: 14,
      lk: 52,
      vw: 700,
      rd: 6,
      cover: true,
      t: 'Getting lost in a grid',
      ex: 'It is harder than it sounds and worth the practice. Notes on losing your bearings deliberately.'
    }, {
      teret: 'Cities',
      a: 'ines',
      hrs: 60,
      rep: 4,
      lk: 19,
      vw: 220,
      rd: 5,
      t: 'The bench I keep coming back to',
      ex: 'On the value of a fixed vantage point in a place that never holds still.'
    }],
    20: [/* Sound */
    {
      teret: 'Ambient',
      a: 'rae',
      hrs: 7,
      rep: 12,
      lk: 45,
      vw: 590,
      rd: 4,
      cover: true,
      unread: true,
      pinned: true,
      t: 'Music for a room with one window',
      ex: 'A short list of records that do not ask for anything. They just change the air a little.'
    }, {
      teret: 'Records',
      a: 'bo',
      hrs: 72,
      rep: 8,
      lk: 34,
      vw: 420,
      rd: 6,
      t: 'The record I keep coming back to',
      ex: 'Not the best one I own. The one I reach for when I do not want to decide.'
    }, {
      teret: 'Live',
      a: 'cyrus',
      hrs: 30,
      rep: 6,
      lk: 28,
      vw: 330,
      rd: 5,
      unread: true,
      t: 'The show where nobody filmed',
      ex: 'One room agreed to just be there. What that agreement did to the sound and the memory.'
    }, {
      teret: 'Ambient',
      a: 'iris',
      hrs: 54,
      rep: 9,
      lk: 41,
      vw: 510,
      rd: 3,
      t: 'Silence has a texture too',
      ex: 'On the recordings that are mostly room tone, and why I find them so easy to live inside.'
    }, {
      teret: 'Records',
      a: 'rae',
      hrs: 110,
      rep: 15,
      lk: 58,
      vw: 820,
      rd: 7,
      cover: true,
      t: 'Learning to hear the room',
      ex: 'The same pressing sounds different in every space. A note on where you sit to listen.'
    }],
    23: [/* The commons */
    {
      teret: 'Guidelines',
      a: 'team',
      hrs: 24,
      rep: 27,
      lk: 96,
      vw: 3400,
      rd: 5,
      pinned: true,
      t: 'What we mean by a sanctuary',
      ex: 'The short version of every rule here: assume good faith, disagree slowly, protect the quiet.'
    }, {
      teret: 'Feedback',
      a: 'vera',
      hrs: 96,
      rep: 19,
      lk: 61,
      vw: 1200,
      rd: 6,
      t: 'A slower way to disagree',
      ex: 'A proposal for a reply flow that rewards understanding the other person before answering.'
    }, {
      teret: 'Meta',
      a: 'dov',
      hrs: 40,
      rep: 12,
      lk: 44,
      vw: 680,
      rd: 4,
      unread: true,
      t: 'Why there are no like counts on the home feed',
      ex: 'We hid the number on purpose. Here is the reasoning, and how to change our minds.'
    }, {
      teret: 'Feedback',
      a: 'nadia',
      hrs: 14,
      rep: 8,
      lk: 22,
      vw: 290,
      rd: 3,
      unread: true,
      t: 'Request: mute a teret without muting the hub',
      ex: 'I love this hub and want nothing from one of its terets. Small ask, real need.'
    }, {
      teret: 'Guidelines',
      a: 'lena',
      hrs: 130,
      rep: 6,
      lk: 30,
      vw: 500,
      rd: 7,
      t: 'On flagging, and what happens next',
      ex: 'A walk through exactly what a flag does, who sees it, and how long it takes.'
    }]
  };
  function timeLabel(hrs) {
    if (hrs < 1) return 'now';
    if (hrs < 24) return hrs + 'h';
    const d = Math.round(hrs / 24);
    if (d < 7) return d + 'd';
    return Math.round(d / 7) + 'w';
  }

  /* Expand raw rows into full byte objects (merge author, derive labels + id) */
  const HUBS_FEED = {};
  let seed = 4100;
  Object.keys(RAW).forEach(function (hubId) {
    HUBS_FEED[hubId] = RAW[hubId].map(function (r) {
      const au = A[r.a] || A.lena;
      return {
        id: ++seed,
        title: r.t,
        excerpt: r.ex,
        teret: r.teret,
        author: au.author,
        init: au.init,
        avatarBg: au.avatarBg,
        avatarFg: au.avatarFg,
        hrs: r.hrs,
        time: timeLabel(r.hrs),
        replies: r.rep,
        likes: r.lk,
        views: r.vw,
        read: r.rd,
        cover: !!r.cover,
        unread: !!r.unread,
        pinned: !!r.pinned
      };
    });
  });
  function sortTopics(list, filter) {
    const arr = list.slice();
    if (filter === 'hot') {
      arr.sort(function (a, b) {
        const sa = (a.likes + a.replies * 3) / Math.pow(a.hrs + 2, 0.8);
        const sb = (b.likes + b.replies * 3) / Math.pow(b.hrs + 2, 0.8);
        return sb - sa;
      });
    } else if (filter === 'top') {
      arr.sort(function (a, b) {
        return b.likes * 2 + b.replies + b.views * 0.05 - (a.likes * 2 + a.replies + a.views * 0.05);
      });
    } else {
      /* latest */
      arr.sort(function (a, b) {
        return a.hrs - b.hrs;
      });
    }
    // Pinned always float to the top regardless of filter (Discourse behaviour)
    arr.sort(function (a, b) {
      return (b.pinned ? 1 : 0) - (a.pinned ? 1 : 0);
    });
    return arr;
  }
  function getHubTopics(hubId, opts) {
    opts = opts || {};
    const filter = opts.filter || 'latest';
    const perPage = opts.perPage || 4;
    const page = opts.page || 1;
    let list = (HUBS_FEED[hubId] || []).slice();
    if (opts.teret) list = list.filter(function (b) {
      return b.teret === opts.teret;
    });
    const sorted = sortTopics(list, filter);
    const end = page * perPage;
    return {
      topics: sorted.slice(0, end),
      total: sorted.length,
      page: page,
      more: end < sorted.length
    };
  }
  window.HUBS_FEED = HUBS_FEED;
  window.getHubTopics = getHubTopics;
  window.sortTopics = sortTopics;
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "hubs-detail-data.js", error: String((e && e.message) || e) }); }

// hubs-detail-screen.jsx
try { (() => {
/* hubs-detail-screen.jsx — full-screen Hub detail (/c/:slug) and Teret detail
 * (/c/:slug/:teret). Both = editorial header + notification control + Latest/Hot/Top
 * filter tabs + a paginated byte (topic) list. Shapes follow the Hub Page API.
 * Exports: HubDetailScreen, TeretDetailScreen.
 */
const {
  HIc,
  Avatar,
  TeretBadge,
  Chip,
  MetaDot,
  CoverPlaceholder,
  Stat
} = window;
const {
  HubIc,
  hubAccent,
  NotifSegmented
} = window;
const getHubTopics = window.getHubTopics;
const HD_NOTIF = window.HUBS_NOTIF;

/* ── Filter tabs — Latest / Hot / Top (+ period row for Top) ─── */
const HD_PERIODS = [{
  key: 'all',
  label: 'All'
}, {
  key: 'yearly',
  label: 'Year'
}, {
  key: 'monthly',
  label: 'Month'
}, {
  key: 'weekly',
  label: 'Week'
}, {
  key: 'daily',
  label: 'Today'
}];
function FilterTabs({
  filter,
  setFilter,
  period,
  setPeriod,
  count
}) {
  const tabs = [{
    key: 'latest',
    label: 'Latest'
  }, {
    key: 'hot',
    label: 'Hot'
  }, {
    key: 'top',
    label: 'Top'
  }];
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8
    }
  }, tabs.map(t => /*#__PURE__*/React.createElement(Chip, {
    key: t.key,
    label: t.label,
    active: filter === t.key,
    onClick: () => setFilter(t.key)
  }))), /*#__PURE__*/React.createElement("span", {
    style: {
      marginLeft: 'auto',
      fontFamily: 'var(--fomio-mono)',
      fontSize: 11.5,
      color: 'var(--fomio-fg-muted)',
      letterSpacing: '0.02em'
    }
  }, count.toLocaleString(), " ", count === 1 ? 'byte' : 'bytes')), filter === 'top' && /*#__PURE__*/React.createElement("div", {
    className: "hb-expand",
    style: {
      display: 'flex',
      gap: 6,
      marginTop: 12
    }
  }, HD_PERIODS.map(p => {
    const on = period === p.key;
    return /*#__PURE__*/React.createElement("button", {
      key: p.key,
      onClick: () => setPeriod(p.key),
      style: {
        height: 28,
        padding: '0 12px',
        borderRadius: 9999,
        cursor: 'pointer',
        border: 'none',
        background: on ? 'var(--fomio-surface)' : 'transparent',
        fontFamily: 'var(--fomio-sans)',
        fontSize: 12,
        fontWeight: on ? 700 : 600,
        color: on ? 'var(--fomio-fg)' : 'var(--fomio-fg-muted)',
        transition: 'background 140ms'
      }
    }, p.label);
  })));
}

/* ── Byte (topic) list row ───────────────────────────────────── */
function TopicRow({
  b,
  lead,
  opts,
  onOpen
}) {
  const comfy = opts.topicLayout !== 'compact';
  const showCover = opts.showCovers && b.cover && comfy;
  return /*#__PURE__*/React.createElement("article", {
    className: "hb-row",
    onClick: () => onOpen(b),
    style: {
      display: 'flex',
      gap: 16,
      alignItems: 'flex-start',
      padding: lead ? '2px 12px 22px' : '18px 12px',
      cursor: 'pointer',
      borderBottom: '1px solid var(--fomio-border)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 7,
      paddingTop: 7,
      flexShrink: 0
    }
  }, b.unread && /*#__PURE__*/React.createElement("span", {
    style: {
      width: 7,
      height: 7,
      borderRadius: '50%',
      background: 'var(--fomio-primary)',
      display: 'block'
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      marginBottom: 7,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement(Avatar, {
    user: b,
    size: 20
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--fomio-sans)',
      fontWeight: 600,
      fontSize: 12.5,
      color: 'var(--fomio-fg)',
      whiteSpace: 'nowrap'
    }
  }, b.author), opts.showTeretBadge && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(MetaDot, null), /*#__PURE__*/React.createElement(TeretBadge, {
    label: b.teret
  })), /*#__PURE__*/React.createElement(MetaDot, null), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--fomio-sans)',
      fontSize: 12,
      color: 'var(--fomio-fg-muted)'
    }
  }, b.time), b.pinned && /*#__PURE__*/React.createElement("span", {
    title: "Pinned",
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 4,
      marginLeft: 4,
      fontFamily: 'var(--fomio-sans)',
      fontSize: 10,
      fontWeight: 700,
      letterSpacing: '0.06em',
      textTransform: 'uppercase',
      color: 'var(--fomio-primary)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 5,
      height: 5,
      borderRadius: '50%',
      background: 'var(--fomio-primary)'
    }
  }), "Pinned")), /*#__PURE__*/React.createElement("h3", {
    className: "hb-name",
    style: {
      margin: '0 0 6px',
      fontFamily: 'var(--fomio-serif)',
      fontWeight: 700,
      fontSize: lead ? 25 : 19,
      lineHeight: 1.24,
      letterSpacing: '-0.02em',
      color: 'var(--fomio-fg)',
      textWrap: 'pretty'
    }
  }, b.title), comfy && /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '0 0 12px',
      fontFamily: 'var(--fomio-serif)',
      fontSize: lead ? 15.5 : 14.5,
      lineHeight: 1.55,
      color: 'var(--fomio-fg-muted)',
      display: '-webkit-box',
      WebkitLineClamp: lead ? 3 : 2,
      WebkitBoxOrient: 'vertical',
      overflow: 'hidden',
      textWrap: 'pretty'
    }
  }, b.excerpt), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 16,
      marginTop: comfy ? 0 : 8
    }
  }, /*#__PURE__*/React.createElement(Stat, {
    icon: "reply",
    value: b.replies
  }), /*#__PURE__*/React.createElement(Stat, {
    icon: "heart",
    value: b.likes,
    active: b.unread
  }), /*#__PURE__*/React.createElement(Stat, {
    icon: "eye",
    value: b.views
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--fomio-sans)',
      fontSize: 12,
      fontWeight: 600,
      color: 'var(--fomio-fg-muted)'
    }
  }, b.read, " min"))), showCover && /*#__PURE__*/React.createElement("div", {
    style: {
      width: lead ? 168 : 116,
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement(CoverPlaceholder, {
    height: lead ? 120 : 82,
    radius: 12,
    label: lead ? 'cover' : 'img'
  })));
}

/* ── Topic list states ───────────────────────────────────────── */
function TopicSkeleton({
  n = 4
}) {
  const line = (w, h, mt) => /*#__PURE__*/React.createElement("div", {
    className: "fh-shimmer",
    style: {
      width: w,
      height: h,
      borderRadius: 6,
      marginTop: mt || 0,
      background: 'var(--fomio-surface)'
    }
  });
  return /*#__PURE__*/React.createElement("div", {
    "aria-busy": "true",
    style: {
      borderTop: '1px solid var(--fomio-border)'
    }
  }, Array.from({
    length: n
  }).map((_, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      display: 'flex',
      gap: 16,
      padding: '18px 12px',
      borderBottom: '1px solid var(--fomio-border)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 7
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, line('42%', 12), line('76%', 20, 12), line('96%', 13, 12), line('40%', 13, 8)))));
}
function TeretEmpty({
  teret,
  gated
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'center',
      padding: '56px 24px',
      maxWidth: 400,
      margin: '0 auto'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 52,
      height: 52,
      borderRadius: 15,
      background: 'var(--fomio-surface)',
      border: '1px solid var(--fomio-border)',
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      marginBottom: 18
    }
  }, /*#__PURE__*/React.createElement(HubIc, {
    name: "hash",
    size: 24,
    color: "var(--fomio-fg-muted)",
    stroke: 1.7
  })), /*#__PURE__*/React.createElement("h3", {
    style: {
      margin: '0 0 8px',
      fontFamily: 'var(--fomio-serif)',
      fontWeight: 700,
      fontSize: 21,
      letterSpacing: '-0.02em',
      color: 'var(--fomio-fg)'
    }
  }, "Nothing in ", teret, " yet"), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '0 0 22px',
      fontFamily: 'var(--fomio-serif)',
      fontSize: 15,
      lineHeight: 1.6,
      color: 'var(--fomio-fg-muted)'
    }
  }, "This teret is quiet. ", gated ? 'Log in to be the first to write here.' : 'Be the first to write a byte in it.'), !gated && /*#__PURE__*/React.createElement("button", {
    style: {
      height: 44,
      padding: '0 20px',
      borderRadius: 9999,
      background: 'var(--fomio-primary)',
      color: '#fff',
      border: 'none',
      cursor: 'pointer',
      fontFamily: 'var(--fomio-sans)',
      fontWeight: 700,
      fontSize: 14,
      display: 'inline-flex',
      alignItems: 'center',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement(HIc, {
    name: "feather",
    size: 16,
    color: "#fff",
    stroke: 1.9
  }), " Write the first byte"));
}

/* ── Byte list with pagination (more_topics_url pattern) ─────── */
function ByteList({
  hubId,
  teret,
  opts,
  feedState
}) {
  const {
    useState,
    useEffect
  } = React;
  const [filter, setFilter] = useState(opts.defaultFilter || 'latest');
  const [period, setPeriod] = useState('monthly');
  const [page, setPage] = useState(1);
  const [loadingMore, setLoadingMore] = useState(false);
  useEffect(() => {
    setPage(1);
  }, [filter, period, hubId, teret]);
  if (feedState === 'loading') {
    return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
      style: {
        marginBottom: 18
      }
    }, /*#__PURE__*/React.createElement(FilterTabs, {
      filter: filter,
      setFilter: setFilter,
      period: period,
      setPeriod: setPeriod,
      count: 0
    })), /*#__PURE__*/React.createElement(TopicSkeleton, null));
  }
  const res = getHubTopics(hubId, {
    teret,
    filter,
    period,
    page,
    perPage: 4
  });
  const loadMore = () => {
    setLoadingMore(true);
    setTimeout(() => {
      setPage(p => p + 1);
      setLoadingMore(false);
    }, 420);
  };
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 16
    }
  }, /*#__PURE__*/React.createElement(FilterTabs, {
    filter: filter,
    setFilter: setFilter,
    period: period,
    setPeriod: setPeriod,
    count: res.total
  })), res.total === 0 ? /*#__PURE__*/React.createElement(TeretEmpty, {
    teret: teret,
    gated: opts.gated
  }) : /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    style: {
      borderTop: '1px solid var(--fomio-border)'
    }
  }, res.topics.map((b, i) => /*#__PURE__*/React.createElement(TopicRow, {
    key: b.id,
    b: b,
    lead: i === 0 && filter !== 'compact',
    opts: opts,
    onOpen: () => {}
  }))), res.more ? /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'center',
      paddingTop: 22
    }
  }, /*#__PURE__*/React.createElement("button", {
    onClick: loadMore,
    disabled: loadingMore,
    className: "hb-seeall",
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 8,
      height: 42,
      padding: '0 22px',
      borderRadius: 9999,
      cursor: 'pointer',
      background: 'transparent',
      border: '1.5px solid var(--fomio-border)',
      fontFamily: 'var(--fomio-sans)',
      fontSize: 13.5,
      fontWeight: 700,
      color: 'var(--fomio-fg)',
      opacity: loadingMore ? 0.6 : 1
    }
  }, loadingMore ? 'Loading…' : /*#__PURE__*/React.createElement(React.Fragment, null, "Load more bytes", /*#__PURE__*/React.createElement(HubIc, {
    name: "chevronDown",
    size: 16,
    color: "var(--fomio-primary)",
    stroke: 2
  })))) : /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'center',
      padding: '26px 0 4px',
      fontFamily: 'var(--fomio-sans)',
      fontSize: 12,
      fontWeight: 600,
      letterSpacing: '0.04em',
      textTransform: 'uppercase',
      color: 'var(--fomio-fg-muted)'
    }
  }, "End of ", teret || 'hub', " \xB7 ", res.total, " bytes")));
}

/* ── Compact stat cluster (shared header) ────────────────────── */
function StatCluster({
  items
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 16,
      flexWrap: 'wrap'
    }
  }, items.map((it, i) => /*#__PURE__*/React.createElement("span", {
    key: i,
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 5,
      fontFamily: 'var(--fomio-sans)',
      fontSize: 12.5,
      fontWeight: 600,
      color: it.accent ? 'var(--fomio-primary)' : 'var(--fomio-fg-secondary)'
    }
  }, it.accent ? /*#__PURE__*/React.createElement("span", {
    style: {
      width: 6,
      height: 6,
      borderRadius: '50%',
      background: 'var(--fomio-primary)'
    }
  }) : /*#__PURE__*/React.createElement(HubIc, {
    name: it.icon,
    size: 14,
    color: "var(--fomio-fg-muted)",
    stroke: 1.8
  }), it.val, " ", /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--fomio-fg-muted)',
      fontWeight: 500
    }
  }, it.label))));
}

/* ── Back / breadcrumb bar ───────────────────────────────────── */
function CrumbBar({
  crumbs
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      marginBottom: 18,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement("button", {
    onClick: crumbs[0].onClick,
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6,
      background: 'none',
      border: 'none',
      cursor: 'pointer',
      padding: 0,
      fontFamily: 'var(--fomio-sans)',
      fontSize: 13,
      fontWeight: 600,
      color: 'var(--fomio-fg-muted)'
    }
  }, /*#__PURE__*/React.createElement(HIc, {
    name: "arrowLeft",
    size: 16,
    color: "var(--fomio-fg-muted)"
  }), " ", crumbs[0].label), crumbs.slice(1).map((c, i) => /*#__PURE__*/React.createElement(React.Fragment, {
    key: i
  }, /*#__PURE__*/React.createElement(HubIc, {
    name: "chevronRight",
    size: 13,
    color: "var(--fomio-fg-muted)",
    stroke: 2
  }), c.onClick ? /*#__PURE__*/React.createElement("button", {
    onClick: c.onClick,
    style: {
      background: 'none',
      border: 'none',
      cursor: 'pointer',
      padding: 0,
      fontFamily: 'var(--fomio-sans)',
      fontSize: 13,
      fontWeight: 600,
      color: 'var(--fomio-fg-muted)'
    }
  }, c.label) : /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--fomio-sans)',
      fontSize: 13,
      fontWeight: 700,
      color: 'var(--fomio-fg)'
    }
  }, c.label))));
}

/* ── Shared detail header (title, description, stats, notif) ─── */
function DetailHeader({
  accent,
  eyebrow,
  title,
  description,
  stats,
  notifLevel,
  onSetNotif,
  gated,
  mode,
  kind
}) {
  const big = mode === 'expanded';
  return /*#__PURE__*/React.createElement("header", {
    style: {
      marginBottom: 22
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 16,
      alignItems: 'flex-start'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 3,
      alignSelf: 'stretch',
      minHeight: 46,
      borderRadius: 2,
      background: accent,
      flexShrink: 0,
      opacity: 0.9
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, eyebrow && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 7,
      marginBottom: 8
    }
  }, /*#__PURE__*/React.createElement(HubIc, {
    name: kind === 'teret' ? 'hash' : 'layers',
    size: 14,
    color: "var(--fomio-primary)",
    stroke: 2
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--fomio-sans)',
      fontSize: 11,
      fontWeight: 700,
      letterSpacing: '0.08em',
      textTransform: 'uppercase',
      color: 'var(--fomio-fg-muted)'
    }
  }, eyebrow)), /*#__PURE__*/React.createElement("h1", {
    style: {
      margin: '0 0 8px',
      fontFamily: 'var(--fomio-serif)',
      fontWeight: 700,
      fontSize: big ? 38 : 30,
      lineHeight: 1.08,
      letterSpacing: '-0.03em',
      color: 'var(--fomio-fg)',
      textWrap: 'balance'
    }
  }, title), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '0 0 16px',
      fontFamily: 'var(--fomio-serif)',
      fontSize: big ? 17 : 15.5,
      lineHeight: 1.55,
      color: 'var(--fomio-fg-muted)',
      maxWidth: 620,
      textWrap: 'pretty'
    }
  }, description), /*#__PURE__*/React.createElement(StatCluster, {
    items: stats
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 20,
      paddingLeft: 19,
      maxWidth: 560
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--fomio-sans)',
      fontSize: 10.5,
      fontWeight: 700,
      letterSpacing: '0.08em',
      textTransform: 'uppercase',
      color: 'var(--fomio-fg-muted)',
      marginBottom: 10
    }
  }, "Notifications"), /*#__PURE__*/React.createElement(NotifSegmented, {
    level: notifLevel,
    gated: gated,
    onSet: onSetNotif
  })));
}

/* ── Teret strip (hub detail) — chips route to teret detail ──── */
function TeretStrip({
  hub,
  activeTeret,
  onOpenTeret
}) {
  return /*#__PURE__*/React.createElement("section", {
    style: {
      marginBottom: 26
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      marginBottom: 12
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--fomio-sans)',
      fontSize: 10.5,
      fontWeight: 700,
      letterSpacing: '0.08em',
      textTransform: 'uppercase',
      color: 'var(--fomio-fg-muted)'
    }
  }, "Terets"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--fomio-mono)',
      fontSize: 11,
      color: 'var(--fomio-fg-muted)'
    }
  }, hub.terets.length)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      gap: 8
    }
  }, hub.terets.map(t => {
    const on = activeTeret === t.slug;
    return /*#__PURE__*/React.createElement("button", {
      key: t.slug,
      onClick: () => onOpenTeret(hub, t),
      className: "hb-teret",
      style: {
        display: 'inline-flex',
        alignItems: 'center',
        gap: 8,
        height: 34,
        padding: '0 14px',
        borderRadius: 9999,
        cursor: 'pointer',
        border: `1px solid ${on ? 'var(--fomio-primary)' : 'var(--fomio-border)'}`,
        background: on ? 'var(--fomio-primary-soft)' : 'var(--fomio-card)',
        fontFamily: 'var(--fomio-sans)',
        fontSize: 13,
        fontWeight: 600,
        color: on ? 'var(--fomio-primary-dark)' : 'var(--fomio-fg)',
        transition: 'border-color 150ms, background 150ms'
      }
    }, /*#__PURE__*/React.createElement(HubIc, {
      name: "hash",
      size: 13,
      color: on ? 'var(--fomio-primary)' : 'var(--fomio-fg-muted)',
      stroke: 2
    }), t.name, /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--fomio-mono)',
        fontSize: 11,
        color: 'var(--fomio-fg-muted)'
      }
    }, t.count));
  })));
}

/* ── Write-a-byte affordance (can_create_topic) ──────────────── */
function ComposeBar({
  context,
  gated
}) {
  return /*#__PURE__*/React.createElement("button", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12,
      width: '100%',
      marginBottom: 24,
      padding: '13px 16px',
      borderRadius: 14,
      cursor: 'pointer',
      textAlign: 'left',
      background: 'var(--fomio-card)',
      border: '1px solid var(--fomio-border)',
      transition: 'border-color 150ms'
    },
    className: "hb-teretrow"
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 34,
      height: 34,
      borderRadius: 10,
      flexShrink: 0,
      background: 'var(--fomio-primary-soft)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center'
    }
  }, /*#__PURE__*/React.createElement(HIc, {
    name: "feather",
    size: 17,
    color: "var(--fomio-primary-dark)",
    stroke: 1.9
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      fontFamily: 'var(--fomio-serif)',
      fontSize: 15,
      fontStyle: 'italic',
      color: 'var(--fomio-fg-muted)'
    }
  }, gated ? 'Log in to write a byte…' : `Write a byte in ${context}…`), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--fomio-sans)',
      fontSize: 12,
      fontWeight: 700,
      letterSpacing: '0.04em',
      textTransform: 'uppercase',
      color: 'var(--fomio-primary)'
    }
  }, "New"));
}

/* ════════════ HUB DETAIL SCREEN (/c/:slug) ═══════════════════ */
function HubDetailScreen({
  hub,
  opts,
  notifLevel,
  onSetNotif,
  onBack,
  onOpenTeret,
  feedState
}) {
  const accent = hubAccent(hub, opts.colorMode);
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(CrumbBar, {
    crumbs: [{
      label: 'Hubs',
      onClick: onBack
    }]
  }), /*#__PURE__*/React.createElement(DetailHeader, {
    kind: "hub",
    accent: accent,
    eyebrow: "Hub",
    title: hub.name,
    description: hub.description,
    stats: [{
      icon: 'layers',
      val: hub.byteCount.toLocaleString(),
      label: 'bytes'
    }, {
      icon: 'users',
      val: hub.members.toLocaleString(),
      label: 'readers'
    }, {
      accent: true,
      val: hub.active,
      label: 'active today'
    }],
    notifLevel: notifLevel,
    onSetNotif: onSetNotif,
    gated: opts.gated,
    mode: opts.mode
  }), /*#__PURE__*/React.createElement(TeretStrip, {
    hub: hub,
    activeTeret: null,
    onOpenTeret: onOpenTeret
  }), /*#__PURE__*/React.createElement(ComposeBar, {
    context: hub.name,
    gated: opts.gated
  }), /*#__PURE__*/React.createElement(ByteList, {
    hubId: hub.id,
    teret: null,
    opts: {
      ...opts,
      showTeretBadge: true
    },
    feedState: feedState
  }));
}

/* ════════════ TERET DETAIL SCREEN (/c/:slug/:teret) ══════════ */
function TeretDetailScreen({
  hub,
  teret,
  opts,
  notifLevel,
  onSetNotif,
  onBack,
  onBackToHub,
  feedState
}) {
  const accent = hubAccent(hub, opts.colorMode);
  const otherTerets = hub.terets.filter(t => t.slug !== teret.slug);
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(CrumbBar, {
    crumbs: [{
      label: 'Hubs',
      onClick: onBack
    }, {
      label: hub.name,
      onClick: onBackToHub
    }, {
      label: teret.name
    }]
  }), /*#__PURE__*/React.createElement(DetailHeader, {
    kind: "teret",
    accent: accent,
    eyebrow: `Teret in ${hub.name}`,
    title: teret.name,
    description: `A teret inside ${hub.name}. ${teret.count} bytes gathered here — follow it on its own, or mute it without leaving the hub.`,
    stats: [{
      icon: 'hash',
      val: teret.count.toLocaleString(),
      label: 'bytes'
    }, {
      icon: 'layers',
      val: hub.name,
      label: 'hub'
    }, {
      accent: true,
      val: hub.active,
      label: 'active today'
    }],
    notifLevel: notifLevel,
    onSetNotif: onSetNotif,
    gated: opts.gated,
    mode: opts.mode
  }), /*#__PURE__*/React.createElement(ComposeBar, {
    context: teret.name,
    gated: opts.gated
  }), /*#__PURE__*/React.createElement(ByteList, {
    hubId: hub.id,
    teret: teret.name,
    opts: {
      ...opts,
      showTeretBadge: false
    },
    feedState: feedState
  }), otherTerets.length > 0 && /*#__PURE__*/React.createElement("section", {
    style: {
      marginTop: 34,
      paddingTop: 22,
      borderTop: '1px solid var(--fomio-border)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--fomio-sans)',
      fontSize: 10.5,
      fontWeight: 700,
      letterSpacing: '0.08em',
      textTransform: 'uppercase',
      color: 'var(--fomio-fg-muted)',
      marginBottom: 12
    }
  }, "More in ", hub.name), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      gap: 8
    }
  }, otherTerets.map(t => /*#__PURE__*/React.createElement("button", {
    key: t.slug,
    onClick: () => onBackToHub && onBackToHub(t),
    className: "hb-teret",
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 8,
      height: 32,
      padding: '0 13px',
      borderRadius: 9999,
      cursor: 'pointer',
      border: '1px solid var(--fomio-border)',
      background: 'transparent',
      fontFamily: 'var(--fomio-sans)',
      fontSize: 12.5,
      fontWeight: 600,
      color: 'var(--fomio-fg)',
      transition: 'border-color 150ms'
    }
  }, /*#__PURE__*/React.createElement(HubIc, {
    name: "hash",
    size: 12,
    color: "var(--fomio-fg-muted)",
    stroke: 2
  }), t.name, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--fomio-mono)',
      fontSize: 10.5,
      color: 'var(--fomio-fg-muted)'
    }
  }, t.count))))));
}
Object.assign(window, {
  HubDetailScreen,
  TeretDetailScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "hubs-detail-screen.jsx", error: String((e && e.message) || e) }); }

// hubs-detail.jsx
try { (() => {
/* hubs-detail.jsx — drill-down surfaces: notification segmented control,
 * the shared hub-detail body (terets + featured bytes), the inline expander,
 * the side sheet, and the search-results (breadcrumb) view.
 * Exports: NotifSegmented, HubDetailBody, HubSheet, SearchResults.
 */
const {
  HIc,
  Avatar,
  TeretBadge
} = window;
const {
  HubIc,
  hubAccent,
  NotifBell
} = window;
const H_NOTIF = window.HUBS_NOTIF;

/* ── Segmented notification control (detail surfaces) ────────── */
function NotifSegmented({
  level,
  gated,
  onSet
}) {
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 4,
      padding: 4,
      borderRadius: 12,
      background: 'var(--fomio-surface)',
      border: '1px solid var(--fomio-border)'
    }
  }, H_NOTIF.map(n => {
    const active = level === n.key;
    return /*#__PURE__*/React.createElement("button", {
      key: n.key,
      onClick: () => !gated && onSet(n.key),
      title: gated ? 'Log in to set notifications' : n.hint,
      style: {
        flex: 1,
        height: 36,
        borderRadius: 9,
        cursor: gated ? 'not-allowed' : 'pointer',
        border: 'none',
        display: 'inline-flex',
        alignItems: 'center',
        justifyContent: 'center',
        gap: 6,
        background: active ? 'var(--fomio-card)' : 'transparent',
        boxShadow: active ? '0 1px 3px rgba(0,0,0,0.08)' : 'none',
        opacity: gated ? 0.55 : 1,
        fontFamily: 'var(--fomio-sans)',
        fontSize: 12.5,
        fontWeight: active ? 700 : 600,
        color: active ? 'var(--fomio-fg)' : 'var(--fomio-fg-muted)',
        transition: 'background 150ms'
      }
    }, /*#__PURE__*/React.createElement(HubIc, {
      name: n.icon,
      size: 15,
      color: active && n.key === 3 ? 'var(--fomio-primary)' : 'currentColor',
      stroke: 1.8,
      fill: active && n.key === 3 ? 'var(--fomio-primary)' : 'none'
    }), n.label);
  })), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '9px 2px 0',
      fontFamily: 'var(--fomio-sans)',
      fontSize: 12,
      color: 'var(--fomio-fg-muted)'
    }
  }, (H_NOTIF[level] || H_NOTIF[1]).hint, "."));
}

/* ── Featured byte row inside a hub detail ───────────────────── */
function FeaturedByte({
  b,
  onOpenByte
}) {
  return /*#__PURE__*/React.createElement("article", {
    className: "hb-row",
    onClick: () => onOpenByte && onOpenByte(b),
    style: {
      display: 'flex',
      gap: 13,
      alignItems: 'flex-start',
      padding: '15px 0',
      borderBottom: '1px solid var(--fomio-border)',
      cursor: 'pointer'
    }
  }, /*#__PURE__*/React.createElement(Avatar, {
    user: b,
    size: 30
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      marginBottom: 4
    }
  }, /*#__PURE__*/React.createElement(TeretBadge, {
    label: b.teret
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--fomio-sans)',
      fontSize: 11.5,
      color: 'var(--fomio-fg-muted)'
    }
  }, b.author, " \xB7 ", b.time)), /*#__PURE__*/React.createElement("h4", {
    className: "hb-name",
    style: {
      margin: 0,
      fontFamily: 'var(--fomio-serif)',
      fontWeight: 700,
      fontSize: 16.5,
      lineHeight: 1.3,
      letterSpacing: '-0.01em',
      color: 'var(--fomio-fg)',
      textWrap: 'pretty'
    }
  }, b.title)), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 5,
      flexShrink: 0,
      paddingTop: 3,
      fontFamily: 'var(--fomio-sans)',
      fontSize: 12,
      fontWeight: 600,
      color: 'var(--fomio-fg-muted)'
    }
  }, /*#__PURE__*/React.createElement(HIc, {
    name: "reply",
    size: 14,
    color: "var(--fomio-fg-muted)",
    stroke: 1.8
  }), b.replies));
}

/* ── Shared detail body (used by both inline + sheet) ────────── */
function HubDetailBody({
  hub,
  opts,
  onCycleNotif,
  onSetNotif,
  onOpenTeret,
  onOpenByte,
  sheet
}) {
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("section", {
    style: {
      marginBottom: 26
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      marginBottom: 12
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--fomio-sans)',
      fontSize: 10.5,
      fontWeight: 700,
      letterSpacing: '0.08em',
      textTransform: 'uppercase',
      color: 'var(--fomio-fg-muted)'
    }
  }, "Terets"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--fomio-mono)',
      fontSize: 11,
      color: 'var(--fomio-fg-muted)'
    }
  }, hub.terets.length)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: sheet ? '1fr' : '1fr 1fr',
      gap: 8
    }
  }, hub.terets.map(t => /*#__PURE__*/React.createElement("button", {
    key: t.slug,
    onClick: () => onOpenTeret && onOpenTeret(hub, t),
    className: "hb-teretrow",
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 11,
      padding: '11px 13px',
      borderRadius: 12,
      cursor: 'pointer',
      border: '1px solid var(--fomio-border)',
      background: 'var(--fomio-card)',
      textAlign: 'left',
      transition: 'border-color 150ms'
    }
  }, /*#__PURE__*/React.createElement(HubIc, {
    name: "hash",
    size: 15,
    color: "var(--fomio-primary)",
    stroke: 2
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      fontFamily: 'var(--fomio-sans)',
      fontSize: 13.5,
      fontWeight: 600,
      color: 'var(--fomio-fg)'
    }
  }, t.name), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--fomio-mono)',
      fontSize: 11.5,
      color: 'var(--fomio-fg-muted)'
    }
  }, t.count), /*#__PURE__*/React.createElement(HubIc, {
    name: "chevronRight",
    size: 15,
    color: "var(--fomio-fg-muted)",
    stroke: 1.8
  }))))), /*#__PURE__*/React.createElement("section", {
    style: {
      marginBottom: 26
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      marginBottom: 4
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--fomio-sans)',
      fontSize: 10.5,
      fontWeight: 700,
      letterSpacing: '0.08em',
      textTransform: 'uppercase',
      color: 'var(--fomio-fg-muted)'
    }
  }, "Featured bytes")), /*#__PURE__*/React.createElement("div", {
    style: {
      borderTop: '1px solid var(--fomio-border)'
    }
  }, hub.bytes.map((b, i) => /*#__PURE__*/React.createElement(FeaturedByte, {
    key: i,
    b: b,
    onOpenByte: onOpenByte
  }))), /*#__PURE__*/React.createElement("button", {
    className: "hb-seeall",
    style: {
      marginTop: 14,
      display: 'inline-flex',
      alignItems: 'center',
      gap: 7,
      height: 40,
      padding: '0 18px',
      borderRadius: 9999,
      cursor: 'pointer',
      background: 'transparent',
      border: '1.5px solid var(--fomio-border)',
      fontFamily: 'var(--fomio-sans)',
      fontSize: 13,
      fontWeight: 700,
      color: 'var(--fomio-fg)'
    }
  }, "See all ", hub.byteCount.toLocaleString(), " bytes", /*#__PURE__*/React.createElement(HubIc, {
    name: "arrowUpRight",
    size: 15,
    color: "var(--fomio-primary)",
    stroke: 2
  }))), /*#__PURE__*/React.createElement("section", null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      marginBottom: 12
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--fomio-sans)',
      fontSize: 10.5,
      fontWeight: 700,
      letterSpacing: '0.08em',
      textTransform: 'uppercase',
      color: 'var(--fomio-fg-muted)'
    }
  }, "Notifications")), /*#__PURE__*/React.createElement(NotifSegmented, {
    level: hub._notif,
    gated: opts.gated,
    onSet: lvl => onSetNotif(hub, lvl)
  })));
}

/* ── Inline expander (rendered under a directory row) ────────── */
function InlineExpand({
  hub,
  opts,
  onSetNotif,
  onOpenTeret,
  onOpenByte
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "hb-expand",
    style: {
      padding: '4px 0 30px 23px',
      borderBottom: '1px solid var(--fomio-border)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 640
    }
  }, /*#__PURE__*/React.createElement(HubDetailBody, {
    hub: hub,
    opts: opts,
    onSetNotif: onSetNotif,
    onOpenTeret: onOpenTeret,
    onOpenByte: onOpenByte
  })));
}

/* ── Side sheet (drawer) ─────────────────────────────────────── */
function HubSheet({
  hub,
  opts,
  onClose,
  onSetNotif,
  onOpenTeret,
  onOpenByte,
  touch
}) {
  if (!hub) return null;
  const accent = hubAccent(hub, opts.colorMode);
  const width = touch ? '100vw' : 'min(520px, 94vw)';
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    onClick: onClose,
    className: "hb-scrim",
    style: {
      position: 'fixed',
      inset: 0,
      zIndex: 300,
      background: 'rgba(20,14,10,0.34)',
      backdropFilter: 'blur(2px)'
    }
  }), /*#__PURE__*/React.createElement("aside", {
    className: "hb-sheet",
    style: {
      position: 'fixed',
      top: 0,
      right: 0,
      bottom: 0,
      width,
      zIndex: 301,
      background: 'var(--fomio-bg)',
      borderLeft: '1px solid var(--fomio-border)',
      boxShadow: '-28px 0 90px -40px rgba(0,0,0,0.5)',
      display: 'flex',
      flexDirection: 'column'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '22px 24px 18px',
      borderBottom: '1px solid var(--fomio-border)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-start',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 3,
      alignSelf: 'stretch',
      minHeight: 40,
      borderRadius: 2,
      background: accent,
      flexShrink: 0
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      margin: '0 0 5px',
      fontFamily: 'var(--fomio-serif)',
      fontWeight: 700,
      fontSize: 26,
      lineHeight: 1.1,
      letterSpacing: '-0.02em',
      color: 'var(--fomio-fg)'
    }
  }, hub.name), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontFamily: 'var(--fomio-serif)',
      fontSize: 14.5,
      lineHeight: 1.5,
      color: 'var(--fomio-fg-muted)',
      textWrap: 'pretty'
    }
  }, hub.description)), /*#__PURE__*/React.createElement("button", {
    onClick: onClose,
    "aria-label": "Close",
    style: {
      width: 34,
      height: 34,
      borderRadius: 10,
      border: 'none',
      cursor: 'pointer',
      background: 'var(--fomio-surface)',
      color: 'var(--fomio-fg-muted)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement(HubIc, {
    name: "x",
    size: 17,
    color: "currentColor",
    stroke: 2
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 14,
      paddingLeft: 15
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 16,
      fontFamily: 'var(--fomio-sans)',
      fontSize: 12.5,
      fontWeight: 600,
      color: 'var(--fomio-fg-secondary)',
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 5
    }
  }, /*#__PURE__*/React.createElement(HubIc, {
    name: "layers",
    size: 14,
    color: "var(--fomio-fg-muted)",
    stroke: 1.8
  }), hub.byteCount.toLocaleString(), " bytes"), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 5
    }
  }, /*#__PURE__*/React.createElement(HubIc, {
    name: "users",
    size: 14,
    color: "var(--fomio-fg-muted)",
    stroke: 1.8
  }), hub.members.toLocaleString(), " readers"), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 5,
      color: 'var(--fomio-primary)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 6,
      height: 6,
      borderRadius: '50%',
      background: 'var(--fomio-primary)'
    }
  }), hub.active, " active today")))), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      overflowY: 'auto',
      padding: '22px 24px 40px'
    }
  }, /*#__PURE__*/React.createElement(HubDetailBody, {
    hub: hub,
    opts: opts,
    sheet: true,
    onSetNotif: onSetNotif,
    onOpenTeret: onOpenTeret,
    onOpenByte: onOpenByte
  }))));
}

/* ── Search results — flat list with hub / teret breadcrumbs ─── */
function SearchResults({
  results,
  query,
  onOpen,
  onOpenTeret
}) {
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--fomio-sans)',
      fontSize: 12.5,
      fontWeight: 600,
      color: 'var(--fomio-fg-muted)',
      margin: '0 0 14px 2px'
    }
  }, results.length, " ", results.length === 1 ? 'result' : 'results', " for", /*#__PURE__*/React.createElement("span", {
    style: {
      fontStyle: 'italic',
      color: 'var(--fomio-fg)'
    }
  }, " \u201C", query, "\u201D")), /*#__PURE__*/React.createElement("div", {
    style: {
      borderTop: '1px solid var(--fomio-border)'
    }
  }, results.map((r, i) => {
    const isTeret = r.type === 'teret';
    return /*#__PURE__*/React.createElement("button", {
      key: i,
      onClick: () => isTeret ? onOpenTeret(r.hub, r.teret) : onOpen(r.hub),
      className: "hb-row",
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 13,
        width: '100%',
        padding: '14px 12px',
        borderBottom: '1px solid var(--fomio-border)',
        cursor: 'pointer',
        background: 'transparent',
        border: 'none',
        borderBottomStyle: 'solid',
        borderBottomWidth: 1,
        borderBottomColor: 'var(--fomio-border)',
        textAlign: 'left'
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        width: 34,
        height: 34,
        borderRadius: 10,
        flexShrink: 0,
        background: isTeret ? 'transparent' : 'var(--fomio-primary-soft)',
        border: isTeret ? '1px solid var(--fomio-border)' : 'none',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center'
      }
    }, /*#__PURE__*/React.createElement(HubIc, {
      name: isTeret ? 'hash' : 'layers',
      size: 16,
      color: isTeret ? 'var(--fomio-fg-muted)' : 'var(--fomio-primary-dark)',
      stroke: 1.9
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        minWidth: 0
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 6,
        marginBottom: 2,
        fontFamily: 'var(--fomio-sans)',
        fontSize: 11,
        fontWeight: 600,
        letterSpacing: '0.02em',
        color: 'var(--fomio-fg-muted)'
      }
    }, /*#__PURE__*/React.createElement("span", null, r.hub.name), isTeret && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(HubIc, {
      name: "chevronRight",
      size: 11,
      color: "var(--fomio-fg-muted)",
      stroke: 2
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        color: 'var(--fomio-primary)'
      }
    }, "Teret"))), /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--fomio-serif)',
        fontWeight: 700,
        fontSize: 16,
        letterSpacing: '-0.01em',
        color: 'var(--fomio-fg)'
      }
    }, highlight(isTeret ? r.teret.name : r.hub.name, query))), /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--fomio-mono)',
        fontSize: 11.5,
        color: 'var(--fomio-fg-muted)',
        flexShrink: 0
      }
    }, isTeret ? `${r.teret.count} bytes` : `${r.hub.terets.length} terets`), /*#__PURE__*/React.createElement(HubIc, {
      name: "chevronRight",
      size: 16,
      color: "var(--fomio-fg-muted)",
      stroke: 1.8
    }));
  })));
}
function highlight(text, q) {
  if (!q) return text;
  const idx = text.toLowerCase().indexOf(q.toLowerCase());
  if (idx < 0) return text;
  return /*#__PURE__*/React.createElement(React.Fragment, null, text.slice(0, idx), /*#__PURE__*/React.createElement("mark", {
    style: {
      background: 'var(--fomio-primary-soft)',
      color: 'var(--fomio-primary-dark)',
      borderRadius: 3,
      padding: '0 1px'
    }
  }, text.slice(idx, idx + q.length)), text.slice(idx + q.length));
}
Object.assign(window, {
  NotifSegmented,
  HubDetailBody,
  InlineExpand,
  HubSheet,
  SearchResults
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "hubs-detail.jsx", error: String((e && e.message) || e) }); }

// hubs-directory.jsx
try { (() => {
/* hubs-directory.jsx — the Hubs directory surface: local icon extras, search
 * field, notification bell, live-byte peek, and the three directory layouts
 * (index / gallery / compact), plus loading & empty states.
 * Exports: HubIc, HubsSearch, NotifBell, hubAccent, Directory,
 *   HubsSkeleton, HubsEmpty.
 */
const {
  HIc,
  Avatar,
  TeretBadge,
  MetaDot
} = window;
const HUBS_NOTIF = window.HUBS_NOTIF;

/* ── Extra glyphs not in the shared HIc set ──────────────────── */
const HUB_ICONS = {
  chevronDown: 'M6 9l6 6 6-6',
  layers: 'M12 2 2 7l10 5 10-5z M2 17l10 5 10-5 M2 12l10 5 10-5',
  hash: 'M4 9h16 M4 15h16 M10 3 8 21 M16 3l-2 18',
  bellOff: 'M8.7 3A6 6 0 0 1 18 8c0 3 .4 4.6 1 5.7 M6 8a6 6 0 0 1 .3-1.8 M6 8c0 4-2 5.7-2 5.7h11 M2 2l20 20 M10.3 21a2 2 0 0 0 3.4 0',
  bellRing: 'M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9 M13.7 21a2 2 0 0 1-3.4 0 M2.5 5a9 9 0 0 1 1.6-2.3 M21.5 5a9 9 0 0 0-1.6-2.3',
  arrowUpRight: 'M7 17 17 7 M8 7h9v9',
  sliders: 'M4 21v-7 M4 10V3 M12 21v-9 M12 8V3 M20 21v-5 M20 12V3 M1 14h6 M9 8h6 M17 16h6',
  compass: 'M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20z M16.2 7.8l-2.9 6.4-6.4 2.9 2.9-6.4z',
  x: 'M18 6 6 18 M6 6l12 12',
  users: 'M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2 M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8z M23 21v-2a4 4 0 0 0-3-3.9 M16 3.1a4 4 0 0 1 0 7.8',
  pulse: 'M22 12h-4l-3 9L9 3l-3 9H2'
};
function HubIc({
  name,
  size = 20,
  color = 'currentColor',
  stroke = 2,
  fill = 'none',
  style
}) {
  if (!HUB_ICONS[name]) return /*#__PURE__*/React.createElement(HIc, {
    name: name,
    size: size,
    color: color,
    stroke: stroke,
    fill: fill,
    style: style
  });
  const d = HUB_ICONS[name];
  return /*#__PURE__*/React.createElement("svg", {
    width: size,
    height: size,
    viewBox: "0 0 24 24",
    fill: fill,
    stroke: color,
    strokeWidth: stroke,
    strokeLinecap: "round",
    strokeLinejoin: "round",
    style: {
      display: 'block',
      flexShrink: 0,
      ...style
    },
    "aria-hidden": "true"
  }, d.split(' M').map((seg, i) => /*#__PURE__*/React.createElement("path", {
    key: i,
    d: (i ? 'M' : '') + seg
  })));
}

/* ── Per-hub accent resolver (strict brand ignores hue) ──────── */
function hubAccent(hub, colorMode) {
  // colorMode: 'brand' | 'accent' | 'full'
  if (!colorMode || colorMode === 'brand') return 'var(--fomio-primary)';
  // Earthy, desaturated, consistent lightness/chroma; only hue varies.
  return `oklch(0.62 0.09 ${hub.hue})`;
}

/* ── Search field — persistent affordance, surface-aware ─────── */
function HubsSearch({
  value,
  onChange,
  onFocus,
  mode,
  autoFocus
}) {
  const ref = React.useRef(null);
  React.useEffect(() => {
    if (autoFocus && ref.current) ref.current.focus();
  }, [autoFocus]);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      display: 'flex',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      left: 15,
      display: 'flex',
      pointerEvents: 'none'
    }
  }, /*#__PURE__*/React.createElement(HubIc, {
    name: "search",
    size: 18,
    color: "var(--fomio-fg-muted)",
    stroke: 1.8
  })), /*#__PURE__*/React.createElement("input", {
    ref: ref,
    value: value,
    onFocus: onFocus,
    onChange: e => onChange(e.target.value),
    placeholder: "Search hubs and terets",
    style: {
      width: '100%',
      height: 46,
      padding: '0 44px 0 44px',
      borderRadius: 9999,
      border: '1.5px solid var(--fomio-border)',
      background: 'var(--fomio-card)',
      fontFamily: 'var(--fomio-sans)',
      fontSize: 14.5,
      fontWeight: 500,
      color: 'var(--fomio-fg)',
      outline: 'none',
      boxSizing: 'border-box',
      transition: 'border-color 150ms'
    },
    onFocusCapture: e => e.target.style.borderColor = 'var(--fomio-primary)',
    onBlur: e => e.target.style.borderColor = 'var(--fomio-border)'
  }), value && /*#__PURE__*/React.createElement("button", {
    onClick: () => onChange(''),
    "aria-label": "Clear search",
    style: {
      position: 'absolute',
      right: 12,
      width: 26,
      height: 26,
      borderRadius: '50%',
      border: 'none',
      cursor: 'pointer',
      background: 'var(--fomio-surface)',
      color: 'var(--fomio-fg-muted)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center'
    }
  }, /*#__PURE__*/React.createElement(HubIc, {
    name: "x",
    size: 14,
    color: "currentColor",
    stroke: 2
  })));
}

/* ── Notification bell — cycles muted → normal → tracking → watching ── */
function NotifBell({
  level,
  onCycle,
  gated,
  size = 'md'
}) {
  const meta = HUBS_NOTIF[level] || HUBS_NOTIF[1];
  const on = level > 0;
  const watching = level === 3;
  const dim = size === 'sm';
  const box = dim ? 32 : 36;
  const color = gated ? 'var(--fomio-fg-muted)' : level === 0 ? 'var(--fomio-fg-muted)' : watching ? 'var(--fomio-primary)' : 'var(--fomio-fg)';
  return /*#__PURE__*/React.createElement("button", {
    onClick: e => {
      e.stopPropagation();
      onCycle();
    },
    title: gated ? 'Log in to set notifications' : `${meta.label} — ${meta.hint}`,
    className: "hb-bell",
    style: {
      width: box,
      height: box,
      borderRadius: 10,
      cursor: 'pointer',
      border: `1px solid ${on && !gated ? 'var(--fomio-border)' : 'var(--fomio-border)'}`,
      background: watching && !gated ? 'var(--fomio-primary-soft)' : 'var(--fomio-card)',
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      position: 'relative',
      transition: 'background 150ms, border-color 150ms'
    }
  }, /*#__PURE__*/React.createElement(HubIc, {
    name: meta.icon,
    size: dim ? 16 : 18,
    color: watching && !gated ? 'var(--fomio-primary-dark)' : color,
    stroke: 1.8,
    fill: watching && !gated ? 'var(--fomio-primary-dark)' : 'none'
  }), level === 2 && !gated && /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      top: 6,
      right: 6,
      width: 6,
      height: 6,
      borderRadius: '50%',
      background: 'var(--fomio-primary)',
      border: '1.5px solid var(--fomio-card)'
    }
  }));
}

/* ── Hub stat cluster (bytes · members · active) ─────────────── */
function HubStats({
  hub,
  muted
}) {
  const c = muted ? 'var(--fomio-fg-muted)' : 'var(--fomio-fg-secondary)';
  const item = (icon, val, label) => /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 5,
      fontFamily: 'var(--fomio-sans)',
      fontSize: 12,
      fontWeight: 600,
      color: c
    }
  }, /*#__PURE__*/React.createElement(HubIc, {
    name: icon,
    size: 14,
    color: c,
    stroke: 1.8
  }), " ", val, /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--fomio-fg-muted)',
      fontWeight: 500
    }
  }, label));
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 16,
      flexWrap: 'wrap'
    }
  }, item('layers', hub.byteCount.toLocaleString(), 'bytes'), item('users', hub.members.toLocaleString(), 'readers'), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 5,
      fontFamily: 'var(--fomio-sans)',
      fontSize: 12,
      fontWeight: 600,
      color: 'var(--fomio-primary)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 6,
      height: 6,
      borderRadius: '50%',
      background: 'var(--fomio-primary)'
    }
  }), hub.active, " ", /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--fomio-fg-muted)',
      fontWeight: 500
    }
  }, "active today")));
}

/* ── Teret list — inline links with counts ───────────────────── */
function TeretList({
  hub,
  query,
  onOpenTeret,
  wrap = true,
  max
}) {
  let terets = hub.terets;
  if (max) terets = terets.slice(0, max);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexWrap: wrap ? 'wrap' : 'nowrap',
      gap: 7,
      overflowX: wrap ? 'visible' : 'auto',
      scrollbarWidth: 'none'
    }
  }, terets.map(t => {
    const hit = query && t.name.toLowerCase().includes(query.toLowerCase());
    return /*#__PURE__*/React.createElement("button", {
      key: t.slug,
      onClick: e => {
        e.stopPropagation();
        onOpenTeret && onOpenTeret(hub, t);
      },
      className: "hb-teret",
      style: {
        display: 'inline-flex',
        alignItems: 'center',
        gap: 6,
        height: 28,
        padding: '0 11px',
        borderRadius: 9999,
        cursor: 'pointer',
        border: `1px solid ${hit ? 'var(--fomio-primary)' : 'var(--fomio-border)'}`,
        background: hit ? 'var(--fomio-primary-soft)' : 'transparent',
        fontFamily: 'var(--fomio-sans)',
        fontSize: 12.5,
        fontWeight: 600,
        color: hit ? 'var(--fomio-primary-dark)' : 'var(--fomio-fg)',
        whiteSpace: 'nowrap',
        transition: 'border-color 150ms, background 150ms'
      }
    }, /*#__PURE__*/React.createElement(HubIc, {
      name: "hash",
      size: 12,
      color: hit ? 'var(--fomio-primary)' : 'var(--fomio-fg-muted)',
      stroke: 2
    }), t.name, /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--fomio-mono)',
        fontSize: 10.5,
        color: 'var(--fomio-fg-muted)'
      }
    }, t.count));
  }), max && hub.terets.length > max && /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      height: 28,
      padding: '0 4px',
      fontFamily: 'var(--fomio-sans)',
      fontSize: 12,
      fontWeight: 600,
      color: 'var(--fomio-fg-muted)'
    }
  }, "+", hub.terets.length - max));
}

/* ── Live-byte peek — 1–2 recent bytes inside a hub ──────────── */
function BytePeek({
  hub,
  compact
}) {
  const bytes = hub.bytes.slice(0, compact ? 1 : 2);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 0,
      marginTop: 2
    }
  }, bytes.map((b, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    className: "hb-peek",
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      padding: '9px 0',
      borderTop: '1px solid var(--fomio-border-soft)'
    }
  }, /*#__PURE__*/React.createElement(Avatar, {
    user: b,
    size: 22
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      minWidth: 0,
      fontFamily: 'var(--fomio-serif)',
      fontWeight: 600,
      fontSize: 14,
      lineHeight: 1.35,
      color: 'var(--fomio-fg)',
      overflow: 'hidden',
      textOverflow: 'ellipsis',
      whiteSpace: 'nowrap'
    }
  }, b.title), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--fomio-sans)',
      fontSize: 11.5,
      fontWeight: 600,
      color: 'var(--fomio-fg-muted)',
      whiteSpace: 'nowrap',
      flexShrink: 0
    }
  }, b.time))));
}

/* ════════════ LAYOUT 1 — Editorial index (magazine ToC) ══════ */
function HubIndexRow({
  hub,
  opts,
  expanded,
  onOpen,
  onCycleNotif,
  onOpenTeret
}) {
  const accent = hubAccent(hub, opts.colorMode);
  return /*#__PURE__*/React.createElement("article", {
    className: "hb-row",
    onClick: () => onOpen(hub),
    style: {
      padding: '26px 0',
      borderBottom: '1px solid var(--fomio-border)',
      cursor: 'pointer'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 20,
      alignItems: 'flex-start'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 3,
      alignSelf: 'stretch',
      minHeight: 54,
      borderRadius: 2,
      background: accent,
      flexShrink: 0,
      opacity: 0.9
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'baseline',
      gap: 12,
      marginBottom: 7
    }
  }, /*#__PURE__*/React.createElement("h2", {
    className: "hb-name",
    style: {
      margin: 0,
      fontFamily: 'var(--fomio-serif)',
      fontWeight: 700,
      fontSize: opts.mode === 'expanded' ? 27 : 23,
      lineHeight: 1.1,
      letterSpacing: '-0.02em',
      color: 'var(--fomio-fg)'
    }
  }, hub.name), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 5,
      marginLeft: 'auto',
      fontFamily: 'var(--fomio-sans)',
      fontSize: 12,
      fontWeight: 700,
      color: 'var(--fomio-primary)',
      opacity: 0,
      transition: 'opacity 160ms'
    },
    className: "hb-enter"
  }, "Open ", /*#__PURE__*/React.createElement(HubIc, {
    name: "arrowUpRight",
    size: 14,
    color: "var(--fomio-primary)",
    stroke: 2
  }))), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '0 0 14px',
      fontFamily: 'var(--fomio-serif)',
      fontSize: 15.5,
      lineHeight: 1.5,
      color: 'var(--fomio-fg-muted)',
      maxWidth: 560,
      textWrap: 'pretty'
    }
  }, hub.description), /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 14
    }
  }, /*#__PURE__*/React.createElement(HubStats, {
    hub: hub
  })), opts.showTerets && /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: opts.showBytes ? 6 : 0
    }
  }, /*#__PURE__*/React.createElement(TeretList, {
    hub: hub,
    query: opts.query,
    onOpenTeret: onOpenTeret
  })), opts.showBytes && /*#__PURE__*/React.createElement(BytePeek, {
    hub: hub
  })), /*#__PURE__*/React.createElement("div", {
    onClick: e => e.stopPropagation(),
    style: {
      flexShrink: 0,
      paddingTop: 2,
      display: 'flex',
      alignItems: 'center',
      gap: 10
    }
  }, opts.drilldown === 'inline' && /*#__PURE__*/React.createElement(HubIc, {
    name: "chevronDown",
    size: 18,
    color: "var(--fomio-fg-muted)",
    stroke: 2,
    style: {
      transform: expanded ? 'rotate(180deg)' : 'rotate(0deg)',
      transition: 'transform 200ms var(--fomio-ease, ease)'
    }
  }), /*#__PURE__*/React.createElement(NotifBell, {
    level: hub._notif,
    gated: opts.gated,
    onCycle: () => onCycleNotif(hub)
  }))));
}

/* ════════════ LAYOUT 2 — Card gallery ════════════════════════ */
function HubCard({
  hub,
  opts,
  onOpen,
  onCycleNotif,
  onOpenTeret
}) {
  const accent = hubAccent(hub, opts.colorMode);
  return /*#__PURE__*/React.createElement("article", {
    className: "hb-card",
    onClick: () => onOpen(hub),
    style: {
      background: 'var(--fomio-card)',
      border: '1px solid var(--fomio-border)',
      borderRadius: 18,
      padding: 20,
      cursor: 'pointer',
      boxSizing: 'border-box',
      display: 'flex',
      flexDirection: 'column',
      gap: 13,
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: 0,
      left: 20,
      right: 20,
      height: 3,
      borderRadius: '0 0 3px 3px',
      background: accent,
      opacity: opts.colorMode && opts.colorMode !== 'brand' ? 0.9 : 0
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-start',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("h3", {
    className: "hb-name",
    style: {
      margin: '0 0 6px',
      fontFamily: 'var(--fomio-serif)',
      fontWeight: 700,
      fontSize: 21,
      lineHeight: 1.15,
      letterSpacing: '-0.02em',
      color: 'var(--fomio-fg)'
    }
  }, hub.name), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontFamily: 'var(--fomio-serif)',
      fontSize: 14,
      lineHeight: 1.5,
      color: 'var(--fomio-fg-muted)',
      display: '-webkit-box',
      WebkitLineClamp: 2,
      WebkitBoxOrient: 'vertical',
      overflow: 'hidden',
      textWrap: 'pretty'
    }
  }, hub.description)), /*#__PURE__*/React.createElement("div", {
    onClick: e => e.stopPropagation()
  }, /*#__PURE__*/React.createElement(NotifBell, {
    level: hub._notif,
    gated: opts.gated,
    onCycle: () => onCycleNotif(hub),
    size: "sm"
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 14,
      fontFamily: 'var(--fomio-sans)',
      fontSize: 12,
      fontWeight: 600,
      color: 'var(--fomio-fg-secondary)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 5
    }
  }, /*#__PURE__*/React.createElement(HubIc, {
    name: "layers",
    size: 14,
    color: "var(--fomio-fg-muted)",
    stroke: 1.8
  }), hub.byteCount.toLocaleString()), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 5,
      color: 'var(--fomio-primary)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 6,
      height: 6,
      borderRadius: '50%',
      background: 'var(--fomio-primary)'
    }
  }), hub.active, " active")), opts.showTerets && /*#__PURE__*/React.createElement(TeretList, {
    hub: hub,
    query: opts.query,
    onOpenTeret: onOpenTeret,
    max: 3
  }), opts.showBytes && /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 'auto'
    }
  }, /*#__PURE__*/React.createElement(BytePeek, {
    hub: hub,
    compact: true
  })));
}

/* ════════════ LAYOUT 3 — Compact scan list ═══════════════════ */
function HubCompactRow({
  hub,
  opts,
  onOpen,
  onCycleNotif
}) {
  const accent = hubAccent(hub, opts.colorMode);
  return /*#__PURE__*/React.createElement("article", {
    className: "hb-row",
    onClick: () => onOpen(hub),
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 14,
      padding: '14px 12px',
      borderBottom: '1px solid var(--fomio-border)',
      cursor: 'pointer'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 8,
      height: 8,
      borderRadius: '50%',
      background: accent,
      flexShrink: 0
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'baseline',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("h3", {
    className: "hb-name",
    style: {
      margin: 0,
      fontFamily: 'var(--fomio-serif)',
      fontWeight: 700,
      fontSize: 17,
      letterSpacing: '-0.01em',
      color: 'var(--fomio-fg)',
      whiteSpace: 'nowrap'
    }
  }, hub.name), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--fomio-sans)',
      fontSize: 12.5,
      color: 'var(--fomio-fg-muted)',
      overflow: 'hidden',
      textOverflow: 'ellipsis',
      whiteSpace: 'nowrap'
    }
  }, hub.description))), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--fomio-sans)',
      fontSize: 12,
      fontWeight: 600,
      color: 'var(--fomio-fg-muted)',
      whiteSpace: 'nowrap',
      flexShrink: 0
    }
  }, hub.terets.length, " terets"), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 5,
      fontFamily: 'var(--fomio-sans)',
      fontSize: 12,
      fontWeight: 600,
      color: 'var(--fomio-fg-secondary)',
      whiteSpace: 'nowrap',
      flexShrink: 0,
      minWidth: 64,
      justifyContent: 'flex-end'
    }
  }, /*#__PURE__*/React.createElement(HubIc, {
    name: "layers",
    size: 13,
    color: "var(--fomio-fg-muted)",
    stroke: 1.8
  }), hub.byteCount.toLocaleString()), /*#__PURE__*/React.createElement("div", {
    onClick: e => e.stopPropagation(),
    style: {
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement(NotifBell, {
    level: hub._notif,
    gated: opts.gated,
    onCycle: () => onCycleNotif(hub),
    size: "sm"
  })));
}

/* ── Directory dispatcher ────────────────────────────────────── */
function Directory({
  hubs,
  opts,
  onOpen,
  onCycleNotif,
  onOpenTeret,
  expandedId,
  renderExpand
}) {
  if (opts.layout === 'gallery') {
    const cols = opts.mode === 'touch' ? 1 : opts.mode === 'expanded' ? 3 : 2;
    return /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'grid',
        gridTemplateColumns: `repeat(${cols}, 1fr)`,
        gap: 18,
        alignItems: 'stretch'
      }
    }, hubs.map(h => /*#__PURE__*/React.createElement(HubCard, {
      key: h.id,
      hub: h,
      opts: opts,
      onOpen: onOpen,
      onCycleNotif: onCycleNotif,
      onOpenTeret: onOpenTeret
    })));
  }
  if (opts.layout === 'compact') {
    return /*#__PURE__*/React.createElement("div", {
      style: {
        borderTop: '1px solid var(--fomio-border)'
      }
    }, hubs.map(h => /*#__PURE__*/React.createElement(React.Fragment, {
      key: h.id
    }, /*#__PURE__*/React.createElement(HubCompactRow, {
      hub: h,
      opts: opts,
      onOpen: onOpen,
      onCycleNotif: onCycleNotif
    }), expandedId === h.id && renderExpand && renderExpand(h))));
  }
  return /*#__PURE__*/React.createElement("div", {
    style: {
      borderTop: '1px solid var(--fomio-border)'
    }
  }, hubs.map(h => /*#__PURE__*/React.createElement(React.Fragment, {
    key: h.id
  }, /*#__PURE__*/React.createElement(HubIndexRow, {
    hub: h,
    opts: opts,
    onOpen: onOpen,
    onCycleNotif: onCycleNotif,
    onOpenTeret: onOpenTeret,
    expanded: expandedId === h.id
  }), expandedId === h.id && renderExpand && renderExpand(h))));
}

/* ════════════ STATES ═════════════════════════════════════════ */
function HubsSkeleton({
  layout,
  mode
}) {
  const sweep = {
    background: 'var(--fomio-surface)'
  };
  const line = (w, h, mt) => /*#__PURE__*/React.createElement("div", {
    className: "fh-shimmer",
    style: {
      ...sweep,
      width: w,
      height: h,
      borderRadius: 6,
      marginTop: mt || 0
    }
  });
  if (layout === 'gallery') {
    const cols = mode === 'touch' ? 1 : mode === 'expanded' ? 3 : 2;
    return /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'grid',
        gridTemplateColumns: `repeat(${cols}, 1fr)`,
        gap: 18
      },
      "aria-busy": "true"
    }, Array.from({
      length: 6
    }).map((_, i) => /*#__PURE__*/React.createElement("div", {
      key: i,
      style: {
        background: 'var(--fomio-card)',
        border: '1px solid var(--fomio-border)',
        borderRadius: 18,
        padding: 20
      }
    }, line('55%', 22), line('100%', 13, 14), line('80%', 13, 8), line('60%', 26, 18))));
  }
  return /*#__PURE__*/React.createElement("div", {
    "aria-busy": "true",
    style: {
      borderTop: '1px solid var(--fomio-border)'
    }
  }, Array.from({
    length: 5
  }).map((_, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      display: 'flex',
      gap: 20,
      padding: '26px 0',
      borderBottom: '1px solid var(--fomio-border)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 3,
      ...sweep,
      borderRadius: 2
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, line('34%', 24), line('82%', 14, 14), line('48%', 14, 8), line('64%', 26, 16)), /*#__PURE__*/React.createElement("div", {
    style: {
      width: 36,
      height: 36,
      borderRadius: 10,
      ...sweep
    }
  }))));
}
function HubsEmpty({
  query,
  onClear
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'center',
      padding: '72px 24px',
      maxWidth: 420,
      margin: '0 auto'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 56,
      height: 56,
      borderRadius: 16,
      background: 'var(--fomio-surface)',
      border: '1px solid var(--fomio-border)',
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      marginBottom: 20
    }
  }, /*#__PURE__*/React.createElement(HubIc, {
    name: "compass",
    size: 26,
    color: "var(--fomio-fg-muted)",
    stroke: 1.6
  })), /*#__PURE__*/React.createElement("h3", {
    style: {
      margin: '0 0 8px',
      fontFamily: 'var(--fomio-serif)',
      fontWeight: 700,
      fontSize: 22,
      letterSpacing: '-0.02em',
      color: 'var(--fomio-fg)'
    }
  }, query ? 'No hubs match that' : 'No hubs yet'), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '0 0 22px',
      fontFamily: 'var(--fomio-serif)',
      fontSize: 15,
      lineHeight: 1.6,
      color: 'var(--fomio-fg-muted)'
    }
  }, query ? /*#__PURE__*/React.createElement(React.Fragment, null, "Nothing here for ", /*#__PURE__*/React.createElement("span", {
    style: {
      fontStyle: 'italic',
      color: 'var(--fomio-fg)'
    }
  }, "\u201C", query, "\u201D"), ". Try a broader word, or browse the full directory.") : 'When hubs are created, they will appear here as a directory to browse.'), query && /*#__PURE__*/React.createElement("button", {
    onClick: onClear,
    style: {
      height: 44,
      padding: '0 22px',
      borderRadius: 9999,
      background: 'var(--fomio-primary)',
      color: '#fff',
      border: 'none',
      cursor: 'pointer',
      fontFamily: 'var(--fomio-sans)',
      fontWeight: 700,
      fontSize: 14
    }
  }, "Clear search"));
}
Object.assign(window, {
  HubIc,
  hubAccent,
  HubsSearch,
  NotifBell,
  Directory,
  HubsSkeleton,
  HubsEmpty
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "hubs-directory.jsx", error: String((e && e.message) || e) }); }

// il3-tweaks.jsx
try { (() => {
const IL3_TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "accentColor": "#C44536",
  "overlayRadius": 12,
  "shadowDepth": 50,
  "scrimStrength": 40,
  "density": "regular",
  "motionSpeed": 200,
  "labelCase": "uppercase"
} /*EDITMODE-END*/;
function applyIL3Tweaks(t) {
  const r = document.documentElement;
  r.style.setProperty('--il3-accent', t.accentColor);
  r.style.setProperty('--il3-accent-soft', 'color-mix(in oklab, ' + t.accentColor + ' 15%, var(--fomio-card))');
  r.style.setProperty('--il3-accent-dark', 'color-mix(in oklab, ' + t.accentColor + ' 80%, black)');
  r.style.setProperty('--il3-overlay-r', t.overlayRadius + 'px');
  var s = t.shadowDepth / 100;
  r.style.setProperty('--il3-shadow', '0 8px 32px -12px rgba(0,0,0,' + (0.04 + s * 0.24).toFixed(2) + '), 0 2px 8px -2px rgba(0,0,0,' + (0.02 + s * 0.12).toFixed(2) + ')');
  r.style.setProperty('--il3-shadow-lg', '0 24px 80px -36px rgba(0,0,0,' + (0.06 + s * 0.32).toFixed(2) + '), 0 4px 12px -4px rgba(0,0,0,' + (0.02 + s * 0.10).toFixed(2) + ')');
  r.style.setProperty('--il3-scrim', 'rgba(0,0,0,' + (t.scrimStrength / 100).toFixed(2) + ')');
  var padMap = {
    compact: '6px',
    regular: '8px',
    spacious: '12px'
  };
  var gapMap = {
    compact: '6px',
    regular: '8px',
    spacious: '12px'
  };
  r.style.setProperty('--il3-pad', padMap[t.density] || '8px');
  r.style.setProperty('--il3-gap', gapMap[t.density] || '8px');
  r.style.setProperty('--il3-speed', t.motionSpeed + 'ms');
  r.style.setProperty('--il3-label-case', t.labelCase);
}
function IL3TweaksApp() {
  var ref = useTweaks(IL3_TWEAK_DEFAULTS);
  var t = ref[0];
  var setTweak = ref[1];
  React.useEffect(function () {
    applyIL3Tweaks(t);
  }, [t]);
  return /*#__PURE__*/React.createElement(TweaksPanel, {
    title: "Interaction layer"
  }, /*#__PURE__*/React.createElement(TweakSection, {
    label: "Appearance"
  }), /*#__PURE__*/React.createElement(TweakColor, {
    label: "Accent color",
    value: t.accentColor,
    options: ['#C44536', '#1565C0', '#4A8C6A', '#7C6A9A', '#D4604F'],
    onChange: function (v) {
      setTweak('accentColor', v);
    }
  }), /*#__PURE__*/React.createElement(TweakSlider, {
    label: "Overlay radius",
    value: t.overlayRadius,
    min: 2,
    max: 24,
    unit: "px",
    onChange: function (v) {
      setTweak('overlayRadius', v);
    }
  }), /*#__PURE__*/React.createElement(TweakSlider, {
    label: "Shadow depth",
    value: t.shadowDepth,
    min: 0,
    max: 100,
    unit: "%",
    onChange: function (v) {
      setTweak('shadowDepth', v);
    }
  }), /*#__PURE__*/React.createElement(TweakSlider, {
    label: "Scrim strength",
    value: t.scrimStrength,
    min: 10,
    max: 80,
    unit: "%",
    onChange: function (v) {
      setTweak('scrimStrength', v);
    }
  }), /*#__PURE__*/React.createElement(TweakSection, {
    label: "Behavior"
  }), /*#__PURE__*/React.createElement(TweakRadio, {
    label: "Density",
    value: t.density,
    options: ['compact', 'regular', 'spacious'],
    onChange: function (v) {
      setTweak('density', v);
    }
  }), /*#__PURE__*/React.createElement(TweakSlider, {
    label: "Motion speed",
    value: t.motionSpeed,
    min: 0,
    max: 500,
    unit: "ms",
    onChange: function (v) {
      setTweak('motionSpeed', v);
    }
  }), /*#__PURE__*/React.createElement(TweakSelect, {
    label: "Label casing",
    value: t.labelCase,
    options: ['uppercase', 'capitalize', 'none'],
    onChange: function (v) {
      setTweak('labelCase', v);
    }
  }));
}
ReactDOM.createRoot(document.getElementById('tweaks-root')).render(React.createElement(IL3TweaksApp));
})(); } catch (e) { __ds_ns.__errors.push({ path: "il3-tweaks.jsx", error: String((e && e.message) || e) }); }

// list-component/list-icons.js
try { (() => {
/* Fomio list family — icon injection.
   Phosphor-style outline glyphs (256 viewBox), filled with currentColor.
   Replaces __ICON_NAME__ placeholders in document body. */
(function () {
  var P = function (d) {
    return '<svg viewBox="0 0 256 256" fill="currentColor" aria-hidden="true"><path d="' + d + '"/></svg>';
  };

  // Content stat icons get a fixed 14px so they sit on the metadata rail
  var S = function (d) {
    return '<svg viewBox="0 0 256 256" width="14" height="14" fill="currentColor" aria-hidden="true"><path d="' + d + '"/></svg>';
  };
  var ICONS = {
    // ── content stats ──
    HEART: S('M178,40c-20.65,0-38.73,8.88-50,23.89C116.73,48.88,98.65,40,78,40a62.07,62.07,0,0,0-62,62c0,70,103.79,126.66,108.21,129a8,8,0,0,0,7.58,0C136.21,228.66,240,172,240,102A62.07,62.07,0,0,0,178,40Z'),
    CHAT: S('M128,24A104,104,0,0,0,36.18,176.88L24.83,210.93a16,16,0,0,0,20.24,20.24l34.05-11.35A104,104,0,1,0,128,24Z'),
    EYE: S('M247.31,124.76c-.35-.79-8.82-19.58-27.65-38.41C194.57,61.26,162.88,48,128,48S61.43,61.26,36.34,86.35C17.51,105.18,9,124,8.69,124.76a8,8,0,0,0,0,6.5c.35.79,8.82,19.57,27.65,38.4C61.43,194.74,93.12,208,128,208s66.57-13.26,91.66-38.34c18.83-18.83,27.3-37.61,27.65-38.4A8,8,0,0,0,247.31,124.76ZM128,168a40,40,0,1,1,40-40A40,40,0,0,1,128,168Z'),
    // ── ui chrome ──
    CHEV: P('M181.66,133.66l-80,80a8,8,0,0,1-11.32-11.32L164.69,128,90.34,53.66a8,8,0,0,1,11.32-11.32l80,80A8,8,0,0,1,181.66,133.66Z'),
    MOON: P('M233.54,142.23a8,8,0,0,0-8-2,88.08,88.08,0,0,1-109.8-109.8,8,8,0,0,0-10-10,104.84,104.84,0,0,0-52.91,37A104,104,0,0,0,136,224a103.09,103.09,0,0,0,62.52-20.88,104.84,104.84,0,0,0,37-52.91A8,8,0,0,0,233.54,142.23Z'),
    // ── settings glyphs ──
    BELL: P('M221.8,175.94C216.25,166.38,208,139.33,208,104a80,80,0,1,0-160,0c0,35.34-8.26,62.38-13.81,71.94A16,16,0,0,0,48,200H88.81a40,40,0,0,0,78.38,0H208a16,16,0,0,0,13.8-24.06ZM128,216a24,24,0,0,1-22.62-16h45.24A24,24,0,0,1,128,216Z'),
    AT: P('M128,24A104,104,0,1,0,232,128,104.11,104.11,0,0,0,128,24Zm0,192a88,88,0,1,1,88-88c0,26.45-10.88,32-20,32-9.25,0-20-5.42-20-32V96a8,8,0,0,0-16,0v4.29a48,48,0,1,0,5,73.74A40.81,40.81,0,0,0,196,184c18.62,0,36-14.51,36-56A104.12,104.12,0,0,0,128,24Zm0,136a32,32,0,1,1,32-32A32,32,0,0,1,128,160Z'),
    ENVELOPE: P('M224,48H32a8,8,0,0,0-8,8V192a16,16,0,0,0,16,16H216a16,16,0,0,0,16-16V56A8,8,0,0,0,224,48Zm-96,85.15L52.57,64H203.43ZM98.71,128,40,181.81V74.19Zm11.84,10.85,12,11.05a8,8,0,0,0,10.82,0l12-11.05,58,53.15H52.57ZM157.29,128,216,74.18V181.82Z'),
    DEVICES: P('M176,16H80A24,24,0,0,0,56,40V216a24,24,0,0,0,24,24h96a24,24,0,0,0,24-24V40A24,24,0,0,0,176,16Zm8,200a8,8,0,0,1-8,8H80a8,8,0,0,1-8-8V40a8,8,0,0,1,8-8h96a8,8,0,0,1,8,8Zm-40-12a16,16,0,1,1-16-16A16,16,0,0,1,144,204Z'),
    USER: P('M230.92,212c-15.23-26.33-38.7-45.21-66.09-54.16a72,72,0,1,0-73.66,0C63.78,166.78,40.31,185.66,25.08,212a8,8,0,1,0,13.85,8c18.84-32.56,52.14-52,89.07-52s70.23,19.44,89.07,52a8,8,0,1,0,13.85-8ZM72,96a56,56,0,1,1,56,56A56.06,56.06,0,0,1,72,96Z'),
    GLOBE: P('M128,24A104,104,0,1,0,232,128,104.12,104.12,0,0,0,128,24ZM101.63,168h52.74C149,186.34,140,202.87,128,215.89,116,202.87,107,186.34,101.63,168ZM98,152a145.72,145.72,0,0,1,0-48h60a145.72,145.72,0,0,1,0,48ZM40,128a87.61,87.61,0,0,1,3.33-24H81.79a161.79,161.79,0,0,0,0,48H43.33A87.61,87.61,0,0,1,40,128ZM154.37,88H101.63C107,69.66,116,53.13,128,40.11,140,53.13,149,69.66,154.37,88Zm19.84,16h38.46a88.15,88.15,0,0,1,0,48H174.21a161.79,161.79,0,0,0,0-48Zm32.16-16H170.94a142.39,142.39,0,0,0-20.26-45A88.37,88.37,0,0,1,206.37,88ZM105.32,43A142.39,142.39,0,0,0,85.06,88H49.63A88.37,88.37,0,0,1,105.32,43ZM49.63,168H85.06a142.39,142.39,0,0,0,20.26,45A88.37,88.37,0,0,1,49.63,168Zm101.05,45a142.39,142.39,0,0,0,20.26-45h35.43A88.37,88.37,0,0,1,150.68,213Z'),
    KEY: P('M216.57,39.43A80,80,0,0,0,83.91,120.78L26.34,178.34A8,8,0,0,0,24,184v40a8,8,0,0,0,8,8H72a8,8,0,0,0,8-8V208H96a8,8,0,0,0,8-8V184h16a8,8,0,0,0,5.66-2.34l9.56-9.57A80,80,0,0,0,216.57,39.43ZM180,100a16,16,0,1,1,16-16A16,16,0,0,1,180,100Z'),
    DOWNLOAD: P('M224,144v64a8,8,0,0,1-8,8H40a8,8,0,0,1-8-8V144a8,8,0,0,1,16,0v56H208V144a8,8,0,0,1,16,0Zm-101.66,5.66a8,8,0,0,0,11.32,0l40-40a8,8,0,0,0-11.32-11.32L136,124.69V32a8,8,0,0,0-16,0v92.69L93.66,98.34a8,8,0,0,0-11.32,11.32Z'),
    LINK: P('M137.54,186.36a8,8,0,0,1,0,11.31l-9.94,10A56,56,0,0,1,48.38,128.4L72.5,104.28A56,56,0,0,1,149.31,102a8,8,0,1,1-10.64,12,40,40,0,0,0-54.85,1.63L59.7,139.72a40,40,0,0,0,56.58,56.58l9.94-9.94A8,8,0,0,1,137.54,186.36Zm70.08-138a56.08,56.08,0,0,0-79.22,0l-9.94,9.95a8,8,0,0,0,11.32,11.31l9.94-9.94a40,40,0,0,1,56.58,56.58L172.18,150.4A40,40,0,0,1,117.33,152,8,8,0,1,0,106.69,164a56,56,0,0,0,76.81-2.26l24.12-24.12A56.08,56.08,0,0,0,207.62,48.38Z'),
    SLIDERS: P('M40,88H73a32,32,0,0,0,62,0h81a8,8,0,0,0,0-16H135a32,32,0,0,0-62,0H40a8,8,0,0,0,0,16Zm64-24A16,16,0,1,1,88,80,16,16,0,0,1,104,64ZM216,168H183a32,32,0,0,0-62,0H40a8,8,0,0,0,0,16h81a32,32,0,0,0,62,0h33a8,8,0,0,0,0-16Zm-64,24a16,16,0,1,1,16-16A16,16,0,0,1,152,192Z'),
    TRASH: P('M216,48H176V40a24,24,0,0,0-24-24H104A24,24,0,0,0,80,40v8H40a8,8,0,0,0,0,16h8V208a16,16,0,0,0,16,16H192a16,16,0,0,0,16-16V64h8a8,8,0,0,0,0-16ZM96,40a8,8,0,0,1,8-8h48a8,8,0,0,1,8,8v8H96Zm96,168H64V64H192Zm-80-104v64a8,8,0,0,1-16,0V104a8,8,0,0,1,16,0Zm48,0v64a8,8,0,0,1-16,0V104a8,8,0,0,1,16,0Z'),
    BOOK: P('M224,48H160a40,40,0,0,0-32,16A40,40,0,0,0,96,48H32A16,16,0,0,0,16,64V192a16,16,0,0,0,16,16H96a24,24,0,0,1,24,24,8,8,0,0,0,16,0,24,24,0,0,1,24-24h64a16,16,0,0,0,16-16V64A16,16,0,0,0,224,48ZM96,192H32V64H96a24,24,0,0,1,24,24V200A39.81,39.81,0,0,0,96,192Zm128,0H160a39.81,39.81,0,0,0-24,8V88a24,24,0,0,1,24-24h64Z'),
    // ── utility glyphs ──
    BOOKMARK: P('M184,32H72A16,16,0,0,0,56,48V224a8,8,0,0,0,12.24,6.78L128,193.43l59.77,37.35A8,8,0,0,0,200,224V48A16,16,0,0,0,184,32Z'),
    SHARE: P('M214.62,82.63l-56-56A8,8,0,0,0,144,32V64.12c-39.61,3-72.6,18.85-95.81,46.43-19.85,23.59-32,55.65-32.16,85.45a8,8,0,0,0,14.7,4.41C56.27,164.16,101.93,142.36,144,140.24V176a8,8,0,0,0,13.66,5.66l56-56A8,8,0,0,0,214.62,82.63ZM160,156.69V132a8,8,0,0,0-8-8c-19.79,0-39.64,3.92-59,11.67a128.43,128.43,0,0,0-36.78,22.32c5.32-19.3,15.24-37,28.8-50.81,21.81-22.18,52.6-34.06,86.83-35.27a8,8,0,0,0,7.71-8V51.31L197.69,88Z'),
    COPY: P('M216,32H88a8,8,0,0,0-8,8V80H40a8,8,0,0,0-8,8V216a8,8,0,0,0,8,8H168a8,8,0,0,0,8-8V176h40a8,8,0,0,0,8-8V40A8,8,0,0,0,216,32ZM160,208H48V96H160Zm48-48H176V88a8,8,0,0,0-8-8H96V48H208Z'),
    ARCHIVE: P('M224,48H32A16,16,0,0,0,16,64V88a16,16,0,0,0,16,16v88a16,16,0,0,0,16,16H208a16,16,0,0,0,16-16V104a16,16,0,0,0,16-16V64A16,16,0,0,0,224,48ZM208,192H48V104H208ZM224,88H32V64H224ZM96,136a8,8,0,0,1,8-8h48a8,8,0,0,1,0,16H104A8,8,0,0,1,96,136Z'),
    FLAG: P('M42.76,50.69A8,8,0,0,0,40,56.69V216a8,8,0,0,0,16,0V157.92c52.6-29.93,89.24,1.41,90.83,2.79l.34.28c12.65,10.09,28.6,12.81,45.32,9.39,18-3.69,34.42-14.79,41.06-22.31a8,8,0,0,0,2-5.27V56.69a8,8,0,0,0-13.24-6.06c-.21.18-22.84,19-45.79,23.71-14.78,3-26.92.51-36.13-6.85C108.71,42.89,57.76,42.16,42.76,50.69Z'),
    SIGNOUT: P('M124,216a8,8,0,0,1-8,8H48a16,16,0,0,1-16-16V48A16,16,0,0,1,48,32h68a8,8,0,0,1,0,16H48V208h68A8,8,0,0,1,124,216Zm109.66-93.66-40-40a8,8,0,0,0-11.32,11.32L204.69,120H104a8,8,0,0,0,0,16H204.69l-22.35,22.34a8,8,0,0,0,11.32,11.32l40-40A8,8,0,0,0,233.66,122.34Z'),
    CHECK: P('M229.66,77.66l-128,128a8,8,0,0,1-11.32,0l-56-56a8,8,0,0,1,11.32-11.32L96,188.69,218.34,66.34a8,8,0,0,1,11.32,11.32Z'),
    SUN: P('M120,40V16a8,8,0,0,1,16,0V40a8,8,0,0,1-16,0Zm72,88a64,64,0,1,1-64-64A64.07,64.07,0,0,1,192,128Zm-16,0a48,48,0,1,0-48,48A48.05,48.05,0,0,0,176,128ZM58.34,69.66A8,8,0,0,0,69.66,58.34l-16-16A8,8,0,0,0,42.34,53.66Zm0,116.68-16,16a8,8,0,0,0,11.32,11.32l16-16a8,8,0,0,0-11.32-11.32ZM192,72a8,8,0,0,0,5.66-2.34l16-16a8,8,0,0,0-11.32-11.32l-16,16A8,8,0,0,0,192,72Zm5.66,114.34a8,8,0,0,0-11.32,11.32l16,16a8,8,0,0,0,11.32-11.32ZM48,128a8,8,0,0,0-8-8H16a8,8,0,0,0,0,16H40A8,8,0,0,0,48,128Zm80,80a8,8,0,0,0-8,8v24a8,8,0,0,0,16,0V216A8,8,0,0,0,128,208Zm112-88H216a8,8,0,0,0,0,16h24a8,8,0,0,0,0-16Z'),
    TEXT: P('M208,56V88a8,8,0,0,1-16,0V64H136V192h24a8,8,0,0,1,0,16H96a8,8,0,0,1,0-16h24V64H64V88a8,8,0,0,1-16,0V56a8,8,0,0,1,8-8H200A8,8,0,0,1,208,56Z'),
    CLOCK: P('M128,24A104,104,0,1,0,232,128,104.11,104.11,0,0,0,128,24Zm0,192a88,88,0,1,1,88-88A88.1,88.1,0,0,1,128,216Zm56-88a8,8,0,0,1-8,8H128a8,8,0,0,1-8-8V72a8,8,0,0,1,16,0v48h40A8,8,0,0,1,184,128Z'),
    EYESLASH: P('M53.92,34.62A8,8,0,1,0,42.08,45.38L61.32,66.55C25,88.84,9.38,123.2,8.69,124.76a8,8,0,0,0,0,6.5c.35.79,8.82,19.57,27.65,38.4C61.43,194.74,93.12,208,128,208a127.11,127.11,0,0,0,52.07-10.83l22,24.21a8,8,0,1,0,11.84-10.76Zm47.33,75.84,41.67,45.85a32,32,0,0,1-41.67-45.85ZM128,192c-30.78,0-57.67-11.19-79.93-33.25A133.16,133.16,0,0,1,25,128c4.69-8.79,19.66-33.39,47.35-49.38l18,19.75a48,48,0,0,0,63.66,70l14.73,16.2A112,112,0,0,1,128,192Zm6-95.43a8,8,0,0,1,3-15.72,48.16,48.16,0,0,1,38.77,42.64,8,8,0,0,1-7.22,8.71,6.39,6.39,0,0,1-.75,0,8,8,0,0,1-8-7.26A32.09,32.09,0,0,0,134,96.57Zm113.28,34.69c-.42.94-10.55,23.37-33.36,43.8a8,8,0,1,1-10.67-11.92A132.77,132.77,0,0,0,231,128a133.15,133.15,0,0,0-23.12-30.77C185.67,75.19,158.78,64,128,64a118.37,118.37,0,0,0-19.36,1.57A8,8,0,1,1,106,49.79,134,134,0,0,1,128,48c34.88,0,66.57,13.26,91.66,38.35,18.83,18.83,27.3,37.62,27.65,38.41A8,8,0,0,1,247.31,131.26Z'),
    LOCK: P('M208,80H172V52a44,44,0,0,0-88,0V80H48A16,16,0,0,0,32,96V208a16,16,0,0,0,16,16H208a16,16,0,0,0,16-16V96A16,16,0,0,0,208,80ZM100,52a28,28,0,0,1,56,0V80H100ZM208,208H48V96H208V208Zm-68-56a12,12,0,1,1-12-12A12,12,0,0,1,140,152Z'),
    HEARTLINE: P('M178,40c-20.65,0-38.73,8.88-50,23.89C116.73,48.88,98.65,40,78,40a62.07,62.07,0,0,0-62,62c0,70,103.79,126.66,108.21,129a8,8,0,0,0,7.58,0C136.21,228.66,240,172,240,102A62.07,62.07,0,0,0,178,40Zm-50,174.8C109.74,204.16,32,155.46,32,102A46.06,46.06,0,0,1,78,56c19.45,0,35.78,10.36,42.6,27a8,8,0,0,0,14.8,0c6.82-16.67,23.15-27,42.6-27a46.06,46.06,0,0,1,46,46C224,155.46,146.26,204.16,128,214.8Z'),
    HOUSE: P('M218.83,103.77l-80-75.48a1.14,1.14,0,0,1-.11-.11,16,16,0,0,0-21.53,0l-.11.11L37.17,103.77A16,16,0,0,0,32,115.55V208a16,16,0,0,0,16,16H96a16,16,0,0,0,16-16V160h32v48a16,16,0,0,0,16,16h48a16,16,0,0,0,16-16V115.55A16,16,0,0,0,218.83,103.77ZM208,208H160V160a16,16,0,0,0-16-16H112a16,16,0,0,0-16,16v48H48V115.55l.11-.1L128,40l79.9,75.43.11.1Z'),
    COMPASS: P('M128,24A104,104,0,1,0,232,128,104.11,104.11,0,0,0,128,24Zm0,192a88,88,0,1,1,88-88A88.1,88.1,0,0,1,128,216Zm45.34-149.66a8,8,0,0,0-8.49-1.81l-72,28A8,8,0,0,0,88,89.45l-28,72a8,8,0,0,0,10.31,10.31l72-28A8,8,0,0,0,146.55,168l28-72A8,8,0,0,0,173.34,66.34ZM128,144a16,16,0,1,1,16-16A16,16,0,0,1,128,144Z'),
    PLUS: P('M224,128a8,8,0,0,1-8,8H136v80a8,8,0,0,1-16,0V136H40a8,8,0,0,1,0-16h80V40a8,8,0,0,1,16,0v80h80A8,8,0,0,1,224,128Z'),
    SEARCH: P('M229.66,218.34l-50.07-50.06a88.11,88.11,0,1,0-11.31,11.31l50.06,50.07a8,8,0,0,0,11.32-11.32ZM40,112a72,72,0,1,1,72,72A72.08,72.08,0,0,1,40,112Z'),
    DOTS: P('M140,128a12,12,0,1,1-12-12A12,12,0,0,1,140,128ZM128,72a12,12,0,1,0-12-12A12,12,0,0,0,128,72Zm0,112a12,12,0,1,0,12,12A12,12,0,0,0,128,184Z'),
    HASH: P('M212,84H171.41l6.43-35.34a8,8,0,0,0-15.74-2.86L155.15,84H106.41l6.43-35.34a8,8,0,0,0-15.74-2.86L90.15,84H48a8,8,0,0,0,0,16H87.24l-8.73,48H36a8,8,0,0,0,0,16H75.59l-6.43,35.34a8,8,0,0,0,6.44,9.3,7.79,7.79,0,0,0,1.44.13,8,8,0,0,0,7.86-6.57L91.85,164h48.74l-6.43,35.34a8,8,0,0,0,6.44,9.3,7.79,7.79,0,0,0,1.44.13,8,8,0,0,0,7.86-6.57L163.85,164H206a8,8,0,0,0,0-16H166.76l8.73-48H212a8,8,0,0,0,0-16Zm-62.59,64H100.67l8.73-48h48.74Z'),
    PALETTE: P('M200.77,53.89A103.27,103.27,0,0,0,128,24h-1.07A104,104,0,0,0,24,128c0,43,26.58,79.06,69.36,94.17A32,32,0,0,0,136,192a16,16,0,0,1,16-16h46.21a31.81,31.81,0,0,0,31.2-24.88,104.43,104.43,0,0,0,2.59-24A103.28,103.28,0,0,0,200.77,53.89Zm12.65,93.71A15.93,15.93,0,0,1,198.21,160H152a32,32,0,0,0-32,32,16,16,0,0,1-21.31,15.07C62.49,194.3,40,164,40,128a88,88,0,0,1,87.09-88h.9a88.35,88.35,0,0,1,88,87.25A88.86,88.86,0,0,1,213.42,147.6ZM140,76a12,12,0,1,1-12-12A12,12,0,0,1,140,76ZM96,100A12,12,0,1,1,84,88,12,12,0,0,1,96,100Zm0,56a12,12,0,1,1-12-12A12,12,0,0,1,96,156Zm88-56a12,12,0,1,1-12-12A12,12,0,0,1,184,100Z')
  };
  function inject() {
    var html = document.body.innerHTML;
    Object.keys(ICONS).forEach(function (k) {
      html = html.split('__ICON_' + k + '__').join(ICONS[k]);
    });
    document.body.innerHTML = html;
  }
  // Inject synchronously. This file is loaded at the end of <body>, after all
  // markup is parsed but before page scripts run, so the DOM is ready and any
  // listeners attached by later scripts bind to the post-injection nodes.
  inject();
  window.FOMIO_ICONS = ICONS;
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "list-component/list-icons.js", error: String((e && e.message) || e) }); }

// mobile-composer-data.js
try { (() => {
// Fomio mobile composer — mock data (no API).
// Terets are the ONLY publish targets; hubs appear as metadata context only.

window.MC_TERETS = [{
  id: 'slow-web',
  name: 'Slow web',
  hub: 'Technology',
  members: '2.1k'
}, {
  id: 'field-notes',
  name: 'Field notes',
  hub: 'Writing',
  members: '984'
}, {
  id: 'longform',
  name: 'Longform',
  hub: 'Writing',
  members: '3.4k'
}, {
  id: 'film-cameras',
  name: 'Film cameras',
  hub: 'Photography',
  members: '1.2k'
}, {
  id: 'quiet-tools',
  name: 'Quiet tools',
  hub: 'Technology',
  members: '756'
}, {
  id: 'city-walks',
  name: 'City walks',
  hub: 'Places',
  members: '512'
}];
window.MC_REPLY_CTX = {
  author: 'Ismail',
  byteTitle: 'On writing slowly',
  excerpt: 'I keep coming back to the idea that the best Bytes are the ones written over a whole morning, not a spare minute…'
};
window.MC_PREFILL = {
  teretId: 'field-notes',
  title: 'Three weeks without a feed',
  body: 'I deleted every app with an algorithm on the first of the month.\n\nWhat surprised me was not the silence — it was how quickly my attention grew back. By the second week I was reading whole chapters again.\n\n## What changed\n\n- Mornings got longer\n- I wrote more, and slower\n- I stopped narrating my life to an imaginary audience\n\n> The feed was never showing me the world. It was showing me a mirror, angled to sell.\n\nStill working out what I want to keep from that month. More soon.'
};
window.MC_MARKDOWN_TOOLS = [{
  id: 'bold',
  label: 'Bold',
  insert: ['**', '**']
}, {
  id: 'italic',
  label: 'Italic',
  insert: ['*', '*']
}, {
  id: 'heading',
  label: 'Heading',
  insert: ['\n## ', '']
}, {
  id: 'quote',
  label: 'Quote',
  insert: ['\n> ', '']
}, {
  id: 'bullets',
  label: 'Bullet list',
  insert: ['\n- ', '']
}, {
  id: 'numbers',
  label: 'Numbered list',
  insert: ['\n1. ', '']
}, {
  id: 'link',
  label: 'Link',
  insert: ['[', '](url)']
}, {
  id: 'code',
  label: 'Code',
  insert: ['`', '`']
}, {
  id: 'codeblock',
  label: 'Code block',
  insert: ['\n```\n', '\n```']
}, {
  id: 'divider',
  label: 'Divider',
  insert: ['\n\n---\n\n', '']
}];
window.MC_ATTACH_OPTIONS = [{
  id: 'photo',
  label: 'Photo',
  desc: 'From your library'
}, {
  id: 'camera',
  label: 'Camera',
  desc: 'Take a photo'
}, {
  id: 'file',
  label: 'File',
  desc: 'Document or archive'
}, {
  id: 'link',
  label: 'Link',
  desc: 'Paste or preview a URL'
}, {
  id: 'poll',
  label: 'Poll',
  desc: 'Ask the teret'
}, {
  id: 'codeblk',
  label: 'Code block',
  desc: 'Fenced, monospaced'
}];
window.MC_TITLE_MAX = 120;
})(); } catch (e) { __ds_ns.__errors.push({ path: "mobile-composer-data.js", error: String((e && e.message) || e) }); }

// mobile-composer-icons.jsx
try { (() => {
// Fomio mobile composer — Phosphor-style stroke icons (regular weight ≈ 1.75).

const MCIcon = ({
  d,
  size = 20,
  weight = 1.75,
  style = {},
  fill = false
}) => /*#__PURE__*/React.createElement("svg", {
  viewBox: "0 0 24 24",
  width: size,
  height: size,
  fill: fill ? 'currentColor' : 'none',
  stroke: fill ? 'none' : 'currentColor',
  strokeWidth: weight,
  strokeLinecap: "round",
  strokeLinejoin: "round",
  style: style
}, Array.isArray(d) ? d.map((p, i) => /*#__PURE__*/React.createElement("path", {
  key: i,
  d: p
})) : /*#__PURE__*/React.createElement("path", {
  d: d
}));
const MC_ICON = {
  paperclip: 'M21.44 11.05l-8.49 8.49a5 5 0 01-7.07-7.07l8.49-8.49a3.5 3.5 0 014.95 4.95l-8.49 8.49a2 2 0 01-2.83-2.83l7.78-7.78',
  markdown: ['M3 5h18v14H3z', 'M6 15v-5l2.5 3L11 10v5', 'M16 10v5M16 15l-2-2.2M16 15l2-2.2'],
  eye: ['M2 12s3.5-6.5 10-6.5S22 12 22 12s-3.5 6.5-10 6.5S2 12 2 12z', 'M12 9.5a2.5 2.5 0 100 5 2.5 2.5 0 000-5z'],
  dots: 'M5 12h.01M12 12h.01M19 12h.01',
  pencil: ['M4 20h4L19 9l-4-4L4 16v4z', 'M13.5 6.5l4 4'],
  bold: 'M7.5 4.5h5.5a3.75 3.75 0 010 7.5H7.5zM7.5 12h6.5a3.75 3.75 0 010 7.5h-6.5z',
  italic: 'M11 4.5h7.5M5.5 19.5H13M14.5 4.5l-5 15',
  heading: 'M6 4.5v15M18 4.5v15M6 12h12',
  quote: 'M6.5 15a3 3 0 003-3V7.5H4.5V12h3a1 1 0 01-1 1zM16.5 15a3 3 0 003-3V7.5h-5V12h3a1 1 0 01-1 1z',
  bullets: ['M9 6h12M9 12h12M9 18h12', 'M4 6h.01M4 12h.01M4 18h.01'],
  numbers: ['M10 6h11M10 12h11M10 18h11', 'M4 5l1.5-1v5', 'M3.8 11.5c0-.8.7-1.5 1.5-1.5s1.5.6 1.5 1.4c0 1.2-3 2.1-3 3.1h3.2'],
  link: 'M10.5 13.5a4 4 0 005.66 0l3-3a4 4 0 00-5.66-5.66l-1.5 1.5M13.5 10.5a4 4 0 00-5.66 0l-3 3a4 4 0 005.66 5.66l1.5-1.5',
  code: 'M16 18l6-6-6-6M8 6l-6 6 6 6',
  codeblock: ['M4 4.5h16v15H4z', 'M10 9.5l-2.5 2.5L10 14.5M14 9.5l2.5 2.5L14 14.5'],
  divider: ['M4 12h16', 'M9 6h6M9 18h6'],
  image: ['M3 5h18v14H3z', 'M3 15.5l5-4.5 4 3.6 3.2-2.6L21 16', 'M8.5 9.5h.01'],
  camera: ['M3 7.5h3.5L8.5 5h7l2 2.5H21V19H3z', 'M12 16a3.25 3.25 0 100-6.5 3.25 3.25 0 000 6.5z'],
  file: ['M14 2.5H6.5a2 2 0 00-2 2v15a2 2 0 002 2h11a2 2 0 002-2V8z', 'M14 2.5V8h5.5'],
  poll: 'M18 20V10M12 20V4M6 20v-6',
  check: 'M5 12.5l4.5 4.5L19 7',
  chevDown: 'M6 9.5l6 6 6-6',
  chevRight: 'M9 6l6 6-6 6',
  close: 'M6.5 6.5l11 11M17.5 6.5l-11 11',
  arrowUp: 'M12 19V5.5M5.5 12L12 5.5 12 5.5 18.5 12',
  cloud: ['M7 18.5A4.5 4.5 0 017 9.5a5.5 5.5 0 0110.8 1.2A4 4 0 0117 18.5z'],
  spinner: 'M12 3a9 9 0 019 9'
};
Object.assign(window, {
  MCIcon,
  MC_ICON
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "mobile-composer-icons.jsx", error: String((e && e.message) || e) }); }

// mobile-composer-screen.jsx
try { (() => {
// Fomio mobile composer — ComposerScreen (create + reply modes).
// Progressive disclosure: teret + title + body + publish; everything else in sheets.

// ── Tiny markdown renderer (preview only) ─────────────────
function mcInline(text, key) {
  const parts = [];
  const re = /(\*\*([^*]+)\*\*)|(\*([^*]+)\*)|(`([^`]+)`)|(\[([^\]]+)\]\(([^)]+)\))/g;
  let last = 0,
    m,
    i = 0;
  while ((m = re.exec(text)) !== null) {
    if (m.index > last) parts.push(text.slice(last, m.index));
    if (m[2] !== undefined) parts.push(/*#__PURE__*/React.createElement("strong", {
      key: i++
    }, m[2]));else if (m[4] !== undefined) parts.push(/*#__PURE__*/React.createElement("em", {
      key: i++
    }, m[4]));else if (m[6] !== undefined) parts.push(/*#__PURE__*/React.createElement("code", {
      key: i++
    }, m[6]));else if (m[8] !== undefined) parts.push(/*#__PURE__*/React.createElement("a", {
      key: i++,
      href: "#",
      onClick: e => e.preventDefault()
    }, m[8]));
    last = m.index + m[0].length;
  }
  if (last < text.length) parts.push(text.slice(last));
  return /*#__PURE__*/React.createElement(React.Fragment, {
    key: key
  }, parts);
}
function MCMarkdownPreview({
  text
}) {
  if (!text.trim()) return /*#__PURE__*/React.createElement("div", {
    className: "mc-preview-empty"
  }, "Nothing to preview yet.");
  const lines = text.split('\n');
  const out = [];
  let k = 0,
    i = 0;
  while (i < lines.length) {
    const l = lines[i];
    if (l.startsWith('```')) {
      const buf = [];
      i++;
      while (i < lines.length && !lines[i].startsWith('```')) {
        buf.push(lines[i]);
        i++;
      }
      i++;
      out.push(/*#__PURE__*/React.createElement("pre", {
        key: k++
      }, /*#__PURE__*/React.createElement("code", null, buf.join('\n'))));
      continue;
    }
    if (/^#{1,3}\s/.test(l)) {
      out.push(/*#__PURE__*/React.createElement("h2", {
        key: k++
      }, mcInline(l.replace(/^#{1,3}\s/, ''), k)));
      i++;
      continue;
    }
    if (/^---+\s*$/.test(l)) {
      out.push(/*#__PURE__*/React.createElement("hr", {
        key: k++
      }));
      i++;
      continue;
    }
    if (l.startsWith('> ')) {
      const buf = [];
      while (i < lines.length && lines[i].startsWith('> ')) {
        buf.push(lines[i].slice(2));
        i++;
      }
      out.push(/*#__PURE__*/React.createElement("blockquote", {
        key: k++
      }, mcInline(buf.join(' '), k)));
      continue;
    }
    if (/^[-*]\s/.test(l)) {
      const buf = [];
      while (i < lines.length && /^[-*]\s/.test(lines[i])) {
        buf.push(lines[i].replace(/^[-*]\s/, ''));
        i++;
      }
      out.push(/*#__PURE__*/React.createElement("ul", {
        key: k++
      }, buf.map((b, j) => /*#__PURE__*/React.createElement("li", {
        key: j
      }, mcInline(b, j)))));
      continue;
    }
    if (/^\d+\.\s/.test(l)) {
      const buf = [];
      while (i < lines.length && /^\d+\.\s/.test(lines[i])) {
        buf.push(lines[i].replace(/^\d+\.\s/, ''));
        i++;
      }
      out.push(/*#__PURE__*/React.createElement("ol", {
        key: k++
      }, buf.map((b, j) => /*#__PURE__*/React.createElement("li", {
        key: j
      }, mcInline(b, j)))));
      continue;
    }
    if (l.trim() === '') {
      i++;
      continue;
    }
    const buf = [];
    while (i < lines.length && lines[i].trim() !== '' && !/^(#|>|[-*]\s|\d+\.\s|```|---)/.test(lines[i])) {
      buf.push(lines[i]);
      i++;
    }
    out.push(/*#__PURE__*/React.createElement("p", {
      key: k++
    }, mcInline(buf.join(' '), k)));
  }
  return /*#__PURE__*/React.createElement(React.Fragment, null, out);
}

// ── Draft status row ───────────────────────────────────────
function MCDraftStatus({
  status
}) {
  if (status === 'hidden') return /*#__PURE__*/React.createElement("div", {
    className: "mc-draft",
    "aria-hidden": "true"
  });
  const label = {
    saving: 'Saving…',
    saved: 'Saved just now',
    offline: 'Offline draft'
  }[status];
  return /*#__PURE__*/React.createElement("div", {
    className: "mc-draft",
    role: "status"
  }, /*#__PURE__*/React.createElement("span", {
    className: "mc-draft-icon"
  }, status === 'saved' ? /*#__PURE__*/React.createElement(MCIcon, {
    d: MC_ICON.check,
    size: 13,
    weight: 2.2
  }) : /*#__PURE__*/React.createElement(MCIcon, {
    d: MC_ICON.cloud,
    size: 13,
    weight: 1.9
  })), label);
}

// ── Composer screen ────────────────────────────────────────
function MCComposerScreen({
  mode = 'create',
  startEmpty = false,
  keyboardOpen = true,
  theme = 'light'
}) {
  const isCreate = mode === 'create';
  const dark = theme !== 'light';
  const prefill = window.MC_PREFILL;
  const [teret, setTeret] = React.useState(startEmpty || !isCreate ? null : window.MC_TERETS.find(t => t.id === prefill.teretId));
  const [title, setTitle] = React.useState(startEmpty || !isCreate ? '' : prefill.title);
  const [body, setBody] = React.useState(!isCreate ? startEmpty ? '' : 'Same here. The strange part is how loud everything feels when you go back — like walking into a casino after a week in the woods.' : startEmpty ? '' : prefill.body);
  const [sheet, setSheet] = React.useState(null); // 'teret' | 'markdown' | 'attach' | null
  const [view, setView] = React.useState('write'); // 'write' | 'preview'
  const [pubState, setPubState] = React.useState('idle'); // idle | publishing | published
  const [validation, setValidation] = React.useState('');
  const [discardOpen, setDiscardOpen] = React.useState(false);
  const [draftStatus, setDraftStatus] = React.useState(startEmpty ? 'hidden' : 'saved');
  const [toast, setToast] = React.useState('');
  const bodyRef = React.useRef(null);
  const saveT = React.useRef(null);
  const valT = React.useRef(null);
  const dirty = title.trim() !== '' || body.trim() !== '';
  const ready = isCreate ? teret && title.trim() && body.trim() : body.trim().length > 0;
  const words = body.trim() ? body.trim().split(/\s+/).length : 0;

  // debounced "Saving… → Saved just now"
  const touch = () => {
    setDraftStatus('saving');
    clearTimeout(saveT.current);
    saveT.current = setTimeout(() => setDraftStatus('saved'), 900);
  };
  const quietValidate = () => {
    let msg = '';
    if (isCreate && !teret) msg = 'Choose a teret.';else if (isCreate && !title.trim()) msg = 'Add a title before publishing.';else if (!body.trim()) msg = isCreate ? 'Write a little before publishing.' : 'Write a little before sending.';else if (body.trim().length < 12) msg = 'Write a little more before posting.';
    setValidation(msg);
    clearTimeout(valT.current);
    valT.current = setTimeout(() => setValidation(''), 2600);
    return !msg;
  };
  const publish = () => {
    if (pubState !== 'idle') return;
    if (!quietValidate()) return;
    setPubState('publishing');
    setTimeout(() => {
      setPubState('published');
      setToast(isCreate ? 'Byte published to ' + teret.name : 'Reply sent');
      setTimeout(() => {
        setToast('');
        setPubState('idle');
      }, 1800);
    }, 1100);
  };
  const cancel = () => {
    if (dirty) setDiscardOpen(true);else {
      setToast('Closed');
      setTimeout(() => setToast(''), 1000);
    }
  };
  const insertMd = ([pre, post]) => {
    const ta = bodyRef.current;
    const start = ta ? ta.selectionStart : body.length;
    const end = ta ? ta.selectionEnd : body.length;
    const sel = body.slice(start, end);
    const next = body.slice(0, start) + pre + sel + post + body.slice(end);
    setBody(next);
    touch();
    setView('write');
    requestAnimationFrame(() => {
      if (!ta) return;
      ta.focus();
      const pos = start + pre.length + sel.length;
      ta.setSelectionRange(pos, pos);
    });
  };
  const pubLabel = isCreate ? pubState === 'publishing' ? 'Publishing' : pubState === 'published' ? 'Published' : 'Publish' : null;
  return /*#__PURE__*/React.createElement("div", {
    className: "mc-phone",
    "data-theme": theme
  }, /*#__PURE__*/React.createElement("div", {
    className: "mc-header"
  }, /*#__PURE__*/React.createElement("button", {
    className: "mc-cancel",
    onClick: cancel,
    "aria-label": "Cancel and close composer"
  }, "Cancel"), /*#__PURE__*/React.createElement("div", {
    className: "mc-header-title"
  }, isCreate ? 'New byte' : 'Replying to ' + window.MC_REPLY_CTX.author), /*#__PURE__*/React.createElement("div", {
    className: "mc-publish-slot"
  }, isCreate ? /*#__PURE__*/React.createElement("button", {
    className: "mc-publish",
    "data-state": pubState === 'idle' ? ready ? 'active' : 'disabled' : pubState,
    onClick: publish,
    "aria-disabled": !ready,
    "aria-label": pubLabel
  }, pubState === 'publishing' && /*#__PURE__*/React.createElement("span", {
    className: "mc-spin"
  }, /*#__PURE__*/React.createElement(MCIcon, {
    d: MC_ICON.spinner,
    size: 13,
    weight: 2.4
  })), pubState === 'published' && /*#__PURE__*/React.createElement(MCIcon, {
    d: MC_ICON.check,
    size: 13,
    weight: 2.6
  }), pubLabel) : /*#__PURE__*/React.createElement("button", {
    className: "mc-publish mc-send",
    "data-state": pubState === 'idle' ? ready ? 'active' : 'disabled' : pubState,
    onClick: publish,
    "aria-disabled": !ready,
    "aria-label": "Send reply"
  }, pubState === 'publishing' ? /*#__PURE__*/React.createElement("span", {
    className: "mc-spin"
  }, /*#__PURE__*/React.createElement(MCIcon, {
    d: MC_ICON.spinner,
    size: 15,
    weight: 2.4
  })) : pubState === 'published' ? /*#__PURE__*/React.createElement(MCIcon, {
    d: MC_ICON.check,
    size: 16,
    weight: 2.6
  }) : /*#__PURE__*/React.createElement(MCIcon, {
    d: MC_ICON.arrowUp,
    size: 17,
    weight: 2.2
  })))), /*#__PURE__*/React.createElement("div", {
    className: 'mc-validation' + (validation ? ' show' : ''),
    role: "status"
  }, validation), /*#__PURE__*/React.createElement("div", {
    className: "mc-scroll"
  }, isCreate && /*#__PURE__*/React.createElement("div", {
    className: "mc-teret-select"
  }, /*#__PURE__*/React.createElement("span", {
    className: "mc-teret-select-label"
  }, "Post in"), /*#__PURE__*/React.createElement("button", {
    className: 'mc-teret-chip' + (teret ? '' : ' empty'),
    onClick: () => setSheet('teret'),
    "aria-label": teret ? 'Posting in ' + teret.name + '. Change teret' : 'Choose a teret'
  }, teret && /*#__PURE__*/React.createElement("span", {
    className: "mc-chip-dot",
    "aria-hidden": "true"
  }), teret ? teret.name : 'Choose a teret', /*#__PURE__*/React.createElement("span", {
    className: "mc-chip-chev"
  }, /*#__PURE__*/React.createElement(MCIcon, {
    d: MC_ICON.chevDown,
    size: 13,
    weight: 2
  })))), isCreate && /*#__PURE__*/React.createElement("div", {
    className: "mc-title-wrap"
  }, /*#__PURE__*/React.createElement("textarea", {
    className: "mc-title",
    rows: 1,
    placeholder: "Title",
    value: title,
    maxLength: window.MC_TITLE_MAX + 10,
    "aria-label": "Byte title",
    onChange: e => {
      setTitle(e.target.value.replace(/\n/g, ''));
      touch();
    },
    style: {
      height: 'auto'
    },
    onInput: e => {
      e.target.style.height = 'auto';
      e.target.style.height = e.target.scrollHeight + 'px';
    }
  }), title.length >= window.MC_TITLE_MAX - 20 && /*#__PURE__*/React.createElement("span", {
    className: 'mc-title-count' + (title.length > window.MC_TITLE_MAX ? ' over' : '')
  }, window.MC_TITLE_MAX - title.length)), !isCreate && /*#__PURE__*/React.createElement("div", {
    className: "mc-reply-ctx"
  }, /*#__PURE__*/React.createElement("div", {
    className: "mc-reply-ctx-who"
  }, "Replying to ", /*#__PURE__*/React.createElement("strong", null, window.MC_REPLY_CTX.author), " \xB7 ", window.MC_REPLY_CTX.byteTitle), /*#__PURE__*/React.createElement("div", {
    className: "mc-reply-ctx-quote"
  }, "\u201C", window.MC_REPLY_CTX.excerpt, "\u201D")), view === 'preview' && /*#__PURE__*/React.createElement("div", {
    className: "mc-seg",
    role: "tablist",
    "aria-label": "Write or preview"
  }, /*#__PURE__*/React.createElement("button", {
    role: "tab",
    "aria-selected": "false",
    onClick: () => setView('write')
  }, "Write"), /*#__PURE__*/React.createElement("button", {
    role: "tab",
    "aria-selected": "true",
    className: "active",
    onClick: () => setView('preview')
  }, "Preview")), view === 'write' ? /*#__PURE__*/React.createElement("textarea", {
    ref: bodyRef,
    className: "mc-body",
    placeholder: isCreate ? 'Write your Byte…' : 'Write your reply…',
    "aria-label": isCreate ? 'Byte body' : 'Reply body',
    value: body,
    onChange: e => {
      setBody(e.target.value);
      touch();
    }
  }) : /*#__PURE__*/React.createElement("div", {
    className: "mc-preview"
  }, /*#__PURE__*/React.createElement(MCMarkdownPreview, {
    text: body
  }))), /*#__PURE__*/React.createElement(MCDraftStatus, {
    status: dirty ? draftStatus : 'hidden'
  }), /*#__PURE__*/React.createElement("div", {
    className: "mc-toolbar",
    role: "toolbar",
    "aria-label": "Composer actions"
  }, /*#__PURE__*/React.createElement("button", {
    className: "mc-tool",
    onClick: () => setSheet('attach'),
    "aria-label": "Attach"
  }, /*#__PURE__*/React.createElement(MCIcon, {
    d: MC_ICON.paperclip,
    size: 21
  })), /*#__PURE__*/React.createElement("button", {
    className: "mc-tool",
    onClick: () => setSheet('markdown'),
    "aria-label": "Markdown formatting"
  }, /*#__PURE__*/React.createElement(MCIcon, {
    d: MC_ICON.markdown,
    size: 21
  })), /*#__PURE__*/React.createElement("button", {
    className: 'mc-tool' + (view === 'preview' ? ' active' : ''),
    onClick: () => setView(view === 'preview' ? 'write' : 'preview'),
    "aria-label": view === 'preview' ? 'Back to writing' : 'Preview',
    "aria-pressed": view === 'preview'
  }, view === 'preview' ? /*#__PURE__*/React.createElement(MCIcon, {
    d: MC_ICON.pencil,
    size: 21
  }) : /*#__PURE__*/React.createElement(MCIcon, {
    d: MC_ICON.eye,
    size: 21
  })), /*#__PURE__*/React.createElement("button", {
    className: "mc-tool",
    "aria-label": "More"
  }, /*#__PURE__*/React.createElement(MCIcon, {
    d: MC_ICON.dots,
    size: 21,
    weight: 2.6
  })), /*#__PURE__*/React.createElement("span", {
    className: "mc-toolbar-spacer"
  }), words > 0 && /*#__PURE__*/React.createElement("span", {
    className: "mc-wordcount"
  }, words, " ", words === 1 ? 'word' : 'words')), keyboardOpen ? /*#__PURE__*/React.createElement(IOSKeyboard, {
    dark: dark
  }) : /*#__PURE__*/React.createElement("div", {
    className: "mc-bottom-pad"
  }), /*#__PURE__*/React.createElement(MCTeretSheet, {
    open: sheet === 'teret',
    onClose: () => setSheet(null),
    selected: teret,
    onSelect: t => {
      setTeret(t);
      touch();
    }
  }), /*#__PURE__*/React.createElement(MCMarkdownSheet, {
    open: sheet === 'markdown',
    onClose: () => setSheet(null),
    onInsert: insertMd
  }), /*#__PURE__*/React.createElement(MCAttachSheet, {
    open: sheet === 'attach',
    onClose: () => setSheet(null)
  }), /*#__PURE__*/React.createElement(MCDiscardDialog, {
    open: discardOpen,
    onKeep: () => setDiscardOpen(false),
    onSave: () => {
      setDiscardOpen(false);
      setDraftStatus('saved');
      setToast('Draft saved');
      setTimeout(() => setToast(''), 1400);
    },
    onDiscard: () => {
      setDiscardOpen(false);
      setTitle('');
      setBody('');
      setTeret(null);
      setDraftStatus('hidden');
    }
  }), /*#__PURE__*/React.createElement("div", {
    className: 'mc-toast' + (toast ? ' show' : '')
  }, toast && /*#__PURE__*/React.createElement(MCIcon, {
    d: MC_ICON.check,
    size: 14,
    weight: 2.4
  }), toast));
}
window.MCComposerScreen = MCComposerScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "mobile-composer-screen.jsx", error: String((e && e.message) || e) }); }

// mobile-composer-sheets.jsx
try { (() => {
// Fomio mobile composer — bottom sheets + discard dialog.
// All overlays are absolutely positioned INSIDE the device frame.

// ── Generic bottom sheet ──────────────────────────────────
function MCSheet({
  open,
  onClose,
  title,
  children,
  tall = false
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: 'mc-overlay' + (open ? ' open' : ''),
    "aria-hidden": !open
  }, /*#__PURE__*/React.createElement("div", {
    className: "mc-scrim",
    onClick: onClose
  }), /*#__PURE__*/React.createElement("div", {
    className: 'mc-sheet' + (tall ? ' tall' : ''),
    role: "dialog",
    "aria-label": title
  }, /*#__PURE__*/React.createElement("div", {
    className: "mc-grabber"
  }), title && /*#__PURE__*/React.createElement("div", {
    className: "mc-sheet-title"
  }, title), /*#__PURE__*/React.createElement("div", {
    className: "mc-sheet-body"
  }, children)));
}

// ── Teret selector sheet ──────────────────────────────────
function MCTeretSheet({
  open,
  onClose,
  selected,
  onSelect
}) {
  return /*#__PURE__*/React.createElement(MCSheet, {
    open: open,
    onClose: onClose,
    title: "Post in a teret",
    tall: true
  }, window.MC_TERETS.map(t => {
    const active = selected && selected.id === t.id;
    return /*#__PURE__*/React.createElement("button", {
      key: t.id,
      className: 'mc-teret-row' + (active ? ' active' : ''),
      onClick: () => {
        onSelect(t);
        onClose();
      },
      role: "option",
      "aria-selected": active
    }, /*#__PURE__*/React.createElement("span", {
      className: "mc-teret-dot",
      "aria-hidden": "true"
    }), /*#__PURE__*/React.createElement("span", {
      className: "mc-teret-names"
    }, /*#__PURE__*/React.createElement("span", {
      className: "mc-teret-name"
    }, t.name), /*#__PURE__*/React.createElement("span", {
      className: "mc-teret-hub"
    }, t.hub, " \xB7 ", t.members, " members")), active && /*#__PURE__*/React.createElement("span", {
      className: "mc-teret-check"
    }, /*#__PURE__*/React.createElement(MCIcon, {
      d: MC_ICON.check,
      size: 18,
      weight: 2.2
    })));
  }), /*#__PURE__*/React.createElement("div", {
    className: "mc-sheet-help"
  }, "Bytes are published into terets. Hubs are just where terets live."));
}

// ── Markdown tools sheet ──────────────────────────────────
function MCMarkdownSheet({
  open,
  onClose,
  onInsert
}) {
  return /*#__PURE__*/React.createElement(MCSheet, {
    open: open,
    onClose: onClose,
    title: "Formatting"
  }, /*#__PURE__*/React.createElement("div", {
    className: "mc-md-grid"
  }, window.MC_MARKDOWN_TOOLS.map(t => /*#__PURE__*/React.createElement("button", {
    key: t.id,
    className: "mc-md-tool",
    onClick: () => {
      onInsert(t.insert);
      onClose();
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "mc-md-tool-icon"
  }, /*#__PURE__*/React.createElement(MCIcon, {
    d: MC_ICON[t.id],
    size: 22
  })), /*#__PURE__*/React.createElement("span", {
    className: "mc-md-tool-label"
  }, t.label)))), /*#__PURE__*/React.createElement("div", {
    className: "mc-sheet-help"
  }, /*#__PURE__*/React.createElement("strong", null, "Markdown supported"), "Use simple formatting to make your Byte easier to read."));
}

// ── Attachment sheet (visual only, future-ready) ──────────
function MCAttachSheet({
  open,
  onClose
}) {
  return /*#__PURE__*/React.createElement(MCSheet, {
    open: open,
    onClose: onClose,
    title: "Add to your Byte"
  }, window.MC_ATTACH_OPTIONS.map(o => /*#__PURE__*/React.createElement("button", {
    key: o.id,
    className: "mc-attach-row",
    onClick: onClose
  }, /*#__PURE__*/React.createElement("span", {
    className: "mc-attach-icon"
  }, /*#__PURE__*/React.createElement(MCIcon, {
    d: MC_ICON[o.id === 'codeblk' ? 'codeblock' : o.id],
    size: 21
  })), /*#__PURE__*/React.createElement("span", {
    className: "mc-teret-names"
  }, /*#__PURE__*/React.createElement("span", {
    className: "mc-teret-name"
  }, o.label), /*#__PURE__*/React.createElement("span", {
    className: "mc-teret-hub"
  }, o.desc)), /*#__PURE__*/React.createElement("span", {
    className: "mc-attach-chev"
  }, /*#__PURE__*/React.createElement(MCIcon, {
    d: MC_ICON.chevRight,
    size: 15
  })))));
}

// ── Discard / save-draft dialog (iOS action-sheet style) ──
function MCDiscardDialog({
  open,
  onKeep,
  onSave,
  onDiscard
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: 'mc-overlay' + (open ? ' open' : ''),
    "aria-hidden": !open
  }, /*#__PURE__*/React.createElement("div", {
    className: "mc-scrim",
    onClick: onKeep
  }), /*#__PURE__*/React.createElement("div", {
    className: "mc-action-sheet",
    role: "alertdialog",
    "aria-label": "Unsaved Byte"
  }, /*#__PURE__*/React.createElement("div", {
    className: "mc-action-group"
  }, /*#__PURE__*/React.createElement("div", {
    className: "mc-action-title"
  }, "You have unsaved writing"), /*#__PURE__*/React.createElement("button", {
    className: "mc-action-btn",
    onClick: onSave
  }, "Save draft"), /*#__PURE__*/React.createElement("button", {
    className: "mc-action-btn destructive",
    onClick: onDiscard
  }, "Discard")), /*#__PURE__*/React.createElement("div", {
    className: "mc-action-group"
  }, /*#__PURE__*/React.createElement("button", {
    className: "mc-action-btn keep",
    onClick: onKeep
  }, "Keep writing"))));
}
Object.assign(window, {
  MCSheet,
  MCTeretSheet,
  MCMarkdownSheet,
  MCAttachSheet,
  MCDiscardDialog
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "mobile-composer-sheets.jsx", error: String((e && e.message) || e) }); }

// np-components-v2.jsx
try { (() => {
// np-components-v2.jsx — unified best-direction notification panel

// ── Mock data ──────────────────────────────────────────────────────────────────
const TODAY_NOTIFS = [{
  id: 1,
  unread: true,
  type: 'reply',
  avBg: '#9E7B5A',
  avText: 'LM',
  author: 'Lena Marsh',
  excerpt: 'That opening line stopped me cold. The thing about writing without an audience is it forces every sentence to justify—',
  thread: 'On writing without an audience',
  teret: 'Essays',
  time: '5m'
}, {
  id: 2,
  unread: true,
  type: 'mention',
  avBg: '#5A7B6E',
  avText: 'MP',
  author: 'Marco Pini',
  excerpt: '@ismail — this is exactly what I meant about slowing down the feed and reading without algorithmic pressure behind it.',
  teret: 'Quiet internet',
  time: '1h'
}, {
  id: 3,
  unread: true,
  type: 'like',
  avBg: '#7A6080',
  avText: '3',
  author: '3 people liked your byte',
  excerpt: 'A slow afternoon, a good book',
  time: '3h'
}];
const YESTERDAY_NOTIFS = [{
  id: 4,
  unread: false,
  type: 'pm',
  avBg: '#607080',
  avText: 'TR',
  author: 'Theo Ramos',
  excerpt: 'Hey, loved your latest. Quick question about the teret structure — are you planning to expand it beyond writing?',
  time: '1d'
}, {
  id: 5,
  unread: false,
  type: 'teret',
  avBg: '#80604A',
  avText: 'VS',
  author: 'Vera Sousa',
  excerpt: 'On revising: the fear and the pleasure',
  teret: 'Craft',
  time: '1d'
}];

// ── SVG helpers ────────────────────────────────────────────────────────────────
const Ic = {
  clock: (s = 16, w = 1.8) => /*#__PURE__*/React.createElement("svg", {
    width: s,
    height: s,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeLinecap: "round",
    strokeLinejoin: "round",
    strokeWidth: w
  }, /*#__PURE__*/React.createElement("circle", {
    cx: "12",
    cy: "12",
    r: "9"
  }), /*#__PURE__*/React.createElement("polyline", {
    points: "12 7 12 12 15 15"
  })),
  flame: (s = 16, w = 1.8) => /*#__PURE__*/React.createElement("svg", {
    width: s,
    height: s,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeLinecap: "round",
    strokeLinejoin: "round",
    strokeWidth: w
  }, /*#__PURE__*/React.createElement("path", {
    d: "M13 2c.5 3.5-2 5-2 8a4 4 0 0 0 4 4c.5-2 2-3 2-5 2 1 4 4 4 7a7 7 0 1 1-14 0c0-3.5 2.5-5.5 4-8 1-1.6 1.5-4 2-6z"
  })),
  compass: (s = 16, w = 1.8) => /*#__PURE__*/React.createElement("svg", {
    width: s,
    height: s,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeLinecap: "round",
    strokeLinejoin: "round",
    strokeWidth: w
  }, /*#__PURE__*/React.createElement("circle", {
    cx: "12",
    cy: "12",
    r: "9"
  }), /*#__PURE__*/React.createElement("polygon", {
    points: "16.24,7.76 14.12,14.12 7.76,16.24 9.88,9.88"
  })),
  bookmark: (s = 16, w = 1.8) => /*#__PURE__*/React.createElement("svg", {
    width: s,
    height: s,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeLinecap: "round",
    strokeLinejoin: "round",
    strokeWidth: w
  }, /*#__PURE__*/React.createElement("path", {
    d: "M6 3h12v18l-6-4-6 4V3z"
  })),
  pen: (s = 16, w = 1.8) => /*#__PURE__*/React.createElement("svg", {
    width: s,
    height: s,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeLinecap: "round",
    strokeLinejoin: "round",
    strokeWidth: w
  }, /*#__PURE__*/React.createElement("path", {
    d: "M12 20h9"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4 12.5-12.5z"
  })),
  bell: (s = 16, w = 1.8) => /*#__PURE__*/React.createElement("svg", {
    width: s,
    height: s,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeLinecap: "round",
    strokeLinejoin: "round",
    strokeWidth: w
  }, /*#__PURE__*/React.createElement("path", {
    d: "M6 16V11a6 6 0 1 1 12 0v5l1.5 2h-15L6 16z"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M10 20a2 2 0 0 0 4 0"
  })),
  user: (s = 16, w = 1.8) => /*#__PURE__*/React.createElement("svg", {
    width: s,
    height: s,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeLinecap: "round",
    strokeLinejoin: "round",
    strokeWidth: w
  }, /*#__PURE__*/React.createElement("path", {
    d: "M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "12",
    cy: "7",
    r: "4"
  })),
  search: (s = 14, w = 2) => /*#__PURE__*/React.createElement("svg", {
    width: s,
    height: s,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeLinecap: "round",
    strokeLinejoin: "round",
    strokeWidth: w
  }, /*#__PURE__*/React.createElement("circle", {
    cx: "10.5",
    cy: "10.5",
    r: "6.5"
  }), /*#__PURE__*/React.createElement("line", {
    x1: "20",
    y1: "20",
    x2: "15.3",
    y2: "15.3"
  })),
  arrow: (s = 12, w = 2.5) => /*#__PURE__*/React.createElement("svg", {
    width: s,
    height: s,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeLinecap: "round",
    strokeLinejoin: "round",
    strokeWidth: w
  }, /*#__PURE__*/React.createElement("line", {
    x1: "5",
    y1: "12",
    x2: "19",
    y2: "12"
  }), /*#__PURE__*/React.createElement("polyline", {
    points: "12 5 19 12 12 19"
  })),
  check: (s = 12, w = 2.5) => /*#__PURE__*/React.createElement("svg", {
    width: s,
    height: s,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeLinecap: "round",
    strokeLinejoin: "round",
    strokeWidth: w
  }, /*#__PURE__*/React.createElement("polyline", {
    points: "20 6 9 17 4 12"
  }))
};

// Type icons — inline SVGs per notification kind
const TypeIc = {
  reply: () => /*#__PURE__*/React.createElement("svg", {
    width: "13",
    height: "13",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeLinecap: "round",
    strokeLinejoin: "round",
    strokeWidth: "1.9"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M12 3a9 9 0 0 1 9 9c0 5-4 9-9 9-1.3 0-2.5-.3-3.6-.8L3 21l1.2-4.5A8.9 8.9 0 0 1 3 12a9 9 0 0 1 9-9z"
  })),
  mention: () => /*#__PURE__*/React.createElement("svg", {
    width: "13",
    height: "13",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeLinecap: "round",
    strokeLinejoin: "round",
    strokeWidth: "1.9"
  }, /*#__PURE__*/React.createElement("circle", {
    cx: "12",
    cy: "12",
    r: "4"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M16 8v5a3 3 0 0 0 6 0v-1a10 10 0 1 0-3.92 7.94"
  })),
  like: () => /*#__PURE__*/React.createElement("svg", {
    width: "13",
    height: "13",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeLinecap: "round",
    strokeLinejoin: "round",
    strokeWidth: "1.9"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M12 20s-7-4.5-9-9a5 5 0 0 1 9-3 5 5 0 0 1 9 3c-2 4.5-9 9-9 9z"
  })),
  pm: () => /*#__PURE__*/React.createElement("svg", {
    width: "13",
    height: "13",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeLinecap: "round",
    strokeLinejoin: "round",
    strokeWidth: "1.9"
  }, /*#__PURE__*/React.createElement("rect", {
    x: "3",
    y: "5",
    width: "18",
    height: "14",
    rx: "2"
  }), /*#__PURE__*/React.createElement("polyline", {
    points: "3,5 12,13 21,5"
  })),
  teret: () => /*#__PURE__*/React.createElement("svg", {
    width: "13",
    height: "13",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeLinecap: "round",
    strokeLinejoin: "round",
    strokeWidth: "1.9"
  }, /*#__PURE__*/React.createElement("circle", {
    cx: "12",
    cy: "12",
    r: "9"
  }), /*#__PURE__*/React.createElement("polygon", {
    points: "16.24,7.76 14.12,14.12 7.76,16.24 9.88,9.88"
  }))
};

// ── NpRow — unified ────────────────────────────────────────────────────────────
function NpRow({
  notif
}) {
  const rowCls = ['np-row', notif.unread && 'np-row--unread'].filter(Boolean).join(' ');
  const TIcon = TypeIc[notif.type] || TypeIc.reply;
  const metaParts = [];
  if (notif.thread) metaParts.push({
    link: true,
    text: notif.thread
  });
  if (notif.teret) metaParts.push({
    link: false,
    text: notif.teret
  });
  metaParts.push({
    link: false,
    text: notif.time
  });
  return /*#__PURE__*/React.createElement("div", {
    className: rowCls
  }, /*#__PURE__*/React.createElement("div", {
    className: "np-av-wrap"
  }, /*#__PURE__*/React.createElement("div", {
    className: "np-av",
    style: {
      background: notif.avBg
    }
  }, notif.avText), notif.unread && /*#__PURE__*/React.createElement("div", {
    className: "np-av-dot"
  })), /*#__PURE__*/React.createElement("div", {
    className: "np-content"
  }, /*#__PURE__*/React.createElement("span", {
    className: "np-author"
  }, notif.author), /*#__PURE__*/React.createElement("div", {
    className: "np-excerpt"
  }, notif.excerpt), /*#__PURE__*/React.createElement("div", {
    className: "np-meta"
  }, metaParts.map((p, i) => /*#__PURE__*/React.createElement(React.Fragment, {
    key: i
  }, i > 0 && /*#__PURE__*/React.createElement("span", {
    className: "np-meta-sep",
    "aria-hidden": "true"
  }, "\xB7"), /*#__PURE__*/React.createElement("span", {
    className: p.link ? 'np-meta-link' : 'np-meta-plain'
  }, p.text))))), /*#__PURE__*/React.createElement("div", {
    className: "np-row-type",
    "aria-hidden": "true"
  }, /*#__PURE__*/React.createElement(TIcon, null)));
}

// ── NotificationPanel — unified ────────────────────────────────────────────────
function NotificationPanel({
  panelState = 'unread',
  isMobile = false,
  style = {}
}) {
  const hasUnread = panelState === 'unread';
  const isEmpty = panelState === 'empty';
  const isAllRead = panelState === 'allread';
  const todayData = hasUnread ? TODAY_NOTIFS : TODAY_NOTIFS.map(n => ({
    ...n,
    unread: false
  }));
  return /*#__PURE__*/React.createElement("div", {
    className: ['np', isMobile && 'np--mobile'].filter(Boolean).join(' '),
    style: style
  }, isMobile && /*#__PURE__*/React.createElement("div", {
    className: "np-handle"
  }), /*#__PURE__*/React.createElement("div", {
    className: "np-header"
  }, /*#__PURE__*/React.createElement("span", {
    className: "np-title"
  }, "Notifications"), hasUnread && /*#__PURE__*/React.createElement("button", {
    className: "np-mark-read"
  }, "Mark all read")), /*#__PURE__*/React.createElement("div", {
    className: "np-tabs"
  }, /*#__PURE__*/React.createElement("button", {
    className: "np-tab np-tab--on"
  }, "All"), /*#__PURE__*/React.createElement("button", {
    className: "np-tab"
  }, "Messages")), isEmpty ? /*#__PURE__*/React.createElement("div", {
    className: "np-empty"
  }, /*#__PURE__*/React.createElement("div", {
    className: "np-empty-icon"
  }, Ic.bell(28, 1.2)), /*#__PURE__*/React.createElement("p", {
    className: "np-empty-title"
  }, "All quiet here"), /*#__PURE__*/React.createElement("p", {
    className: "np-empty-sub"
  }, "Notifications appear when someone replies, mentions you, or sends a message.")) : /*#__PURE__*/React.createElement("div", {
    className: "np-body"
  }, isAllRead && /*#__PURE__*/React.createElement("div", {
    className: "np-caught-up"
  }, Ic.check(13), " You're all caught up"), /*#__PURE__*/React.createElement("div", {
    className: "np-sh"
  }, "Today"), todayData.map(n => /*#__PURE__*/React.createElement(NpRow, {
    key: n.id,
    notif: n
  })), /*#__PURE__*/React.createElement("div", {
    className: "np-sh"
  }, "Yesterday"), YESTERDAY_NOTIFS.map(n => /*#__PURE__*/React.createElement(NpRow, {
    key: n.id,
    notif: n
  }))), !isEmpty && !isMobile && /*#__PURE__*/React.createElement("div", {
    className: "np-footer"
  }, /*#__PURE__*/React.createElement("span", {
    className: "np-footer-link"
  }, "View all notifications ", Ic.arrow(12))));
}

// ── SidebarMock ────────────────────────────────────────────────────────────────
function SidebarMock({
  variant = 'full'
}) {
  const isRail = variant === 'rail';
  const navItems = [{
    icon: Ic.clock(),
    label: 'Latest',
    on: true
  }, {
    icon: Ic.flame(),
    label: 'Hot'
  }, {
    icon: Ic.compass(),
    label: 'Hubs'
  }, {
    icon: Ic.bookmark(),
    label: 'Bookmarks'
  }, {
    icon: Ic.pen(),
    label: 'Create byte',
    primary: true
  }];
  return /*#__PURE__*/React.createElement("div", {
    className: `sbm${isRail ? ' sbm--rail' : ''}`
  }, /*#__PURE__*/React.createElement("div", {
    className: "sbm-top"
  }, isRail ? /*#__PURE__*/React.createElement("div", {
    className: "sbm-mark"
  }, "f") : /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    className: "sbm-wordmark"
  }, /*#__PURE__*/React.createElement("em", null, "fomio")), /*#__PURE__*/React.createElement("div", {
    className: "sbm-search"
  }, Ic.search(13), /*#__PURE__*/React.createElement("span", {
    className: "sbm-search-ph"
  }, "Search\u2026"), /*#__PURE__*/React.createElement("span", {
    className: "sbm-search-kbd"
  }, "\u2318K")))), /*#__PURE__*/React.createElement("div", {
    className: "sbm-nav"
  }, navItems.map((item, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    className: ['sbm-item', item.on && 'sbm-item--on', item.primary && 'sbm-item--primary'].filter(Boolean).join(' ')
  }, /*#__PURE__*/React.createElement("span", {
    className: "sbm-icon"
  }, item.icon), !isRail && /*#__PURE__*/React.createElement("span", {
    className: "sbm-label"
  }, item.label)))), /*#__PURE__*/React.createElement("div", {
    className: "sbm-btm"
  }, /*#__PURE__*/React.createElement("div", {
    className: "sbm-item sbm-item--bell"
  }, /*#__PURE__*/React.createElement("span", {
    className: "sbm-icon"
  }, Ic.bell()), !isRail && /*#__PURE__*/React.createElement("span", {
    className: "sbm-label"
  }, "Notifications"), /*#__PURE__*/React.createElement("span", {
    className: "sbm-badge"
  }, "4")), /*#__PURE__*/React.createElement("div", {
    className: "sbm-item"
  }, /*#__PURE__*/React.createElement("span", {
    className: "sbm-icon"
  }, /*#__PURE__*/React.createElement("div", {
    className: "sbm-av"
  })), !isRail && /*#__PURE__*/React.createElement("span", {
    className: "sbm-label"
  }, "@ismail"))));
}

// ── MobileNav ──────────────────────────────────────────────────────────────────
function MobileNav() {
  const items = [{
    icon: Ic.clock(20),
    label: 'Latest'
  }, {
    icon: Ic.compass(20),
    label: 'Explore'
  }, {
    icon: Ic.pen(20),
    label: 'Create'
  }, {
    icon: Ic.bell(20),
    label: 'Alerts',
    active: true,
    badge: '4'
  }, {
    icon: Ic.user(20),
    label: 'Me'
  }];
  return /*#__PURE__*/React.createElement("div", {
    className: "mn"
  }, items.map((item, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    className: `mn-item${item.active ? ' mn-item--on' : ''}`
  }, /*#__PURE__*/React.createElement("div", {
    className: "mn-icon-wrap"
  }, item.icon, item.badge && /*#__PURE__*/React.createElement("span", {
    className: "mn-badge"
  }, item.badge)), /*#__PURE__*/React.createElement("span", {
    className: "mn-label"
  }, item.label))));
}
Object.assign(window, {
  TODAY_NOTIFS,
  YESTERDAY_NOTIFS,
  Ic,
  TypeIc,
  NpRow,
  NotificationPanel,
  SidebarMock,
  MobileNav
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "np-components-v2.jsx", error: String((e && e.message) || e) }); }

// search-app.jsx
try { (() => {
/* Fomio search — main island. Composes sidebar, morphing header, search bar,
   live suggestions, filters, grouped results, states, and tweaks. */

const FOLLOWED = ["jun"]; // handles the viewer follows

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "direction": "bold",
  "theme": "light",
  "density": "comfy",
  "types": "dropdown",
  "filterLayout": "inline"
} /*EDITMODE-END*/;
function App() {
  const D = window.SEARCH_DATA;
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);
  const [query, setQuery] = React.useState("chronological feeds");
  const [committed, setCommitted] = React.useState(true);
  const [focused, setFocused] = React.useState(false);
  const [scope, setScope] = React.useState("bytes");
  const [advOpen, setAdvOpen] = React.useState(false);
  const [sugIdx, setSugIdx] = React.useState(-1);
  const [context, setContext] = React.useState(null); // { id, name, color } when search is scoped
  const [previewSel, setPreviewSel] = React.useState("live");
  const inputRef = React.useRef(null);
  const [f, setF] = React.useState({
    time: "Any time",
    sort: "Relevance",
    follow: false,
    hasReplies: false,
    unread: false,
    inTitle: false,
    status: "any",
    minLikes: 0,
    terets: [],
    postedBy: ""
  });
  const set = patch => setF(prev => ({
    ...prev,
    ...patch
  }));
  const bold = t.direction === "bold";
  const dense = t.density === "compact";
  const railLayout = t.filterLayout === "rail" || bold;

  // theme → <html data-theme>
  React.useEffect(() => {
    document.documentElement.setAttribute("data-theme", t.theme);
  }, [t.theme]);
  React.useEffect(() => {
    document.documentElement.setAttribute("data-direction", t.direction);
  }, [t.direction]);

  // ── derive matches ──────────────────────────────────────────────────────
  const terms = query.trim().toLowerCase().split(/\s+/).filter(w => w.length > 1 && w[0] !== "@");
  const has = text => terms.length === 0 || terms.some(tm => text.toLowerCase().includes(tm));
  const matchedBytes = React.useMemo(() => {
    return D.bytes.filter(b => {
      const hay = f.inTitle ? b.title : b.title + " " + b.excerpt + " " + b.author + " " + b.teret;
      if (!has(hay)) return false;
      if (f.unread && !b.unread) return false;
      if (f.hasReplies && b.replies === 0) return false;
      if (f.follow && !FOLLOWED.includes(b.handle)) return false;
      if (f.minLikes && b.likes < f.minLikes) return false;
      if (f.terets.length) {
        const tname = D.terets.find(tt => f.terets.includes(tt.id) && tt.name === b.teret);
        if (!tname) return false;
      }
      if (f.postedBy && !("@" + b.handle).includes(f.postedBy.replace(/^@?/, "@"))) return false;
      return true;
    });
  }, [query, f]);
  const matchedTerets = D.terets.filter(tt => has(tt.name + " " + tt.desc + " " + tt.hub));
  const matchedTags = D.tags.filter(tg => has(tg.name));
  const matchedPeople = D.people.filter(p => has(p.name + " " + p.handle + " " + p.bio));

  // context scoping limits bytes to the scoped teret (Discourse: context / context_id)
  const ctxBytes = context ? matchedBytes.filter(b => b.teret === context.name) : matchedBytes;

  // ── filter tokens for the summary bar ───────────────────────────────────
  const tokens = [];
  if (f.time !== "Any time") tokens.push({
    key: "time",
    label: f.time
  });
  if (f.sort !== "Relevance") tokens.push({
    key: "sort",
    label: f.sort
  });
  if (f.follow) tokens.push({
    key: "follow",
    label: "People I follow"
  });
  if (f.hasReplies) tokens.push({
    key: "hasReplies",
    label: "Has replies"
  });
  if (f.unread) tokens.push({
    key: "unread",
    label: "Unread"
  });
  if (f.inTitle) tokens.push({
    key: "inTitle",
    label: "Title only"
  });
  if (f.status !== "any") tokens.push({
    key: "status",
    label: f.status
  });
  if (f.minLikes) tokens.push({
    key: "minLikes",
    label: "≥ " + f.minLikes + " likes"
  });
  if (f.postedBy) tokens.push({
    key: "postedBy",
    label: "by " + f.postedBy
  });
  f.terets.forEach(id => {
    const tt = D.terets.find(x => x.id === id);
    if (tt) tokens.push({
      key: "teret:" + id,
      label: tt.name
    });
  });
  const defaults = {
    time: "Any time",
    sort: "Relevance",
    follow: false,
    hasReplies: false,
    unread: false,
    inTitle: false,
    status: "any",
    minLikes: 0,
    postedBy: ""
  };
  const removeToken = key => {
    if (key.startsWith("teret:")) {
      const id = key.slice(6);
      set({
        terets: f.terets.filter(x => x !== id)
      });
      return;
    }
    set({
      [key]: defaults[key]
    });
  };
  const clearAll = () => set({
    ...defaults,
    terets: []
  });

  // ── commit / clear ────────────────────────────────────────────────────────
  const commit = q => {
    const v = q != null ? q : query;
    setQuery(v);
    setCommitted(true);
    setFocused(false);
    setSugIdx(-1);
    inputRef.current && inputRef.current.blur();
  };
  const clearQuery = () => {
    setQuery("");
    setCommitted(false);
    setSugIdx(-1);
    inputRef.current && inputRef.current.focus();
  };

  // suggestion flat list (for keyboard nav)
  const sugItems = [...D.suggestions.completions.map(c => ({
    type: "q",
    value: c
  })), ...matchedTerets.slice(0, 2).map(tt => ({
    type: "teret",
    value: tt
  })), ...matchedPeople.slice(0, 2).map(p => ({
    type: "person",
    value: p
  }))];
  const showSug = focused && query.trim().length > 0 && !committed;

  // ── global keyboard ─────────────────────────────────────────────────────
  React.useEffect(() => {
    const onKey = e => {
      if (e.key === "/" && document.activeElement !== inputRef.current) {
        e.preventDefault();
        inputRef.current && inputRef.current.focus();
      } else if (e.key === "Escape") {
        if (showSug) {
          setFocused(false);
          setSugIdx(-1);
        } else if (query) clearQuery();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [showSug, query]);
  const onInputKey = e => {
    if (!showSug) {
      if (e.key === "Enter") commit();
      return;
    }
    if (e.key === "ArrowDown") {
      e.preventDefault();
      setSugIdx(i => Math.min(sugItems.length - 1, i + 1));
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      setSugIdx(i => Math.max(-1, i - 1));
    } else if (e.key === "Enter") {
      e.preventDefault();
      if (sugIdx >= 0 && sugItems[sugIdx]) {
        const it = sugItems[sugIdx];
        if (it.type === "q") commit(it.value);else if (it.type === "teret") {
          setScope("terets");
          commit(it.value.name);
        } else {
          setScope("people");
          commit(it.value.handle);
        }
      } else commit();
    }
  };
  const onType = v => {
    setQuery(v);
    setCommitted(false);
    setFocused(true);
    setSugIdx(-1);
  };
  const isEmpty = !committed || query.trim() === "";
  const tooShort = committed && query.trim().length > 0 && query.trim().length < 3;
  const teretsCount = matchedTerets.length + matchedTags.length;
  const noResults = committed && query.trim() !== "" && !tooShort && (scope === "bytes" && ctxBytes.length === 0 && (context || matchedTerets.length === 0 && matchedPeople.length === 0 && matchedTags.length === 0) || scope === "terets" && teretsCount === 0 || scope === "people" && matchedPeople.length === 0);
  const scopeCount = scope === "bytes" ? ctxBytes.length : scope === "terets" ? teretsCount : matchedPeople.length;
  const noResCounts = {
    bytes: ctxBytes.length,
    terets: teretsCount,
    people: matchedPeople.length
  };

  // jump straight to any existing Discourse /search state (review aid, not a feature)
  const jumpTo = s => {
    setAdvOpen(false);
    if (s === "empty") {
      setQuery("");
      setCommitted(false);
      setContext(null);
      setScope("bytes");
    } else if (s === "results") {
      setQuery("chronological feeds");
      setCommitted(true);
      setContext(null);
      setScope("bytes");
    } else if (s === "context") {
      setQuery("chronological feeds");
      setCommitted(true);
      setScope("bytes");
      setContext({
        id: "essays",
        name: "Essays",
        color: "#C44536"
      });
    } else if (s === "noresult") {
      setQuery("qxzqvw");
      setCommitted(true);
      setContext(null);
      setScope("bytes");
    } else if (s === "invalid") {
      setQuery("ch");
      setCommitted(true);
      setContext(null);
      setScope("bytes");
    } else if (s === "users") {
      setQuery("writing");
      setCommitted(true);
      setContext(null);
      setScope("people");
    } else if (s === "tags") {
      setQuery("writing");
      setCommitted(true);
      setContext(null);
      setScope("terets");
    }
  };
  return /*#__PURE__*/React.createElement("div", {
    className: "app" + (railLayout ? " has-rail" : ""),
    "data-bold": bold ? "1" : "0"
  }, /*#__PURE__*/React.createElement(Sidebar, null), /*#__PURE__*/React.createElement("main", {
    className: "main"
  }, /*#__PURE__*/React.createElement("div", {
    className: "search-wrap"
  }, /*#__PURE__*/React.createElement(SearchHeader, {
    isEmpty: isEmpty,
    query: query,
    bold: bold,
    count: scopeCount,
    scope: scope,
    noResults: noResults
  }), /*#__PURE__*/React.createElement(SearchBar, {
    query: query,
    onType: onType,
    onKey: onInputKey,
    inputRef: inputRef,
    onFocus: () => setFocused(true),
    onCommit: () => commit(),
    onClear: clearQuery,
    typesMode: t.types,
    scope: scope,
    setScope: setScope,
    showSug: showSug,
    sugItems: sugItems,
    sugIdx: sugIdx,
    setSugIdx: setSugIdx,
    commit: commit,
    setScope2: setScope,
    terms: terms
  }), t.types === "segmented" && /*#__PURE__*/React.createElement(ScopeSegmented, {
    scope: scope,
    setScope: setScope,
    counts: {
      bytes: ctxBytes.length,
      terets: teretsCount,
      people: matchedPeople.length
    },
    showCounts: committed && !isEmpty
  }), context && !isEmpty && /*#__PURE__*/React.createElement(ContextBar, {
    name: context.name,
    color: context.color,
    onClear: () => setContext(null)
  }), !isEmpty && !tooShort && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(FilterChips, {
    f: f,
    set: set,
    advancedOpen: advOpen,
    onToggleAdvanced: () => setAdvOpen(o => !o),
    showAdvancedLink: !railLayout
  }), !railLayout && advOpen && /*#__PURE__*/React.createElement("div", {
    className: "adv-panel"
  }, /*#__PURE__*/React.createElement(AdvancedFields, {
    f: f,
    set: set,
    layout: "inline"
  }))), /*#__PURE__*/React.createElement("div", {
    className: "body-grid" + (railLayout && !isEmpty && !tooShort ? " body-grid--rail" : "")
  }, /*#__PURE__*/React.createElement("div", {
    className: "body-main"
  }, isEmpty ? /*#__PURE__*/React.createElement(EmptyState, {
    onPick: q => {
      setScope("bytes");
      commit(q);
    }
  }) : tooShort ? /*#__PURE__*/React.createElement(InvalidSearch, {
    onPick: q => {
      setScope("bytes");
      commit(q);
    }
  }) : noResults ? /*#__PURE__*/React.createElement(NoResults, {
    query: query,
    scope: scope,
    setScope: setScope,
    counts: noResCounts,
    onClear: clearAll,
    hasFilters: tokens.length > 0,
    context: context,
    onClearContext: () => setContext(null)
  }) : /*#__PURE__*/React.createElement(Results, {
    scope: scope,
    setScope: setScope,
    terms: terms,
    dense: dense,
    bold: bold,
    bytes: ctxBytes,
    terets: matchedTerets,
    people: matchedPeople,
    tags: matchedTags,
    context: context,
    tokens: tokens,
    removeToken: removeToken,
    clearAll: clearAll,
    count: scopeCount
  })), railLayout && !isEmpty && !tooShort && /*#__PURE__*/React.createElement("aside", {
    className: "rail"
  }, /*#__PURE__*/React.createElement("div", {
    className: "rail-card"
  }, /*#__PURE__*/React.createElement("h3", {
    className: "rail-title"
  }, /*#__PURE__*/React.createElement(Sliders, {
    size: 15
  }), " Refine"), /*#__PURE__*/React.createElement(AdvancedFields, {
    f: f,
    set: set,
    layout: "rail"
  })), /*#__PURE__*/React.createElement("div", {
    className: "rail-card"
  }, /*#__PURE__*/React.createElement("h3", {
    className: "rail-title"
  }, "People also searched"), /*#__PURE__*/React.createElement("div", {
    className: "rail-also"
  }, ["chronological design", "calm technology", "rss revival", "writing tools"].map(q => /*#__PURE__*/React.createElement("button", {
    key: q,
    className: "rail-also-row",
    onClick: () => commit(q)
  }, /*#__PURE__*/React.createElement(SearchIcon, {
    size: 13
  }), " ", q)))))), /*#__PURE__*/React.createElement(KbdHints, null))), /*#__PURE__*/React.createElement(TweaksPanel, {
    title: "Tweaks"
  }, /*#__PURE__*/React.createElement(TweakSection, {
    label: "Direction"
  }), /*#__PURE__*/React.createElement(TweakRadio, {
    label: "Style",
    value: t.direction,
    options: [{
      value: "calm",
      label: "Calm"
    }, {
      value: "bold",
      label: "Bold"
    }],
    onChange: v => setTweak("direction", v)
  }), /*#__PURE__*/React.createElement(TweakSection, {
    label: "Presentation"
  }), /*#__PURE__*/React.createElement(TweakRadio, {
    label: "Theme",
    value: t.theme,
    options: [{
      value: "light",
      label: "Light"
    }, {
      value: "dark",
      label: "Dark"
    }],
    onChange: v => setTweak("theme", v)
  }), /*#__PURE__*/React.createElement(TweakRadio, {
    label: "Density",
    value: t.density,
    options: [{
      value: "comfy",
      label: "Comfy"
    }, {
      value: "compact",
      label: "Compact"
    }],
    onChange: v => setTweak("density", v)
  }), /*#__PURE__*/React.createElement(TweakSection, {
    label: "Search types"
  }), /*#__PURE__*/React.createElement(TweakRadio, {
    label: "Scope control",
    value: t.types,
    options: [{
      value: "segmented",
      label: "Segmented"
    }, {
      value: "dropdown",
      label: "In-bar"
    }],
    onChange: v => setTweak("types", v)
  }), /*#__PURE__*/React.createElement(TweakSection, {
    label: "Filters"
  }), /*#__PURE__*/React.createElement(TweakRadio, {
    label: "Layout",
    value: t.filterLayout,
    options: [{
      value: "inline",
      label: "Inline"
    }, {
      value: "rail",
      label: "Rail"
    }],
    onChange: v => setTweak("filterLayout", v)
  }), bold && /*#__PURE__*/React.createElement("p", {
    className: "twk-note"
  }, "Bold direction pins the refine rail on."), /*#__PURE__*/React.createElement(TweakSection, {
    label: "Review states"
  }), /*#__PURE__*/React.createElement(TweakSelect, {
    label: "Jump to",
    value: previewSel,
    options: [{
      value: "live",
      label: "Live (interactive)"
    }, {
      value: "results",
      label: "Results — Bytes"
    }, {
      value: "users",
      label: "Results — Users"
    }, {
      value: "tags",
      label: "Results — Terets & tags"
    }, {
      value: "context",
      label: "Context-scoped"
    }, {
      value: "noresult",
      label: "No results"
    }, {
      value: "invalid",
      label: "Invalid (too short)"
    }, {
      value: "empty",
      label: "Empty / landing"
    }],
    onChange: v => {
      setPreviewSel(v);
      if (v !== "live") jumpTo(v);
    }
  }), /*#__PURE__*/React.createElement("p", {
    className: "twk-note"
  }, "Covers every state Discourse renders on /search.")));
}
ReactDOM.createRoot(document.getElementById("root")).render(/*#__PURE__*/React.createElement(App, null));
})(); } catch (e) { __ds_ns.__errors.push({ path: "search-app.jsx", error: String((e && e.message) || e) }); }

// search-data.js
try { (() => {
/* ───────────────────────────────────────────────────────────────────────────
   Fomio — /search mock data
   Plain global (window.SEARCH_DATA) consumed by the React islands.
   Editorial, calm copy. Domain nouns: byte (post), teret (subcategory), hub.
   ─────────────────────────────────────────────────────────────────────────── */
(function () {
  const terets = [{
    id: "essays",
    name: "Essays",
    hub: "Writing",
    color: "#C44536",
    bytes: 1284,
    desc: "Long-form thinking, unhurried."
  }, {
    id: "quiet",
    name: "Quiet internet",
    hub: "Internet",
    color: "#4A6B5C",
    bytes: 643,
    desc: "On building a calmer web."
  }, {
    id: "craft",
    name: "Craft",
    hub: "Writing",
    color: "#6B4A5C",
    bytes: 902,
    desc: "The practice of making things."
  }, {
    id: "letters",
    name: "Letters",
    hub: "Writing",
    color: "#5C4A6B",
    bytes: 311,
    desc: "Correspondence, public and private."
  }, {
    id: "field",
    name: "Field notes",
    hub: "Living",
    color: "#7A5C3A",
    bytes: 188,
    desc: "Observations from the day."
  }, {
    id: "reading",
    name: "Reading",
    hub: "Living",
    color: "#3A5C7A",
    bytes: 426,
    desc: "What we read and why."
  }];
  const people = [{
    id: "lena",
    name: "Lena Marsh",
    handle: "lena",
    bio: "Writing essays without an audience.",
    bytes: 142,
    following: false,
    hue: "#C44536"
  }, {
    id: "jun",
    name: "Jun Nakamura",
    handle: "jun",
    bio: "Writing toward a slower internet.",
    bytes: 88,
    following: true,
    hue: "#4A6B5C"
  }, {
    id: "ada",
    name: "Ada Reyes",
    handle: "ada",
    bio: "Letters to no one. Writing, mostly.",
    bytes: 64,
    following: false,
    hue: "#6B4A5C"
  }, {
    id: "owen",
    name: "Owen Whitfield",
    handle: "owen",
    bio: "Editor. Reads everything twice.",
    bytes: 207,
    following: false,
    hue: "#5C4A6B"
  }];

  // tags (Discourse search type categories_tags includes tags)
  const tags = [{
    name: "chronology",
    bytes: 64
  }, {
    name: "attention",
    bytes: 41
  }, {
    name: "writing",
    bytes: 318
  }, {
    name: "rss",
    bytes: 23
  }, {
    name: "calm-tech",
    bytes: 37
  }, {
    name: "slow-web",
    bytes: 19
  }];

  // Bytes (topics/posts). `match` marks whether the hit was in title or body.
  const bytes = [{
    id: "b1",
    featured: true,
    title: "The case for chronological feeds",
    excerpt: "A clock is a modest instrument. It doesn’t know you, doesn’t care what you’ve read before, doesn’t try. A chronological feed puts one thing after another — an orientation, not a recommendation.",
    author: "Jun Nakamura",
    handle: "jun",
    hue: "#4A6B5C",
    teret: "Quiet internet",
    teretColor: "#4A6B5C",
    read: "9 min",
    date: "1 day ago",
    likes: 127,
    replies: 34,
    match: "title",
    unread: true
  }, {
    id: "b2",
    title: "What we lose to the algorithm",
    excerpt: "Every recommended feed is a small argument about who you are. Over a year of reading without one, the shape of my attention changed — and a chronological feed had something to do with it.",
    author: "Lena Marsh",
    handle: "lena",
    hue: "#C44536",
    teret: "Essays",
    teretColor: "#C44536",
    read: "12 min",
    date: "3 days ago",
    likes: 89,
    replies: 21,
    match: "body",
    unread: false
  }, {
    id: "b3",
    title: "Reverse-chron and the shape of a morning",
    excerpt: "There’s a specific pleasure in opening an app and finding it unchanged — no new tab, no pulsing dot. The feed trusts you to arrive when you arrive.",
    author: "Ada Reyes",
    handle: "ada",
    hue: "#6B4A5C",
    teret: "Craft",
    teretColor: "#6B4A5C",
    read: "6 min",
    date: "5 hours ago",
    likes: 54,
    replies: 12,
    match: "title",
    unread: false
  }, {
    id: "b4",
    title: "Notes on building a calmer reader",
    excerpt: "We removed the counter first, then the feed ranking. What surprised us was how little people missed — and how a plain chronological list felt, somehow, like more.",
    author: "Owen Whitfield",
    handle: "owen",
    hue: "#5C4A6B",
    teret: "Quiet internet",
    teretColor: "#4A6B5C",
    read: "8 min",
    date: "1 week ago",
    likes: 203,
    replies: 47,
    match: "body",
    unread: false
  }, {
    id: "b5",
    title: "A feed is a promise about time",
    excerpt: "Chronology is the one ordering that doesn’t pretend to know better than you. It is the difference between a library and a slot machine.",
    author: "Lena Marsh",
    handle: "lena",
    hue: "#C44536",
    teret: "Essays",
    teretColor: "#C44536",
    read: "5 min",
    date: "2 weeks ago",
    likes: 71,
    replies: 9,
    match: "title",
    unread: false
  }];
  const recent = ["chronological feeds", "writing without an audience", "amoled dark mode", "@lena essays"];
  const saved = [{
    q: "essays",
    scope: "in Essays · last month",
    count: 38
  }, {
    q: "unread",
    scope: "Unread in Quiet internet",
    count: 6
  }];

  // Live suggestions while typing (query-agnostic mock)
  const suggestions = {
    completions: ["chronological feeds", "chronological vs ranked", "chronology and attention"],
    terets: [terets[1], terets[0]],
    people: [people[1], people[0]]
  };
  const sorts = ["Relevance", "Latest post", "Most liked", "Most viewed", "Latest topic"];
  const times = ["Any time", "Past 24 hours", "Past week", "Past month", "Past year"];
  window.SEARCH_DATA = {
    terets,
    people,
    tags,
    bytes,
    recent,
    saved,
    suggestions,
    sorts,
    times
  };
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "search-data.js", error: String((e && e.message) || e) }); }

// search-filters.jsx
try { (() => {
/* Fomio search — filter surfaces: quick chips, advanced disclosure,
   active-filter summary bar, and the persistent refine rail. */

// ── tiny popover dropdown ─────────────────────────────────────────────────────
function Dropdown({
  label,
  value,
  options,
  onChange,
  icon
}) {
  const [open, setOpen] = React.useState(false);
  const ref = React.useRef(null);
  React.useEffect(() => {
    if (!open) return;
    const off = e => {
      if (ref.current && !ref.current.contains(e.target)) setOpen(false);
    };
    document.addEventListener("mousedown", off);
    return () => document.removeEventListener("mousedown", off);
  }, [open]);
  const active = value && value !== options[0];
  return /*#__PURE__*/React.createElement("div", {
    className: "dd",
    ref: ref
  }, /*#__PURE__*/React.createElement("button", {
    className: "chip" + (active ? " chip--on" : ""),
    onClick: () => setOpen(!open)
  }, icon, /*#__PURE__*/React.createElement("span", null, value), /*#__PURE__*/React.createElement(Chevron, {
    size: 13
  })), open && /*#__PURE__*/React.createElement("div", {
    className: "dd-menu"
  }, options.map(o => /*#__PURE__*/React.createElement("button", {
    key: o,
    className: "dd-item" + (o === value ? " is-sel" : ""),
    onClick: () => {
      onChange(o);
      setOpen(false);
    }
  }, /*#__PURE__*/React.createElement("span", null, o), o === value && /*#__PURE__*/React.createElement(Check, {
    size: 14
  })))));
}

// ── quick filter chip row ─────────────────────────────────────────────────────
function FilterChips({
  f,
  set,
  onToggleAdvanced,
  advancedOpen,
  showAdvancedLink
}) {
  const D = window.SEARCH_DATA;
  return /*#__PURE__*/React.createElement("div", {
    className: "chips"
  }, /*#__PURE__*/React.createElement(Dropdown, {
    label: "Time",
    value: f.time,
    options: D.times,
    onChange: v => set({
      time: v
    }),
    icon: /*#__PURE__*/React.createElement(Clock, {
      size: 13
    })
  }), /*#__PURE__*/React.createElement(Dropdown, {
    label: "Sort",
    value: f.sort,
    options: D.sorts,
    onChange: v => set({
      sort: v
    }),
    icon: /*#__PURE__*/React.createElement(Sort, {
      size: 13
    })
  }), /*#__PURE__*/React.createElement("span", {
    className: "chip-div"
  }), /*#__PURE__*/React.createElement("button", {
    className: "chip" + (f.follow ? " chip--on" : ""),
    onClick: () => set({
      follow: !f.follow
    })
  }, /*#__PURE__*/React.createElement(Users, {
    size: 13
  }), " People I follow"), /*#__PURE__*/React.createElement("button", {
    className: "chip" + (f.hasReplies ? " chip--on" : ""),
    onClick: () => set({
      hasReplies: !f.hasReplies
    })
  }, /*#__PURE__*/React.createElement(Chat, {
    size: 13
  }), " Has replies"), /*#__PURE__*/React.createElement("button", {
    className: "chip" + (f.unread ? " chip--on" : ""),
    onClick: () => set({
      unread: !f.unread
    })
  }, /*#__PURE__*/React.createElement("span", {
    className: "udot"
  }), " Unread"), showAdvancedLink && /*#__PURE__*/React.createElement("button", {
    className: "adv-link" + (advancedOpen ? " is-open" : ""),
    onClick: onToggleAdvanced
  }, /*#__PURE__*/React.createElement(Sliders, {
    size: 14
  }), " Advanced search ", /*#__PURE__*/React.createElement(Chevron, {
    size: 13
  })));
}

// ── advanced disclosure / rail body (shared fields) ──────────────────────────
function AdvancedFields({
  f,
  set,
  layout
}) {
  const D = window.SEARCH_DATA;
  const toggleTeret = id => set({
    terets: f.terets.includes(id) ? f.terets.filter(x => x !== id) : [...f.terets, id]
  });
  return /*#__PURE__*/React.createElement("div", {
    className: "adv-grid adv-grid--" + layout
  }, /*#__PURE__*/React.createElement("label", {
    className: "adv-field"
  }, /*#__PURE__*/React.createElement("span", {
    className: "adv-lbl"
  }, "Posted by"), /*#__PURE__*/React.createElement("input", {
    className: "adv-input",
    placeholder: "@username",
    value: f.postedBy,
    onChange: e => set({
      postedBy: e.target.value
    })
  })), /*#__PURE__*/React.createElement("label", {
    className: "adv-field"
  }, /*#__PURE__*/React.createElement("span", {
    className: "adv-lbl"
  }, "Status"), /*#__PURE__*/React.createElement("select", {
    className: "adv-input",
    value: f.status,
    onChange: e => set({
      status: e.target.value
    })
  }, /*#__PURE__*/React.createElement("option", {
    value: "any"
  }, "Any status"), /*#__PURE__*/React.createElement("option", {
    value: "open"
  }, "Open"), /*#__PURE__*/React.createElement("option", {
    value: "closed"
  }, "Closed"), /*#__PURE__*/React.createElement("option", {
    value: "archived"
  }, "Archived"), /*#__PURE__*/React.createElement("option", {
    value: "solved"
  }, "Solved"))), /*#__PURE__*/React.createElement("label", {
    className: "adv-field"
  }, /*#__PURE__*/React.createElement("span", {
    className: "adv-lbl"
  }, "Minimum likes"), /*#__PURE__*/React.createElement("input", {
    className: "adv-input",
    type: "number",
    min: "0",
    value: f.minLikes,
    onChange: e => set({
      minLikes: Number(e.target.value)
    })
  })), /*#__PURE__*/React.createElement("label", {
    className: "adv-field adv-check"
  }, /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: "adv-box" + (f.inTitle ? " is-on" : ""),
    onClick: () => set({
      inTitle: !f.inTitle
    })
  }, f.inTitle && /*#__PURE__*/React.createElement(Check, {
    size: 12
  })), /*#__PURE__*/React.createElement("span", null, "Match in title only")), /*#__PURE__*/React.createElement("div", {
    className: "adv-field adv-field--full"
  }, /*#__PURE__*/React.createElement("span", {
    className: "adv-lbl"
  }, "Terets"), /*#__PURE__*/React.createElement("div", {
    className: "adv-terets"
  }, D.terets.map(t => /*#__PURE__*/React.createElement("button", {
    key: t.id,
    className: "tchip" + (f.terets.includes(t.id) ? " is-on" : ""),
    onClick: () => toggleTeret(t.id)
  }, /*#__PURE__*/React.createElement("span", {
    className: "tchip-sq",
    style: {
      background: t.color
    }
  }), " ", t.name)))));
}

// ── active-filter summary bar ─────────────────────────────────────────────────
function SummaryBar({
  count,
  tokens,
  onRemove,
  onClear,
  scopeLabel
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "sumbar"
  }, /*#__PURE__*/React.createElement("span", {
    className: "sum-count"
  }, /*#__PURE__*/React.createElement("strong", null, count), " ", count === 1 ? "result" : "results", scopeLabel ? " · " + scopeLabel : ""), tokens.length > 0 && /*#__PURE__*/React.createElement("div", {
    className: "sum-tokens"
  }, tokens.map(t => /*#__PURE__*/React.createElement("button", {
    key: t.key,
    className: "token",
    onClick: () => onRemove(t.key)
  }, t.label, " ", /*#__PURE__*/React.createElement(Close, {
    size: 11
  }))), /*#__PURE__*/React.createElement("button", {
    className: "sum-clear",
    onClick: onClear
  }, "Clear all")));
}
Object.assign(window, {
  Dropdown,
  FilterChips,
  AdvancedFields,
  SummaryBar
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "search-filters.jsx", error: String((e && e.message) || e) }); }

// search-icons.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* Fomio search — icon set (Lucide-style strokes; brand-approved fallback) */
const Ic = ({
  d,
  size = 16,
  sw = 1.8,
  fill = "none",
  children,
  vb = "0 0 24 24"
}) => React.createElement("svg", {
  width: size,
  height: size,
  viewBox: vb,
  fill,
  stroke: "currentColor",
  strokeWidth: sw,
  strokeLinecap: "round",
  strokeLinejoin: "round",
  style: {
    display: "block",
    flexShrink: 0
  }
}, d ? React.createElement("path", {
  d
}) : children);
const SearchIcon = p => /*#__PURE__*/React.createElement(Ic, p, /*#__PURE__*/React.createElement("circle", {
  cx: "10.5",
  cy: "10.5",
  r: "6.5"
}), /*#__PURE__*/React.createElement("line", {
  x1: "20",
  y1: "20",
  x2: "15.3",
  y2: "15.3"
}));
const Plus = p => /*#__PURE__*/React.createElement(Ic, p, /*#__PURE__*/React.createElement("line", {
  x1: "12",
  y1: "5",
  x2: "12",
  y2: "19"
}), /*#__PURE__*/React.createElement("line", {
  x1: "5",
  y1: "12",
  x2: "19",
  y2: "12"
}));
const Bell = p => /*#__PURE__*/React.createElement(Ic, p, /*#__PURE__*/React.createElement("path", {
  d: "M6 16V11a6 6 0 1 1 12 0v5l1.5 2h-15L6 16z"
}), /*#__PURE__*/React.createElement("path", {
  d: "M10 20a2 2 0 0 0 4 0"
}));
const Bookmark = p => /*#__PURE__*/React.createElement(Ic, _extends({}, p, {
  d: "M6 3h12v18l-6-4-6 4V3z"
}));
const Home = p => /*#__PURE__*/React.createElement(Ic, _extends({}, p, {
  d: "M3 11l9-8 9 8v10a1 1 0 0 1-1 1h-5v-7h-6v7H4a1 1 0 0 1-1-1V11z"
}));
const Inbox = p => /*#__PURE__*/React.createElement(Ic, p, /*#__PURE__*/React.createElement("path", {
  d: "M22 12h-6l-2 3h-4l-2-3H2"
}), /*#__PURE__*/React.createElement("path", {
  d: "M5 5h14l3 7v6a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1v-6z"
}));
const Users = p => /*#__PURE__*/React.createElement(Ic, p, /*#__PURE__*/React.createElement("path", {
  d: "M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"
}), /*#__PURE__*/React.createElement("circle", {
  cx: "9",
  cy: "7",
  r: "4"
}), /*#__PURE__*/React.createElement("path", {
  d: "M23 21v-2a4 4 0 0 0-3-3.87"
}), /*#__PURE__*/React.createElement("path", {
  d: "M16 3.13a4 4 0 0 1 0 7.75"
}));
const Hash = p => /*#__PURE__*/React.createElement(Ic, p, /*#__PURE__*/React.createElement("line", {
  x1: "4",
  y1: "9",
  x2: "20",
  y2: "9"
}), /*#__PURE__*/React.createElement("line", {
  x1: "4",
  y1: "15",
  x2: "20",
  y2: "15"
}), /*#__PURE__*/React.createElement("line", {
  x1: "10",
  y1: "3",
  x2: "8",
  y2: "21"
}), /*#__PURE__*/React.createElement("line", {
  x1: "16",
  y1: "3",
  x2: "14",
  y2: "21"
}));
const Heart = p => /*#__PURE__*/React.createElement(Ic, _extends({}, p, {
  d: "M12 20s-7-4.5-9-9a5 5 0 0 1 9-3 5 5 0 0 1 9 3c-2 4.5-9 9-9 9z"
}));
const Chat = p => /*#__PURE__*/React.createElement(Ic, _extends({}, p, {
  d: "M12 3a9 9 0 0 1 9 9c0 5-4 9-9 9-1.3 0-2.5-.3-3.6-.8L3 21l1.2-4.5A8.9 8.9 0 0 1 3 12a9 9 0 0 1 9-9z"
}));
const Clock = p => /*#__PURE__*/React.createElement(Ic, p, /*#__PURE__*/React.createElement("circle", {
  cx: "12",
  cy: "12",
  r: "9"
}), /*#__PURE__*/React.createElement("path", {
  d: "M12 7v5l3 2"
}));
const Chevron = p => /*#__PURE__*/React.createElement(Ic, p, /*#__PURE__*/React.createElement("polyline", {
  points: "6 9 12 15 18 9"
}));
const Close = p => /*#__PURE__*/React.createElement(Ic, p, /*#__PURE__*/React.createElement("line", {
  x1: "6",
  y1: "6",
  x2: "18",
  y2: "18"
}), /*#__PURE__*/React.createElement("line", {
  x1: "18",
  y1: "6",
  x2: "6",
  y2: "18"
}));
const Sliders = p => /*#__PURE__*/React.createElement(Ic, p, /*#__PURE__*/React.createElement("line", {
  x1: "4",
  y1: "6",
  x2: "20",
  y2: "6"
}), /*#__PURE__*/React.createElement("circle", {
  cx: "9",
  cy: "6",
  r: "2.4",
  fill: "var(--fomio-card)"
}), /*#__PURE__*/React.createElement("line", {
  x1: "4",
  y1: "14",
  x2: "20",
  y2: "14"
}), /*#__PURE__*/React.createElement("circle", {
  cx: "15",
  cy: "14",
  r: "2.4",
  fill: "var(--fomio-card)"
}));
const Sort = p => /*#__PURE__*/React.createElement(Ic, p, /*#__PURE__*/React.createElement("path", {
  d: "M7 4v16"
}), /*#__PURE__*/React.createElement("path", {
  d: "M4 8l3-4 3 4"
}), /*#__PURE__*/React.createElement("path", {
  d: "M17 20V4"
}), /*#__PURE__*/React.createElement("path", {
  d: "M14 16l3 4 3-4"
}));
const ArrowRet = p => /*#__PURE__*/React.createElement(Ic, p, /*#__PURE__*/React.createElement("polyline", {
  points: "9 10 4 15 9 20"
}), /*#__PURE__*/React.createElement("path", {
  d: "M20 4v7a4 4 0 0 1-4 4H4"
}));
const Star = p => /*#__PURE__*/React.createElement(Ic, _extends({}, p, {
  d: "M12 3l2.6 5.6 6.1.7-4.5 4.1 1.2 6-5.4-3-5.4 3 1.2-6-4.5-4.1 6.1-.7z"
}));
const Eye = p => /*#__PURE__*/React.createElement(Ic, p, /*#__PURE__*/React.createElement("path", {
  d: "M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7-10-7-10-7z"
}), /*#__PURE__*/React.createElement("circle", {
  cx: "12",
  cy: "12",
  r: "3"
}));
const Check = p => /*#__PURE__*/React.createElement(Ic, p, /*#__PURE__*/React.createElement("polyline", {
  points: "20 6 9 17 4 12"
}));
Object.assign(window, {
  Ic,
  SearchIcon,
  Plus,
  Bell,
  Bookmark,
  Home,
  Inbox,
  Users,
  Hash,
  Heart,
  Chat,
  Clock,
  Chevron,
  Close,
  Sliders,
  Sort,
  ArrowRet,
  Star,
  Eye,
  Check
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "search-icons.jsx", error: String((e && e.message) || e) }); }

// search-results.jsx
try { (() => {
/* Fomio search — result rendering: highlight, byte cards, teret/person rows,
   group headers, and the empty / no-result state bodies.
   Exposed on window for the main app island. */

// ── highlight matched terms in primary-soft ──────────────────────────────────
function hl(text, terms) {
  if (!terms || !terms.length) return text;
  const re = new RegExp("(" + terms.map(t => t.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")).join("|") + ")", "ig");
  const parts = String(text).split(re);
  const low = terms.map(t => t.toLowerCase());
  return parts.map((p, i) => low.includes(p.toLowerCase()) ? /*#__PURE__*/React.createElement("mark", {
    key: i,
    className: "hlt"
  }, p) : /*#__PURE__*/React.createElement(React.Fragment, {
    key: i
  }, p));
}

// ── small-caps group header ───────────────────────────────────────────────────
function GroupHead({
  label,
  count,
  action,
  onAction
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "grp-head"
  }, /*#__PURE__*/React.createElement("h2", {
    className: "grp-title"
  }, label, count != null && /*#__PURE__*/React.createElement("span", {
    className: "grp-count"
  }, count)), action && /*#__PURE__*/React.createElement("button", {
    className: "grp-action",
    onClick: onAction
  }, action));
}

// ── avatar ────────────────────────────────────────────────────────────────────
function Avatar({
  name,
  hue,
  size = 36
}) {
  const initials = name.split(" ").map(w => w[0]).slice(0, 2).join("");
  return /*#__PURE__*/React.createElement("span", {
    className: "av",
    style: {
      width: size,
      height: size,
      background: hue,
      fontSize: size * 0.4
    }
  }, initials);
}

// ── byte (post) result card ─────────────────────────────────────────────────
function ByteCard({
  b,
  terms,
  dense,
  bold,
  index
}) {
  return /*#__PURE__*/React.createElement("article", {
    className: "byte" + (b.featured && bold ? " byte--feat" : "") + (dense ? " byte--dense" : "")
  }, bold && index != null && /*#__PURE__*/React.createElement("span", {
    className: "byte-idx"
  }, String(index + 1).padStart(2, "0")), /*#__PURE__*/React.createElement("div", {
    className: "byte-main"
  }, /*#__PURE__*/React.createElement("div", {
    className: "byte-meta"
  }, /*#__PURE__*/React.createElement("span", {
    className: "tag",
    style: bold ? {
      background: b.teretColor,
      color: "#fff"
    } : null
  }, b.teret), /*#__PURE__*/React.createElement("span", {
    className: "byte-author"
  }, b.author), /*#__PURE__*/React.createElement("span", {
    className: "dot"
  }, "\xB7"), /*#__PURE__*/React.createElement("span", null, b.date), b.match === "body" && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("span", {
    className: "dot"
  }, "\xB7"), /*#__PURE__*/React.createElement("span", {
    className: "byte-matchin"
  }, "matched in body"))), /*#__PURE__*/React.createElement("h3", {
    className: "byte-title"
  }, /*#__PURE__*/React.createElement("a", {
    href: "#"
  }, hl(b.title, terms))), !dense && /*#__PURE__*/React.createElement("p", {
    className: "byte-excerpt"
  }, hl(b.excerpt, terms)), /*#__PURE__*/React.createElement("div", {
    className: "byte-foot"
  }, /*#__PURE__*/React.createElement("span", {
    className: "item"
  }, /*#__PURE__*/React.createElement(Heart, {
    size: 14
  }), " ", b.likes), /*#__PURE__*/React.createElement("span", {
    className: "item"
  }, /*#__PURE__*/React.createElement(Chat, {
    size: 14
  }), " ", b.replies, " replies"), /*#__PURE__*/React.createElement("span", {
    className: "item"
  }, /*#__PURE__*/React.createElement(Clock, {
    size: 14
  }), " ", b.read), b.unread && /*#__PURE__*/React.createElement("span", {
    className: "item unread"
  }, /*#__PURE__*/React.createElement("i", {
    className: "udot"
  }), " Unread"))));
}

// ── teret cluster row ─────────────────────────────────────────────────────────
function TeretRow({
  t,
  terms
}) {
  return /*#__PURE__*/React.createElement("a", {
    className: "tr-row",
    href: "#"
  }, /*#__PURE__*/React.createElement("span", {
    className: "tr-sq",
    style: {
      background: t.color
    }
  }), /*#__PURE__*/React.createElement("span", {
    className: "tr-body"
  }, /*#__PURE__*/React.createElement("span", {
    className: "tr-name"
  }, hl(t.name, terms), " ", /*#__PURE__*/React.createElement("span", {
    className: "tr-hub"
  }, "in ", t.hub)), /*#__PURE__*/React.createElement("span", {
    className: "tr-desc"
  }, t.desc)), /*#__PURE__*/React.createElement("span", {
    className: "tr-count"
  }, t.bytes.toLocaleString(), " bytes"));
}

// ── person cluster row ──────────────────────────────────────────────────────
function PersonRow({
  p,
  terms
}) {
  const [following, setFollowing] = React.useState(p.following);
  return /*#__PURE__*/React.createElement("div", {
    className: "pr-row"
  }, /*#__PURE__*/React.createElement(Avatar, {
    name: p.name,
    hue: p.hue,
    size: 40
  }), /*#__PURE__*/React.createElement("span", {
    className: "pr-body"
  }, /*#__PURE__*/React.createElement("span", {
    className: "pr-name"
  }, hl(p.name, terms), " ", /*#__PURE__*/React.createElement("span", {
    className: "pr-handle"
  }, "@", p.handle)), /*#__PURE__*/React.createElement("span", {
    className: "pr-bio"
  }, p.bio)), /*#__PURE__*/React.createElement("button", {
    className: "pr-follow" + (following ? " is-on" : ""),
    onClick: () => setFollowing(!following)
  }, following ? "Following" : "Follow"));
}

// ── recent / saved chips for the empty state ─────────────────────────────────
function RecentChip({
  q,
  onPick
}) {
  return /*#__PURE__*/React.createElement("button", {
    className: "rc-chip",
    onClick: () => onPick(q)
  }, /*#__PURE__*/React.createElement(Clock, {
    size: 13
  }), " ", q);
}

// ── tag chip (categories_tags result type) ───────────────────────────────────
function TagChip({
  tag,
  terms
}) {
  return /*#__PURE__*/React.createElement("a", {
    className: "tag-chip",
    href: "#"
  }, /*#__PURE__*/React.createElement("span", {
    className: "tag-hash"
  }, "#"), /*#__PURE__*/React.createElement("span", {
    className: "tag-name"
  }, hl(tag.name, terms)), /*#__PURE__*/React.createElement("span", {
    className: "tag-count"
  }, tag.bytes.toLocaleString()));
}
Object.assign(window, {
  hl,
  GroupHead,
  Avatar,
  ByteCard,
  TeretRow,
  PersonRow,
  RecentChip,
  TagChip
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "search-results.jsx", error: String((e && e.message) || e) }); }

// search-views.jsx
try { (() => {
/* Fomio search — view components: sidebar, header, search bar, suggestions,
   scope control, empty / no-result / results bodies, keyboard hints. */

// ════════════════════════════ Sidebar ════════════════════════════
function Sidebar() {
  const nav = [{
    icon: /*#__PURE__*/React.createElement(Home, {
      size: 16
    }),
    label: "Latest"
  }, {
    icon: /*#__PURE__*/React.createElement(Users, {
      size: 16
    }),
    label: "Unread"
  }];
  return /*#__PURE__*/React.createElement("aside", {
    className: "sb"
  }, /*#__PURE__*/React.createElement("div", {
    className: "sb-brand"
  }, /*#__PURE__*/React.createElement("span", {
    className: "sb-logo"
  }, /*#__PURE__*/React.createElement("span", {
    className: "ital"
  }, "fomio"), /*#__PURE__*/React.createElement("span", {
    className: "arc"
  }))), /*#__PURE__*/React.createElement("div", {
    className: "sb-scroll"
  }, /*#__PURE__*/React.createElement("button", {
    className: "sb-search is-active",
    type: "button"
  }, /*#__PURE__*/React.createElement(SearchIcon, {
    size: 14
  }), /*#__PURE__*/React.createElement("span", {
    className: "ph"
  }, "Search"), /*#__PURE__*/React.createElement("span", {
    className: "kbd"
  }, "/")), /*#__PURE__*/React.createElement("nav", {
    className: "sb-quick"
  }, /*#__PURE__*/React.createElement("button", {
    className: "sb-row primary"
  }, /*#__PURE__*/React.createElement("span", {
    className: "ic"
  }, /*#__PURE__*/React.createElement(Plus, {
    size: 16
  })), /*#__PURE__*/React.createElement("span", {
    className: "lb"
  }, "New byte")), /*#__PURE__*/React.createElement("button", {
    className: "sb-row"
  }, /*#__PURE__*/React.createElement("span", {
    className: "ic"
  }, /*#__PURE__*/React.createElement(Inbox, {
    size: 16
  })), /*#__PURE__*/React.createElement("span", {
    className: "lb"
  }, "Inbox"), /*#__PURE__*/React.createElement("span", {
    className: "badge"
  }, "3")), /*#__PURE__*/React.createElement("button", {
    className: "sb-row"
  }, /*#__PURE__*/React.createElement("span", {
    className: "ic"
  }, /*#__PURE__*/React.createElement(Bookmark, {
    size: 16
  })), /*#__PURE__*/React.createElement("span", {
    className: "lb"
  }, "Bookmarks"))), /*#__PURE__*/React.createElement("div", {
    className: "sb-section"
  }, /*#__PURE__*/React.createElement("h5", {
    className: "sb-head"
  }, "explore"), /*#__PURE__*/React.createElement("nav", {
    className: "sb-quick"
  }, nav.map(n => /*#__PURE__*/React.createElement("a", {
    key: n.label,
    className: "sb-row"
  }, /*#__PURE__*/React.createElement("span", {
    className: "ic"
  }, n.icon), /*#__PURE__*/React.createElement("span", {
    className: "lb"
  }, n.label))), /*#__PURE__*/React.createElement("a", {
    className: "sb-row"
  }, /*#__PURE__*/React.createElement("span", {
    className: "ic"
  }, /*#__PURE__*/React.createElement(Heart, {
    size: 16
  })), /*#__PURE__*/React.createElement("span", {
    className: "lb"
  }, "Hot")))), /*#__PURE__*/React.createElement("div", {
    className: "sb-section"
  }, /*#__PURE__*/React.createElement("h5", {
    className: "sb-head"
  }, "your terets"), /*#__PURE__*/React.createElement("nav", {
    className: "sb-quick"
  }, window.SEARCH_DATA.terets.slice(0, 4).map(tt => /*#__PURE__*/React.createElement("a", {
    key: tt.id,
    className: "sb-row"
  }, /*#__PURE__*/React.createElement("span", {
    className: "ic"
  }, /*#__PURE__*/React.createElement("span", {
    className: "sq",
    style: {
      background: tt.color
    }
  })), /*#__PURE__*/React.createElement("span", {
    className: "lb"
  }, tt.name)))))), /*#__PURE__*/React.createElement("div", {
    className: "sb-footer"
  }, /*#__PURE__*/React.createElement("span", {
    className: "av",
    style: {
      background: "#C44536"
    }
  }, "IZ"), /*#__PURE__*/React.createElement("span", {
    className: "id"
  }, /*#__PURE__*/React.createElement("span", {
    className: "nm"
  }, "Ismail Z."), /*#__PURE__*/React.createElement("span", {
    className: "hd"
  }, "@ismail")), /*#__PURE__*/React.createElement("button", {
    className: "bell"
  }, /*#__PURE__*/React.createElement(Bell, {
    size: 16
  }), /*#__PURE__*/React.createElement("span", {
    className: "dot"
  }))));
}

// ════════════════════════════ Header ════════════════════════════
function SearchHeader({
  isEmpty,
  query,
  bold
}) {
  if (isEmpty) {
    return /*#__PURE__*/React.createElement("header", {
      className: "hd hd--empty"
    }, /*#__PURE__*/React.createElement("h1", {
      className: "hd-display"
    }, "Search ", /*#__PURE__*/React.createElement("span", {
      className: "hd-mark"
    }, "fomio", /*#__PURE__*/React.createElement("span", {
      className: "hd-arc"
    }))), /*#__PURE__*/React.createElement("p", {
      className: "hd-deck"
    }, "Find bytes, terets, and people across every hub \u2014 chronological, unhurried, and entirely yours."));
  }
  return /*#__PURE__*/React.createElement("header", {
    className: "hd"
  }, /*#__PURE__*/React.createElement("span", {
    className: "hd-eyebrow"
  }, "Search results"), /*#__PURE__*/React.createElement("h1", {
    className: "hd-title"
  }, "for ", /*#__PURE__*/React.createElement("em", null, "\u201C", query, "\u201D")));
}

// ════════════════════════════ Search bar ════════════════════════════
const SCOPES = [{
  id: "bytes",
  label: "Bytes"
}, {
  id: "terets",
  label: "Terets & tags"
}, {
  id: "people",
  label: "People"
}];
function SearchBar({
  query,
  onType,
  onKey,
  inputRef,
  onFocus,
  onCommit,
  onClear,
  typesMode,
  scope,
  setScope,
  showSug,
  sugItems,
  sugIdx,
  setSugIdx,
  commit,
  terms
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "sbar-zone"
  }, /*#__PURE__*/React.createElement("div", {
    className: "sbar" + (showSug ? " is-open" : "")
  }, /*#__PURE__*/React.createElement("span", {
    className: "sbar-ic"
  }, /*#__PURE__*/React.createElement(SearchIcon, {
    size: 20
  })), typesMode === "dropdown" && /*#__PURE__*/React.createElement(ScopeInBar, {
    scope: scope,
    setScope: setScope
  }), /*#__PURE__*/React.createElement("input", {
    ref: inputRef,
    className: "sbar-input",
    value: query,
    placeholder: "Search fomio\u2026",
    onChange: e => onType(e.target.value),
    onKeyDown: onKey,
    onFocus: onFocus,
    "aria-label": "Search query"
  }), query && /*#__PURE__*/React.createElement("button", {
    className: "sbar-clear",
    onClick: onClear,
    "aria-label": "Clear"
  }, /*#__PURE__*/React.createElement(Close, {
    size: 16
  })), /*#__PURE__*/React.createElement("button", {
    className: "sbar-go",
    onClick: onCommit
  }, "Search")), showSug && /*#__PURE__*/React.createElement(Suggestions, {
    items: sugItems,
    idx: sugIdx,
    setIdx: setSugIdx,
    query: query,
    commit: commit,
    setScope: setScope,
    terms: terms
  }));
}
function ScopeInBar({
  scope,
  setScope
}) {
  const [open, setOpen] = React.useState(false);
  const ref = React.useRef(null);
  React.useEffect(() => {
    const off = e => {
      if (ref.current && !ref.current.contains(e.target)) setOpen(false);
    };
    document.addEventListener("mousedown", off);
    return () => document.removeEventListener("mousedown", off);
  }, []);
  const cur = SCOPES.find(s => s.id === scope);
  return /*#__PURE__*/React.createElement("div", {
    className: "scope-inbar",
    ref: ref
  }, /*#__PURE__*/React.createElement("button", {
    className: "scope-inbar-btn",
    onClick: () => setOpen(!open)
  }, "in ", /*#__PURE__*/React.createElement("strong", null, cur.label), " ", /*#__PURE__*/React.createElement(Chevron, {
    size: 13
  })), open && /*#__PURE__*/React.createElement("div", {
    className: "dd-menu"
  }, SCOPES.map(s => /*#__PURE__*/React.createElement("button", {
    key: s.id,
    className: "dd-item" + (s.id === scope ? " is-sel" : ""),
    onClick: () => {
      setScope(s.id);
      setOpen(false);
    }
  }, /*#__PURE__*/React.createElement("span", null, s.label), s.id === scope && /*#__PURE__*/React.createElement(Check, {
    size: 14
  })))));
}
function Suggestions({
  items,
  idx,
  setIdx,
  query,
  commit,
  setScope,
  terms
}) {
  let flat = -1;
  const row = (active, key, onClick, children) => {
    const i = ++flat;
    return /*#__PURE__*/React.createElement("button", {
      key: key,
      className: "sug-row" + (i === idx ? " is-hi" : ""),
      onMouseEnter: () => setIdx(i),
      onMouseDown: e => e.preventDefault(),
      onClick: onClick
    }, children);
  };
  const completions = items.filter(it => it.type === "q");
  const terets = items.filter(it => it.type === "teret");
  const people = items.filter(it => it.type === "person");
  return /*#__PURE__*/React.createElement("div", {
    className: "sug"
  }, /*#__PURE__*/React.createElement("div", {
    className: "sug-sect"
  }, /*#__PURE__*/React.createElement("span", {
    className: "sug-lbl"
  }, "Suggestions"), completions.map(it => row(false, it.value, () => commit(it.value), /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(SearchIcon, {
    size: 15,
    className: "sug-lead"
  }), /*#__PURE__*/React.createElement("span", {
    className: "sug-tx"
  }, hl(it.value, terms)))))), terets.length > 0 && /*#__PURE__*/React.createElement("div", {
    className: "sug-sect"
  }, /*#__PURE__*/React.createElement("span", {
    className: "sug-lbl"
  }, "Terets & tags"), terets.map(it => row(false, it.value.id, () => {
    setScope("terets");
    commit(it.value.name);
  }, /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("span", {
    className: "sq",
    style: {
      background: it.value.color
    }
  }), /*#__PURE__*/React.createElement("span", {
    className: "sug-tx"
  }, hl(it.value.name, terms)), /*#__PURE__*/React.createElement("span", {
    className: "sug-meta"
  }, it.value.bytes.toLocaleString(), " bytes"))))), people.length > 0 && /*#__PURE__*/React.createElement("div", {
    className: "sug-sect"
  }, /*#__PURE__*/React.createElement("span", {
    className: "sug-lbl"
  }, "People"), people.map(it => row(false, it.value.id, () => {
    setScope("people");
    commit(it.value.handle);
  }, /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Avatar, {
    name: it.value.name,
    hue: it.value.hue,
    size: 22
  }), /*#__PURE__*/React.createElement("span", {
    className: "sug-tx"
  }, hl(it.value.name, terms)), /*#__PURE__*/React.createElement("span", {
    className: "sug-meta"
  }, "@", it.value.handle))))), /*#__PURE__*/React.createElement("div", {
    className: "sug-foot"
  }, /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement("kbd", null, "\u2191"), /*#__PURE__*/React.createElement("kbd", null, "\u2193"), " navigate"), /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement("kbd", null, "\u21B5"), " open"), /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement("kbd", null, "esc"), " dismiss")));
}

// ════════════════════════════ Scope segmented ════════════════════════════
function ScopeSegmented({
  scope,
  setScope,
  counts,
  showCounts
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "scope-seg",
    role: "tablist"
  }, SCOPES.map(s => /*#__PURE__*/React.createElement("button", {
    key: s.id,
    role: "tab",
    "aria-selected": s.id === scope,
    className: "scope-tab" + (s.id === scope ? " is-on" : ""),
    onClick: () => setScope(s.id)
  }, s.label, showCounts && /*#__PURE__*/React.createElement("span", {
    className: "scope-n"
  }, counts[s.id]))));
}

// ════════════════════════════ Empty state ════════════════════════════
function EmptyState({
  onPick
}) {
  const D = window.SEARCH_DATA;
  return /*#__PURE__*/React.createElement("div", {
    className: "empty"
  }, /*#__PURE__*/React.createElement("section", {
    className: "empty-sect"
  }, /*#__PURE__*/React.createElement(GroupHead, {
    label: "Recent",
    action: "Clear"
  }), /*#__PURE__*/React.createElement("div", {
    className: "rc-row"
  }, D.recent.map(q => /*#__PURE__*/React.createElement(RecentChip, {
    key: q,
    q: q,
    onPick: onPick
  })))), /*#__PURE__*/React.createElement("section", {
    className: "empty-sect"
  }, /*#__PURE__*/React.createElement(GroupHead, {
    label: "Saved searches"
  }), /*#__PURE__*/React.createElement("div", {
    className: "saved-list"
  }, D.saved.map(s => /*#__PURE__*/React.createElement("button", {
    key: s.q,
    className: "saved-row",
    onClick: () => onPick(s.q)
  }, /*#__PURE__*/React.createElement(Star, {
    size: 16,
    className: "saved-star"
  }), /*#__PURE__*/React.createElement("span", {
    className: "saved-body"
  }, /*#__PURE__*/React.createElement("span", {
    className: "saved-q"
  }, s.q), /*#__PURE__*/React.createElement("span", {
    className: "saved-scope"
  }, s.scope)), /*#__PURE__*/React.createElement("span", {
    className: "saved-count"
  }, s.count))))), /*#__PURE__*/React.createElement("section", {
    className: "empty-sect"
  }, /*#__PURE__*/React.createElement(GroupHead, {
    label: "Browse terets"
  }), /*#__PURE__*/React.createElement("div", {
    className: "browse-grid"
  }, D.terets.map(tt => /*#__PURE__*/React.createElement("button", {
    key: tt.id,
    className: "browse-card",
    onClick: () => onPick(tt.name)
  }, /*#__PURE__*/React.createElement("span", {
    className: "browse-sq",
    style: {
      background: tt.color
    }
  }), /*#__PURE__*/React.createElement("span", {
    className: "browse-name"
  }, tt.name), /*#__PURE__*/React.createElement("span", {
    className: "browse-desc"
  }, tt.desc), /*#__PURE__*/React.createElement("span", {
    className: "browse-count"
  }, tt.bytes.toLocaleString(), " bytes \xB7 ", tt.hub))))));
}

// ════════════════════════════ No results ════════════════════════════
function NoResults({
  query,
  scope,
  setScope,
  counts,
  onClear,
  hasFilters,
  context,
  onClearContext
}) {
  const labels = {
    bytes: "Bytes",
    terets: "Terets & tags",
    people: "People"
  };
  const noun = {
    bytes: "bytes",
    terets: "terets or tags",
    people: "people"
  };
  const others = ["bytes", "terets", "people"].filter(s => s !== scope && counts[s] > 0);
  return /*#__PURE__*/React.createElement("div", {
    className: "nores"
  }, /*#__PURE__*/React.createElement("div", {
    className: "nores-mark"
  }, /*#__PURE__*/React.createElement(SearchIcon, {
    size: 26
  })), /*#__PURE__*/React.createElement("h2", {
    className: "nores-title"
  }, "No ", noun[scope], " match ", /*#__PURE__*/React.createElement("em", null, "\u201C", query, "\u201D")), /*#__PURE__*/React.createElement("p", {
    className: "nores-deck"
  }, "Try a shorter phrase, check the spelling, or widen the time range.", context && " You’re only searching within " + context.name + ".", hasFilters && !context && " Some filters may be hiding results."), /*#__PURE__*/React.createElement("div", {
    className: "nores-actions"
  }, context && /*#__PURE__*/React.createElement("button", {
    className: "btn btn--primary",
    onClick: onClearContext
  }, "Search all of fomio"), !context && hasFilters && /*#__PURE__*/React.createElement("button", {
    className: "btn btn--primary",
    onClick: onClear
  }, "Clear filters"), others.map(s => /*#__PURE__*/React.createElement("button", {
    key: s,
    className: "btn btn--ghost",
    onClick: () => setScope(s)
  }, "Search ", labels[s], " instead ", /*#__PURE__*/React.createElement("span", {
    className: "btn-n"
  }, counts[s])))));
}

// ════════════════════════════ Invalid search (term too short) ════════════════════════════
function InvalidSearch({
  onPick
}) {
  const D = window.SEARCH_DATA;
  return /*#__PURE__*/React.createElement("div", {
    className: "nores"
  }, /*#__PURE__*/React.createElement("div", {
    className: "nores-mark"
  }, /*#__PURE__*/React.createElement(SearchIcon, {
    size: 26
  })), /*#__PURE__*/React.createElement("h2", {
    className: "nores-title"
  }, "Your search was too short"), /*#__PURE__*/React.createElement("p", {
    className: "nores-deck"
  }, "Search terms need at least three characters. Try a fuller word or phrase \u2014 or pick up a recent search."), /*#__PURE__*/React.createElement("div", {
    className: "nores-recent"
  }, D.recent.map(q => /*#__PURE__*/React.createElement(RecentChip, {
    key: q,
    q: q,
    onPick: onPick
  }))));
}

// ════════════════════════════ Context scope banner ════════════════════════════
function ContextBar({
  name,
  color,
  onClear
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "ctx-bar"
  }, /*#__PURE__*/React.createElement("span", {
    className: "ctx-sq",
    style: {
      background: color
    }
  }), /*#__PURE__*/React.createElement("span", {
    className: "ctx-tx"
  }, "Searching within ", /*#__PURE__*/React.createElement("strong", null, name)), /*#__PURE__*/React.createElement("button", {
    className: "ctx-clear",
    onClick: onClear
  }, "Search all of fomio"));
}

// ════════════════════════════ Results ════════════════════════════
function Results({
  scope,
  setScope,
  terms,
  dense,
  bold,
  bytes,
  terets,
  people,
  tags,
  context,
  tokens,
  removeToken,
  clearAll,
  count
}) {
  const scopeLabel = scope === "bytes" ? "Bytes" : scope === "terets" ? "Terets & tags" : "People";
  return /*#__PURE__*/React.createElement("div", {
    className: "results"
  }, /*#__PURE__*/React.createElement(SummaryBar, {
    count: count,
    tokens: tokens,
    onRemove: removeToken,
    onClear: clearAll,
    scopeLabel: scopeLabel
  }), scope === "bytes" && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    className: "grp"
  }, /*#__PURE__*/React.createElement("div", {
    className: "byte-list"
  }, bytes.map((b, i) => /*#__PURE__*/React.createElement(ByteCard, {
    key: b.id,
    b: b,
    terms: terms,
    dense: dense,
    bold: bold,
    index: i
  })))), !context && (terets.length > 0 || people.length > 0) && /*#__PURE__*/React.createElement("div", {
    className: "grp-rule"
  }), !context && people.length > 0 && /*#__PURE__*/React.createElement("div", {
    className: "grp grp--sec"
  }, /*#__PURE__*/React.createElement(GroupHead, {
    label: "People",
    count: people.length,
    action: "See all",
    onAction: () => setScope("people")
  }), /*#__PURE__*/React.createElement("div", {
    className: "pr-list"
  }, people.slice(0, 2).map(p => /*#__PURE__*/React.createElement(PersonRow, {
    key: p.id,
    p: p,
    terms: terms
  })))), !context && terets.length > 0 && /*#__PURE__*/React.createElement("div", {
    className: "grp grp--sec"
  }, /*#__PURE__*/React.createElement(GroupHead, {
    label: "Terets & tags",
    count: terets.length,
    action: "See all",
    onAction: () => setScope("terets")
  }), /*#__PURE__*/React.createElement("div", {
    className: "tr-list"
  }, terets.slice(0, 3).map(tt => /*#__PURE__*/React.createElement(TeretRow, {
    key: tt.id,
    t: tt,
    terms: terms
  }))))), scope === "terets" && /*#__PURE__*/React.createElement("div", {
    className: "grp"
  }, tags.length > 0 && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(GroupHead, {
    label: "Tags",
    count: tags.length
  }), /*#__PURE__*/React.createElement("div", {
    className: "tag-cloud"
  }, tags.map(tg => /*#__PURE__*/React.createElement(TagChip, {
    key: tg.name,
    tag: tg,
    terms: terms
  }))), /*#__PURE__*/React.createElement("div", {
    className: "grp-rule"
  })), /*#__PURE__*/React.createElement(GroupHead, {
    label: tags.length > 0 ? "Terets" : "Terets & tags",
    count: terets.length
  }), /*#__PURE__*/React.createElement("div", {
    className: "tr-list"
  }, terets.map(tt => /*#__PURE__*/React.createElement(TeretRow, {
    key: tt.id,
    t: tt,
    terms: terms
  })))), scope === "people" && /*#__PURE__*/React.createElement("div", {
    className: "grp"
  }, /*#__PURE__*/React.createElement("div", {
    className: "pr-list"
  }, people.map(p => /*#__PURE__*/React.createElement(PersonRow, {
    key: p.id,
    p: p,
    terms: terms
  })))));
}

// ════════════════════════════ Keyboard hints ════════════════════════════
function KbdHints() {
  return /*#__PURE__*/React.createElement("div", {
    className: "kbd-bar"
  }, /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement("kbd", null, "/"), " focus search"), /*#__PURE__*/React.createElement("span", {
    className: "kbd-sep"
  }, "\xB7"), /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement("kbd", null, "\u2191"), /*#__PURE__*/React.createElement("kbd", null, "\u2193"), " navigate"), /*#__PURE__*/React.createElement("span", {
    className: "kbd-sep"
  }, "\xB7"), /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement("kbd", null, "\u21B5"), " open"), /*#__PURE__*/React.createElement("span", {
    className: "kbd-sep"
  }, "\xB7"), /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement("kbd", null, "esc"), " clear"));
}
Object.assign(window, {
  Sidebar,
  SearchHeader,
  SearchBar,
  ScopeInBar,
  Suggestions,
  ScopeSegmented,
  EmptyState,
  NoResults,
  InvalidSearch,
  ContextBar,
  Results,
  KbdHints
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "search-views.jsx", error: String((e && e.message) || e) }); }

// topics-app.jsx
try { (() => {
/* topics-app.jsx — responsive shell + navigation/state orchestration.
 * Exports: FomioTopicsApp.
 */
const {
  useState,
  useEffect,
  useRef,
  useCallback,
  useMemo
} = React;
const {
  TopicsSidebar,
  BottomTabBar,
  TouchHeader,
  TopicsFilterBar,
  TopicsFeed,
  FeedSkeleton,
  FeedEmpty,
  FeedError,
  HubGate,
  TopicReader,
  ArchDrawer,
  ArchButton,
  TIc,
  FomioMark
} = window;
function useSurfaceMode(forced) {
  const [mode, setMode] = useState('expanded');
  useEffect(() => {
    if (forced && forced !== 'auto') {
      setMode(forced);
      return;
    }
    const update = () => {
      const w = window.innerWidth;
      if (w >= 1280) setMode('expanded');else if (w >= 1024) setMode('compact-desktop');else if (w >= 768) setMode('rail');else setMode('touch');
    };
    update();
    window.addEventListener('resize', update);
    return () => window.removeEventListener('resize', update);
  }, [forced]);
  return mode;
}
const TAB_TITLES = {
  home: 'Home',
  search: 'Search',
  notifications: 'Notifications',
  write: 'Write',
  bookmarks: 'Bookmarks',
  messages: 'Messages',
  profile: 'Profile'
};
function Placeholder({
  tab
}) {
  const title = TAB_TITLES[tab] || 'Section';
  return /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'center',
      padding: '72px 24px',
      maxWidth: 420,
      margin: '0 auto'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 56,
      height: 56,
      borderRadius: 16,
      background: 'var(--fomio-surface)',
      border: '1px solid var(--fomio-border)',
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      marginBottom: 18
    }
  }, /*#__PURE__*/React.createElement(TIc, {
    name: tab === 'notifications' ? 'bell' : tab === 'search' ? 'search' : 'layers',
    size: 26,
    color: "var(--fomio-fg-muted)",
    stroke: 1.6
  })), /*#__PURE__*/React.createElement("h3", {
    style: {
      margin: '0 0 8px',
      fontFamily: 'var(--fomio-serif)',
      fontWeight: 700,
      fontSize: 24,
      letterSpacing: '-0.02em',
      color: 'var(--fomio-fg)'
    }
  }, title), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontFamily: 'var(--fomio-serif)',
      fontSize: 15,
      lineHeight: 1.6,
      color: 'var(--fomio-fg-muted)'
    }
  }, "Stubbed in this prototype \u2014 Topics is the focus of this build."));
}

/* sort/derive the visible topic set from filter + hub */
function selectTopics(all, filter, hub) {
  let list = all.slice();
  if (hub) list = list.filter(t => t.hub === hub);
  if (filter === 'top') list.sort((a, b) => b.likeCount - a.likeCount);else if (filter === 'new') list = list.filter(t => t.unseen || t.newPosts > 0);else if (filter === 'unread') list = list.filter(t => t.unread > 0);else list.sort((a, b) => b.pinned - a.pinned || new Date(b.bumpedAt) - new Date(a.bumpedAt));
  // keep pinned first for latest
  if (filter === 'latest' || filter === 'top') list.sort((a, b) => b.pinned === a.pinned ? 0 : b.pinned ? 1 : -1);
  return list;
}
function FomioTopicsApp({
  tweaks
}) {
  const data = window.TOPICS_DATA;
  const mode = useSurfaceMode(tweaks.surfaceMode || 'auto');
  const isDark = !!tweaks.darkMode;
  const layout = tweaks.feedLayout || 'ledger';
  const feedState = tweaks.feedState || 'populated';
  const loggedOut = (tweaks.auth || 'in') === 'out';
  const isModerator = (tweaks.role || 'member') === 'moderator';
  const [tab, setTab] = useState('topics');
  const [activeHub, setActiveHub] = useState(null);
  const [openView, setOpenView] = useState(null); // topic reading view
  const [filter, setFilter] = useState('latest');
  const [railManual, setRailManual] = useState(false);
  const [chromeHidden, setChromeHidden] = useState(false);
  const [archOpen, setArchOpen] = useState(false);
  const lastScroll = useRef(0);
  useEffect(() => {
    document.documentElement.setAttribute('data-theme', isDark ? 'dark' : 'light');
  }, [isDark]);

  // Deep-link tweak: jump straight to the reading view
  useEffect(() => {
    if (tweaks.screen === 'reading') {
      setOpenView(data.topicView);
      setTab('topics');
    } else setOpenView(null);
  }, [tweaks.screen]);
  const gatedUnread = loggedOut;
  const showGate = (filter === 'unread' || filter === 'new') && loggedOut;
  const onNav = useCallback(key => {
    setOpenView(null);
    if (key.indexOf('hub:') === 0) {
      setActiveHub(key.split(':')[1]);
      setTab('topics');
      return;
    }
    setActiveHub(null);
    setTab(key);
  }, []);
  const onOpenTopic = useCallback(() => {
    setOpenView(data.topicView);
    window.scrollTo(0, 0);
  }, [data]);
  const onOpenSuggested = useCallback(() => {
    setOpenView(data.topicView);
    window.scrollTo(0, 0);
  }, [data]);
  const onBrowseHub = useCallback(h => {
    setActiveHub(h.key);
  }, []);
  const onScroll = useCallback(e => {
    const y = e.target.scrollTop;
    const dy = y - lastScroll.current;
    if (Math.abs(dy) > 6) {
      setChromeHidden(dy > 0 && y > 40);
      lastScroll.current = y;
    }
  }, []);
  const isTouch = mode === 'touch';
  const rail = !isTouch && (mode === 'rail' || railManual);
  const canToggleRail = mode === 'compact-desktop' || mode === 'expanded';
  const hubObj = activeHub ? data.hubs.find(h => h.key === activeHub) : null;
  const visible = useMemo(() => selectTopics(data.topics, filter, activeHub), [data, filter, activeHub]);

  // ── Body ──
  let body;
  if (openView) {
    body = /*#__PURE__*/React.createElement(TopicReader, {
      view: openView,
      hubs: data.hubs,
      onBack: () => setOpenView(null),
      onOpenSuggested: onOpenSuggested,
      isModerator: isModerator,
      loggedOut: loggedOut,
      mode: mode
    });
  } else if (tab !== 'topics') {
    body = /*#__PURE__*/React.createElement(Placeholder, {
      tab: tab
    });
  } else {
    const header = !isTouch && /*#__PURE__*/React.createElement("div", {
      style: {
        marginBottom: 20
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'baseline',
        gap: 12,
        flexWrap: 'wrap'
      }
    }, /*#__PURE__*/React.createElement("h1", {
      style: {
        margin: 0,
        fontFamily: 'var(--fomio-serif)',
        fontWeight: 700,
        fontSize: mode === 'expanded' ? 30 : 26,
        letterSpacing: '-0.025em',
        color: 'var(--fomio-fg)'
      }
    }, hubObj ? hubObj.label : 'Topics'), /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--fomio-sans)',
        fontSize: 12,
        fontWeight: 600,
        letterSpacing: '0.04em',
        textTransform: 'uppercase',
        color: 'var(--fomio-fg-muted)'
      }
    }, hubObj ? `${hubObj.topics} threads` : 'Every hub · chronological')), hubObj && /*#__PURE__*/React.createElement("p", {
      style: {
        margin: '8px 0 0',
        fontFamily: 'var(--fomio-serif)',
        fontSize: 15,
        lineHeight: 1.55,
        color: 'var(--fomio-fg-muted)',
        maxWidth: 560
      }
    }, hubObj.description));
    const chips = /*#__PURE__*/React.createElement("div", {
      style: {
        marginBottom: 22,
        position: 'sticky',
        top: 0,
        zIndex: 5,
        paddingTop: isTouch ? 4 : 0,
        background: isTouch ? 'transparent' : 'var(--fomio-bg)'
      }
    }, /*#__PURE__*/React.createElement(TopicsFilterBar, {
      filter: filter,
      setFilter: setFilter,
      hub: activeHub,
      hubs: data.hubs,
      onPickHub: setActiveHub,
      gatedUnread: gatedUnread,
      onMarkRead: () => {}
    }));
    let feed;
    if (showGate) feed = /*#__PURE__*/React.createElement(HubGate, {
      onLogin: () => {}
    });else if (feedState === 'loading') feed = /*#__PURE__*/React.createElement(FeedSkeleton, null);else if (feedState === 'error') feed = /*#__PURE__*/React.createElement(FeedError, {
      onRetry: () => {}
    });else if (feedState === 'empty' || visible.length === 0) feed = /*#__PURE__*/React.createElement(FeedEmpty, {
      onCompose: () => setTab('write'),
      hubLabel: hubObj ? hubObj.label : null
    });else feed = /*#__PURE__*/React.createElement(TopicsFeed, {
      layout: layout,
      topics: visible,
      hubs: data.hubs,
      onOpen: onOpenTopic,
      onBrowseHub: onBrowseHub,
      mode: mode
    });
    body = /*#__PURE__*/React.createElement(React.Fragment, null, header, chips, feed);
  }
  const maxW = openView ? 1040 : layout === 'digest' ? 1000 : 860;
  const pad = mode === 'expanded' ? '40px 56px' : mode === 'compact-desktop' ? '36px 40px' : '28px 28px';
  if (isTouch) {
    return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
      style: {
        position: 'fixed',
        inset: 0,
        background: 'var(--fomio-bg)',
        display: 'flex',
        flexDirection: 'column'
      }
    }, /*#__PURE__*/React.createElement(TouchHeader, {
      subtitle: openView ? null : hubObj ? hubObj.label : 'Topics · chronological',
      hidden: chromeHidden && !openView
    }), /*#__PURE__*/React.createElement("main", {
      onScroll: onScroll,
      style: {
        flex: 1,
        overflowY: 'auto',
        padding: '18px 20px 110px',
        WebkitOverflowScrolling: 'touch'
      }
    }, body), /*#__PURE__*/React.createElement(BottomTabBar, {
      tab: openView ? 'topics' : tab,
      onNav: onNav,
      user: data.user,
      hidden: chromeHidden && !openView,
      loggedOut: loggedOut
    })), /*#__PURE__*/React.createElement(ArchButton, {
      onClick: () => setArchOpen(true)
    }), /*#__PURE__*/React.createElement(ArchDrawer, {
      open: archOpen,
      onClose: () => setArchOpen(false)
    }));
  }
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      minHeight: '100vh',
      background: 'var(--fomio-bg)'
    }
  }, /*#__PURE__*/React.createElement(TopicsSidebar, {
    data: data,
    rail: rail,
    tab: openView ? 'topics' : tab,
    activeHub: activeHub,
    onNav: onNav,
    onToggleRail: () => setRailManual(v => !v),
    loggedOut: loggedOut,
    canToggle: canToggleRail
  }), /*#__PURE__*/React.createElement("main", {
    style: {
      flex: 1,
      minWidth: 0,
      padding: pad,
      boxSizing: 'border-box'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: maxW,
      margin: '0 auto'
    }
  }, body))), /*#__PURE__*/React.createElement(ArchButton, {
    onClick: () => setArchOpen(true)
  }), /*#__PURE__*/React.createElement(ArchDrawer, {
    open: archOpen,
    onClose: () => setArchOpen(false)
  }));
}
window.FomioTopicsApp = FomioTopicsApp;
})(); } catch (e) { __ds_ns.__errors.push({ path: "topics-app.jsx", error: String((e && e.message) || e) }); }

// topics-arch.jsx
try { (() => {
/* topics-arch.jsx — the companion architecture doc, delivered as an in-app
 * drawer. Four sections mirror the brief: Editorial Layouts, Component Tree,
 * State & Performance, Micro-Interactions. Exports: ArchDrawer, ArchButton.
 */
const {
  TIc
} = window;
const LAYOUTS = [['Ledger', 'list', 'A hairline typographic register — no cards. Read-pip gutter, serif title + Hub/tags/author meta, and a right rail where the reply count is the dominant serif number. The pinned topic reads as a weighted lead with a terracotta rule and its excerpt exposed.', 'Desktop / rail: three columns of weight — pip · title-block · [posters · count · time]. Rail keeps the count, drops views. Mobile: right rail collapses beneath the title into one meta line (posters · replies · time); the pip stays in the gutter so scanning survives the reflow.'], ['Digest', 'columns', 'Topics grouped under their Hub as magazine sections, each with a 2px rule heading and a "Browse" affordance. Reading-forward: excerpt exposed, participants small. The natural home for Categories browsing.', 'Desktop: sections flow two-up via CSS columns (break-inside avoided). Rail: single column. Mobile: same single column, Hub headings become sticky section anchors.'], ['Threads', 'activity', 'Conversation-first. The latest reply is a pull-quote against a left rule; the title is the quieter context line above. Sorted by recent activity — the natural view for Top / Hot.', 'Desktop: last-poster avatar (44) with a reply glyph, quote block, then participants · replies · likes · time. Mobile: avatar shrinks to 36, likes drop from the footer, quote clamps to 3 lines.']];
const TREE = [['<TopicsScreen>', 0, 'SafeAreaView · useWindowDimensions → surface mode'], ['<NavigationShell>', 1, 'switches Sidebar ⇆ BottomTabBar at 768px'], ['<TopicsSidebar> (≥768)', 2, 'Animated.View, width 72⇄256 spring'], ['<BrandMark/> + <RailToggle/>', 3, ''], ['<NavSection primary>', 3, 'Home · Topics · Search · Alerts · Write'], ['<HubList> categories.json', 3, 'swatch + unread pip / topic count'], ['<FloatingProfile>', 3, 'elevated, presence dot · session/current.json'], ['<BottomTabBar> (<768)', 2, 'BlurView · Reanimated translateY on scroll'], ['<TopicsScreenContainer>', 1, 'owns filter + hub + read-state, preload hook'], ['<TopicsFilterBar>', 2, 'Latest · New · Unread(gated) · Top · Categories▾'], ['<HubMenu>', 3, 'category picker, portal + outside-press close'], ['<TopicsFeed variant>', 2, 'Ledger | Digest | Threads · FlashList'], ['<TopicRow> / <DigestSection> / <ThreadItem>', 3, 'press → navigate("Topic")'], ['<ReadPip> <PosterStack> <HubBadge> <BigCount>', 4, 'atoms bound to serializer fields'], ['<FeedStates>', 2, 'Skeleton · Empty · Error · HubGate'], ['<TopicReader> GET /t/:id', 1, 'TopicViewSerializer'], ['<TopicHeader>', 2, 'fancy_title · tags · counts · Summarize'], ['<ModerationBar>', 2, 'rendered when details.can_close etc.'], ['<PostStream>', 2, 'FlashList of <Post>, reply-to context, gap marker'], ['<Post long>', 3, 'clamp → expand/collapse, focus preserved'], ['<ParticipantRail>', 2, 'notification level · participants · suggested'], ['<ReplyDock>', 2, 'composer · closed note · logged-out gate']];
const STATE = [['Preloaded initial data', 'The screen mounts against server-embedded /latest.json (the same payload the web shell hydrates from), so the first paint is real topics, never a spinner. React Query keeps that as initialData; background refetch is silent and diffed in.'], ['Skeleton, not spinner', 'Because the row geometry is known, loading renders a shimmer skeleton that matches the Ledger metrics exactly — same gutter, title height, and rail widths. Swapping skeleton → data causes zero layout shift; the eye stays on one anchor.'], ['Read-state as source of truth', 'unread, new_posts, notification_level and bookmarked drive every pip, badge and sort. They live in one normalized store keyed by topic id; MessageBus pushes (message_bus_last_id cursor) patch that store, so a new reply updates the count in place without refetching the list.'], ['No layout shift on filter change', 'Filter and Hub are URL/route params, not remounts. Switching Latest→Top cross-fades the same FlashList in place (opacity only) while the data reorders underneath — the scroll container never changes height mid-transition.'], ['Windowed lists', 'FlashList virtualizes both the feed and the post stream. The reader jumps to last_read_post_number via the stream[] index array (a 40-post gap marker instead of mounting 40 rows), so opening a 400-reply topic is O(visible), not O(n).'], ['Errors are textual & non-destructive', 'A failed /latest.json keeps the last good list behind an inline, textual error with a Retry — your place is never cleared. Optimistic reply/like writes roll back with a toast on failure.']];
const MICRO = [['Rail ⇆ full', 'Sidebar width springs 72→256 (cubic-bezier 0.22,0.61,0.36,1, ~220ms). Hub swatches hold their x-position so the eye tracks one anchor; labels and counts cross-fade in 60ms later. The active item keeps its 3px terracotta marker through the whole transition.'], ['Filter chips', 'Active chip fills terracotta; the switch cross-fades the list (FadeIn.delay(i*40)). Unread while logged out shows a lock and routes to the permission notice instead of an empty list. Categories▾ opens a portal menu that closes on outside-press.'], ['Read-pip settle', 'Marking read does not pop the row out — the terracotta dot fades to nothing over 200ms in place, so a long "mark all read" reads as a calm wave down the column rather than a reshuffle.'], ['Tab bar on scroll', 'Scroll down → the glass bar translates +140% off-screen (300ms); scroll up or settle → it springs back. The touch header mirrors it upward. Reading gets full height; chrome returns the instant you reach for it.'], ['Floating profile', 'Rests on a soft shadow, not a flat row. Press lifts it 2px and deepens the shadow; the green presence dot is the only always-on color besides the brand arc. Long-press → quick account switch.'], ['Reader entrance', 'Opening a topic slides the reader in from the right (24px, 260ms) while the feed dims 8% underneath — teaching the spatial push/pop. Back reverses it. The OP "Continue reading" expands in place and keeps focus on the button.'], ['Reduced motion', 'prefers-reduced-motion swaps every spring/translate/cross-fade for an instant state change. Nothing decorative survives — motion only ever confirmed a cause.']];
function Pill({
  items,
  active,
  onPick
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 0,
      padding: '12px 22px 0',
      borderBottom: '1px solid var(--fomio-border)'
    }
  }, items.map(([k, l, ic]) => /*#__PURE__*/React.createElement("button", {
    key: k,
    onClick: () => onPick(k),
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6,
      height: 38,
      padding: '0 13px',
      background: 'transparent',
      border: 'none',
      borderBottom: active === k ? '2px solid var(--fomio-primary)' : '2px solid transparent',
      marginBottom: -1,
      cursor: 'pointer',
      fontFamily: 'var(--fomio-sans)',
      fontSize: 12.5,
      fontWeight: active === k ? 700 : 500,
      color: active === k ? 'var(--fomio-primary)' : 'var(--fomio-fg-muted)'
    }
  }, /*#__PURE__*/React.createElement(TIc, {
    name: ic,
    size: 15,
    color: "currentColor",
    stroke: 1.8
  }), " ", l)));
}
function ArchDrawer({
  open,
  onClose
}) {
  const [view, setView] = React.useState('layouts');
  if (!open) return null;
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    onClick: onClose,
    style: {
      position: 'fixed',
      inset: 0,
      zIndex: 200,
      background: 'rgba(20,14,10,0.32)',
      backdropFilter: 'blur(2px)'
    }
  }), /*#__PURE__*/React.createElement("aside", {
    style: {
      position: 'fixed',
      top: 0,
      right: 0,
      bottom: 0,
      width: 'min(500px, 94vw)',
      zIndex: 201,
      background: 'var(--fomio-bg)',
      borderLeft: '1px solid var(--fomio-border)',
      boxShadow: '-24px 0 80px -36px rgba(0,0,0,0.4)',
      display: 'flex',
      flexDirection: 'column'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12,
      padding: '20px 22px 16px',
      borderBottom: '1px solid var(--fomio-border)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--fomio-serif)',
      fontWeight: 700,
      fontSize: 19,
      fontStyle: 'italic',
      letterSpacing: '-0.02em',
      color: 'var(--fomio-fg)'
    }
  }, "Topics architecture"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--fomio-sans)',
      fontSize: 11.5,
      color: 'var(--fomio-fg-muted)',
      marginTop: 2
    }
  }, "Expo (React Native) \xB7 headless Discourse")), /*#__PURE__*/React.createElement("button", {
    onClick: onClose,
    style: {
      width: 32,
      height: 32,
      borderRadius: 9,
      border: 'none',
      cursor: 'pointer',
      background: 'var(--fomio-surface)',
      color: 'var(--fomio-fg-muted)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center'
    }
  }, /*#__PURE__*/React.createElement(TIc, {
    name: "x",
    size: 16,
    color: "currentColor",
    stroke: 2
  }))), /*#__PURE__*/React.createElement(Pill, {
    active: view,
    onPick: setView,
    items: [['layouts', 'Layouts', 'columns'], ['tree', 'Component tree', 'code'], ['state', 'State & perf', 'activity'], ['micro', 'Micro-interactions', 'sparkle']]
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      overflowY: 'auto',
      padding: '22px'
    }
  }, view === 'layouts' && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 24
    }
  }, LAYOUTS.map(([name, ic, what, resp], i) => /*#__PURE__*/React.createElement("div", {
    key: i
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 9,
      marginBottom: 8
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 28,
      height: 28,
      borderRadius: 8,
      background: 'var(--fomio-surface)',
      border: '1px solid var(--fomio-border)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center'
    }
  }, /*#__PURE__*/React.createElement(TIc, {
    name: ic,
    size: 15,
    color: "var(--fomio-primary)",
    stroke: 1.9
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--fomio-serif)',
      fontWeight: 700,
      fontSize: 17,
      letterSpacing: '-0.01em',
      color: 'var(--fomio-fg)'
    }
  }, name)), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '0 0 8px',
      fontFamily: 'var(--fomio-serif)',
      fontSize: 14,
      lineHeight: 1.6,
      color: 'var(--fomio-fg-secondary)'
    }
  }, what), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      paddingLeft: 12,
      borderLeft: '2px solid var(--fomio-border)',
      fontFamily: 'var(--fomio-sans)',
      fontSize: 12.5,
      lineHeight: 1.55,
      color: 'var(--fomio-fg-muted)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 700,
      color: 'var(--fomio-fg-secondary)'
    }
  }, "Responsive \xB7 "), resp)))), view === 'tree' && /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--fomio-mono)',
      fontSize: 12,
      lineHeight: 1.5
    }
  }, TREE.map(([name, depth, note], i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      padding: '5px 0',
      paddingLeft: depth * 15,
      borderLeft: depth > 0 ? '1px solid var(--fomio-border)' : 'none',
      marginLeft: depth > 0 ? 4 : 0
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 700,
      color: /Floating|Moderation|ReplyDock|BottomTabBar|BlurView/.test(name) ? 'var(--fomio-primary-dark)' : 'var(--fomio-fg)'
    }
  }, name), note && /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'block',
      fontFamily: 'var(--fomio-sans)',
      fontSize: 11.5,
      color: 'var(--fomio-fg-muted)',
      marginTop: 2
    }
  }, note)))), view === 'state' && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 18
    }
  }, STATE.map(([t, b], i) => /*#__PURE__*/React.createElement(Note, {
    key: i,
    title: t,
    body: b
  }))), view === 'micro' && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 18
    }
  }, MICRO.map(([t, b], i) => /*#__PURE__*/React.createElement(Note, {
    key: i,
    title: t,
    body: b
  }))))));
}
function Note({
  title,
  body
}) {
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      marginBottom: 5
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 6,
      height: 6,
      borderRadius: '50%',
      background: 'var(--fomio-primary)'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--fomio-sans)',
      fontWeight: 700,
      fontSize: 13.5,
      color: 'var(--fomio-fg)'
    }
  }, title)), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      paddingLeft: 14,
      fontFamily: 'var(--fomio-serif)',
      fontSize: 14,
      lineHeight: 1.6,
      color: 'var(--fomio-fg-muted)'
    }
  }, body));
}
function ArchButton({
  onClick
}) {
  return /*#__PURE__*/React.createElement("button", {
    onClick: onClick,
    className: "ft-notesbtn",
    style: {
      position: 'fixed',
      top: 16,
      right: 16,
      zIndex: 150,
      height: 36,
      padding: '0 14px',
      borderRadius: 9999,
      cursor: 'pointer',
      background: 'color-mix(in srgb, var(--fomio-card) 82%, transparent)',
      backdropFilter: 'blur(12px)',
      WebkitBackdropFilter: 'blur(12px)',
      border: '1px solid var(--fomio-border)',
      boxShadow: '0 6px 18px -8px var(--fomio-shadow)',
      display: 'inline-flex',
      alignItems: 'center',
      gap: 7,
      fontFamily: 'var(--fomio-sans)',
      fontSize: 12.5,
      fontWeight: 700,
      color: 'var(--fomio-fg)'
    }
  }, /*#__PURE__*/React.createElement(TIc, {
    name: "code",
    size: 15,
    color: "var(--fomio-primary)",
    stroke: 2
  }), " Architecture");
}
Object.assign(window, {
  ArchDrawer,
  ArchButton
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "topics-arch.jsx", error: String((e && e.message) || e) }); }

// topics-data.js
try { (() => {
/* topics-data.js — Fomio Topics screen data
 * Maps the headless Discourse contracts (docs/03-serializers.md) onto Fomio nouns:
 *   Topic  → a Byte thread (a discussion)      · ListableTopicSerializer
 *   Category → a Hub                            · category_id / hub
 *   Tags   → free tags on a thread             · tags[]
 *   posters[] → participant stack (OP + latest)· ListableTopicSerializer.posters
 *   read state → unread / new_posts / notification_level / bookmarked
 *   GET /t/:id → TopicViewSerializer            · topicView below
 * No invented chroma: avatar + hub swatches are desaturated earth tones only;
 * the single saturated accent is the terracotta brand red.
 */
(function () {
  // ── Participants (SiteUser-ish) ──────────────────────────────
  const U = {
    jun: {
      username: 'jun',
      name: 'Jun Nakamura',
      initials: 'JN',
      avatarBg: '#C9D6C2',
      avatarFg: '#3E5C3E'
    },
    lena: {
      username: 'lena',
      name: 'Lena Marsh',
      initials: 'LM',
      avatarBg: '#D6C9A8',
      avatarFg: '#5C4A1E'
    },
    ada: {
      username: 'ada',
      name: 'Ada Reyes',
      initials: 'AR',
      avatarBg: '#D6BFC9',
      avatarFg: '#5C3E4D'
    },
    priya: {
      username: 'priya',
      name: 'Priya Hart',
      initials: 'PH',
      avatarBg: '#BFCAD6',
      avatarFg: '#3E4A5C'
    },
    theo: {
      username: 'theo',
      name: 'Theo Mendez',
      initials: 'TM',
      avatarBg: '#D6C2C2',
      avatarFg: '#5C3E3E'
    },
    sofia: {
      username: 'sofia',
      name: 'Sofia Okonkwo',
      initials: 'SO',
      avatarBg: '#C7C9D6',
      avatarFg: '#3E3E5C'
    },
    omar: {
      username: 'omar',
      name: 'Omar Haddad',
      initials: 'OH',
      avatarBg: '#CBD3C6',
      avatarFg: '#42553B',
      mod: true
    },
    mira: {
      username: 'mira',
      name: 'Mira Vance',
      initials: 'MV',
      avatarBg: '#D9CBBB',
      avatarFg: '#5A4633'
    },
    kaz: {
      username: 'kaz',
      name: 'Kaz Ito',
      initials: 'KI',
      avatarBg: '#C2CDD0',
      avatarFg: '#3B4C50'
    }
  };
  const poster = (u, extras, description) => ({
    user: u,
    extras,
    description
  });
  window.TOPICS_DATA = {
    site: {
      name: 'fomio',
      tagline: 'A quiet place to read and write'
    },
    user: {
      name: 'Ismail Z.',
      username: 'ismail',
      initials: 'IZ',
      avatarBg: '#D6C9A8',
      avatarFg: '#5C4A1E',
      unreadNotifs: 3,
      unreadMsgs: 1,
      isModerator: false
    },
    /* /sidebar_sections.json — primary nav (Fomio nouns) */
    navPrimary: [{
      key: 'home',
      label: 'Home',
      icon: 'home'
    }, {
      key: 'topics',
      label: 'Topics',
      icon: 'layers'
    }, {
      key: 'search',
      label: 'Search',
      icon: 'search'
    }, {
      key: 'notifications',
      label: 'Notifications',
      icon: 'bell',
      badgeKey: 'unreadNotifs'
    }, {
      key: 'write',
      label: 'Write',
      icon: 'feather',
      accent: true
    }],
    userSections: [{
      key: 'bookmarks',
      label: 'Bookmarks',
      icon: 'bookmark'
    }, {
      key: 'messages',
      label: 'Messages',
      icon: 'mail',
      badgeKey: 'unreadMsgs'
    }],
    /* /categories.json — Hubs (categories). swatch = desaturated earth tone. */
    hubs: [{
      key: 'quiet',
      label: 'Quiet internet',
      slug: 'quiet-internet',
      swatch: '#8C9A82',
      topics: 214,
      unread: 6,
      description: 'On attention, feeds, and the shape of calmer software.'
    }, {
      key: 'craft',
      label: 'Craft',
      slug: 'craft',
      swatch: '#B08968',
      topics: 388,
      unread: 0,
      description: 'The making of sentences, paragraphs, and pages.'
    }, {
      key: 'essays',
      label: 'Essays',
      slug: 'essays',
      swatch: '#9A8FB0',
      topics: 176,
      unread: 2,
      description: 'Longer arguments, in no hurry.'
    }, {
      key: 'meta',
      label: 'Meta',
      slug: 'meta',
      swatch: '#6E8A99',
      topics: 52,
      unread: 1,
      description: 'How fomio itself is run and moderated.'
    }],
    /* /latest.json — each item is a ListableTopicSerializer */
    topics: [{
      id: 4821,
      slug: 'chronological-feeds-are-a-moral-position',
      title: 'Chronological feeds are a moral position, not a nostalgia',
      fancyTitle: 'Chronological feeds are a <strong>moral position</strong>, not a nostalgia',
      hub: 'quiet',
      tags: ['feeds', 'attention', 'ethics'],
      postsCount: 47,
      replyCount: 46,
      likeCount: 312,
      views: 5120,
      participantCount: 18,
      opLikeCount: 128,
      bumpedAt: '2024-07-02T09:12:00Z',
      lastPostedAt: '2024-07-02T09:12:00Z',
      timeAgo: '12m',
      createdAgo: '2d',
      pinned: true,
      pinnedGlobally: true,
      closed: false,
      archived: false,
      hasSummary: true,
      visible: true,
      notificationLevel: 3,
      lastReadPostNumber: 39,
      unread: 8,
      newPosts: 0,
      unseen: false,
      bookmarked: true,
      liked: true,
      excerpt: 'A clock is the most neutral editor we have: it puts one thing after another and refuses to guess. Anything that reorders your attention is making an argument on your behalf — so let us at least name the argument.',
      posters: [poster(U.jun, 'original', 'Original Poster'), poster(U.sofia, '', 'Frequent Poster'), poster(U.omar, 'moderator', 'Moderator'), poster(U.priya, '', 'Frequent Poster'), poster(U.lena, 'latest', 'Most Recent Poster')]
    }, {
      id: 4817,
      slug: 'the-paragraph-as-a-unit-of-thought',
      title: 'The paragraph as a unit of thought',
      fancyTitle: 'The paragraph as a unit of thought',
      hub: 'craft',
      tags: ['writing', 'structure'],
      postsCount: 23,
      replyCount: 22,
      likeCount: 74,
      views: 1980,
      participantCount: 9,
      opLikeCount: 51,
      bumpedAt: '2024-07-02T07:40:00Z',
      lastPostedAt: '2024-07-02T07:40:00Z',
      timeAgo: '1h',
      createdAgo: '3d',
      pinned: false,
      closed: false,
      archived: false,
      hasSummary: false,
      visible: true,
      notificationLevel: 2,
      lastReadPostNumber: 22,
      unread: 0,
      newPosts: 3,
      unseen: false,
      bookmarked: false,
      liked: false,
      excerpt: 'Sentences are easy. Paragraphs are where the argument actually lives — and where most drafts quietly fall apart.',
      posters: [poster(U.sofia, 'original', 'Original Poster'), poster(U.ada, '', ''), poster(U.kaz, 'latest', 'Most Recent Poster')]
    }, {
      id: 4809,
      slug: 'on-writing-without-an-audience',
      title: 'On writing without an audience — a year of letters to no one',
      fancyTitle: 'On writing without an audience — a year of <strong>letters to no one</strong>',
      hub: 'essays',
      tags: ['practice', 'solitude'],
      postsCount: 31,
      replyCount: 30,
      likeCount: 142,
      views: 2640,
      participantCount: 14,
      opLikeCount: 89,
      bumpedAt: '2024-07-02T05:02:00Z',
      lastPostedAt: '2024-07-02T05:02:00Z',
      timeAgo: '3h',
      createdAgo: '5d',
      pinned: false,
      closed: false,
      archived: false,
      hasSummary: true,
      visible: true,
      notificationLevel: 1,
      lastReadPostNumber: null,
      unread: 0,
      newPosts: 0,
      unseen: true,
      bookmarked: false,
      liked: false,
      excerpt: 'What changes when the count goes away? The sentence slows down. It stops performing. This is a long one — thirty replies deep and still, somehow, unhurried.',
      posters: [poster(U.ada, 'original', 'Original Poster'), poster(U.lena, '', ''), poster(U.priya, '', ''), poster(U.mira, 'latest', 'Most Recent Poster')]
    }, {
      id: 4802,
      slug: 'notifications-are-a-design-failure',
      title: 'Notifications are a design failure',
      fancyTitle: 'Notifications are a design failure',
      hub: 'quiet',
      tags: ['attention', 'design'],
      postsCount: 58,
      replyCount: 57,
      likeCount: 203,
      views: 4410,
      participantCount: 21,
      opLikeCount: 96,
      bumpedAt: '2024-07-01T22:15:00Z',
      lastPostedAt: '2024-07-01T22:15:00Z',
      timeAgo: '11h',
      createdAgo: '4d',
      pinned: false,
      closed: false,
      archived: false,
      hasSummary: true,
      visible: true,
      notificationLevel: 2,
      lastReadPostNumber: 40,
      unread: 17,
      newPosts: 0,
      unseen: false,
      bookmarked: false,
      liked: true,
      excerpt: 'Every red dot is a decision someone else made about your attention. A modest proposal for fewer of them, and only the ones you asked for.',
      posters: [poster(U.theo, 'original', 'Original Poster'), poster(U.jun, '', ''), poster(U.omar, 'moderator', 'Moderator'), poster(U.kaz, 'latest', 'Most Recent Poster')]
    }, {
      id: 4794,
      slug: 'a-small-pause-in-a-loud-year',
      title: 'A small pause in a loud year',
      fancyTitle: 'A small pause in a loud year',
      hub: 'essays',
      tags: ['practice'],
      postsCount: 12,
      replyCount: 11,
      likeCount: 61,
      views: 1210,
      participantCount: 6,
      opLikeCount: 44,
      bumpedAt: '2024-07-01T16:30:00Z',
      lastPostedAt: '2024-07-01T16:30:00Z',
      timeAgo: '17h',
      createdAgo: '2d',
      pinned: false,
      closed: false,
      archived: false,
      hasSummary: false,
      visible: true,
      notificationLevel: 1,
      lastReadPostNumber: 11,
      unread: 0,
      newPosts: 0,
      unseen: false,
      bookmarked: false,
      liked: false,
      excerpt: 'I uninstalled everything. I kept fomio. Here is what a week looked like afterwards — quieter, and somehow longer.',
      posters: [poster(U.priya, 'original', 'Original Poster'), poster(U.ada, 'latest', 'Most Recent Poster')]
    }, {
      id: 4788,
      slug: 'style-guide-please-read-before-posting',
      title: 'Community style guide — please read before posting',
      fancyTitle: 'Community style guide — <strong>please read before posting</strong>',
      hub: 'meta',
      tags: ['guidelines'],
      postsCount: 4,
      replyCount: 3,
      likeCount: 220,
      views: 9800,
      participantCount: 3,
      opLikeCount: 210,
      bumpedAt: '2024-06-28T10:00:00Z',
      lastPostedAt: '2024-06-28T10:00:00Z',
      timeAgo: '4d',
      createdAgo: '1y',
      pinned: true,
      pinnedGlobally: false,
      closed: true,
      archived: false,
      hasSummary: false,
      visible: true,
      notificationLevel: 1,
      lastReadPostNumber: 4,
      unread: 0,
      newPosts: 0,
      unseen: false,
      bookmarked: false,
      liked: false,
      excerpt: 'The short version: read first, act clearly, and assume the other person is thinking. Closed to keep it canonical — reply in the linked working thread instead.',
      posters: [poster(U.omar, 'original', 'Moderator'), poster(U.mira, 'latest', '')]
    }, {
      id: 4781,
      slug: 'letters-to-no-one-the-craft-thread',
      title: 'Letters to no one — the craft thread',
      fancyTitle: 'Letters to no one — the craft thread',
      hub: 'craft',
      tags: ['writing', 'habit'],
      postsCount: 19,
      replyCount: 18,
      likeCount: 88,
      views: 1640,
      participantCount: 8,
      opLikeCount: 40,
      bumpedAt: '2024-06-27T14:20:00Z',
      lastPostedAt: '2024-06-27T14:20:00Z',
      timeAgo: '5d',
      createdAgo: '6d',
      pinned: false,
      closed: false,
      archived: false,
      hasSummary: false,
      visible: true,
      notificationLevel: 1,
      lastReadPostNumber: null,
      unread: 0,
      newPosts: 0,
      unseen: true,
      bookmarked: false,
      liked: false,
      excerpt: 'Notes from a year of writing things only I would read. What the habit did to the prose.',
      posters: [poster(U.ada, 'original', 'Original Poster'), poster(U.sofia, '', ''), poster(U.kaz, 'latest', 'Most Recent Poster')]
    }, {
      id: 4770,
      slug: 'the-quiet-internet-reading-list',
      title: 'The quiet-internet reading list (2024)',
      fancyTitle: 'The quiet-internet reading list <strong>(2024)</strong>',
      hub: 'quiet',
      tags: ['reading', 'links'],
      postsCount: 41,
      replyCount: 40,
      likeCount: 176,
      views: 3300,
      participantCount: 16,
      opLikeCount: 71,
      bumpedAt: '2024-06-26T09:00:00Z',
      lastPostedAt: '2024-06-26T09:00:00Z',
      timeAgo: '6d',
      createdAgo: '3w',
      pinned: false,
      closed: false,
      archived: false,
      hasSummary: true,
      visible: true,
      notificationLevel: 1,
      lastReadPostNumber: 40,
      unread: 0,
      newPosts: 0,
      unseen: false,
      bookmarked: true,
      liked: false,
      excerpt: 'A living list of essays, talks, and small tools that treat your attention as yours. Add yours below.',
      posters: [poster(U.mira, 'original', 'Original Poster'), poster(U.theo, '', ''), poster(U.priya, '', ''), poster(U.jun, 'latest', 'Most Recent Poster')]
    }],
    /* GET /t/4821.json — TopicViewSerializer for the reading view */
    topicView: {
      topic: {
        id: 4821,
        title: 'Chronological feeds are a moral position, not a nostalgia',
        fancyTitle: 'Chronological feeds are a <strong>moral position</strong>, not a nostalgia',
        slug: 'chronological-feeds-are-a-moral-position',
        hub: 'quiet',
        tags: ['feeds', 'attention', 'ethics'],
        postsCount: 47,
        replyCount: 46,
        likeCount: 312,
        views: 5120,
        participantCount: 18,
        wordCount: 5200,
        createdAgo: '2 days ago',
        pinned: true,
        closed: false,
        archived: false,
        hasSummary: true,
        currentPostNumber: 40,
        highestPostNumber: 47,
        lastReadPostNumber: 39,
        details: {
          notificationLevel: 3,
          canCreatePost: true,
          canEdit: false,
          canDelete: false,
          canFlag: true,
          canClose: false,
          canArchive: false,
          canEditTags: true,
          createdBy: U.jun,
          lastPoster: U.lena,
          participants: [{
            ...U.jun,
            postCount: 6,
            primaryGroup: ''
          }, {
            ...U.sofia,
            postCount: 9,
            primaryGroup: ''
          }, {
            ...U.omar,
            postCount: 4,
            primaryGroup: 'moderators'
          }, {
            ...U.priya,
            postCount: 7,
            primaryGroup: ''
          }, {
            ...U.lena,
            postCount: 5,
            primaryGroup: ''
          }, {
            ...U.kaz,
            postCount: 3,
            primaryGroup: ''
          }]
        }
      },
      postStream: {
        stream: [1, 2, 3, 4, 40, 41, 46, 47],
        posts: [{
          postNumber: 1,
          postType: 1,
          user: U.jun,
          userTitle: '',
          createdAgo: '2d',
          timeLabel: 'Jul 30',
          likeCount: 128,
          replyCount: 12,
          replyToPostNumber: null,
          bookmarked: true,
          canEdit: false,
          acted: true,
          paragraphs: ['A clock is a modest instrument. It does not know you, does not care what you have read before, does not try. It puts one thing after another, and then it stops.', 'That modesty is a rare posture in software right now. Most feeds lean in. They guess, they correct, they produce the inevitable small hum of being watched. We have been told this is a convenience. I want to argue it is a position — a claim about who your attention belongs to — and that pretending otherwise is the actual nostalgia.', 'So: chronology is not a throwback. It is the most neutral editor we have. Everything downstream of this thread assumes we agree on that, so let us argue about it first.'],
          isSummaryOf: false,
          long: true
        }, {
          postNumber: 40,
          postType: 1,
          user: U.sofia,
          userTitle: 'Frequent Poster',
          createdAgo: '2h',
          timeLabel: '2:14 PM',
          likeCount: 22,
          replyCount: 3,
          replyToPostNumber: 1,
          bookmarked: false,
          canEdit: false,
          acted: false,
          paragraphs: ['Replying to the original: I think the word doing the work here is "neutral." A clock is neutral about relevance but not about recency — it still privileges the new. That is a bias too, just a legible one.', 'Which is maybe your whole point. A legible bias is one I can argue with.']
        }, {
          postNumber: 41,
          postType: 1,
          user: U.omar,
          userTitle: 'Moderator',
          createdAgo: '1h',
          timeLabel: '3:02 PM',
          likeCount: 9,
          replyCount: 0,
          replyToPostNumber: 40,
          bookmarked: false,
          canEdit: true,
          acted: false,
          moderatorPost: true,
          paragraphs: ['Light touch mod note, not a ruling: keeping this on the ethics of ordering rather than specific platforms. The platform call-outs are drifting toward a pile-on. Carry those to Meta and I will link them.']
        }, {
          postNumber: 46,
          postType: 1,
          user: U.priya,
          userTitle: '',
          createdAgo: '18m',
          timeLabel: '3:44 PM',
          likeCount: 5,
          replyCount: 1,
          replyToPostNumber: 1,
          bookmarked: false,
          canEdit: false,
          acted: false,
          paragraphs: ['The part I keep returning to is "and then it stops." A feed that ends is doing something almost countercultural. The scroll that never bottoms out is the real editorial choice we stopped noticing.']
        }, {
          postNumber: 47,
          postType: 1,
          user: U.lena,
          userTitle: '',
          createdAgo: '12m',
          timeLabel: '3:58 PM',
          likeCount: 3,
          replyCount: 0,
          replyToPostNumber: null,
          bookmarked: false,
          canEdit: false,
          acted: false,
          latest: true,
          paragraphs: ['Coming late and reading all forty-six: what a calm way to disagree. Saving this whole thread to re-read on paper.']
        }]
      },
      suggestedTopics: [{
        id: 4802,
        title: 'Notifications are a design failure',
        hub: 'quiet',
        postsCount: 58
      }, {
        id: 4770,
        title: 'The quiet-internet reading list (2024)',
        hub: 'quiet',
        postsCount: 41
      }, {
        id: 4817,
        title: 'The paragraph as a unit of thought',
        hub: 'craft',
        postsCount: 23
      }]
    }
  };
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "topics-data.js", error: String((e && e.message) || e) }); }

// topics-feed.jsx
try { (() => {
/* topics-feed.jsx — the Topics feed: three editorial layouts that break from
 * cards (Ledger / Digest / Threads), the filter bar with a Categories/Hub
 * dropdown, and the list-level states (skeleton / empty / error / gated).
 * Exports: TopicsFilterBar, TopicsFeed, FeedSkeleton, FeedEmpty, FeedError, HubGate.
 */
const {
  TIc,
  Avatar,
  ReadPip,
  HubBadge,
  Tag,
  Chip,
  MetaDot,
  Stat,
  PosterStack,
  BigCount
} = window;
function hubMap(hubs) {
  const m = {};
  hubs.forEach(h => {
    m[h.key] = h;
  });
  return m;
}
const lastPosterOf = t => (t.posters.find(p => p.extras === 'latest') || t.posters[t.posters.length - 1]).user;
const opOf = t => (t.posters.find(p => p.extras === 'original') || t.posters[0]).user;

/* ── Status flags shown inline with the title ────────────────── */
function StatusFlags({
  t,
  size = 14
}) {
  return /*#__PURE__*/React.createElement(React.Fragment, null, t.pinned && /*#__PURE__*/React.createElement(TIc, {
    name: "pin",
    size: size,
    color: "var(--fomio-fg-muted)",
    stroke: 1.9,
    style: {
      transform: 'translateY(1px)'
    }
  }), t.closed && /*#__PURE__*/React.createElement(TIc, {
    name: "lock",
    size: size,
    color: "var(--fomio-fg-muted)",
    stroke: 1.9,
    style: {
      transform: 'translateY(1px)'
    }
  }));
}

/* notification level → tracked/watching indicator (semantic, not color-only) */
function NotifTag({
  level
}) {
  if (level < 2) return null;
  const label = level === 3 ? 'Watching' : 'Tracking';
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 4,
      fontFamily: 'var(--fomio-sans)',
      fontSize: 11.5,
      fontWeight: 600,
      color: 'var(--fomio-fg-muted)'
    }
  }, /*#__PURE__*/React.createElement(TIc, {
    name: level === 3 ? 'eye' : 'bell',
    size: 13,
    color: "var(--fomio-fg-muted)",
    stroke: 1.8
  }), label);
}

/* ════════════ LAYOUT 1 — LEDGER (dense typographic index) ═════
 * No cards. A hairline register: read-pip gutter, title + meta, and a
 * right rail where the reply count is the dominant number. The pinned
 * topic reads as a weighted lead with its excerpt exposed. */
function Ledger({
  topics,
  hubs,
  onOpen,
  mode
}) {
  const hm = hubMap(hubs);
  const touch = mode === 'touch';
  return /*#__PURE__*/React.createElement("div", null, topics.map((t, i) => {
    const lead = t.pinned && i === 0;
    const hub = hm[t.hub];
    return /*#__PURE__*/React.createElement("article", {
      key: t.id,
      className: "ft-row",
      onClick: () => onOpen(t),
      tabIndex: 0,
      onKeyDown: e => {
        if (e.key === 'Enter') onOpen(t);
      },
      style: {
        display: 'flex',
        gap: touch ? 12 : 18,
        alignItems: 'flex-start',
        padding: lead ? '2px 10px 22px' : '18px 10px',
        borderBottom: '1px solid var(--fomio-border)',
        borderLeft: lead ? '2px solid var(--fomio-primary)' : '2px solid transparent',
        marginLeft: lead ? -2 : 0
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        width: 10,
        paddingTop: 7,
        flexShrink: 0
      }
    }, /*#__PURE__*/React.createElement(ReadPip, {
      topic: t,
      size: 8
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        minWidth: 0,
        display: 'flex',
        flexDirection: 'column'
      }
    }, /*#__PURE__*/React.createElement("h3", {
      className: "ft-title",
      style: {
        margin: '0 0 7px',
        fontFamily: 'var(--fomio-serif)',
        fontWeight: 700,
        fontSize: lead ? touch ? 22 : 26 : touch ? 17.5 : 20,
        lineHeight: 1.24,
        letterSpacing: '-0.02em',
        color: 'var(--fomio-fg)',
        textWrap: 'pretty'
      }
    }, /*#__PURE__*/React.createElement("span", {
      dangerouslySetInnerHTML: {
        __html: t.fancyTitle
      }
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        display: 'inline-flex',
        gap: 6,
        alignItems: 'center',
        verticalAlign: 'middle',
        marginLeft: 8
      }
    }, /*#__PURE__*/React.createElement(StatusFlags, {
      t: t
    }))), lead && /*#__PURE__*/React.createElement("p", {
      style: {
        margin: '0 0 11px',
        fontFamily: 'var(--fomio-serif)',
        fontSize: touch ? 15 : 16,
        lineHeight: 1.55,
        color: 'var(--fomio-fg-secondary)',
        maxWidth: 620,
        textWrap: 'pretty',
        display: '-webkit-box',
        WebkitLineClamp: 2,
        WebkitBoxOrient: 'vertical',
        overflow: 'hidden'
      }
    }, t.excerpt), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 9,
        flexWrap: 'wrap',
        fontFamily: 'var(--fomio-sans)'
      }
    }, /*#__PURE__*/React.createElement(HubBadge, {
      hub: hub
    }), t.tags.slice(0, touch ? 1 : 3).map(tg => /*#__PURE__*/React.createElement(Tag, {
      key: tg,
      label: tg
    })), /*#__PURE__*/React.createElement(MetaDot, null), /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 12,
        color: 'var(--fomio-fg-muted)'
      }
    }, "by ", /*#__PURE__*/React.createElement("span", {
      style: {
        fontWeight: 600,
        color: 'var(--fomio-fg-secondary)'
      }
    }, "@", opOf(t).username)), !touch && /*#__PURE__*/React.createElement(NotifTag, {
      level: t.notificationLevel
    }), t.bookmarked && /*#__PURE__*/React.createElement(TIc, {
      name: "bookmark",
      size: 13,
      color: "var(--fomio-fg-muted)",
      fill: "var(--fomio-fg-muted)",
      stroke: 1.8
    })), touch && /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 14,
        marginTop: 11
      }
    }, /*#__PURE__*/React.createElement(PosterStack, {
      posters: t.posters,
      size: 22,
      max: 3
    }), /*#__PURE__*/React.createElement(Stat, {
      icon: "messages",
      value: t.replyCount
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        marginLeft: 'auto',
        fontFamily: 'var(--fomio-sans)',
        fontSize: 12,
        color: 'var(--fomio-fg-muted)'
      }
    }, t.timeAgo))), !touch && /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 18,
        flexShrink: 0,
        paddingTop: 2
      }
    }, /*#__PURE__*/React.createElement(PosterStack, {
      posters: t.posters,
      size: 26,
      max: 4
    }), /*#__PURE__*/React.createElement(BigCount, {
      value: t.replyCount,
      label: "replies",
      active: t.unread > 0
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        width: 52,
        textAlign: 'right'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--fomio-sans)',
        fontSize: 12.5,
        fontWeight: 600,
        color: 'var(--fomio-fg-muted)'
      }
    }, t.timeAgo), /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--fomio-mono)',
        fontSize: 10.5,
        color: 'var(--fomio-fg-muted)',
        marginTop: 4,
        opacity: 0.8
      }
    }, t.views.toLocaleString(), "\xB7v"))));
  }));
}

/* ════════════ LAYOUT 2 — DIGEST (grouped by Hub, magazine) ════
 * Topics are grouped under their Hub as editorial sections. Reading-
 * forward: excerpt exposed, participants small. Good for browsing by
 * category. Sections flow two-up on wide surfaces. */
function DigestSection({
  hub,
  topics,
  onOpen,
  onBrowseHub
}) {
  return /*#__PURE__*/React.createElement("section", {
    style: {
      breakInside: 'avoid',
      marginBottom: 34
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      paddingBottom: 12,
      borderBottom: '2px solid var(--fomio-fg)',
      marginBottom: 4
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 12,
      height: 12,
      borderRadius: 3,
      background: hub.swatch,
      flexShrink: 0
    }
  }), /*#__PURE__*/React.createElement("h2", {
    style: {
      margin: 0,
      fontFamily: 'var(--fomio-serif)',
      fontWeight: 700,
      fontSize: 21,
      letterSpacing: '-0.02em',
      color: 'var(--fomio-fg)'
    }
  }, hub.label), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--fomio-mono)',
      fontSize: 12,
      color: 'var(--fomio-fg-muted)'
    }
  }, hub.topics), /*#__PURE__*/React.createElement("button", {
    onClick: () => onBrowseHub(hub),
    className: "ft-textbtn",
    style: {
      marginLeft: 'auto',
      display: 'inline-flex',
      alignItems: 'center',
      gap: 5,
      background: 'none',
      border: 'none',
      cursor: 'pointer',
      fontFamily: 'var(--fomio-sans)',
      fontSize: 12,
      fontWeight: 700,
      letterSpacing: '0.03em',
      textTransform: 'uppercase',
      color: 'var(--fomio-fg-muted)'
    }
  }, "Browse ", /*#__PURE__*/React.createElement(TIc, {
    name: "arrowRight",
    size: 14,
    color: "currentColor",
    stroke: 2
  }))), topics.map(t => /*#__PURE__*/React.createElement("article", {
    key: t.id,
    className: "ft-row",
    onClick: () => onOpen(t),
    tabIndex: 0,
    onKeyDown: e => {
      if (e.key === 'Enter') onOpen(t);
    },
    style: {
      display: 'flex',
      gap: 14,
      padding: '16px 10px',
      alignItems: 'flex-start',
      borderBottom: '1px solid var(--fomio-border)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 8,
      paddingTop: 6,
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement(ReadPip, {
    topic: t,
    size: 8
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0,
      display: 'flex',
      flexDirection: 'column'
    }
  }, /*#__PURE__*/React.createElement("h3", {
    className: "ft-title",
    style: {
      margin: '0 0 5px',
      fontFamily: 'var(--fomio-serif)',
      fontWeight: 700,
      fontSize: 18,
      lineHeight: 1.28,
      letterSpacing: '-0.02em',
      color: 'var(--fomio-fg)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    dangerouslySetInnerHTML: {
      __html: t.fancyTitle
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      gap: 6,
      alignItems: 'center',
      verticalAlign: 'middle',
      marginLeft: 7
    }
  }, /*#__PURE__*/React.createElement(StatusFlags, {
    t: t,
    size: 13
  }))), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '0 0 9px',
      fontFamily: 'var(--fomio-serif)',
      fontSize: 14,
      lineHeight: 1.5,
      color: 'var(--fomio-fg-muted)',
      display: '-webkit-box',
      WebkitLineClamp: 2,
      WebkitBoxOrient: 'vertical',
      overflow: 'hidden',
      textWrap: 'pretty'
    }
  }, t.excerpt), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement(PosterStack, {
    posters: t.posters,
    size: 20,
    max: 3
  }), /*#__PURE__*/React.createElement(Stat, {
    icon: "messages",
    value: t.replyCount
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      marginLeft: 'auto',
      fontFamily: 'var(--fomio-sans)',
      fontSize: 11.5,
      color: 'var(--fomio-fg-muted)'
    }
  }, t.timeAgo))))));
}
function Digest({
  topics,
  hubs,
  onOpen,
  onBrowseHub,
  mode
}) {
  const cols = mode === 'expanded' ? 2 : 1;
  const groups = hubs.map(h => ({
    hub: h,
    items: topics.filter(t => t.hub === h.key)
  })).filter(g => g.items.length);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      columnCount: cols,
      columnGap: 40
    }
  }, groups.map(g => /*#__PURE__*/React.createElement(DigestSection, {
    key: g.hub.key,
    hub: g.hub,
    topics: g.items,
    onOpen: onOpen,
    onBrowseHub: onBrowseHub
  })));
}

/* ════════════ LAYOUT 3 — THREADS (conversation / activity) ════
 * Foregrounds the live conversation: the latest reply reads as a pull
 * quote, the topic title is the quieter context line above it. Sorted
 * by recent activity — the natural home for Top / Hot. */
function Threads({
  topics,
  hubs,
  onOpen,
  mode
}) {
  const hm = hubMap(hubs);
  const touch = mode === 'touch';
  return /*#__PURE__*/React.createElement("div", null, topics.map(t => {
    const lp = lastPosterOf(t);
    const hub = hm[t.hub];
    return /*#__PURE__*/React.createElement("article", {
      key: t.id,
      className: "ft-row",
      onClick: () => onOpen(t),
      tabIndex: 0,
      onKeyDown: e => {
        if (e.key === 'Enter') onOpen(t);
      },
      style: {
        display: 'flex',
        gap: 16,
        padding: '22px 10px',
        alignItems: 'flex-start',
        borderBottom: '1px solid var(--fomio-border)'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        position: 'relative',
        flexShrink: 0,
        paddingTop: 2
      }
    }, /*#__PURE__*/React.createElement(Avatar, {
      user: lp,
      size: touch ? 36 : 44
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        position: 'absolute',
        right: -3,
        bottom: -3,
        width: 20,
        height: 20,
        borderRadius: '50%',
        background: 'var(--fomio-card)',
        border: '1px solid var(--fomio-border)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center'
      }
    }, /*#__PURE__*/React.createElement(TIc, {
      name: "reply",
      size: 11,
      color: "var(--fomio-fg-muted)",
      stroke: 2
    }))), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        minWidth: 0
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 8,
        marginBottom: 7,
        flexWrap: 'wrap'
      }
    }, /*#__PURE__*/React.createElement(HubBadge, {
      hub: hub,
      size: "sm"
    }), /*#__PURE__*/React.createElement(MetaDot, null), /*#__PURE__*/React.createElement("span", {
      className: "ft-title",
      style: {
        fontFamily: 'var(--fomio-serif)',
        fontWeight: 600,
        fontSize: 14.5,
        letterSpacing: '-0.01em',
        color: 'var(--fomio-fg)',
        overflow: 'hidden',
        textOverflow: 'ellipsis',
        whiteSpace: 'nowrap',
        maxWidth: '100%'
      },
      dangerouslySetInnerHTML: {
        __html: t.fancyTitle
      }
    }), /*#__PURE__*/React.createElement(StatusFlags, {
      t: t,
      size: 13
    })), /*#__PURE__*/React.createElement("p", {
      style: {
        margin: '0 0 12px',
        fontFamily: 'var(--fomio-serif)',
        fontSize: touch ? 15 : 16.5,
        lineHeight: 1.5,
        color: 'var(--fomio-fg)',
        textWrap: 'pretty',
        display: '-webkit-box',
        WebkitLineClamp: 3,
        WebkitBoxOrient: 'vertical',
        overflow: 'hidden',
        borderLeft: '2px solid var(--fomio-border)',
        paddingLeft: 14
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        fontWeight: 700
      }
    }, "@", lp.username), " ", t.excerpt), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 14,
        flexWrap: 'wrap'
      }
    }, /*#__PURE__*/React.createElement(PosterStack, {
      posters: t.posters,
      size: 22,
      max: 4
    }), /*#__PURE__*/React.createElement(Stat, {
      icon: "messages",
      value: `${t.replyCount} replies`
    }), !touch && /*#__PURE__*/React.createElement(Stat, {
      icon: "heart",
      value: t.likeCount,
      active: t.liked
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        display: 'inline-flex',
        alignItems: 'center',
        gap: 5,
        fontFamily: 'var(--fomio-sans)',
        fontSize: 12,
        fontWeight: 600,
        color: 'var(--fomio-fg-muted)'
      }
    }, /*#__PURE__*/React.createElement(TIc, {
      name: "clock",
      size: 13,
      color: "var(--fomio-fg-muted)",
      stroke: 1.8
    }), t.timeAgo), t.unread > 0 && /*#__PURE__*/React.createElement("span", {
      style: {
        marginLeft: 'auto',
        fontFamily: 'var(--fomio-sans)',
        fontSize: 11.5,
        fontWeight: 700,
        color: 'var(--fomio-primary)'
      }
    }, t.unread, " unread"))));
  }));
}
function TopicsFeed({
  layout,
  topics,
  hubs,
  onOpen,
  onBrowseHub,
  mode
}) {
  if (layout === 'digest') return /*#__PURE__*/React.createElement(Digest, {
    topics: topics,
    hubs: hubs,
    onOpen: onOpen,
    onBrowseHub: onBrowseHub,
    mode: mode
  });
  if (layout === 'threads') return /*#__PURE__*/React.createElement(Threads, {
    topics: topics,
    hubs: hubs,
    onOpen: onOpen,
    mode: mode
  });
  return /*#__PURE__*/React.createElement(Ledger, {
    topics: topics,
    hubs: hubs,
    onOpen: onOpen,
    mode: mode
  });
}

/* ════════════ FILTER BAR ══════════════════════════════════════ */
function TopicsFilterBar({
  filter,
  setFilter,
  hub,
  hubs,
  onPickHub,
  gatedUnread,
  onMarkRead
}) {
  const [open, setOpen] = React.useState(false);
  const chips = [{
    key: 'latest',
    label: 'Latest',
    icon: 'clock'
  }, {
    key: 'new',
    label: 'New',
    icon: 'sparkle'
  }, {
    key: 'unread',
    label: 'Unread',
    icon: 'bookOpen',
    gated: gatedUnread
  }, {
    key: 'top',
    label: 'Top',
    icon: 'flame'
  }];
  const activeHub = hub ? hubs.find(h => h.key === hub) : null;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8,
      overflowX: 'auto',
      scrollbarWidth: 'none',
      flexWrap: 'nowrap'
    }
  }, chips.map(c => /*#__PURE__*/React.createElement(Chip, {
    key: c.key,
    label: c.label,
    icon: c.icon,
    active: filter === c.key && !hub,
    gated: c.gated,
    onClick: () => {
      setFilter(c.key);
      onPickHub(null);
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement(Chip, {
    label: activeHub ? activeHub.label : 'Categories',
    icon: "layers",
    dropdown: true,
    active: !!hub,
    onClick: () => setOpen(o => !o)
  }), open && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    onClick: () => setOpen(false),
    style: {
      position: 'fixed',
      inset: 0,
      zIndex: 30
    }
  }), /*#__PURE__*/React.createElement("div", {
    role: "menu",
    style: {
      position: 'absolute',
      top: 42,
      left: 0,
      zIndex: 31,
      width: 268,
      background: 'var(--fomio-card)',
      border: '1px solid var(--fomio-border)',
      borderRadius: 14,
      boxShadow: '0 18px 44px -18px var(--fomio-shadow)',
      padding: 6,
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("button", {
    onClick: () => {
      onPickHub(null);
      setOpen(false);
    },
    className: "ft-navitem",
    style: menuItem(!hub)
  }, /*#__PURE__*/React.createElement(TIc, {
    name: "layers",
    size: 16,
    color: "var(--fomio-fg-muted)",
    stroke: 1.9
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      textAlign: 'left'
    }
  }, "All hubs")), hubs.map(h => /*#__PURE__*/React.createElement("button", {
    key: h.key,
    onClick: () => {
      onPickHub(h.key);
      setOpen(false);
    },
    className: "ft-navitem",
    style: menuItem(hub === h.key)
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 10,
      height: 10,
      borderRadius: 3,
      background: h.swatch,
      flexShrink: 0
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      textAlign: 'left',
      overflow: 'hidden',
      textOverflow: 'ellipsis',
      whiteSpace: 'nowrap'
    }
  }, h.label), h.unread > 0 && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--fomio-mono)',
      fontSize: 11,
      color: 'var(--fomio-primary)'
    }
  }, h.unread), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--fomio-mono)',
      fontSize: 11,
      color: 'var(--fomio-fg-muted)'
    }
  }, h.topics))))))), /*#__PURE__*/React.createElement("button", {
    onClick: onMarkRead,
    className: "ft-textbtn",
    style: {
      marginLeft: 'auto',
      background: 'none',
      border: 'none',
      cursor: 'pointer',
      padding: '0 4px',
      fontFamily: 'var(--fomio-sans)',
      fontSize: 11,
      fontWeight: 700,
      letterSpacing: '0.04em',
      textTransform: 'uppercase',
      color: 'var(--fomio-primary)',
      display: 'inline-flex',
      alignItems: 'center',
      gap: 5,
      whiteSpace: 'nowrap'
    }
  }, /*#__PURE__*/React.createElement(TIc, {
    name: "check",
    size: 15,
    color: "var(--fomio-primary)",
    stroke: 2
  }), " Mark read"));
}
function menuItem(active) {
  return {
    display: 'flex',
    alignItems: 'center',
    gap: 10,
    width: '100%',
    height: 38,
    padding: '0 10px',
    borderRadius: 9,
    border: 'none',
    cursor: 'pointer',
    background: active ? 'var(--fomio-surface)' : 'transparent',
    fontFamily: 'var(--fomio-sans)',
    fontSize: 13.5,
    fontWeight: active ? 700 : 500,
    color: 'var(--fomio-fg)'
  };
}

/* ════════════ LIST STATES ═════════════════════════════════════ */
function SkelLine({
  w,
  h = 14,
  mt = 0,
  r = 6
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "ft-shimmer",
    style: {
      width: w,
      height: h,
      borderRadius: r,
      marginTop: mt,
      background: 'var(--fomio-surface)'
    }
  });
}
function FeedSkeleton() {
  return /*#__PURE__*/React.createElement("div", {
    "aria-busy": "true",
    "aria-label": "Loading topics"
  }, Array.from({
    length: 6
  }).map((_, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      display: 'flex',
      gap: 18,
      padding: i === 0 ? '2px 10px 22px' : '18px 10px',
      borderBottom: '1px solid var(--fomio-border)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 10,
      paddingTop: 8
    }
  }, /*#__PURE__*/React.createElement(SkelLine, {
    w: 8,
    h: 8,
    r: 4
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement(SkelLine, {
    w: i === 0 ? '82%' : '64%',
    h: i === 0 ? 24 : 20
  }), i === 0 && /*#__PURE__*/React.createElement(SkelLine, {
    w: "90%",
    h: 14,
    mt: 12
  }), /*#__PURE__*/React.createElement(SkelLine, {
    w: "40%",
    h: 12,
    mt: 12
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement(SkelLine, {
    w: 72,
    h: 26,
    r: 13
  }), /*#__PURE__*/React.createElement(SkelLine, {
    w: 34,
    h: 22
  })))));
}
function FeedEmpty({
  onCompose,
  hubLabel
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'center',
      padding: '60px 24px',
      maxWidth: 440,
      margin: '0 auto'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 56,
      height: 56,
      borderRadius: 16,
      background: 'var(--fomio-surface)',
      border: '1px solid var(--fomio-border)',
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      marginBottom: 20
    }
  }, /*#__PURE__*/React.createElement(TIc, {
    name: "inbox",
    size: 26,
    color: "var(--fomio-fg-muted)",
    stroke: 1.6
  })), /*#__PURE__*/React.createElement("h3", {
    style: {
      margin: '0 0 8px',
      fontFamily: 'var(--fomio-serif)',
      fontWeight: 700,
      fontSize: 22,
      letterSpacing: '-0.02em',
      color: 'var(--fomio-fg)'
    }
  }, hubLabel ? `Nothing in ${hubLabel} yet` : 'No topics here yet'), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '0 0 24px',
      fontFamily: 'var(--fomio-serif)',
      fontSize: 15,
      lineHeight: 1.6,
      color: 'var(--fomio-fg-muted)'
    }
  }, "This filter is empty \u2014 which is a fine state to be in. Start the first thread and give someone something to read on Monday."), /*#__PURE__*/React.createElement("button", {
    onClick: onCompose,
    className: "ft-cta",
    style: ctaStyle()
  }, /*#__PURE__*/React.createElement(TIc, {
    name: "feather",
    size: 17,
    color: "#fff",
    stroke: 1.9
  }), " Start a topic"));
}
function FeedError({
  onRetry
}) {
  return /*#__PURE__*/React.createElement("div", {
    role: "alert",
    style: {
      textAlign: 'center',
      padding: '60px 24px',
      maxWidth: 440,
      margin: '0 auto'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 56,
      height: 56,
      borderRadius: 16,
      background: 'var(--fomio-surface)',
      border: '1px solid var(--fomio-border)',
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      marginBottom: 20
    }
  }, /*#__PURE__*/React.createElement(TIc, {
    name: "alert",
    size: 26,
    color: "var(--fomio-danger)",
    stroke: 1.7
  })), /*#__PURE__*/React.createElement("h3", {
    style: {
      margin: '0 0 8px',
      fontFamily: 'var(--fomio-serif)',
      fontWeight: 700,
      fontSize: 22,
      letterSpacing: '-0.02em',
      color: 'var(--fomio-fg)'
    }
  }, "Couldn\u2019t load the latest topics"), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '0 0 24px',
      fontFamily: 'var(--fomio-serif)',
      fontSize: 15,
      lineHeight: 1.6,
      color: 'var(--fomio-fg-muted)'
    }
  }, "The request to ", /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--fomio-mono)',
      fontSize: 13
    }
  }, "/latest.json"), " timed out. Your place in the feed is saved \u2014 nothing was lost. Check your connection and try again."), /*#__PURE__*/React.createElement("button", {
    onClick: onRetry,
    className: "ft-cta",
    style: ctaStyle()
  }, /*#__PURE__*/React.createElement(TIc, {
    name: "activity",
    size: 17,
    color: "#fff",
    stroke: 2
  }), " Retry"));
}

/* Permission gate — logged-out user reaching Unread (read state needs an account) */
function HubGate({
  onLogin
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 14,
      alignItems: 'flex-start',
      padding: '18px 20px',
      background: 'var(--fomio-card)',
      border: '1px solid var(--fomio-border)',
      borderRadius: 16,
      marginTop: 4
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 38,
      height: 38,
      borderRadius: 11,
      background: 'var(--fomio-primary-soft)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement(TIc, {
    name: "lock",
    size: 18,
    color: "var(--fomio-primary-dark)",
    stroke: 1.8
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--fomio-sans)',
      fontWeight: 700,
      fontSize: 14,
      color: 'var(--fomio-fg)',
      marginBottom: 3
    }
  }, "Log in to track what you\u2019ve read"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--fomio-serif)',
      fontSize: 14,
      lineHeight: 1.5,
      color: 'var(--fomio-fg-muted)'
    }
  }, "Unread and New follow your read state across devices \u2014 they need an account to remember your place. Latest and Top stay open to everyone.")), /*#__PURE__*/React.createElement("button", {
    onClick: onLogin,
    style: {
      height: 36,
      padding: '0 16px',
      borderRadius: 9999,
      background: 'var(--fomio-primary)',
      color: '#fff',
      border: 'none',
      cursor: 'pointer',
      fontFamily: 'var(--fomio-sans)',
      fontWeight: 700,
      fontSize: 13,
      flexShrink: 0
    }
  }, "Log in"));
}
function ctaStyle() {
  return {
    height: 44,
    padding: '0 22px',
    borderRadius: 9999,
    background: 'var(--fomio-primary)',
    color: '#fff',
    border: 'none',
    cursor: 'pointer',
    fontFamily: 'var(--fomio-sans)',
    fontWeight: 700,
    fontSize: 14,
    letterSpacing: '0.01em',
    display: 'inline-flex',
    alignItems: 'center',
    gap: 8
  };
}
Object.assign(window, {
  TopicsFilterBar,
  TopicsFeed,
  FeedSkeleton,
  FeedEmpty,
  FeedError,
  HubGate
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "topics-feed.jsx", error: String((e && e.message) || e) }); }

// topics-icons.jsx
try { (() => {
/* topics-icons.jsx — Lucide-style icon set + shared primitives for Fomio Topics.
 * Glyphs are single-path/multi-subpath Lucide shapes (24x24, round caps).
 * Exports to window: TIc, FomioMark, Avatar, PresenceDot, ReadPip, HubBadge,
 *   Tag, Chip, MetaDot, Stat, PosterStack, BigCount, CoverStripe.
 */
const TOPIC_ICONS = {
  home: 'M3 9.5 12 3l9 6.5V20a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1z',
  layers: 'M12 2 2 7l10 5 10-5z M2 12l10 5 10-5 M2 17l10 5 10-5',
  search: 'M11 19a8 8 0 1 0 0-16 8 8 0 0 0 0 16z M21 21l-4.3-4.3',
  bell: 'M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9 M13.7 21a2 2 0 0 1-3.4 0',
  feather: 'M20.2 3.8a5.4 5.4 0 0 0-7.6 0L4 12.4V20h7.6l8.6-8.6a5.4 5.4 0 0 0 0-7.6z M16 8 2 22 M17.5 15H9',
  bookmark: 'M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z',
  mail: 'M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z M22 6l-10 7L2 6',
  user: 'M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2 M12 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8z',
  hash: 'M4 9h16 M4 15h16 M10 3 8 21 M16 3l-2 18',
  tag: 'M20.6 13.4 12 22l-9-9V3h10l7.6 7.6a2 2 0 0 1 0 2.8z M7.5 7.5h.01',
  pin: 'M12 17v5 M9 10.8V4h6v6.8l2 3.2H7z',
  lock: 'M5 11h14v10H5z M8 11V7a4 4 0 0 1 8 0v4',
  eye: 'M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6z',
  heart: 'M19 14c1.5-1.5 3-3.3 3-5.5A4.5 4.5 0 0 0 12 5 4.5 4.5 0 0 0 2 8.5c0 2.2 1.5 4 3 5.5l7 7z',
  reply: 'M9 17l-5-5 5-5 M4 12h11a5 5 0 0 1 5 5v1',
  messages: 'M21 11.5a8.4 8.4 0 0 1-9 8.5 8.5 8.5 0 0 1-3.9-.9L3 21l1.9-5.1A8.5 8.5 0 0 1 3 11.5a8.5 8.5 0 0 1 9-8.5 8.4 8.4 0 0 1 9 8.5z',
  flame: 'M12 2s5 4 5 9a5 5 0 0 1-10 0c0-1.5.5-2.5.5-2.5 1 2 2.5 2.5 2.5 2.5S8 8 12 2z',
  clock: 'M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20z M12 7v5l3 2',
  check: 'M20 6 9 17l-5-5',
  checkCircle: 'M22 11.1V12a10 10 0 1 1-5.9-9.1 M22 4 12 14.1l-3-3',
  chevronDown: 'M6 9l6 6 6-6',
  chevronRight: 'M9 18l6-6-6-6',
  chevronsLeft: 'M11 17l-5-5 5-5 M18 17l-5-5 5-5',
  arrowLeft: 'M19 12H5 M12 19l-7-7 7-7',
  arrowRight: 'M5 12h14 M12 5l7 7-7 7',
  settings: 'M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6z M19.4 15a1.6 1.6 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.6 1.6 0 0 0-2.7 1.2V21a2 2 0 0 1-4 0v-.1A1.6 1.6 0 0 0 9 19.4a1.6 1.6 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.6 1.6 0 0 0-1.2-2.7H3a2 2 0 0 1 0-4h.1A1.6 1.6 0 0 0 4.6 9a1.6 1.6 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.6 1.6 0 0 0 1.8.3H9a1.6 1.6 0 0 0 1-1.5V3a2 2 0 0 1 4 0v.1a1.6 1.6 0 0 0 2.7 1.2l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.6 1.6 0 0 0-.3 1.8V9a1.6 1.6 0 0 0 1.5 1H21a2 2 0 0 1 0 4h-.1a1.6 1.6 0 0 0-1.5 1z',
  edit: 'M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7 M18.5 2.5a2.1 2.1 0 0 1 3 3L12 15l-4 1 1-4z',
  x: 'M18 6 6 18 M6 6l12 12',
  code: 'M16 18l6-6-6-6 M8 6l-6 6 6 6',
  sparkle: 'M12 3v4 M12 17v4 M3 12h4 M17 12h4 M6.3 6.3l2.8 2.8 M14.9 14.9l2.8 2.8 M17.7 6.3l-2.8 2.8 M9.1 14.9l-2.8 2.8',
  inbox: 'M22 12h-6l-2 3h-4l-2-3H2 M5.5 5.1 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.5-6.9A2 2 0 0 0 16.7 4H7.3a2 2 0 0 0-1.8 1.1z',
  alert: 'M12 9v4 M12 17h.01 M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z',
  shield: 'M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z',
  flag: 'M4 22V4a1 1 0 0 1 1-1h13l-2.5 4L18 11H5 M4 22h0',
  more: 'M12 13a1 1 0 1 0 0-2 1 1 0 0 0 0 2z M19 13a1 1 0 1 0 0-2 1 1 0 0 0 0 2z M5 13a1 1 0 1 0 0-2 1 1 0 0 0 0 2z',
  list: 'M8 6h13 M8 12h13 M8 18h13 M3 6h.01 M3 12h.01 M3 18h.01',
  columns: 'M3 4h18v16H3z M12 4v16',
  activity: 'M22 12h-4l-3 9L9 3l-3 9H2',
  bookOpen: 'M12 7v14 M3 5h6a2 2 0 0 1 3 2 2 2 0 0 1 3-2h6v13h-7a2 2 0 0 0-2 2 2 2 0 0 0-2-2H3z',
  filter: 'M22 3H2l8 9.5V19l4 2v-8.5z',
  atSign: 'M12 16a4 4 0 1 0 0-8 4 4 0 0 0 0 8z M16 12v1.5a2.5 2.5 0 0 0 5 0V12a9 9 0 1 0-4.5 7.8'
};
function TIc({
  name,
  size = 20,
  color = 'currentColor',
  stroke = 2,
  fill = 'none',
  style
}) {
  const d = TOPIC_ICONS[name] || '';
  return /*#__PURE__*/React.createElement("svg", {
    width: size,
    height: size,
    viewBox: "0 0 24 24",
    fill: fill,
    stroke: color,
    strokeWidth: stroke,
    strokeLinecap: "round",
    strokeLinejoin: "round",
    style: {
      display: 'block',
      flexShrink: 0,
      ...style
    },
    "aria-hidden": "true"
  }, d.split(' M').map((seg, i) => /*#__PURE__*/React.createElement("path", {
    key: i,
    d: (i ? 'M' : '') + seg
  })));
}

/* fomio italic-serif wordmark with the single terracotta arc */
function FomioMark({
  size = 24,
  mark = false,
  color = 'var(--fomio-fg)'
}) {
  if (mark) {
    return /*#__PURE__*/React.createElement("span", {
      style: {
        position: 'relative',
        display: 'inline-flex',
        alignItems: 'flex-end'
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--fomio-serif)',
        fontWeight: 700,
        fontStyle: 'italic',
        fontSize: size,
        lineHeight: 1,
        letterSpacing: '-0.03em',
        color
      }
    }, "f"), /*#__PURE__*/React.createElement("svg", {
      width: size * 0.7,
      height: size * 0.28,
      viewBox: "0 0 22 8",
      style: {
        position: 'absolute',
        left: '4%',
        bottom: -size * 0.12
      }
    }, /*#__PURE__*/React.createElement("path", {
      d: "M1 2 Q11 9 21 2",
      stroke: "var(--fomio-primary)",
      strokeWidth: "2.4",
      strokeLinecap: "round",
      fill: "none"
    })));
  }
  return /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'relative',
      display: 'inline-flex',
      alignItems: 'flex-end'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--fomio-serif)',
      fontWeight: 700,
      fontStyle: 'italic',
      fontSize: size,
      lineHeight: 1,
      letterSpacing: '-0.03em',
      color
    }
  }, "fomio"), /*#__PURE__*/React.createElement("svg", {
    width: size * 1.05,
    height: size * 0.3,
    viewBox: "0 0 44 10",
    style: {
      position: 'absolute',
      right: 0,
      bottom: -size * 0.1
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M2 3 Q22 11 42 3",
    stroke: "var(--fomio-primary)",
    strokeWidth: "2.6",
    strokeLinecap: "round",
    fill: "none"
  })));
}
function Avatar({
  user,
  size = 32,
  ring
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      width: size,
      height: size,
      borderRadius: '50%',
      background: user.avatarBg,
      color: user.avatarFg,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontFamily: 'var(--fomio-serif)',
      fontWeight: 700,
      fontStyle: 'italic',
      fontSize: Math.round(size * 0.38),
      flexShrink: 0,
      userSelect: 'none',
      boxShadow: ring ? '0 0 0 2px var(--fomio-bg), 0 0 0 3.5px var(--fomio-primary)' : 'none'
    }
  }, user.initials);
}
function PresenceDot({
  size = 10
}) {
  return /*#__PURE__*/React.createElement("span", {
    style: {
      width: size,
      height: size,
      borderRadius: '50%',
      background: '#22C55E',
      border: '2px solid var(--fomio-card)',
      flexShrink: 0
    }
  });
}

/* Read-state indicator in the row gutter.
 *  unread>0  → terracotta dot     (tracked topic w/ unread replies)
 *  newPosts>0→ terracotta ring    (following, new since last read)
 *  unseen    → hollow ring         (brand-new topic, never opened)
 *  else      → nothing             (fully read)                       */
function ReadPip({
  topic,
  size = 8
}) {
  let node = null,
    label = 'Read';
  if (topic.unread > 0) {
    node = {
      bg: 'var(--fomio-primary)',
      border: 'none'
    };
    label = topic.unread + ' unread';
  } else if (topic.newPosts > 0) {
    node = {
      bg: 'transparent',
      border: '2px solid var(--fomio-primary)'
    };
    label = topic.newPosts + ' new';
  } else if (topic.unseen) {
    node = {
      bg: 'transparent',
      border: '2px solid var(--fomio-fg-muted)'
    };
    label = 'New topic';
  }
  return /*#__PURE__*/React.createElement("span", {
    title: label,
    "aria-label": label,
    style: {
      display: 'inline-flex',
      width: size,
      height: size
    }
  }, node && /*#__PURE__*/React.createElement("span", {
    style: {
      width: size,
      height: size,
      borderRadius: '50%',
      background: node.bg,
      border: node.border,
      display: 'block'
    }
  }));
}

/* Hub (category) badge — muted earth swatch + sans label; never terracotta. */
function HubBadge({
  hub,
  size = 'md'
}) {
  if (!hub) return null;
  const sm = size === 'sm';
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6,
      whiteSpace: 'nowrap'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: sm ? 7 : 8,
      height: sm ? 7 : 8,
      borderRadius: 2.5,
      background: hub.swatch,
      flexShrink: 0
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--fomio-sans)',
      fontWeight: 700,
      fontSize: sm ? 10.5 : 11.5,
      letterSpacing: '0.02em',
      color: 'var(--fomio-fg-secondary)'
    }
  }, hub.label));
}
function Tag({
  label
}) {
  return /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--fomio-mono)',
      fontSize: 11.5,
      color: 'var(--fomio-fg-muted)',
      whiteSpace: 'nowrap'
    }
  }, "#", label);
}
function Chip({
  label,
  icon,
  active,
  gated,
  dropdown,
  onClick,
  count
}) {
  return /*#__PURE__*/React.createElement("button", {
    onClick: onClick,
    "aria-pressed": active,
    style: {
      fontFamily: 'var(--fomio-sans)',
      fontWeight: 600,
      fontSize: 13,
      letterSpacing: '0.01em',
      height: 34,
      padding: '0 14px',
      borderRadius: 9999,
      border: `1.5px solid ${active ? 'var(--fomio-primary)' : 'var(--fomio-border)'}`,
      background: active ? 'var(--fomio-primary)' : 'transparent',
      color: active ? '#fff' : 'var(--fomio-fg)',
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6,
      whiteSpace: 'nowrap',
      cursor: 'pointer',
      transition: 'background 150ms, border-color 150ms'
    }
  }, icon && /*#__PURE__*/React.createElement(TIc, {
    name: icon,
    size: 14,
    color: active ? '#fff' : 'var(--fomio-fg-muted)',
    stroke: 2
  }), label, count != null && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--fomio-mono)',
      fontSize: 11,
      color: active ? 'rgba(255,255,255,0.85)' : 'var(--fomio-fg-muted)'
    }
  }, count), gated && /*#__PURE__*/React.createElement(TIc, {
    name: "lock",
    size: 12,
    color: active ? '#fff' : 'var(--fomio-fg-muted)',
    stroke: 2
  }), dropdown && /*#__PURE__*/React.createElement(TIc, {
    name: "chevronDown",
    size: 13,
    color: active ? '#fff' : 'var(--fomio-fg-muted)',
    stroke: 2
  }));
}
function MetaDot() {
  return /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--fomio-fg-muted)',
      fontSize: 11,
      lineHeight: 1,
      opacity: 0.7
    }
  }, "\xB7");
}
function Stat({
  icon,
  value,
  active,
  title
}) {
  const c = active ? 'var(--fomio-primary)' : 'var(--fomio-fg-muted)';
  return /*#__PURE__*/React.createElement("span", {
    title: title,
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 5,
      fontFamily: 'var(--fomio-sans)',
      fontSize: 12,
      fontWeight: 600,
      color: c
    }
  }, /*#__PURE__*/React.createElement(TIc, {
    name: icon,
    size: 15,
    color: c,
    stroke: 1.8,
    fill: active ? c : 'none'
  }), " ", value);
}

/* Overlapping participant stack (OP gets the terracotta ring). */
function PosterStack({
  posters,
  size = 26,
  max = 4
}) {
  const shown = posters.slice(0, max);
  const overflow = posters.length - shown.length;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center'
    }
  }, shown.map((p, i) => /*#__PURE__*/React.createElement("span", {
    key: i,
    title: '@' + p.user.username + (p.description ? ' · ' + p.description : ''),
    style: {
      marginLeft: i ? -size * 0.34 : 0,
      zIndex: shown.length - i,
      borderRadius: '50%',
      boxShadow: p.extras === 'original' ? '0 0 0 2px var(--fomio-card), 0 0 0 3.5px var(--fomio-primary)' : '0 0 0 2px var(--fomio-card)'
    }
  }, /*#__PURE__*/React.createElement(Avatar, {
    user: p.user,
    size: size
  }))), overflow > 0 && /*#__PURE__*/React.createElement("span", {
    style: {
      marginLeft: -size * 0.34,
      zIndex: 0,
      width: size,
      height: size,
      borderRadius: '50%',
      background: 'var(--fomio-surface)',
      boxShadow: '0 0 0 2px var(--fomio-card)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontFamily: 'var(--fomio-sans)',
      fontSize: size * 0.34,
      fontWeight: 700,
      color: 'var(--fomio-fg-muted)'
    }
  }, "+", overflow));
}

/* The dominant reply number in the ledger — serif, right-aligned. */
function BigCount({
  value,
  label,
  active
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'right',
      lineHeight: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--fomio-serif)',
      fontWeight: 700,
      fontSize: 22,
      letterSpacing: '-0.02em',
      color: active ? 'var(--fomio-primary)' : 'var(--fomio-fg)'
    }
  }, value), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--fomio-sans)',
      fontSize: 10,
      fontWeight: 600,
      letterSpacing: '0.06em',
      textTransform: 'uppercase',
      color: 'var(--fomio-fg-muted)',
      marginTop: 4
    }
  }, label));
}
function CoverStripe({
  height = 120,
  radius = 12,
  label = 'image'
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      height,
      borderRadius: radius,
      overflow: 'hidden',
      position: 'relative',
      background: 'var(--fomio-surface)',
      border: '1px solid var(--fomio-border)',
      backgroundImage: 'repeating-linear-gradient(135deg, transparent, transparent 9px, var(--fomio-border-soft) 9px, var(--fomio-border-soft) 10px)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--fomio-mono)',
      fontSize: 11,
      color: 'var(--fomio-fg-muted)',
      letterSpacing: '0.04em',
      background: 'var(--fomio-bg)',
      padding: '2px 8px',
      borderRadius: 6
    }
  }, label));
}
Object.assign(window, {
  TIc,
  FomioMark,
  Avatar,
  PresenceDot,
  ReadPip,
  HubBadge,
  Tag,
  Chip,
  MetaDot,
  Stat,
  PosterStack,
  BigCount,
  CoverStripe
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "topics-icons.jsx", error: String((e && e.message) || e) }); }

// topics-nav.jsx
try { (() => {
/* topics-nav.jsx — navigation for Topics: collapsible sidebar (full + rail)
 * with a live Hubs section, the floating profile entry point, the touch
 * bottom tab bar, and the touch header.
 * Exports: TopicsSidebar, FloatingProfile, BottomTabBar, TouchHeader.
 */
const {
  TIc,
  Avatar,
  PresenceDot,
  FomioMark
} = window;

/* ── Floating profile — the lifted, non-flat entry point ─────── */
function FloatingProfile({
  user,
  rail,
  loggedOut,
  active,
  onNav
}) {
  if (loggedOut) {
    if (rail) return /*#__PURE__*/React.createElement("button", {
      onClick: () => onNav('profile'),
      title: "Log in",
      className: "ft-profile",
      style: {
        margin: '0 auto',
        width: 44,
        height: 44,
        borderRadius: '50%',
        cursor: 'pointer',
        background: 'var(--fomio-card)',
        border: '1px solid var(--fomio-border)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        boxShadow: '0 6px 18px -6px var(--fomio-shadow)'
      }
    }, /*#__PURE__*/React.createElement(TIc, {
      name: "user",
      size: 20,
      color: "var(--fomio-fg-muted)",
      stroke: 1.8
    }));
    return /*#__PURE__*/React.createElement("button", {
      onClick: () => onNav('profile'),
      className: "ft-profile",
      style: {
        width: '100%',
        textAlign: 'left',
        cursor: 'pointer',
        borderRadius: 16,
        padding: '12px 14px',
        background: 'var(--fomio-card)',
        border: '1px solid var(--fomio-border)',
        boxShadow: '0 10px 28px -12px var(--fomio-shadow)',
        display: 'flex',
        alignItems: 'center',
        gap: 11,
        fontFamily: 'var(--fomio-sans)'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        width: 36,
        height: 36,
        borderRadius: '50%',
        background: 'var(--fomio-surface)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        flexShrink: 0
      }
    }, /*#__PURE__*/React.createElement(TIc, {
      name: "user",
      size: 18,
      color: "var(--fomio-fg-muted)",
      stroke: 1.8
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        minWidth: 0
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 13,
        fontWeight: 700,
        color: 'var(--fomio-fg)'
      }
    }, "Log in"), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 11.5,
        color: 'var(--fomio-fg-muted)'
      }
    }, "Read freely \xB7 write when ready")));
  }
  if (rail) return /*#__PURE__*/React.createElement("button", {
    onClick: () => onNav('profile'),
    title: user.name,
    className: "ft-profile",
    style: {
      position: 'relative',
      margin: '0 auto',
      width: 44,
      height: 44,
      borderRadius: '50%',
      cursor: 'pointer',
      border: 'none',
      padding: 0,
      background: 'transparent',
      boxShadow: active ? '0 0 0 2px var(--fomio-bg), 0 0 0 3.5px var(--fomio-primary)' : '0 8px 20px -6px var(--fomio-shadow)'
    }
  }, /*#__PURE__*/React.createElement(Avatar, {
    user: user,
    size: 44
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      right: -1,
      bottom: -1
    }
  }, /*#__PURE__*/React.createElement(PresenceDot, {
    size: 12
  })));
  return /*#__PURE__*/React.createElement("button", {
    onClick: () => onNav('profile'),
    className: "ft-profile",
    style: {
      width: '100%',
      textAlign: 'left',
      cursor: 'pointer',
      borderRadius: 16,
      padding: '11px 13px',
      background: 'var(--fomio-card)',
      border: `1px solid ${active ? 'var(--fomio-primary)' : 'var(--fomio-border)'}`,
      boxShadow: '0 12px 30px -14px var(--fomio-shadow)',
      display: 'flex',
      alignItems: 'center',
      gap: 11,
      fontFamily: 'var(--fomio-sans)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement(Avatar, {
    user: user,
    size: 38
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      right: -1,
      bottom: -1
    }
  }, /*#__PURE__*/React.createElement(PresenceDot, {
    size: 12
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13.5,
      fontWeight: 700,
      color: 'var(--fomio-fg)',
      overflow: 'hidden',
      textOverflow: 'ellipsis',
      whiteSpace: 'nowrap'
    }
  }, user.name), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 11.5,
      color: 'var(--fomio-fg-muted)'
    }
  }, "@", user.username)), /*#__PURE__*/React.createElement(TIc, {
    name: "settings",
    size: 16,
    color: "var(--fomio-fg-muted)",
    stroke: 1.7
  }));
}
function NavItem({
  icon,
  label,
  active,
  accent,
  badge,
  rail,
  dot,
  onClick
}) {
  const color = accent ? 'var(--fomio-primary)' : active ? 'var(--fomio-fg)' : 'var(--fomio-fg-muted)';
  return /*#__PURE__*/React.createElement("button", {
    onClick: onClick,
    className: "ft-navitem",
    title: rail ? label : undefined,
    style: {
      position: 'relative',
      display: 'flex',
      alignItems: 'center',
      gap: 12,
      width: '100%',
      padding: rail ? '11px 0' : '9px 12px',
      borderRadius: 10,
      cursor: 'pointer',
      border: 'none',
      justifyContent: rail ? 'center' : 'flex-start',
      background: active && !rail ? 'var(--fomio-surface)' : 'transparent',
      color,
      fontFamily: 'var(--fomio-sans)',
      fontSize: 14,
      fontWeight: active ? 600 : 500,
      transition: 'background 120ms'
    }
  }, active && rail && /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      left: 6,
      top: '50%',
      transform: 'translateY(-50%)',
      width: 3,
      height: 20,
      borderRadius: 2,
      background: 'var(--fomio-primary)'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'relative',
      display: 'flex'
    }
  }, /*#__PURE__*/React.createElement(TIc, {
    name: icon,
    size: 19,
    color: accent ? 'var(--fomio-primary)' : 'currentColor',
    stroke: 1.9,
    fill: active && !accent && icon === 'layers' ? 'none' : 'none'
  }), dot && /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      top: -2,
      right: -2,
      width: 8,
      height: 8,
      borderRadius: '50%',
      background: 'var(--fomio-primary)',
      border: '1.5px solid var(--fomio-bg)'
    }
  })), !rail && /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      textAlign: 'left'
    }
  }, label), !rail && badge ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--fomio-mono)',
      fontSize: 11,
      fontWeight: 700,
      color: '#fff',
      background: 'var(--fomio-primary)',
      padding: '1px 6px',
      borderRadius: 9999,
      minWidth: 18,
      textAlign: 'center'
    }
  }, badge) : null);
}
function SectionHeading({
  label,
  action
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      padding: '18px 12px 6px'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--fomio-sans)',
      fontSize: 10.5,
      fontWeight: 700,
      letterSpacing: '0.08em',
      textTransform: 'uppercase',
      color: 'var(--fomio-fg-muted)'
    }
  }, label), action && /*#__PURE__*/React.createElement("button", {
    className: "ft-edit",
    title: "Customize",
    style: {
      background: 'none',
      border: 'none',
      cursor: 'pointer',
      padding: 2,
      display: 'flex',
      color: 'var(--fomio-fg-muted)'
    }
  }, /*#__PURE__*/React.createElement(TIc, {
    name: "edit",
    size: 13,
    color: "currentColor",
    stroke: 1.8
  })));
}

/* ── Sidebar (full + rail) ───────────────────────────────────── */
function TopicsSidebar({
  data,
  rail,
  tab,
  activeHub,
  onNav,
  onToggleRail,
  loggedOut,
  canToggle
}) {
  const {
    user,
    navPrimary,
    userSections,
    hubs
  } = data;
  const W = rail ? 72 : 256;
  return /*#__PURE__*/React.createElement("aside", {
    style: {
      width: W,
      flexShrink: 0,
      height: '100vh',
      position: 'sticky',
      top: 0,
      background: 'var(--fomio-bg)',
      borderRight: '1px solid var(--fomio-border)',
      display: 'flex',
      flexDirection: 'column',
      boxSizing: 'border-box',
      padding: rail ? '20px 12px' : '20px 14px',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: rail ? 'center' : 'space-between',
      padding: rail ? '2px 0 18px' : '4px 8px 20px'
    }
  }, /*#__PURE__*/React.createElement(FomioMark, {
    size: rail ? 24 : 25,
    mark: rail
  }), !rail && canToggle && /*#__PURE__*/React.createElement("button", {
    onClick: onToggleRail,
    className: "ft-navitem",
    title: "Collapse to rail",
    style: {
      width: 28,
      height: 28,
      borderRadius: 8,
      border: 'none',
      cursor: 'pointer',
      background: 'transparent',
      color: 'var(--fomio-fg-muted)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center'
    }
  }, /*#__PURE__*/React.createElement(TIc, {
    name: "chevronsLeft",
    size: 17,
    color: "currentColor",
    stroke: 1.9
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minHeight: 0,
      overflowY: 'auto',
      overflowX: 'hidden',
      display: 'flex',
      flexDirection: 'column',
      gap: 2,
      scrollbarWidth: 'none'
    }
  }, navPrimary.map(n => /*#__PURE__*/React.createElement(NavItem, {
    key: n.key,
    icon: n.icon,
    label: n.label,
    accent: n.accent,
    rail: rail,
    active: !n.accent && tab === n.key && !activeHub,
    badge: !loggedOut && n.badgeKey ? user[n.badgeKey] : null,
    dot: rail && !loggedOut && n.badgeKey && user[n.badgeKey] > 0,
    onClick: () => onNav(n.key)
  })), !rail && /*#__PURE__*/React.createElement(SectionHeading, {
    label: "Hubs",
    action: true
  }), rail && /*#__PURE__*/React.createElement("div", {
    style: {
      height: 1,
      background: 'var(--fomio-border-soft)',
      margin: '10px 8px'
    }
  }), hubs.map(h => rail ? /*#__PURE__*/React.createElement("button", {
    key: h.key,
    onClick: () => onNav('hub:' + h.key),
    className: "ft-navitem",
    title: h.label,
    style: {
      display: 'flex',
      justifyContent: 'center',
      padding: '10px 0',
      borderRadius: 10,
      border: 'none',
      cursor: 'pointer',
      background: activeHub === h.key ? 'var(--fomio-surface)' : 'transparent'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 10,
      height: 10,
      borderRadius: 3,
      background: h.swatch
    }
  })) : /*#__PURE__*/React.createElement("button", {
    key: h.key,
    onClick: () => onNav('hub:' + h.key),
    className: "ft-navitem",
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 11,
      width: '100%',
      padding: '9px 12px',
      borderRadius: 10,
      cursor: 'pointer',
      border: 'none',
      background: activeHub === h.key ? 'var(--fomio-surface)' : 'transparent',
      fontFamily: 'var(--fomio-sans)',
      fontSize: 13.5,
      fontWeight: activeHub === h.key ? 600 : 500,
      color: 'var(--fomio-fg-muted)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 10,
      height: 10,
      borderRadius: 3,
      background: h.swatch,
      flexShrink: 0
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      textAlign: 'left',
      color: 'var(--fomio-fg)',
      overflow: 'hidden',
      textOverflow: 'ellipsis',
      whiteSpace: 'nowrap'
    }
  }, h.label), !loggedOut && h.unread > 0 ? /*#__PURE__*/React.createElement("span", {
    style: {
      width: 7,
      height: 7,
      borderRadius: '50%',
      background: 'var(--fomio-primary)'
    }
  }) : /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--fomio-mono)',
      fontSize: 11,
      color: 'var(--fomio-fg-muted)'
    }
  }, h.topics))), !rail && /*#__PURE__*/React.createElement(SectionHeading, {
    label: "Your sections",
    action: true
  }), userSections.map(s => /*#__PURE__*/React.createElement(NavItem, {
    key: s.key,
    icon: s.icon,
    label: s.label,
    rail: rail,
    active: tab === s.key,
    badge: !loggedOut && s.badgeKey ? user[s.badgeKey] : null,
    dot: rail && !loggedOut && s.badgeKey && user[s.badgeKey] > 0,
    onClick: () => onNav(s.key)
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      paddingTop: 14
    }
  }, /*#__PURE__*/React.createElement(FloatingProfile, {
    user: user,
    rail: rail,
    loggedOut: loggedOut,
    active: tab === 'profile',
    onNav: onNav
  })), rail && canToggle && /*#__PURE__*/React.createElement("button", {
    onClick: onToggleRail,
    className: "ft-navitem",
    title: "Expand sidebar",
    style: {
      marginTop: 12,
      width: '100%',
      height: 36,
      borderRadius: 10,
      border: 'none',
      cursor: 'pointer',
      background: 'transparent',
      color: 'var(--fomio-fg-muted)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center'
    }
  }, /*#__PURE__*/React.createElement(TIc, {
    name: "chevronRight",
    size: 18,
    color: "currentColor",
    stroke: 1.9
  })));
}

/* ── Touch header ────────────────────────────────────────────── */
function TouchHeader({
  subtitle,
  hidden
}) {
  return /*#__PURE__*/React.createElement("header", {
    style: {
      position: 'sticky',
      top: 0,
      zIndex: 40,
      background: 'color-mix(in srgb, var(--fomio-bg) 88%, transparent)',
      backdropFilter: 'blur(12px)',
      WebkitBackdropFilter: 'blur(12px)',
      borderBottom: '1px solid var(--fomio-border-soft)',
      padding: '14px 20px 12px',
      transform: hidden ? 'translateY(-100%)' : 'translateY(0)',
      transition: 'transform 260ms var(--fomio-ease, ease)'
    }
  }, /*#__PURE__*/React.createElement(FomioMark, {
    size: 26
  }), subtitle && /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 7,
      fontFamily: 'var(--fomio-sans)',
      fontSize: 11,
      fontWeight: 700,
      letterSpacing: '0.08em',
      textTransform: 'uppercase',
      color: 'var(--fomio-fg-muted)'
    }
  }, subtitle));
}

/* ── Bottom tab bar (glass) — hides on scroll down ───────────── */
function BottomTabBar({
  tab,
  onNav,
  user,
  hidden,
  loggedOut
}) {
  const items = [{
    key: 'home',
    label: 'Home',
    icon: 'home'
  }, {
    key: 'topics',
    label: 'Topics',
    icon: 'layers'
  }, {
    key: 'write',
    label: 'Write',
    icon: 'feather',
    center: true
  }, {
    key: 'notifications',
    label: 'Alerts',
    icon: 'bell',
    badge: loggedOut ? 0 : user.unreadNotifs
  }, {
    key: 'profile',
    label: 'You',
    icon: 'user',
    avatar: true
  }];
  return /*#__PURE__*/React.createElement("nav", {
    style: {
      position: 'fixed',
      left: 14,
      right: 14,
      bottom: 16,
      height: 66,
      zIndex: 60,
      borderRadius: 26,
      overflow: 'hidden',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-around',
      padding: '0 8px',
      background: 'color-mix(in srgb, var(--fomio-card) 74%, transparent)',
      backdropFilter: 'blur(22px) saturate(180%)',
      WebkitBackdropFilter: 'blur(22px) saturate(180%)',
      border: '1px solid var(--fomio-border-soft)',
      boxShadow: '0 12px 34px -10px var(--fomio-shadow)',
      transform: hidden ? 'translateY(140%)' : 'translateY(0)',
      transition: 'transform 300ms var(--fomio-ease, ease)'
    }
  }, items.map(it => {
    const active = it.key === tab;
    const col = active ? 'var(--fomio-primary)' : 'var(--fomio-fg-muted)';
    if (it.center) return /*#__PURE__*/React.createElement("button", {
      key: it.key,
      onClick: () => onNav(it.key),
      "aria-label": "Write",
      style: {
        width: 48,
        height: 48,
        borderRadius: 24,
        border: 'none',
        cursor: 'pointer',
        background: 'var(--fomio-primary)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        boxShadow: '0 6px 16px -3px color-mix(in srgb, var(--fomio-primary) 55%, transparent)'
      }
    }, /*#__PURE__*/React.createElement(TIc, {
      name: "feather",
      size: 22,
      color: "#fff",
      stroke: 2
    }));
    if (it.avatar) return /*#__PURE__*/React.createElement("button", {
      key: it.key,
      onClick: () => onNav(it.key),
      "aria-label": "You",
      style: {
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        gap: 3,
        background: 'none',
        border: 'none',
        cursor: 'pointer',
        padding: '0 8px'
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        position: 'relative',
        display: 'flex'
      }
    }, loggedOut ? /*#__PURE__*/React.createElement("span", {
      style: {
        width: 26,
        height: 26,
        borderRadius: '50%',
        background: 'var(--fomio-surface)',
        border: '1px solid var(--fomio-border)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center'
      }
    }, /*#__PURE__*/React.createElement(TIc, {
      name: "user",
      size: 16,
      color: col,
      stroke: 1.8
    })) : /*#__PURE__*/React.createElement("span", {
      style: {
        borderRadius: '50%',
        boxShadow: active ? '0 0 0 2px var(--fomio-card), 0 0 0 3.5px var(--fomio-primary)' : 'none'
      }
    }, /*#__PURE__*/React.createElement(Avatar, {
      user: user,
      size: 26
    })), !loggedOut && /*#__PURE__*/React.createElement("span", {
      style: {
        position: 'absolute',
        right: -2,
        bottom: -2
      }
    }, /*#__PURE__*/React.createElement(PresenceDot, {
      size: 9
    }))), /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--fomio-sans)',
        fontSize: 10,
        fontWeight: active ? 700 : 600,
        color: col
      }
    }, it.label));
    return /*#__PURE__*/React.createElement("button", {
      key: it.key,
      onClick: () => onNav(it.key),
      "aria-label": it.label,
      style: {
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        gap: 3,
        background: 'none',
        border: 'none',
        cursor: 'pointer',
        padding: '0 8px',
        position: 'relative'
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        position: 'relative',
        display: 'flex'
      }
    }, /*#__PURE__*/React.createElement(TIc, {
      name: it.icon,
      size: 22,
      color: col,
      stroke: 1.9
    }), it.badge > 0 && /*#__PURE__*/React.createElement("span", {
      style: {
        position: 'absolute',
        top: -5,
        right: -8,
        minWidth: 16,
        height: 16,
        borderRadius: 8,
        background: 'var(--fomio-primary)',
        color: '#fff',
        fontFamily: 'var(--fomio-sans)',
        fontSize: 9,
        fontWeight: 700,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '0 4px',
        border: '1.5px solid var(--fomio-card)'
      }
    }, it.badge)), /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--fomio-sans)',
        fontSize: 10,
        fontWeight: active ? 700 : 600,
        color: col
      }
    }, it.label));
  }));
}
Object.assign(window, {
  TopicsSidebar,
  FloatingProfile,
  BottomTabBar,
  TouchHeader
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "topics-nav.jsx", error: String((e && e.message) || e) }); }

// topics-reader.jsx
try { (() => {
/* topics-reader.jsx — the topic reading view (GET /t/:id → TopicViewSerializer).
 * Renders the OP + reply stream, participant rail, notification control,
 * moderation surface (revealed by role), permission gate (closed / logged out),
 * and long-content expand/collapse. Exports: TopicReader.
 */
const {
  TIc,
  Avatar,
  HubBadge,
  Tag,
  Stat,
  PosterStack,
  MetaDot
} = window;

/* ── Pinned / closed context banners ─────────────────────────── */
function TopicBanner({
  topic
}) {
  if (!topic.pinned && !topic.closed) return null;
  const icon = topic.closed ? 'lock' : 'pin';
  const text = topic.closed ? 'This topic is closed. It stays readable as a canonical reference — new replies are turned off.' : 'Pinned by moderators — kept at the top of its Hub for newcomers.';
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      padding: '10px 14px',
      background: 'var(--fomio-surface)',
      border: '1px solid var(--fomio-border)',
      borderRadius: 12,
      marginBottom: 20
    }
  }, /*#__PURE__*/React.createElement(TIc, {
    name: icon,
    size: 16,
    color: "var(--fomio-fg-muted)",
    stroke: 1.9
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--fomio-sans)',
      fontSize: 13,
      color: 'var(--fomio-fg-secondary)'
    }
  }, text));
}

/* ── Moderation surface — everyday vs management separated ────── */
function ModerationBar({
  topic
}) {
  const mgmt = [{
    icon: topic.closed ? 'lock' : 'lock',
    label: topic.closed ? 'Reopen' : 'Close'
  }, {
    icon: 'pin',
    label: topic.pinned ? 'Unpin' : 'Pin'
  }, {
    icon: 'tag',
    label: 'Edit tags'
  }, {
    icon: 'columns',
    label: 'Split'
  }, {
    icon: 'shield',
    label: 'Review flags',
    badge: 2
  }];
  return /*#__PURE__*/React.createElement("div", {
    role: "region",
    "aria-label": "Moderation tools",
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      flexWrap: 'wrap',
      padding: '11px 14px',
      marginBottom: 20,
      borderRadius: 12,
      background: 'var(--fomio-card)',
      border: '1px dashed var(--fomio-primary)',
      boxShadow: '0 1px 0 var(--fomio-border-soft)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 7,
      fontFamily: 'var(--fomio-sans)',
      fontSize: 11,
      fontWeight: 700,
      letterSpacing: '0.06em',
      textTransform: 'uppercase',
      color: 'var(--fomio-primary-dark)'
    }
  }, /*#__PURE__*/React.createElement(TIc, {
    name: "shield",
    size: 14,
    color: "var(--fomio-primary-dark)",
    stroke: 2
  }), " Moderator"), /*#__PURE__*/React.createElement("span", {
    style: {
      width: 1,
      height: 20,
      background: 'var(--fomio-border)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 6,
      flexWrap: 'wrap'
    }
  }, mgmt.map(m => /*#__PURE__*/React.createElement("button", {
    key: m.label,
    className: "ft-modbtn",
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6,
      height: 32,
      padding: '0 12px',
      borderRadius: 9999,
      cursor: 'pointer',
      background: 'transparent',
      border: '1px solid var(--fomio-border)',
      fontFamily: 'var(--fomio-sans)',
      fontSize: 12.5,
      fontWeight: 600,
      color: 'var(--fomio-fg-secondary)'
    }
  }, /*#__PURE__*/React.createElement(TIc, {
    name: m.icon,
    size: 14,
    color: "var(--fomio-fg-muted)",
    stroke: 1.9
  }), " ", m.label, m.badge && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--fomio-mono)',
      fontSize: 10.5,
      fontWeight: 700,
      color: '#fff',
      background: 'var(--fomio-primary)',
      padding: '0 5px',
      borderRadius: 9999
    }
  }, m.badge)))));
}

/* ── A single post in the stream ─────────────────────────────── */
function Post({
  post,
  isOP,
  stream,
  expanded,
  onToggle
}) {
  const paras = post.paragraphs;
  const clamp = isOP && post.long && !expanded;
  const shown = clamp ? paras.slice(0, 2) : paras;
  const replyTo = post.replyToPostNumber != null ? stream.find(p => p.postNumber === post.replyToPostNumber) : null;
  return /*#__PURE__*/React.createElement("article", {
    id: 'post-' + post.postNumber,
    style: {
      display: 'flex',
      gap: 14,
      alignItems: 'flex-start',
      padding: isOP ? '0 0 26px' : '24px 0',
      borderBottom: '1px solid var(--fomio-border)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement(Avatar, {
    user: post.user,
    size: isOP ? 44 : 38,
    ring: isOP
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      marginBottom: post.moderatorPost ? 8 : 10,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--fomio-sans)',
      fontWeight: 700,
      fontSize: 14,
      color: 'var(--fomio-fg)'
    }
  }, post.user.name), post.userTitle && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--fomio-sans)',
      fontSize: 11,
      fontWeight: 600,
      color: 'var(--fomio-fg-muted)'
    }
  }, post.userTitle), post.moderatorPost && /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 4,
      fontFamily: 'var(--fomio-sans)',
      fontSize: 10.5,
      fontWeight: 700,
      letterSpacing: '0.04em',
      textTransform: 'uppercase',
      color: 'var(--fomio-primary-dark)',
      background: 'var(--fomio-primary-soft)',
      padding: '2px 7px',
      borderRadius: 9999
    }
  }, /*#__PURE__*/React.createElement(TIc, {
    name: "shield",
    size: 11,
    color: "var(--fomio-primary-dark)",
    stroke: 2
  }), " Staff"), /*#__PURE__*/React.createElement("span", {
    style: {
      marginLeft: 'auto',
      display: 'inline-flex',
      alignItems: 'center',
      gap: 8,
      fontFamily: 'var(--fomio-sans)',
      fontSize: 11.5,
      color: 'var(--fomio-fg-muted)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--fomio-mono)'
    }
  }, "#", post.postNumber), /*#__PURE__*/React.createElement(MetaDot, null), post.createdAgo)), replyTo && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6,
      marginBottom: 9,
      padding: '3px 9px',
      borderRadius: 9999,
      background: 'var(--fomio-surface)',
      fontFamily: 'var(--fomio-sans)',
      fontSize: 11.5,
      color: 'var(--fomio-fg-muted)'
    }
  }, /*#__PURE__*/React.createElement(TIc, {
    name: "reply",
    size: 12,
    color: "var(--fomio-fg-muted)",
    stroke: 1.9
  }), "replying to ", /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 600,
      color: 'var(--fomio-fg-secondary)'
    }
  }, "@", replyTo.user.username), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--fomio-mono)'
    }
  }, "#", replyTo.postNumber)), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--fomio-serif)',
      fontSize: isOP ? 17.5 : 16,
      lineHeight: 1.68,
      color: 'var(--fomio-fg)'
    }
  }, shown.map((p, i) => /*#__PURE__*/React.createElement("p", {
    key: i,
    style: {
      margin: i ? '0.9em 0 0' : 0
    }
  }, p))), clamp && /*#__PURE__*/React.createElement("button", {
    onClick: onToggle,
    className: "ft-textbtn",
    style: {
      marginTop: 12,
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6,
      background: 'none',
      border: 'none',
      cursor: 'pointer',
      fontFamily: 'var(--fomio-sans)',
      fontSize: 13,
      fontWeight: 700,
      color: 'var(--fomio-primary)'
    }
  }, /*#__PURE__*/React.createElement(TIc, {
    name: "chevronDown",
    size: 15,
    color: "var(--fomio-primary)",
    stroke: 2
  }), "Continue reading \xB7 ", paras.length - 2, " more ", paras.length - 2 === 1 ? 'paragraph' : 'paragraphs'), isOP && expanded && post.long && /*#__PURE__*/React.createElement("button", {
    onClick: onToggle,
    className: "ft-textbtn",
    style: {
      marginTop: 12,
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6,
      background: 'none',
      border: 'none',
      cursor: 'pointer',
      fontFamily: 'var(--fomio-sans)',
      fontSize: 13,
      fontWeight: 700,
      color: 'var(--fomio-fg-muted)'
    }
  }, /*#__PURE__*/React.createElement(TIc, {
    name: "chevronDown",
    size: 15,
    color: "var(--fomio-fg-muted)",
    stroke: 2,
    style: {
      transform: 'rotate(180deg)'
    }
  }), " Collapse"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 18,
      marginTop: 16
    }
  }, /*#__PURE__*/React.createElement("button", {
    className: "ft-postact",
    style: postAct(post.acted)
  }, /*#__PURE__*/React.createElement(TIc, {
    name: "heart",
    size: 15,
    color: post.acted ? 'var(--fomio-primary)' : 'var(--fomio-fg-muted)',
    stroke: 1.8,
    fill: post.acted ? 'var(--fomio-primary)' : 'none'
  }), " ", post.likeCount), /*#__PURE__*/React.createElement("button", {
    className: "ft-postact",
    style: postAct(false)
  }, /*#__PURE__*/React.createElement(TIc, {
    name: "reply",
    size: 15,
    color: "var(--fomio-fg-muted)",
    stroke: 1.8
  }), " Reply"), post.replyCount > 0 && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--fomio-sans)',
      fontSize: 12,
      color: 'var(--fomio-fg-muted)'
    }
  }, post.replyCount, " ", post.replyCount === 1 ? 'reply' : 'replies'), /*#__PURE__*/React.createElement("button", {
    className: "ft-postact",
    title: "More",
    style: {
      ...postAct(false),
      marginLeft: 'auto'
    }
  }, /*#__PURE__*/React.createElement(TIc, {
    name: "more",
    size: 16,
    color: "var(--fomio-fg-muted)",
    stroke: 2
  })))));
}
function postAct(active) {
  return {
    display: 'inline-flex',
    alignItems: 'center',
    gap: 6,
    background: 'none',
    border: 'none',
    cursor: 'pointer',
    padding: 0,
    fontFamily: 'var(--fomio-sans)',
    fontSize: 12.5,
    fontWeight: 600,
    color: active ? 'var(--fomio-primary)' : 'var(--fomio-fg-muted)'
  };
}

/* ── Reply composer dock OR permission notice ────────────────── */
function ReplyDock({
  topic,
  loggedOut
}) {
  if (loggedOut) {
    return /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 12,
        padding: '14px 16px',
        borderRadius: 14,
        background: 'var(--fomio-card)',
        border: '1px solid var(--fomio-border)'
      }
    }, /*#__PURE__*/React.createElement(TIc, {
      name: "lock",
      size: 17,
      color: "var(--fomio-fg-muted)",
      stroke: 1.8
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        flex: 1,
        fontFamily: 'var(--fomio-serif)',
        fontSize: 14.5,
        color: 'var(--fomio-fg-secondary)'
      }
    }, "Log in to reply \u2014 reading stays open to everyone."), /*#__PURE__*/React.createElement("button", {
      style: dockBtn()
    }, "Log in"));
  }
  if (topic.closed) {
    return /*#__PURE__*/React.createElement("div", {
      role: "note",
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 12,
        padding: '14px 16px',
        borderRadius: 14,
        background: 'var(--fomio-surface)',
        border: '1px solid var(--fomio-border)'
      }
    }, /*#__PURE__*/React.createElement(TIc, {
      name: "lock",
      size: 17,
      color: "var(--fomio-fg-muted)",
      stroke: 1.8
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        flex: 1,
        fontFamily: 'var(--fomio-serif)',
        fontSize: 14.5,
        color: 'var(--fomio-fg-secondary)'
      }
    }, "This topic is closed to new replies. You can still react and bookmark."));
  }
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12,
      padding: '10px 12px 10px 16px',
      borderRadius: 14,
      background: 'var(--fomio-card)',
      border: '1px solid var(--fomio-border)',
      boxShadow: '0 8px 24px -16px var(--fomio-shadow)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      fontFamily: 'var(--fomio-serif)',
      fontSize: 15,
      color: 'var(--fomio-fg-muted)',
      fontStyle: 'italic'
    }
  }, "Add to the conversation\u2026"), /*#__PURE__*/React.createElement("button", {
    style: dockBtn()
  }, /*#__PURE__*/React.createElement(TIc, {
    name: "feather",
    size: 16,
    color: "#fff",
    stroke: 1.9
  }), " Reply"));
}
function dockBtn() {
  return {
    height: 40,
    padding: '0 18px',
    borderRadius: 9999,
    background: 'var(--fomio-primary)',
    color: '#fff',
    border: 'none',
    cursor: 'pointer',
    fontFamily: 'var(--fomio-sans)',
    fontWeight: 700,
    fontSize: 13.5,
    display: 'inline-flex',
    alignItems: 'center',
    gap: 7,
    flexShrink: 0
  };
}

/* ── Right rail — participants, notification level, suggested ─── */
const NOTIF_OPTS = [{
  level: 3,
  icon: 'eye',
  label: 'Watching'
}, {
  level: 2,
  icon: 'bell',
  label: 'Tracking'
}, {
  level: 1,
  icon: 'checkCircle',
  label: 'Normal'
}, {
  level: 0,
  icon: 'x',
  label: 'Muted'
}];
function ParticipantRail({
  topic,
  view,
  onOpenSuggested
}) {
  const d = topic.details;
  const cur = NOTIF_OPTS.find(o => o.level === d.notificationLevel) || NOTIF_OPTS[2];
  return /*#__PURE__*/React.createElement("aside", {
    style: {
      width: 236,
      flexShrink: 0,
      display: 'flex',
      flexDirection: 'column',
      gap: 26,
      position: 'sticky',
      top: 24,
      alignSelf: 'flex-start'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(RailHead, {
    label: "Notifications"
  }), /*#__PURE__*/React.createElement("button", {
    className: "ft-navitem",
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      width: '100%',
      height: 40,
      padding: '0 12px',
      borderRadius: 10,
      border: '1px solid var(--fomio-border)',
      cursor: 'pointer',
      background: 'var(--fomio-card)',
      fontFamily: 'var(--fomio-sans)',
      fontSize: 13.5,
      fontWeight: 600,
      color: 'var(--fomio-fg)'
    }
  }, /*#__PURE__*/React.createElement(TIc, {
    name: cur.icon,
    size: 16,
    color: "var(--fomio-primary)",
    stroke: 1.9
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      textAlign: 'left'
    }
  }, cur.label), /*#__PURE__*/React.createElement(TIc, {
    name: "chevronDown",
    size: 15,
    color: "var(--fomio-fg-muted)",
    stroke: 2
  })), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '8px 2px 0',
      fontFamily: 'var(--fomio-serif)',
      fontSize: 12.5,
      lineHeight: 1.5,
      color: 'var(--fomio-fg-muted)'
    }
  }, "Watching \u2014 you\u2019ll be notified of every reply.")), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(RailHead, {
    label: `Participants · ${d.participants.length}`
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 4
    }
  }, d.participants.map(p => /*#__PURE__*/React.createElement("div", {
    key: p.username,
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      padding: '5px 4px'
    }
  }, /*#__PURE__*/React.createElement(Avatar, {
    user: p,
    size: 26
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      minWidth: 0,
      fontFamily: 'var(--fomio-sans)',
      fontSize: 13,
      fontWeight: 600,
      color: 'var(--fomio-fg)',
      overflow: 'hidden',
      textOverflow: 'ellipsis',
      whiteSpace: 'nowrap'
    }
  }, "@", p.username, p.primaryGroup === 'moderators' && /*#__PURE__*/React.createElement("span", {
    style: {
      marginLeft: 6,
      fontSize: 10,
      fontWeight: 700,
      letterSpacing: '0.04em',
      textTransform: 'uppercase',
      color: 'var(--fomio-primary-dark)'
    }
  }, "mod")), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--fomio-mono)',
      fontSize: 12,
      color: 'var(--fomio-fg-muted)'
    }
  }, p.postCount))))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(RailHead, {
    label: "Suggested"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column'
    }
  }, view.suggestedTopics.map(s => /*#__PURE__*/React.createElement("button", {
    key: s.id,
    onClick: () => onOpenSuggested(s.id),
    className: "ft-row",
    style: {
      textAlign: 'left',
      background: 'none',
      border: 'none',
      borderBottom: '1px solid var(--fomio-border)',
      cursor: 'pointer',
      padding: '11px 4px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--fomio-serif)',
      fontWeight: 600,
      fontSize: 14,
      lineHeight: 1.35,
      letterSpacing: '-0.01em',
      color: 'var(--fomio-fg)',
      marginBottom: 5
    }
  }, s.title), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--fomio-sans)',
      fontSize: 11.5,
      color: 'var(--fomio-fg-muted)'
    }
  }, s.postsCount, " replies"))))));
}
function RailHead({
  label
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--fomio-sans)',
      fontSize: 10.5,
      fontWeight: 700,
      letterSpacing: '0.08em',
      textTransform: 'uppercase',
      color: 'var(--fomio-fg-muted)',
      marginBottom: 12
    }
  }, label);
}

/* ── The reader shell ────────────────────────────────────────── */
function TopicReader({
  view,
  hubs,
  onBack,
  onOpenSuggested,
  isModerator,
  loggedOut,
  mode
}) {
  const [expanded, setExpanded] = React.useState(false);
  const t = view.topic;
  const hub = hubs.find(h => h.key === t.hub);
  const wide = mode === 'expanded' || mode === 'compact-desktop';
  const touch = mode === 'touch';
  const posts = view.postStream.posts;
  const gap = t.highestPostNumber - posts[1].postNumber > 30;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 44,
      alignItems: 'flex-start'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0,
      maxWidth: 720
    }
  }, /*#__PURE__*/React.createElement("button", {
    onClick: onBack,
    className: "ft-textbtn",
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 7,
      background: 'none',
      border: 'none',
      cursor: 'pointer',
      padding: '0 0 20px',
      fontFamily: 'var(--fomio-sans)',
      fontSize: 13,
      fontWeight: 600,
      color: 'var(--fomio-fg-muted)'
    }
  }, /*#__PURE__*/React.createElement(TIc, {
    name: "arrowLeft",
    size: 17,
    color: "var(--fomio-fg-muted)",
    stroke: 1.9
  }), " All topics"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      marginBottom: 14,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(HubBadge, {
    hub: hub
  }), /*#__PURE__*/React.createElement(MetaDot, null), t.tags.map(tg => /*#__PURE__*/React.createElement(Tag, {
    key: tg,
    label: tg
  })), t.hasSummary && /*#__PURE__*/React.createElement("button", {
    className: "ft-textbtn",
    style: {
      marginLeft: 'auto',
      display: 'inline-flex',
      alignItems: 'center',
      gap: 5,
      background: 'none',
      border: 'none',
      cursor: 'pointer',
      fontFamily: 'var(--fomio-sans)',
      fontSize: 12,
      fontWeight: 700,
      color: 'var(--fomio-primary)'
    }
  }, /*#__PURE__*/React.createElement(TIc, {
    name: "sparkle",
    size: 14,
    color: "var(--fomio-primary)",
    stroke: 1.9
  }), " Summarize")), /*#__PURE__*/React.createElement("h1", {
    style: {
      margin: '0 0 16px',
      fontFamily: 'var(--fomio-serif)',
      fontWeight: 700,
      fontSize: touch ? 27 : 34,
      lineHeight: 1.14,
      letterSpacing: '-0.03em',
      color: 'var(--fomio-fg)',
      textWrap: 'balance'
    },
    dangerouslySetInnerHTML: {
      __html: t.fancyTitle
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 16,
      flexWrap: 'wrap',
      marginBottom: 24,
      paddingBottom: 22,
      borderBottom: '1px solid var(--fomio-border)'
    }
  }, /*#__PURE__*/React.createElement(Stat, {
    icon: "messages",
    value: `${t.replyCount} replies`
  }), /*#__PURE__*/React.createElement(Stat, {
    icon: "user",
    value: `${t.participantCount} people`
  }), /*#__PURE__*/React.createElement(Stat, {
    icon: "heart",
    value: t.likeCount
  }), /*#__PURE__*/React.createElement(Stat, {
    icon: "eye",
    value: t.views.toLocaleString()
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--fomio-sans)',
      fontSize: 12,
      color: 'var(--fomio-fg-muted)'
    }
  }, "started ", t.createdAgo)), /*#__PURE__*/React.createElement(TopicBanner, {
    topic: t
  }), isModerator && /*#__PURE__*/React.createElement(ModerationBar, {
    topic: t
  }), /*#__PURE__*/React.createElement(Post, {
    post: posts[0],
    isOP: true,
    stream: posts,
    expanded: expanded,
    onToggle: () => setExpanded(e => !e)
  }), gap && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12,
      padding: '18px 0'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      height: 1,
      flex: 1,
      background: 'var(--fomio-border)'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--fomio-sans)',
      fontSize: 11.5,
      fontWeight: 600,
      color: 'var(--fomio-fg-muted)',
      whiteSpace: 'nowrap'
    }
  }, t.highestPostNumber - posts.length, " earlier replies \xB7 jump to your last read"), /*#__PURE__*/React.createElement("span", {
    style: {
      height: 1,
      flex: 1,
      background: 'var(--fomio-border)'
    }
  })), posts.slice(1).map(p => /*#__PURE__*/React.createElement(Post, {
    key: p.postNumber,
    post: p,
    stream: posts
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 24
    }
  }, /*#__PURE__*/React.createElement(ReplyDock, {
    topic: t,
    loggedOut: loggedOut
  })), !wide && /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 34
    }
  }, /*#__PURE__*/React.createElement(RailHead, {
    label: "Suggested topics"
  }), view.suggestedTopics.map(s => /*#__PURE__*/React.createElement("button", {
    key: s.id,
    onClick: () => onOpenSuggested(s.id),
    className: "ft-row",
    style: {
      display: 'block',
      width: '100%',
      textAlign: 'left',
      background: 'none',
      border: 'none',
      borderBottom: '1px solid var(--fomio-border)',
      cursor: 'pointer',
      padding: '14px 4px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--fomio-serif)',
      fontWeight: 700,
      fontSize: 16,
      letterSpacing: '-0.01em',
      color: 'var(--fomio-fg)',
      marginBottom: 5
    }
  }, s.title), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--fomio-sans)',
      fontSize: 12,
      color: 'var(--fomio-fg-muted)'
    }
  }, s.postsCount, " replies"))))), wide && /*#__PURE__*/React.createElement(ParticipantRail, {
    topic: t,
    view: view,
    onOpenSuggested: onOpenSuggested
  }));
}
window.TopicReader = TopicReader;
})(); } catch (e) { __ds_ns.__errors.push({ path: "topics-reader.jsx", error: String((e && e.message) || e) }); }

// tweaks-panel.jsx
try { (() => {
// tweaks-panel.jsx
// Reusable Tweaks shell + form-control helpers.
//
// Owns the host protocol (listens for __activate_edit_mode / __deactivate_edit_mode,
// posts __edit_mode_available / __edit_mode_set_keys / __edit_mode_dismissed) so
// individual prototypes don't re-roll it. Ships a consistent set of controls so you
// don't hand-draw <input type="range">, segmented radios, steppers, etc.
//
// Usage (in an HTML file that loads React + Babel):
//
//   const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
//     "primaryColor": "#D97757",
//     "fontSize": 16,
//     "density": "regular",
//     "dark": false
//   }/*EDITMODE-END*/;
//
//   function App() {
//     const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);
//     return (
//       <div style={{ fontSize: t.fontSize, color: t.primaryColor }}>
//         Hello
//         <TweaksPanel>
//           <TweakSection label="Typography" />
//           <TweakSlider label="Font size" value={t.fontSize} min={10} max={32} unit="px"
//                        onChange={(v) => setTweak('fontSize', v)} />
//           <TweakRadio  label="Density" value={t.density}
//                        options={['compact', 'regular', 'comfy']}
//                        onChange={(v) => setTweak('density', v)} />
//           <TweakSection label="Theme" />
//           <TweakColor  label="Primary" value={t.primaryColor}
//                        onChange={(v) => setTweak('primaryColor', v)} />
//           <TweakToggle label="Dark mode" value={t.dark}
//                        onChange={(v) => setTweak('dark', v)} />
//         </TweaksPanel>
//       </div>
//     );
//   }
//
// ─────────────────────────────────────────────────────────────────────────────

const __TWEAKS_STYLE = `
  .twk-panel{position:fixed;right:16px;bottom:16px;z-index:2147483646;width:280px;
    max-height:calc(100vh - 32px);display:flex;flex-direction:column;
    background:rgba(250,249,247,.78);color:#29261b;
    -webkit-backdrop-filter:blur(24px) saturate(160%);backdrop-filter:blur(24px) saturate(160%);
    border:.5px solid rgba(255,255,255,.6);border-radius:14px;
    box-shadow:0 1px 0 rgba(255,255,255,.5) inset,0 12px 40px rgba(0,0,0,.18);
    font:11.5px/1.4 ui-sans-serif,system-ui,-apple-system,sans-serif;overflow:hidden}
  .twk-hd{display:flex;align-items:center;justify-content:space-between;
    padding:10px 8px 10px 14px;cursor:move;user-select:none}
  .twk-hd b{font-size:12px;font-weight:600;letter-spacing:.01em}
  .twk-x{appearance:none;border:0;background:transparent;color:rgba(41,38,27,.55);
    width:22px;height:22px;border-radius:6px;cursor:default;font-size:13px;line-height:1}
  .twk-x:hover{background:rgba(0,0,0,.06);color:#29261b}
  .twk-body{padding:2px 14px 14px;display:flex;flex-direction:column;gap:10px;
    overflow-y:auto;overflow-x:hidden;min-height:0;
    scrollbar-width:thin;scrollbar-color:rgba(0,0,0,.15) transparent}
  .twk-body::-webkit-scrollbar{width:8px}
  .twk-body::-webkit-scrollbar-track{background:transparent;margin:2px}
  .twk-body::-webkit-scrollbar-thumb{background:rgba(0,0,0,.15);border-radius:4px;
    border:2px solid transparent;background-clip:content-box}
  .twk-body::-webkit-scrollbar-thumb:hover{background:rgba(0,0,0,.25);
    border:2px solid transparent;background-clip:content-box}
  .twk-row{display:flex;flex-direction:column;gap:5px}
  .twk-row-h{flex-direction:row;align-items:center;justify-content:space-between;gap:10px}
  .twk-lbl{display:flex;justify-content:space-between;align-items:baseline;
    color:rgba(41,38,27,.72)}
  .twk-lbl>span:first-child{font-weight:500}
  .twk-val{color:rgba(41,38,27,.5);font-variant-numeric:tabular-nums}

  .twk-sect{font-size:10px;font-weight:600;letter-spacing:.06em;text-transform:uppercase;
    color:rgba(41,38,27,.45);padding:10px 0 0}
  .twk-sect:first-child{padding-top:0}

  .twk-field{appearance:none;width:100%;height:26px;padding:0 8px;
    border:.5px solid rgba(0,0,0,.1);border-radius:7px;
    background:rgba(255,255,255,.6);color:inherit;font:inherit;outline:none}
  .twk-field:focus{border-color:rgba(0,0,0,.25);background:rgba(255,255,255,.85)}
  select.twk-field{padding-right:22px;
    background-image:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='10' height='6' viewBox='0 0 10 6'><path fill='rgba(0,0,0,.5)' d='M0 0h10L5 6z'/></svg>");
    background-repeat:no-repeat;background-position:right 8px center}

  .twk-slider{appearance:none;-webkit-appearance:none;width:100%;height:4px;margin:6px 0;
    border-radius:999px;background:rgba(0,0,0,.12);outline:none}
  .twk-slider::-webkit-slider-thumb{-webkit-appearance:none;appearance:none;
    width:14px;height:14px;border-radius:50%;background:#fff;
    border:.5px solid rgba(0,0,0,.12);box-shadow:0 1px 3px rgba(0,0,0,.2);cursor:default}
  .twk-slider::-moz-range-thumb{width:14px;height:14px;border-radius:50%;
    background:#fff;border:.5px solid rgba(0,0,0,.12);box-shadow:0 1px 3px rgba(0,0,0,.2);cursor:default}

  .twk-seg{position:relative;display:flex;padding:2px;border-radius:8px;
    background:rgba(0,0,0,.06);user-select:none}
  .twk-seg-thumb{position:absolute;top:2px;bottom:2px;border-radius:6px;
    background:rgba(255,255,255,.9);box-shadow:0 1px 2px rgba(0,0,0,.12);
    transition:left .15s cubic-bezier(.3,.7,.4,1),width .15s}
  .twk-seg.dragging .twk-seg-thumb{transition:none}
  .twk-seg button{appearance:none;position:relative;z-index:1;flex:1;border:0;
    background:transparent;color:inherit;font:inherit;font-weight:500;min-height:22px;
    border-radius:6px;cursor:default;padding:4px 6px;line-height:1.2;
    overflow-wrap:anywhere}

  .twk-toggle{position:relative;width:32px;height:18px;border:0;border-radius:999px;
    background:rgba(0,0,0,.15);transition:background .15s;cursor:default;padding:0}
  .twk-toggle[data-on="1"]{background:#34c759}
  .twk-toggle i{position:absolute;top:2px;left:2px;width:14px;height:14px;border-radius:50%;
    background:#fff;box-shadow:0 1px 2px rgba(0,0,0,.25);transition:transform .15s}
  .twk-toggle[data-on="1"] i{transform:translateX(14px)}

  .twk-num{display:flex;align-items:center;height:26px;padding:0 0 0 8px;
    border:.5px solid rgba(0,0,0,.1);border-radius:7px;background:rgba(255,255,255,.6)}
  .twk-num-lbl{font-weight:500;color:rgba(41,38,27,.6);cursor:ew-resize;
    user-select:none;padding-right:8px}
  .twk-num input{flex:1;min-width:0;height:100%;border:0;background:transparent;
    font:inherit;font-variant-numeric:tabular-nums;text-align:right;padding:0 8px 0 0;
    outline:none;color:inherit;-moz-appearance:textfield}
  .twk-num input::-webkit-inner-spin-button,.twk-num input::-webkit-outer-spin-button{
    -webkit-appearance:none;margin:0}
  .twk-num-unit{padding-right:8px;color:rgba(41,38,27,.45)}

  .twk-btn{appearance:none;height:26px;padding:0 12px;border:0;border-radius:7px;
    background:rgba(0,0,0,.78);color:#fff;font:inherit;font-weight:500;cursor:default}
  .twk-btn:hover{background:rgba(0,0,0,.88)}
  .twk-btn.secondary{background:rgba(0,0,0,.06);color:inherit}
  .twk-btn.secondary:hover{background:rgba(0,0,0,.1)}

  .twk-swatch{appearance:none;-webkit-appearance:none;width:56px;height:22px;
    border:.5px solid rgba(0,0,0,.1);border-radius:6px;padding:0;cursor:default;
    background:transparent;flex-shrink:0}
  .twk-swatch::-webkit-color-swatch-wrapper{padding:0}
  .twk-swatch::-webkit-color-swatch{border:0;border-radius:5.5px}
  .twk-swatch::-moz-color-swatch{border:0;border-radius:5.5px}
`;

// ── useTweaks ───────────────────────────────────────────────────────────────
// Single source of truth for tweak values. setTweak persists via the host
// (__edit_mode_set_keys → host rewrites the EDITMODE block on disk).
function useTweaks(defaults) {
  const [values, setValues] = React.useState(defaults);
  // Accepts either setTweak('key', value) or setTweak({ key: value, ... }) so a
  // useState-style call doesn't write a "[object Object]" key into the persisted
  // JSON block.
  const setTweak = React.useCallback((keyOrEdits, val) => {
    const edits = typeof keyOrEdits === 'object' && keyOrEdits !== null ? keyOrEdits : {
      [keyOrEdits]: val
    };
    setValues(prev => ({
      ...prev,
      ...edits
    }));
    window.parent.postMessage({
      type: '__edit_mode_set_keys',
      edits
    }, '*');
  }, []);
  return [values, setTweak];
}

// ── TweaksPanel ─────────────────────────────────────────────────────────────
// Floating shell. Registers the protocol listener BEFORE announcing
// availability — if the announce ran first, the host's activate could land
// before our handler exists and the toolbar toggle would silently no-op.
// The close button posts __edit_mode_dismissed so the host's toolbar toggle
// flips off in lockstep; the host echoes __deactivate_edit_mode back which
// is what actually hides the panel.
function TweaksPanel({
  title = 'Tweaks',
  children
}) {
  const [open, setOpen] = React.useState(false);
  const dragRef = React.useRef(null);
  const offsetRef = React.useRef({
    x: 16,
    y: 16
  });
  const PAD = 16;
  const clampToViewport = React.useCallback(() => {
    const panel = dragRef.current;
    if (!panel) return;
    const w = panel.offsetWidth,
      h = panel.offsetHeight;
    const maxRight = Math.max(PAD, window.innerWidth - w - PAD);
    const maxBottom = Math.max(PAD, window.innerHeight - h - PAD);
    offsetRef.current = {
      x: Math.min(maxRight, Math.max(PAD, offsetRef.current.x)),
      y: Math.min(maxBottom, Math.max(PAD, offsetRef.current.y))
    };
    panel.style.right = offsetRef.current.x + 'px';
    panel.style.bottom = offsetRef.current.y + 'px';
  }, []);
  React.useEffect(() => {
    if (!open) return;
    clampToViewport();
    if (typeof ResizeObserver === 'undefined') {
      window.addEventListener('resize', clampToViewport);
      return () => window.removeEventListener('resize', clampToViewport);
    }
    const ro = new ResizeObserver(clampToViewport);
    ro.observe(document.documentElement);
    return () => ro.disconnect();
  }, [open, clampToViewport]);
  React.useEffect(() => {
    const onMsg = e => {
      const t = e?.data?.type;
      if (t === '__activate_edit_mode') setOpen(true);else if (t === '__deactivate_edit_mode') setOpen(false);
    };
    window.addEventListener('message', onMsg);
    window.parent.postMessage({
      type: '__edit_mode_available'
    }, '*');
    return () => window.removeEventListener('message', onMsg);
  }, []);
  const dismiss = () => {
    setOpen(false);
    window.parent.postMessage({
      type: '__edit_mode_dismissed'
    }, '*');
  };
  const onDragStart = e => {
    const panel = dragRef.current;
    if (!panel) return;
    const r = panel.getBoundingClientRect();
    const sx = e.clientX,
      sy = e.clientY;
    const startRight = window.innerWidth - r.right;
    const startBottom = window.innerHeight - r.bottom;
    const move = ev => {
      offsetRef.current = {
        x: startRight - (ev.clientX - sx),
        y: startBottom - (ev.clientY - sy)
      };
      clampToViewport();
    };
    const up = () => {
      window.removeEventListener('mousemove', move);
      window.removeEventListener('mouseup', up);
    };
    window.addEventListener('mousemove', move);
    window.addEventListener('mouseup', up);
  };
  if (!open) return null;
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("style", null, __TWEAKS_STYLE), /*#__PURE__*/React.createElement("div", {
    ref: dragRef,
    className: "twk-panel",
    "data-noncommentable": "",
    style: {
      right: offsetRef.current.x,
      bottom: offsetRef.current.y
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "twk-hd",
    onMouseDown: onDragStart
  }, /*#__PURE__*/React.createElement("b", null, title), /*#__PURE__*/React.createElement("button", {
    className: "twk-x",
    "aria-label": "Close tweaks",
    onMouseDown: e => e.stopPropagation(),
    onClick: dismiss
  }, "\u2715")), /*#__PURE__*/React.createElement("div", {
    className: "twk-body"
  }, children)));
}

// ── Layout helpers ──────────────────────────────────────────────────────────

function TweakSection({
  label,
  children
}) {
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    className: "twk-sect"
  }, label), children);
}
function TweakRow({
  label,
  value,
  children,
  inline = false
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: inline ? 'twk-row twk-row-h' : 'twk-row'
  }, /*#__PURE__*/React.createElement("div", {
    className: "twk-lbl"
  }, /*#__PURE__*/React.createElement("span", null, label), value != null && /*#__PURE__*/React.createElement("span", {
    className: "twk-val"
  }, value)), children);
}

// ── Controls ────────────────────────────────────────────────────────────────

function TweakSlider({
  label,
  value,
  min = 0,
  max = 100,
  step = 1,
  unit = '',
  onChange
}) {
  return /*#__PURE__*/React.createElement(TweakRow, {
    label: label,
    value: `${value}${unit}`
  }, /*#__PURE__*/React.createElement("input", {
    type: "range",
    className: "twk-slider",
    min: min,
    max: max,
    step: step,
    value: value,
    onChange: e => onChange(Number(e.target.value))
  }));
}
function TweakToggle({
  label,
  value,
  onChange
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "twk-row twk-row-h"
  }, /*#__PURE__*/React.createElement("div", {
    className: "twk-lbl"
  }, /*#__PURE__*/React.createElement("span", null, label)), /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: "twk-toggle",
    "data-on": value ? '1' : '0',
    role: "switch",
    "aria-checked": !!value,
    onClick: () => onChange(!value)
  }, /*#__PURE__*/React.createElement("i", null)));
}
function TweakRadio({
  label,
  value,
  options,
  onChange
}) {
  const trackRef = React.useRef(null);
  const [dragging, setDragging] = React.useState(false);
  const opts = options.map(o => typeof o === 'object' ? o : {
    value: o,
    label: o
  });
  const idx = Math.max(0, opts.findIndex(o => o.value === value));
  const n = opts.length;

  // The active value is read by pointer-move handlers attached for the lifetime
  // of a drag — ref it so a stale closure doesn't fire onChange for every move.
  const valueRef = React.useRef(value);
  valueRef.current = value;
  const segAt = clientX => {
    const r = trackRef.current.getBoundingClientRect();
    const inner = r.width - 4;
    const i = Math.floor((clientX - r.left - 2) / inner * n);
    return opts[Math.max(0, Math.min(n - 1, i))].value;
  };
  const onPointerDown = e => {
    setDragging(true);
    const v0 = segAt(e.clientX);
    if (v0 !== valueRef.current) onChange(v0);
    const move = ev => {
      if (!trackRef.current) return;
      const v = segAt(ev.clientX);
      if (v !== valueRef.current) onChange(v);
    };
    const up = () => {
      setDragging(false);
      window.removeEventListener('pointermove', move);
      window.removeEventListener('pointerup', up);
    };
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', up);
  };
  return /*#__PURE__*/React.createElement(TweakRow, {
    label: label
  }, /*#__PURE__*/React.createElement("div", {
    ref: trackRef,
    role: "radiogroup",
    onPointerDown: onPointerDown,
    className: dragging ? 'twk-seg dragging' : 'twk-seg'
  }, /*#__PURE__*/React.createElement("div", {
    className: "twk-seg-thumb",
    style: {
      left: `calc(2px + ${idx} * (100% - 4px) / ${n})`,
      width: `calc((100% - 4px) / ${n})`
    }
  }), opts.map(o => /*#__PURE__*/React.createElement("button", {
    key: o.value,
    type: "button",
    role: "radio",
    "aria-checked": o.value === value
  }, o.label))));
}
function TweakSelect({
  label,
  value,
  options,
  onChange
}) {
  return /*#__PURE__*/React.createElement(TweakRow, {
    label: label
  }, /*#__PURE__*/React.createElement("select", {
    className: "twk-field",
    value: value,
    onChange: e => onChange(e.target.value)
  }, options.map(o => {
    const v = typeof o === 'object' ? o.value : o;
    const l = typeof o === 'object' ? o.label : o;
    return /*#__PURE__*/React.createElement("option", {
      key: v,
      value: v
    }, l);
  })));
}
function TweakText({
  label,
  value,
  placeholder,
  onChange
}) {
  return /*#__PURE__*/React.createElement(TweakRow, {
    label: label
  }, /*#__PURE__*/React.createElement("input", {
    className: "twk-field",
    type: "text",
    value: value,
    placeholder: placeholder,
    onChange: e => onChange(e.target.value)
  }));
}
function TweakNumber({
  label,
  value,
  min,
  max,
  step = 1,
  unit = '',
  onChange
}) {
  const clamp = n => {
    if (min != null && n < min) return min;
    if (max != null && n > max) return max;
    return n;
  };
  const startRef = React.useRef({
    x: 0,
    val: 0
  });
  const onScrubStart = e => {
    e.preventDefault();
    startRef.current = {
      x: e.clientX,
      val: value
    };
    const decimals = (String(step).split('.')[1] || '').length;
    const move = ev => {
      const dx = ev.clientX - startRef.current.x;
      const raw = startRef.current.val + dx * step;
      const snapped = Math.round(raw / step) * step;
      onChange(clamp(Number(snapped.toFixed(decimals))));
    };
    const up = () => {
      window.removeEventListener('pointermove', move);
      window.removeEventListener('pointerup', up);
    };
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', up);
  };
  return /*#__PURE__*/React.createElement("div", {
    className: "twk-num"
  }, /*#__PURE__*/React.createElement("span", {
    className: "twk-num-lbl",
    onPointerDown: onScrubStart
  }, label), /*#__PURE__*/React.createElement("input", {
    type: "number",
    value: value,
    min: min,
    max: max,
    step: step,
    onChange: e => onChange(clamp(Number(e.target.value)))
  }), unit && /*#__PURE__*/React.createElement("span", {
    className: "twk-num-unit"
  }, unit));
}
function TweakColor({
  label,
  value,
  onChange
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "twk-row twk-row-h"
  }, /*#__PURE__*/React.createElement("div", {
    className: "twk-lbl"
  }, /*#__PURE__*/React.createElement("span", null, label)), /*#__PURE__*/React.createElement("input", {
    type: "color",
    className: "twk-swatch",
    value: value,
    onChange: e => onChange(e.target.value)
  }));
}
function TweakButton({
  label,
  onClick,
  secondary = false
}) {
  return /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: secondary ? 'twk-btn secondary' : 'twk-btn',
    onClick: onClick
  }, label);
}
Object.assign(window, {
  useTweaks,
  TweaksPanel,
  TweakSection,
  TweakRow,
  TweakSlider,
  TweakToggle,
  TweakRadio,
  TweakSelect,
  TweakText,
  TweakNumber,
  TweakColor,
  TweakButton
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "tweaks-panel.jsx", error: String((e && e.message) || e) }); }

// ui_kits/mobile/ios-frame.jsx
try { (() => {
// iOS.jsx — Simplified iOS 26 (Liquid Glass) device frame
// Based on the iOS 26 UI Kit + Figma status bar spec. No assets, no deps.
// Exports: IOSDevice, IOSStatusBar, IOSNavBar, IOSGlassPill, IOSList, IOSListRow, IOSKeyboard

// ─────────────────────────────────────────────────────────────
// Status bar
// ─────────────────────────────────────────────────────────────
function IOSStatusBar({
  dark = false,
  time = '9:41'
}) {
  const c = dark ? '#fff' : '#000';
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 154,
      alignItems: 'center',
      justifyContent: 'center',
      padding: '21px 24px 19px',
      boxSizing: 'border-box',
      position: 'relative',
      zIndex: 20,
      width: '100%'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      height: 22,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      paddingTop: 1.5
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: '-apple-system, "SF Pro", system-ui',
      fontWeight: 590,
      fontSize: 17,
      lineHeight: '22px',
      color: c
    }
  }, time)), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      height: 22,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 7,
      paddingTop: 1,
      paddingRight: 1
    }
  }, /*#__PURE__*/React.createElement("svg", {
    width: "19",
    height: "12",
    viewBox: "0 0 19 12"
  }, /*#__PURE__*/React.createElement("rect", {
    x: "0",
    y: "7.5",
    width: "3.2",
    height: "4.5",
    rx: "0.7",
    fill: c
  }), /*#__PURE__*/React.createElement("rect", {
    x: "4.8",
    y: "5",
    width: "3.2",
    height: "7",
    rx: "0.7",
    fill: c
  }), /*#__PURE__*/React.createElement("rect", {
    x: "9.6",
    y: "2.5",
    width: "3.2",
    height: "9.5",
    rx: "0.7",
    fill: c
  }), /*#__PURE__*/React.createElement("rect", {
    x: "14.4",
    y: "0",
    width: "3.2",
    height: "12",
    rx: "0.7",
    fill: c
  })), /*#__PURE__*/React.createElement("svg", {
    width: "17",
    height: "12",
    viewBox: "0 0 17 12"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M8.5 3.2C10.8 3.2 12.9 4.1 14.4 5.6L15.5 4.5C13.7 2.7 11.2 1.5 8.5 1.5C5.8 1.5 3.3 2.7 1.5 4.5L2.6 5.6C4.1 4.1 6.2 3.2 8.5 3.2Z",
    fill: c
  }), /*#__PURE__*/React.createElement("path", {
    d: "M8.5 6.8C9.9 6.8 11.1 7.3 12 8.2L13.1 7.1C11.8 5.9 10.2 5.1 8.5 5.1C6.8 5.1 5.2 5.9 3.9 7.1L5 8.2C5.9 7.3 7.1 6.8 8.5 6.8Z",
    fill: c
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "8.5",
    cy: "10.5",
    r: "1.5",
    fill: c
  })), /*#__PURE__*/React.createElement("svg", {
    width: "27",
    height: "13",
    viewBox: "0 0 27 13"
  }, /*#__PURE__*/React.createElement("rect", {
    x: "0.5",
    y: "0.5",
    width: "23",
    height: "12",
    rx: "3.5",
    stroke: c,
    strokeOpacity: "0.35",
    fill: "none"
  }), /*#__PURE__*/React.createElement("rect", {
    x: "2",
    y: "2",
    width: "20",
    height: "9",
    rx: "2",
    fill: c
  }), /*#__PURE__*/React.createElement("path", {
    d: "M25 4.5V8.5C25.8 8.2 26.5 7.2 26.5 6.5C26.5 5.8 25.8 4.8 25 4.5Z",
    fill: c,
    fillOpacity: "0.4"
  }))));
}

// ─────────────────────────────────────────────────────────────
// Liquid glass pill — blur + tint + shine
// ─────────────────────────────────────────────────────────────
function IOSGlassPill({
  children,
  dark = false,
  style = {}
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      height: 44,
      minWidth: 44,
      borderRadius: 9999,
      position: 'relative',
      overflow: 'hidden',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      boxShadow: dark ? '0 2px 6px rgba(0,0,0,0.35), 0 6px 16px rgba(0,0,0,0.2)' : '0 1px 3px rgba(0,0,0,0.07), 0 3px 10px rgba(0,0,0,0.06)',
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      borderRadius: 9999,
      backdropFilter: 'blur(12px) saturate(180%)',
      WebkitBackdropFilter: 'blur(12px) saturate(180%)',
      background: dark ? 'rgba(120,120,128,0.28)' : 'rgba(255,255,255,0.5)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      borderRadius: 9999,
      boxShadow: dark ? 'inset 1.5px 1.5px 1px rgba(255,255,255,0.15), inset -1px -1px 1px rgba(255,255,255,0.08)' : 'inset 1.5px 1.5px 1px rgba(255,255,255,0.7), inset -1px -1px 1px rgba(255,255,255,0.4)',
      border: dark ? '0.5px solid rgba(255,255,255,0.15)' : '0.5px solid rgba(0,0,0,0.06)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      zIndex: 1,
      display: 'flex',
      alignItems: 'center',
      padding: '0 4px'
    }
  }, children));
}

// ─────────────────────────────────────────────────────────────
// Navigation bar — glass pills + large title
// ─────────────────────────────────────────────────────────────
function IOSNavBar({
  title = 'Title',
  dark = false,
  trailingIcon = true
}) {
  const muted = dark ? 'rgba(255,255,255,0.6)' : '#404040';
  const text = dark ? '#fff' : '#000';
  const pillIcon = content => /*#__PURE__*/React.createElement(IOSGlassPill, {
    dark: dark
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 36,
      height: 36,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center'
    }
  }, content));
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 10,
      paddingTop: 62,
      paddingBottom: 10,
      position: 'relative',
      zIndex: 5
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      padding: '0 16px'
    }
  }, pillIcon(/*#__PURE__*/React.createElement("svg", {
    width: "12",
    height: "20",
    viewBox: "0 0 12 20",
    fill: "none",
    style: {
      marginLeft: -1
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M10 2L2 10l8 8",
    stroke: muted,
    strokeWidth: "2.5",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }))), trailingIcon && pillIcon(/*#__PURE__*/React.createElement("svg", {
    width: "22",
    height: "6",
    viewBox: "0 0 22 6"
  }, /*#__PURE__*/React.createElement("circle", {
    cx: "3",
    cy: "3",
    r: "2.5",
    fill: muted
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "11",
    cy: "3",
    r: "2.5",
    fill: muted
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "19",
    cy: "3",
    r: "2.5",
    fill: muted
  })))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '0 16px',
      fontFamily: '-apple-system, system-ui',
      fontSize: 34,
      fontWeight: 700,
      lineHeight: '41px',
      color: text,
      letterSpacing: 0.4
    }
  }, title));
}

// ─────────────────────────────────────────────────────────────
// Grouped list (inset card, r:26) + row (52px)
// ─────────────────────────────────────────────────────────────
function IOSListRow({
  title,
  detail,
  icon,
  chevron = true,
  isLast = false,
  dark = false
}) {
  const text = dark ? '#fff' : '#000';
  const sec = dark ? 'rgba(235,235,245,0.6)' : 'rgba(60,60,67,0.6)';
  const ter = dark ? 'rgba(235,235,245,0.3)' : 'rgba(60,60,67,0.3)';
  const sep = dark ? 'rgba(84,84,88,0.65)' : 'rgba(60,60,67,0.12)';
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      minHeight: 52,
      padding: '0 16px',
      position: 'relative',
      fontFamily: '-apple-system, system-ui',
      fontSize: 17,
      letterSpacing: -0.43
    }
  }, icon && /*#__PURE__*/React.createElement("div", {
    style: {
      width: 30,
      height: 30,
      borderRadius: 7,
      background: icon,
      marginRight: 12,
      flexShrink: 0
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      color: text
    }
  }, title), detail && /*#__PURE__*/React.createElement("span", {
    style: {
      color: sec,
      marginRight: 6
    }
  }, detail), chevron && /*#__PURE__*/React.createElement("svg", {
    width: "8",
    height: "14",
    viewBox: "0 0 8 14",
    style: {
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M1 1l6 6-6 6",
    stroke: ter,
    strokeWidth: "2",
    fill: "none",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  })), !isLast && /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      bottom: 0,
      right: 0,
      left: icon ? 58 : 16,
      height: 0.5,
      background: sep
    }
  }));
}
function IOSList({
  header,
  children,
  dark = false
}) {
  const hc = dark ? 'rgba(235,235,245,0.6)' : 'rgba(60,60,67,0.6)';
  const bg = dark ? '#1C1C1E' : '#fff';
  return /*#__PURE__*/React.createElement("div", null, header && /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: '-apple-system, system-ui',
      fontSize: 13,
      color: hc,
      textTransform: 'uppercase',
      padding: '8px 36px 6px',
      letterSpacing: -0.08
    }
  }, header), /*#__PURE__*/React.createElement("div", {
    style: {
      background: bg,
      borderRadius: 26,
      margin: '0 16px',
      overflow: 'hidden'
    }
  }, children));
}

// ─────────────────────────────────────────────────────────────
// Device frame
// ─────────────────────────────────────────────────────────────
function IOSDevice({
  children,
  width = 402,
  height = 874,
  dark = false,
  title,
  keyboard = false
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      width,
      height,
      borderRadius: 48,
      overflow: 'hidden',
      position: 'relative',
      background: dark ? '#000' : '#F2F2F7',
      boxShadow: '0 40px 80px rgba(0,0,0,0.18), 0 0 0 1px rgba(0,0,0,0.12)',
      fontFamily: '-apple-system, system-ui, sans-serif',
      WebkitFontSmoothing: 'antialiased'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: 11,
      left: '50%',
      transform: 'translateX(-50%)',
      width: 126,
      height: 37,
      borderRadius: 24,
      background: '#000',
      zIndex: 50
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: 0,
      left: 0,
      right: 0,
      zIndex: 10
    }
  }, /*#__PURE__*/React.createElement(IOSStatusBar, {
    dark: dark
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      height: '100%',
      display: 'flex',
      flexDirection: 'column'
    }
  }, title !== undefined && /*#__PURE__*/React.createElement(IOSNavBar, {
    title: title,
    dark: dark
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      overflow: 'auto'
    }
  }, children), keyboard && /*#__PURE__*/React.createElement(IOSKeyboard, {
    dark: dark
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      bottom: 0,
      left: 0,
      right: 0,
      zIndex: 60,
      height: 34,
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'flex-end',
      paddingBottom: 8,
      pointerEvents: 'none'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 139,
      height: 5,
      borderRadius: 100,
      background: dark ? 'rgba(255,255,255,0.7)' : 'rgba(0,0,0,0.25)'
    }
  })));
}

// ─────────────────────────────────────────────────────────────
// Keyboard — iOS 26 liquid glass
// ─────────────────────────────────────────────────────────────
function IOSKeyboard({
  dark = false
}) {
  const glyph = dark ? 'rgba(255,255,255,0.7)' : '#595959';
  const sugg = dark ? 'rgba(255,255,255,0.6)' : '#333';
  const keyBg = dark ? 'rgba(255,255,255,0.22)' : 'rgba(255,255,255,0.85)';

  // special-key icons
  const icons = {
    shift: /*#__PURE__*/React.createElement("svg", {
      width: "19",
      height: "17",
      viewBox: "0 0 19 17"
    }, /*#__PURE__*/React.createElement("path", {
      d: "M9.5 1L1 9.5h4.5V16h8V9.5H18L9.5 1z",
      fill: glyph
    })),
    del: /*#__PURE__*/React.createElement("svg", {
      width: "23",
      height: "17",
      viewBox: "0 0 23 17"
    }, /*#__PURE__*/React.createElement("path", {
      d: "M7 1h13a2 2 0 012 2v11a2 2 0 01-2 2H7l-6-7.5L7 1z",
      fill: "none",
      stroke: glyph,
      strokeWidth: "1.6",
      strokeLinejoin: "round"
    }), /*#__PURE__*/React.createElement("path", {
      d: "M10 5l7 7M17 5l-7 7",
      stroke: glyph,
      strokeWidth: "1.6",
      strokeLinecap: "round"
    })),
    ret: /*#__PURE__*/React.createElement("svg", {
      width: "20",
      height: "14",
      viewBox: "0 0 20 14"
    }, /*#__PURE__*/React.createElement("path", {
      d: "M18 1v6H4m0 0l4-4M4 7l4 4",
      fill: "none",
      stroke: "#fff",
      strokeWidth: "1.8",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }))
  };
  const key = (content, {
    w,
    flex,
    ret,
    fs = 25,
    k
  } = {}) => /*#__PURE__*/React.createElement("div", {
    key: k,
    style: {
      height: 42,
      borderRadius: 8.5,
      flex: flex ? 1 : undefined,
      width: w,
      minWidth: 0,
      background: ret ? '#08f' : keyBg,
      boxShadow: '0 1px 0 rgba(0,0,0,0.075)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontFamily: '-apple-system, "SF Compact", system-ui',
      fontSize: fs,
      fontWeight: 458,
      color: ret ? '#fff' : glyph
    }
  }, content);
  const row = (keys, pad = 0) => /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 6.5,
      justifyContent: 'center',
      padding: `0 ${pad}px`
    }
  }, keys.map(l => key(l, {
    flex: true,
    k: l
  })));
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      zIndex: 15,
      borderRadius: 27,
      overflow: 'hidden',
      padding: '11px 0 2px',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      boxShadow: dark ? '0 -2px 20px rgba(0,0,0,0.09)' : '0 -1px 6px rgba(0,0,0,0.018), 0 -3px 20px rgba(0,0,0,0.012)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      borderRadius: 27,
      backdropFilter: 'blur(12px) saturate(180%)',
      WebkitBackdropFilter: 'blur(12px) saturate(180%)',
      background: dark ? 'rgba(120,120,128,0.14)' : 'rgba(255,255,255,0.25)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      borderRadius: 27,
      boxShadow: dark ? 'inset 1.5px 1.5px 1px rgba(255,255,255,0.15)' : 'inset 1.5px 1.5px 1px rgba(255,255,255,0.7), inset -1px -1px 1px rgba(255,255,255,0.4)',
      border: dark ? '0.5px solid rgba(255,255,255,0.15)' : '0.5px solid rgba(0,0,0,0.06)',
      pointerEvents: 'none'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 20,
      alignItems: 'center',
      padding: '8px 22px 13px',
      width: '100%',
      boxSizing: 'border-box',
      position: 'relative'
    }
  }, ['"The"', 'the', 'to'].map((w, i) => /*#__PURE__*/React.createElement(React.Fragment, {
    key: i
  }, i > 0 && /*#__PURE__*/React.createElement("div", {
    style: {
      width: 1,
      height: 25,
      background: '#ccc',
      opacity: 0.3
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      textAlign: 'center',
      fontFamily: '-apple-system, system-ui',
      fontSize: 17,
      color: sugg,
      letterSpacing: -0.43,
      lineHeight: '22px'
    }
  }, w)))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 13,
      padding: '0 6.5px',
      width: '100%',
      boxSizing: 'border-box',
      position: 'relative'
    }
  }, row(['q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p']), row(['a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l'], 20), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 14.25,
      alignItems: 'center'
    }
  }, key(icons.shift, {
    w: 45,
    k: 'shift'
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 6.5,
      flex: 1
    }
  }, ['z', 'x', 'c', 'v', 'b', 'n', 'm'].map(l => key(l, {
    flex: true,
    k: l
  }))), key(icons.del, {
    w: 45,
    k: 'del'
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 6,
      alignItems: 'center'
    }
  }, key('ABC', {
    w: 92.25,
    fs: 18,
    k: 'abc'
  }), key('', {
    flex: true,
    k: 'space'
  }), key(icons.ret, {
    w: 92.25,
    ret: true,
    k: 'ret'
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      height: 56,
      width: '100%',
      position: 'relative'
    }
  }));
}
Object.assign(window, {
  IOSDevice,
  IOSStatusBar,
  IOSNavBar,
  IOSGlassPill,
  IOSList,
  IOSListRow,
  IOSKeyboard
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/mobile/ios-frame.jsx", error: String((e && e.message) || e) }); }

// ui_kits/mobile/screens.jsx
try { (() => {
// Fomio mobile screens — four scenes built on top of IOSDevice.
// Surfaces the product's own tokens (warm cream, Lora serif, terracotta) inside the iOS frame.
// Exposes: FomioFeedScreen, FomioByteScreen, FomioComposeScreen, FomioNotificationsScreen

const TOKENS = {
  bg: '#F8F7F3',
  surface: '#F2F1EC',
  card: '#FFFFFF',
  border: '#E3E3E6',
  borderSoft: 'rgba(15,23,42,0.08)',
  fg: '#1A1A1A',
  fgMuted: '#6B6B72',
  fgSecondary: '#5C5D67',
  primary: '#C44536',
  primaryDark: '#9E3326',
  primarySoft: '#F5D0CC',
  amoledBg: '#000',
  amoledCard: '#050505',
  amoledBorder: '#1C1C1E',
  amoledFg: '#F5F5F7',
  amoledMuted: '#A1A1AA',
  serif: 'Lora, Georgia, serif',
  sans: 'Raleway, -apple-system, system-ui, sans-serif'
};

// ── Small primitives ───────────────────────────────────────────
const Avatar = ({
  name,
  size = 32,
  bg = '#D6C9A8',
  fg = '#5C4A1E'
}) => /*#__PURE__*/React.createElement("div", {
  style: {
    width: size,
    height: size,
    borderRadius: size / 2,
    background: bg,
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    fontFamily: TOKENS.sans,
    fontWeight: 700,
    color: fg,
    fontSize: Math.round(size * 0.4),
    flexShrink: 0
  }
}, name);
const Chip = ({
  label,
  active,
  dark
}) => /*#__PURE__*/React.createElement("div", {
  style: {
    fontFamily: TOKENS.sans,
    fontWeight: 600,
    fontSize: 13,
    letterSpacing: 0.02,
    height: 34,
    padding: '0 16px',
    borderRadius: 9999,
    border: `1.5px solid ${active ? TOKENS.primary : dark ? TOKENS.amoledBorder : TOKENS.border}`,
    background: active ? TOKENS.primary : 'transparent',
    color: active ? '#fff' : dark ? TOKENS.amoledFg : TOKENS.fg,
    display: 'inline-flex',
    alignItems: 'center',
    whiteSpace: 'nowrap'
  }
}, label);
const TeretBadge = ({
  label
}) => /*#__PURE__*/React.createElement("span", {
  style: {
    fontFamily: TOKENS.sans,
    fontWeight: 700,
    fontSize: 10,
    letterSpacing: 0.06,
    textTransform: 'uppercase',
    padding: '3px 9px',
    borderRadius: 9999,
    background: TOKENS.primarySoft,
    color: TOKENS.primaryDark
  }
}, label);
const MetaDot = ({
  dark
}) => /*#__PURE__*/React.createElement("span", {
  style: {
    color: dark ? TOKENS.amoledMuted : TOKENS.fgMuted,
    fontSize: 11
  }
}, "\xB7");

// ── Phosphor-style icons ──────────────────────────────────────
const I = {
  home: (c, f) => /*#__PURE__*/React.createElement("svg", {
    width: "22",
    height: "22",
    viewBox: "0 0 24 24",
    fill: f ? c : 'none',
    stroke: c,
    strokeWidth: "1.7"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M3 11l9-8 9 8v10a1 1 0 01-1 1h-5v-7h-6v7H4a1 1 0 01-1-1V11z"
  })),
  search: c => /*#__PURE__*/React.createElement("svg", {
    width: "22",
    height: "22",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: c,
    strokeWidth: "1.7"
  }, /*#__PURE__*/React.createElement("circle", {
    cx: "10.5",
    cy: "10.5",
    r: "6.5"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M20 20l-4.8-4.8",
    strokeLinecap: "round"
  })),
  plus: c => /*#__PURE__*/React.createElement("svg", {
    width: "22",
    height: "22",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: c,
    strokeWidth: "2"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M12 5v14M5 12h14",
    strokeLinecap: "round"
  })),
  bell: (c, f) => /*#__PURE__*/React.createElement("svg", {
    width: "22",
    height: "22",
    viewBox: "0 0 24 24",
    fill: f ? c : 'none',
    stroke: c,
    strokeWidth: "1.7"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M6 16V11a6 6 0 1112 0v5l1.5 2h-15L6 16z"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M10 20a2 2 0 004 0"
  })),
  user: (c, f) => /*#__PURE__*/React.createElement("svg", {
    width: "22",
    height: "22",
    viewBox: "0 0 24 24",
    fill: f ? c : 'none',
    stroke: c,
    strokeWidth: "1.7"
  }, /*#__PURE__*/React.createElement("circle", {
    cx: "12",
    cy: "9",
    r: "4"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M4 21c1.5-4 4.5-6 8-6s6.5 2 8 6"
  })),
  heart: (c, f) => /*#__PURE__*/React.createElement("svg", {
    width: "18",
    height: "18",
    viewBox: "0 0 24 24",
    fill: f ? c : 'none',
    stroke: c,
    strokeWidth: "1.7"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M12 20s-7-4.5-9-9a5 5 0 019-3 5 5 0 019 3c-2 4.5-9 9-9 9z"
  })),
  reply: c => /*#__PURE__*/React.createElement("svg", {
    width: "18",
    height: "18",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: c,
    strokeWidth: "1.7"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M12 3a9 9 0 019 9c0 5-4 9-9 9-1.3 0-2.5-.3-3.6-.8L3 21l1.2-4.5A8.9 8.9 0 013 12a9 9 0 019-9z"
  })),
  eye: c => /*#__PURE__*/React.createElement("svg", {
    width: "18",
    height: "18",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: c,
    strokeWidth: "1.7"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "12",
    cy: "12",
    r: "3"
  })),
  bookmark: (c, f) => /*#__PURE__*/React.createElement("svg", {
    width: "18",
    height: "18",
    viewBox: "0 0 24 24",
    fill: f ? c : 'none',
    stroke: c,
    strokeWidth: "1.7"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M6 3h12v18l-6-4-6 4V3z"
  })),
  share: c => /*#__PURE__*/React.createElement("svg", {
    width: "18",
    height: "18",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: c,
    strokeWidth: "1.7"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M12 3v13M7 8l5-5 5 5M5 21h14"
  })),
  up: c => /*#__PURE__*/React.createElement("svg", {
    width: "18",
    height: "18",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: c,
    strokeWidth: "2"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M12 19V5M5 12l7-7 7 7",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  })),
  check: c => /*#__PURE__*/React.createElement("svg", {
    width: "18",
    height: "18",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: c,
    strokeWidth: "1.7"
  }, /*#__PURE__*/React.createElement("circle", {
    cx: "12",
    cy: "12",
    r: "9"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M8 12l3 3 5-6",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }))
};

// ── Fomio header (custom, replaces default nav title) ─────────
const FomioHeader = ({
  title,
  dark,
  subtitle,
  showArc = true
}) => /*#__PURE__*/React.createElement("div", {
  style: {
    padding: '56px 20px 12px',
    background: 'transparent'
  }
}, /*#__PURE__*/React.createElement("div", {
  style: {
    display: 'flex',
    alignItems: 'center',
    gap: 10
  }
}, /*#__PURE__*/React.createElement("h1", {
  style: {
    margin: 0,
    fontFamily: TOKENS.serif,
    fontStyle: 'italic',
    fontWeight: 700,
    fontSize: 34,
    letterSpacing: -0.8,
    lineHeight: 1,
    color: dark ? TOKENS.amoledFg : TOKENS.fg
  }
}, title), showArc && /*#__PURE__*/React.createElement("svg", {
  width: "36",
  height: "14",
  viewBox: "0 0 36 14",
  style: {
    marginBottom: -4
  }
}, /*#__PURE__*/React.createElement("path", {
  d: "M2 4 Q18 14 34 4",
  stroke: TOKENS.primary,
  strokeWidth: "3",
  strokeLinecap: "round",
  fill: "none"
}))), subtitle && /*#__PURE__*/React.createElement("div", {
  style: {
    marginTop: 6,
    fontFamily: TOKENS.sans,
    fontSize: 12,
    fontWeight: 600,
    letterSpacing: 0.08,
    textTransform: 'uppercase',
    color: dark ? TOKENS.amoledMuted : TOKENS.fgMuted
  }
}, subtitle));

// ── Tab bar (BlurView-style glass) ────────────────────────────
const TabBar = ({
  active = 'home',
  dark
}) => {
  const items = [{
    k: 'home',
    label: 'Home',
    icon: I.home
  }, {
    k: 'search',
    label: 'Search',
    icon: I.search
  }, {
    k: 'compose',
    label: 'Compose',
    icon: I.plus,
    center: true
  }, {
    k: 'bell',
    label: 'Alerts',
    icon: I.bell,
    badge: 3
  }, {
    k: 'user',
    label: 'You',
    icon: I.user
  }];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: 16,
      right: 16,
      bottom: 26,
      height: 68,
      borderRadius: 28,
      zIndex: 30,
      overflow: 'hidden',
      boxShadow: dark ? '0 10px 30px rgba(0,0,0,0.5)' : '0 10px 30px rgba(0,0,0,0.10)',
      background: dark ? 'rgba(10,10,10,0.72)' : 'rgba(255,255,255,0.72)',
      backdropFilter: 'blur(22px) saturate(180%)',
      WebkitBackdropFilter: 'blur(22px) saturate(180%)',
      border: `1px solid ${dark ? 'rgba(255,255,255,0.08)' : 'rgba(0,0,0,0.05)'}`,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-around',
      padding: '0 8px'
    }
  }, items.map(it => {
    const isActive = it.k === active;
    const col = isActive ? TOKENS.primary : dark ? TOKENS.amoledMuted : TOKENS.fgMuted;
    if (it.center) {
      return /*#__PURE__*/React.createElement("div", {
        key: it.k,
        style: {
          width: 48,
          height: 48,
          borderRadius: 24,
          background: TOKENS.primary,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          boxShadow: '0 6px 16px rgba(196,69,54,0.35)'
        }
      }, it.icon('#fff'));
    }
    return /*#__PURE__*/React.createElement("div", {
      key: it.k,
      style: {
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        gap: 3,
        position: 'relative',
        padding: '0 10px'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        position: 'relative'
      }
    }, it.icon(col, isActive), it.badge && /*#__PURE__*/React.createElement("span", {
      style: {
        position: 'absolute',
        top: -4,
        right: -8,
        minWidth: 16,
        height: 16,
        borderRadius: 8,
        background: TOKENS.primary,
        color: '#fff',
        fontFamily: TOKENS.sans,
        fontSize: 9,
        fontWeight: 700,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '0 4px'
      }
    }, it.badge)), /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: TOKENS.sans,
        fontSize: 10,
        fontWeight: 600,
        color: col,
        letterSpacing: 0.04
      }
    }, it.label));
  }));
};

// ── Byte card ─────────────────────────────────────────────────
const ByteCard = ({
  byte,
  dark
}) => /*#__PURE__*/React.createElement("div", {
  style: {
    background: dark ? TOKENS.amoledCard : TOKENS.card,
    border: `1px solid ${dark ? TOKENS.amoledBorder : TOKENS.border}`,
    borderRadius: 18,
    padding: 18,
    marginBottom: 12
  }
}, /*#__PURE__*/React.createElement("div", {
  style: {
    display: 'flex',
    alignItems: 'center',
    gap: 8,
    marginBottom: 12
  }
}, /*#__PURE__*/React.createElement(Avatar, {
  name: byte.init,
  size: 28,
  bg: byte.avatarBg,
  fg: byte.avatarFg
}), /*#__PURE__*/React.createElement("span", {
  style: {
    fontFamily: TOKENS.sans,
    fontWeight: 600,
    fontSize: 13,
    color: dark ? TOKENS.amoledFg : TOKENS.fg
  }
}, byte.author), /*#__PURE__*/React.createElement(MetaDot, {
  dark: dark
}), /*#__PURE__*/React.createElement(TeretBadge, {
  label: byte.teret
}), /*#__PURE__*/React.createElement("span", {
  style: {
    marginLeft: 'auto'
  }
}, byte.unread && /*#__PURE__*/React.createElement("span", {
  style: {
    width: 8,
    height: 8,
    borderRadius: 4,
    background: TOKENS.primary,
    display: 'inline-block'
  }
}))), /*#__PURE__*/React.createElement("h3", {
  style: {
    margin: '0 0 6px',
    fontFamily: TOKENS.serif,
    fontWeight: 700,
    fontSize: 19,
    lineHeight: 1.3,
    letterSpacing: -0.3,
    color: dark ? TOKENS.amoledFg : TOKENS.fg
  }
}, byte.title), /*#__PURE__*/React.createElement("p", {
  style: {
    margin: '0 0 14px',
    fontFamily: TOKENS.serif,
    fontSize: 14,
    lineHeight: 1.55,
    color: dark ? TOKENS.amoledMuted : TOKENS.fgMuted
  }
}, byte.excerpt), /*#__PURE__*/React.createElement("div", {
  style: {
    display: 'flex',
    alignItems: 'center',
    gap: 16,
    fontFamily: TOKENS.sans,
    fontSize: 11,
    fontWeight: 600,
    letterSpacing: 0.04,
    color: dark ? TOKENS.amoledMuted : TOKENS.fgMuted
  }
}, /*#__PURE__*/React.createElement("span", {
  style: {
    display: 'inline-flex',
    alignItems: 'center',
    gap: 5
  }
}, I.heart(dark ? TOKENS.amoledMuted : TOKENS.fgMuted), " ", byte.likes), /*#__PURE__*/React.createElement("span", {
  style: {
    display: 'inline-flex',
    alignItems: 'center',
    gap: 5
  }
}, I.reply(dark ? TOKENS.amoledMuted : TOKENS.fgMuted), " ", byte.replies), /*#__PURE__*/React.createElement("span", {
  style: {
    display: 'inline-flex',
    alignItems: 'center',
    gap: 5
  }
}, I.eye(dark ? TOKENS.amoledMuted : TOKENS.fgMuted), " ", byte.views), /*#__PURE__*/React.createElement("span", {
  style: {
    marginLeft: 'auto'
  }
}, byte.time)));

// ── Screen: Feed ──────────────────────────────────────────────
window.FomioFeedScreen = function ({
  dark = false
}) {
  const [filter, setFilter] = React.useState('Latest');
  const filters = ['Latest', 'Hot', 'Unread'];
  const bytes = [{
    init: 'LM',
    author: 'Lena Marsh',
    teret: 'Essays',
    avatarBg: '#D6C9A8',
    avatarFg: '#5C4A1E',
    title: 'On writing without an audience',
    excerpt: "There's a specific pleasure in opening an app and finding it unchanged — no new tab, no pulsing dot.",
    likes: 42,
    replies: 8,
    views: 214,
    time: '3d',
    unread: true
  }, {
    init: 'JN',
    author: 'Jun Nakamura',
    teret: 'Quiet internet',
    avatarBg: '#C9D6C2',
    avatarFg: '#3E5C3E',
    title: 'The case for chronological feeds',
    excerpt: 'A soft polemic against recommendation engines and why a clock beats a score.',
    likes: 127,
    replies: 34,
    views: 902,
    time: '1d',
    unread: true
  }, {
    init: 'AR',
    author: 'Ada Reyes',
    teret: 'Craft',
    avatarBg: '#D6BFC9',
    avatarFg: '#5C3E4D',
    title: 'Letters to no one',
    excerpt: 'Notes from a year of writing things only I would read. What changes when the count goes away.',
    likes: 89,
    replies: 12,
    views: 412,
    time: '5h',
    unread: false
  }, {
    init: 'PH',
    author: 'Priya Hart',
    teret: 'Essays',
    avatarBg: '#BFCAD6',
    avatarFg: '#3E4A5C',
    title: 'A small pause in a loud year',
    excerpt: "I uninstalled everything. I kept fomio. Here's what a week looked like afterwards.",
    likes: 61,
    replies: 19,
    views: 301,
    time: '2d',
    unread: false
  }];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      minHeight: '100%',
      background: dark ? TOKENS.amoledBg : TOKENS.bg,
      fontFamily: TOKENS.sans,
      position: 'relative',
      paddingBottom: 120
    }
  }, /*#__PURE__*/React.createElement(FomioHeader, {
    title: "fomio",
    dark: dark,
    subtitle: "Your hub \xB7 Monday morning"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8,
      padding: '4px 20px 16px',
      overflowX: 'auto'
    }
  }, filters.map(f => /*#__PURE__*/React.createElement("div", {
    key: f,
    onClick: () => setFilter(f),
    style: {
      cursor: 'pointer'
    }
  }, /*#__PURE__*/React.createElement(Chip, {
    label: f,
    active: filter === f,
    dark: dark
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: TOKENS.sans,
      fontSize: 11,
      fontWeight: 700,
      letterSpacing: 0.04,
      textTransform: 'uppercase',
      color: TOKENS.primary,
      display: 'inline-flex',
      alignItems: 'center',
      gap: 5,
      alignSelf: 'center',
      padding: '0 8px'
    }
  }, I.check(TOKENS.primary), " Mark read")), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '0 16px'
    }
  }, bytes.map((b, i) => /*#__PURE__*/React.createElement(ByteCard, {
    key: i,
    byte: b,
    dark: dark
  }))), /*#__PURE__*/React.createElement(TabBar, {
    active: "home",
    dark: dark
  }));
};

// ── Screen: Byte detail ───────────────────────────────────────
window.FomioByteScreen = function ({
  dark = false
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      minHeight: '100%',
      background: dark ? TOKENS.amoledBg : TOKENS.bg,
      position: 'relative',
      paddingBottom: 120
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '56px 16px 8px',
      display: 'flex',
      alignItems: 'center',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 36,
      height: 36,
      borderRadius: 18,
      background: dark ? TOKENS.amoledCard : TOKENS.card,
      border: `1px solid ${dark ? TOKENS.amoledBorder : TOKENS.border}`,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center'
    }
  }, /*#__PURE__*/React.createElement("svg", {
    width: "12",
    height: "18",
    viewBox: "0 0 12 18",
    fill: "none",
    stroke: dark ? TOKENS.amoledFg : TOKENS.fg,
    strokeWidth: "2",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M10 2L2 9l8 7"
  }))), /*#__PURE__*/React.createElement(TeretBadge, {
    label: "Quiet internet"
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      marginLeft: 'auto',
      color: dark ? TOKENS.amoledMuted : TOKENS.fgMuted,
      fontFamily: TOKENS.sans,
      fontSize: 12,
      fontWeight: 600
    }
  }, "Byte #1,284")), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '12px 20px 0'
    }
  }, /*#__PURE__*/React.createElement("h1", {
    style: {
      margin: '8px 0 14px',
      fontFamily: TOKENS.serif,
      fontWeight: 700,
      fontSize: 28,
      lineHeight: 1.2,
      letterSpacing: -0.6,
      color: dark ? TOKENS.amoledFg : TOKENS.fg
    }
  }, "The case for chronological feeds"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      marginBottom: 20
    }
  }, /*#__PURE__*/React.createElement(Avatar, {
    name: "JN",
    size: 36,
    bg: "#C9D6C2",
    fg: "#3E5C3E"
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: TOKENS.sans,
      fontWeight: 700,
      fontSize: 13,
      color: dark ? TOKENS.amoledFg : TOKENS.fg
    }
  }, "Jun Nakamura"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: TOKENS.sans,
      fontSize: 11,
      color: dark ? TOKENS.amoledMuted : TOKENS.fgMuted,
      letterSpacing: 0.04
    }
  }, "Posted 1 day ago \xB7 9 min read"))), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: TOKENS.serif,
      fontSize: 16,
      lineHeight: 1.65,
      color: dark ? TOKENS.amoledFg : TOKENS.fg
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '0 0 14px'
    }
  }, "A clock is a modest instrument. It doesn't know you, doesn't care what you've read before, doesn't try. It puts one thing after another."), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '0 0 14px'
    }
  }, "That ", /*#__PURE__*/React.createElement("em", null, "modesty"), " is a rare posture in software right now. Most feeds lean in. They guess. They correct. They produce the inevitable small hum of being watched."), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '0 0 14px',
      color: dark ? TOKENS.amoledMuted : TOKENS.fgSecondary,
      fontStyle: 'italic'
    }
  }, "\"We forget that chronology is a choice. It is the most neutral editor we have.\""))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '24px 20px 0'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: TOKENS.sans,
      fontSize: 11,
      fontWeight: 700,
      letterSpacing: 0.08,
      textTransform: 'uppercase',
      color: dark ? TOKENS.amoledMuted : TOKENS.fgMuted,
      marginBottom: 12
    }
  }, "34 replies"), /*#__PURE__*/React.createElement("div", {
    style: {
      background: dark ? TOKENS.amoledCard : TOKENS.card,
      border: `1px solid ${dark ? TOKENS.amoledBorder : TOKENS.border}`,
      borderRadius: 18,
      padding: 14
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      marginBottom: 8
    }
  }, /*#__PURE__*/React.createElement(Avatar, {
    name: "AR",
    size: 24,
    bg: "#D6BFC9",
    fg: "#5C3E4D"
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: TOKENS.sans,
      fontWeight: 600,
      fontSize: 12,
      color: dark ? TOKENS.amoledFg : TOKENS.fg
    }
  }, "Ada Reyes"), /*#__PURE__*/React.createElement(MetaDot, {
    dark: dark
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: TOKENS.sans,
      fontSize: 11,
      color: dark ? TOKENS.amoledMuted : TOKENS.fgMuted
    }
  }, "6h")), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontFamily: TOKENS.serif,
      fontSize: 14,
      lineHeight: 1.55,
      color: dark ? TOKENS.amoledFg : TOKENS.fg
    }
  }, "The clock-as-editor framing is useful. It also frees the writer \u2014 if nothing is optimising, the piece is simply allowed to land."))), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: 16,
      right: 16,
      bottom: 26,
      height: 58,
      borderRadius: 29,
      zIndex: 30,
      background: dark ? 'rgba(10,10,10,0.82)' : 'rgba(255,255,255,0.82)',
      backdropFilter: 'blur(22px) saturate(180%)',
      WebkitBackdropFilter: 'blur(22px) saturate(180%)',
      border: `1px solid ${dark ? 'rgba(255,255,255,0.08)' : 'rgba(0,0,0,0.05)'}`,
      boxShadow: '0 10px 30px rgba(0,0,0,0.12)',
      display: 'flex',
      alignItems: 'center',
      padding: '0 12px',
      gap: 6
    }
  }, [{
    icon: I.heart,
    label: '127',
    active: true
  }, {
    icon: I.reply,
    label: '34'
  }, {
    icon: I.bookmark,
    label: ''
  }, {
    icon: I.share,
    label: ''
  }].map((a, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      flex: 1,
      height: 42,
      borderRadius: 21,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 6,
      background: a.active ? TOKENS.primarySoft : 'transparent',
      color: a.active ? TOKENS.primaryDark : dark ? TOKENS.amoledFg : TOKENS.fg,
      fontFamily: TOKENS.sans,
      fontWeight: 700,
      fontSize: 13
    }
  }, a.icon(a.active ? TOKENS.primaryDark : dark ? TOKENS.amoledFg : TOKENS.fg, a.active), a.label && /*#__PURE__*/React.createElement("span", null, a.label))), /*#__PURE__*/React.createElement("div", {
    style: {
      height: 42,
      padding: '0 18px',
      borderRadius: 21,
      background: TOKENS.primary,
      color: '#fff',
      fontFamily: TOKENS.sans,
      fontWeight: 700,
      fontSize: 13,
      letterSpacing: 0.02,
      display: 'flex',
      alignItems: 'center'
    }
  }, "Reply")));
};

// ── Screen: Compose ───────────────────────────────────────────
window.FomioComposeScreen = function ({
  dark = false
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      minHeight: '100%',
      background: dark ? TOKENS.amoledBg : TOKENS.bg,
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '56px 20px 8px',
      display: 'flex',
      alignItems: 'center',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: TOKENS.sans,
      fontWeight: 600,
      fontSize: 14,
      color: dark ? TOKENS.amoledMuted : TOKENS.fgMuted
    }
  }, "Cancel"), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      textAlign: 'center',
      fontFamily: TOKENS.serif,
      fontWeight: 700,
      fontSize: 17,
      fontStyle: 'italic',
      color: dark ? TOKENS.amoledFg : TOKENS.fg
    }
  }, "New byte"), /*#__PURE__*/React.createElement("span", {
    style: {
      padding: '7px 14px',
      borderRadius: 9999,
      background: TOKENS.primary,
      color: '#fff',
      fontFamily: TOKENS.sans,
      fontWeight: 700,
      fontSize: 13,
      letterSpacing: 0.02
    }
  }, "Post")), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '8px 20px 12px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 8,
      padding: '6px 12px 6px 6px',
      borderRadius: 9999,
      background: dark ? TOKENS.amoledCard : TOKENS.card,
      border: `1px solid ${dark ? TOKENS.amoledBorder : TOKENS.border}`
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 22,
      height: 22,
      borderRadius: 11,
      background: TOKENS.primarySoft,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      color: TOKENS.primaryDark,
      fontWeight: 800,
      fontSize: 12,
      fontFamily: TOKENS.sans
    }
  }, "E"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: TOKENS.sans,
      fontWeight: 600,
      fontSize: 12,
      color: dark ? TOKENS.amoledFg : TOKENS.fg
    }
  }, "Essays"), /*#__PURE__*/React.createElement("svg", {
    width: "12",
    height: "12",
    viewBox: "0 0 12 12",
    fill: "none",
    stroke: dark ? TOKENS.amoledMuted : TOKENS.fgMuted,
    strokeWidth: "1.7"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M3 5l3 3 3-3"
  })))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '8px 20px 0'
    }
  }, /*#__PURE__*/React.createElement("input", {
    placeholder: "Title",
    style: {
      width: '100%',
      border: 'none',
      outline: 'none',
      background: 'transparent',
      fontFamily: TOKENS.serif,
      fontWeight: 700,
      fontSize: 26,
      letterSpacing: -0.5,
      color: dark ? TOKENS.amoledFg : TOKENS.fg,
      padding: '8px 0'
    },
    defaultValue: "On writing without an audience"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: TOKENS.serif,
      fontSize: 17,
      lineHeight: 1.6,
      color: dark ? TOKENS.amoledFg : TOKENS.fg,
      marginTop: 8
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '0 0 12px'
    }
  }, "There's a specific pleasure in opening an app and finding it unchanged \u2014 no new tab, no pulsing dot, no urgent nothing."), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '0 0 12px',
      color: dark ? TOKENS.amoledMuted : TOKENS.fgMuted
    }
  }, "Bytes here are read in the order they were written.", /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-block',
      width: 2,
      height: 20,
      background: TOKENS.primary,
      verticalAlign: 'middle',
      marginLeft: 2,
      animation: 'blink 1s step-end infinite'
    }
  })))), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: 0,
      right: 0,
      bottom: 0,
      zIndex: 30,
      background: dark ? 'rgba(10,10,10,0.9)' : 'rgba(248,247,243,0.9)',
      backdropFilter: 'blur(14px)',
      WebkitBackdropFilter: 'blur(14px)',
      borderTop: `1px solid ${dark ? TOKENS.amoledBorder : TOKENS.border}`,
      padding: '10px 16px 14px',
      display: 'flex',
      gap: 14,
      alignItems: 'center'
    }
  }, ['B', 'i', '"', '{ }', '— ', '#'].map((g, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      width: 36,
      height: 36,
      borderRadius: 18,
      background: dark ? TOKENS.amoledCard : TOKENS.card,
      border: `1px solid ${dark ? TOKENS.amoledBorder : TOKENS.border}`,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontFamily: i === 2 ? TOKENS.serif : TOKENS.sans,
      fontWeight: i === 0 ? 800 : 600,
      fontStyle: i === 1 ? 'italic' : 'normal',
      fontSize: 14,
      color: dark ? TOKENS.amoledFg : TOKENS.fg
    }
  }, g)), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: TOKENS.sans,
      fontSize: 11,
      fontWeight: 600,
      color: dark ? TOKENS.amoledMuted : TOKENS.fgMuted,
      letterSpacing: 0.04
    }
  }, "Draft saved \xB7 2s ago")), /*#__PURE__*/React.createElement("style", null, `@keyframes blink { 50% { opacity: 0 } }`));
};

// ── Screen: Notifications ─────────────────────────────────────
window.FomioNotificationsScreen = function ({
  dark = false
}) {
  const rows = [{
    init: 'JN',
    name: 'Jun Nakamura',
    bg: '#C9D6C2',
    fg: '#3E5C3E',
    text: /*#__PURE__*/React.createElement(React.Fragment, null, "replied to ", /*#__PURE__*/React.createElement("strong", null, "On writing without an audience")),
    time: '12m',
    unread: true
  }, {
    init: 'AR',
    name: 'Ada Reyes',
    bg: '#D6BFC9',
    fg: '#5C3E4D',
    text: /*#__PURE__*/React.createElement(React.Fragment, null, "liked your byte ", /*#__PURE__*/React.createElement("strong", null, "Letters to no one")),
    time: '2h',
    unread: true
  }, {
    init: 'LM',
    name: 'Lena Marsh',
    bg: '#D6C9A8',
    fg: '#5C4A1E',
    text: /*#__PURE__*/React.createElement(React.Fragment, null, "pinned a byte in ", /*#__PURE__*/React.createElement("em", null, "Essays")),
    time: '5h',
    unread: true
  }, {
    init: 'PH',
    name: 'Priya Hart',
    bg: '#BFCAD6',
    fg: '#3E4A5C',
    text: /*#__PURE__*/React.createElement(React.Fragment, null, "started following you"),
    time: '1d',
    unread: false
  }, {
    init: 'TM',
    name: 'Theo Mendez',
    bg: '#D6C2C2',
    fg: '#5C3E3E',
    text: /*#__PURE__*/React.createElement(React.Fragment, null, "mentioned you in ", /*#__PURE__*/React.createElement("strong", null, "A quieter timeline")),
    time: '2d',
    unread: false
  }];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      minHeight: '100%',
      background: dark ? TOKENS.amoledBg : TOKENS.bg,
      position: 'relative',
      paddingBottom: 120
    }
  }, /*#__PURE__*/React.createElement(FomioHeader, {
    title: "Alerts",
    dark: dark,
    subtitle: "3 new since Friday",
    showArc: false
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      padding: '4px 20px 12px'
    }
  }, /*#__PURE__*/React.createElement(Chip, {
    label: "All",
    active: true,
    dark: dark
  }), /*#__PURE__*/React.createElement(Chip, {
    label: "Mentions",
    dark: dark
  }), /*#__PURE__*/React.createElement(Chip, {
    label: "Replies",
    dark: dark
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: TOKENS.sans,
      fontSize: 11,
      fontWeight: 700,
      color: TOKENS.primary,
      letterSpacing: 0.04,
      textTransform: 'uppercase',
      display: 'inline-flex',
      alignItems: 'center',
      gap: 5
    }
  }, I.check(TOKENS.primary), " Mark read")), /*#__PURE__*/React.createElement("div", {
    style: {
      margin: '0 16px',
      borderRadius: 18,
      background: dark ? TOKENS.amoledCard : TOKENS.card,
      border: `1px solid ${dark ? TOKENS.amoledBorder : TOKENS.border}`,
      overflow: 'hidden'
    }
  }, rows.map((r, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      display: 'flex',
      alignItems: 'flex-start',
      gap: 12,
      padding: '14px 16px',
      borderBottom: i < rows.length - 1 ? `1px solid ${dark ? TOKENS.amoledBorder : TOKENS.border}` : 'none',
      background: r.unread ? dark ? 'rgba(212,96,79,0.06)' : 'rgba(196,69,54,0.04)' : 'transparent'
    }
  }, /*#__PURE__*/React.createElement(Avatar, {
    name: r.init,
    size: 34,
    bg: r.bg,
    fg: r.fg
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: TOKENS.serif,
      fontSize: 14,
      lineHeight: 1.45,
      color: dark ? TOKENS.amoledFg : TOKENS.fg
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 700
    }
  }, r.name), " ", r.text), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: TOKENS.sans,
      fontSize: 11,
      fontWeight: 600,
      color: dark ? TOKENS.amoledMuted : TOKENS.fgMuted,
      marginTop: 4,
      letterSpacing: 0.04
    }
  }, r.time, " ago")), r.unread && /*#__PURE__*/React.createElement("span", {
    style: {
      width: 8,
      height: 8,
      borderRadius: 4,
      background: TOKENS.primary,
      marginTop: 8
    }
  })))), /*#__PURE__*/React.createElement(TabBar, {
    active: "bell",
    dark: dark
  }));
};
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/mobile/screens.jsx", error: String((e && e.message) || e) }); }

// uploads/CATEGORIES_TYPES.ts
try { (() => {
/**
 * TypeScript types for Discourse Categories API
 * Based on analysis of:
 * - app/controllers/categories_controller.rb
 * - app/serializers/*category*serializer.rb
 */

// ============================================================================
// BASE TYPES (from BasicCategorySerializer)
// ============================================================================

// ============================================================================
// SITE CATEGORY (read-only, no edit perms)
// ============================================================================

// ============================================================================
// FULL CATEGORY (with edit perms)
// ============================================================================

// ============================================================================
// DETAILED CATEGORY (with topics included)
// ============================================================================

// ============================================================================
// TOPIC (Minimal, as appears in category)
// ============================================================================

// ============================================================================
// API RESPONSE TYPES
// ============================================================================

// ============================================================================
// REQUEST QUERY PARAMETERS
// ============================================================================

// ============================================================================
// API RESULT WRAPPER (for src/api integration)
// ============================================================================

// Helper for unwrapping
function unwrap(result) {
  if (!result.ok) {
    throw new Error(result.error);
  }
  return result.data;
}

// ============================================================================
// PERMISSION TYPES ENUM
// ============================================================================
var CategoryPermission = /*#__PURE__*/function (CategoryPermission) {
  CategoryPermission[CategoryPermission["FULL"] = 1] = "FULL";
  CategoryPermission[CategoryPermission["CREATE_POST"] = 2] = "CREATE_POST";
  CategoryPermission[CategoryPermission["READONLY"] = 3] = "READONLY";
  return CategoryPermission;
}(CategoryPermission || {});
var NotificationLevel = /*#__PURE__*/function (NotificationLevel) {
  NotificationLevel[NotificationLevel["MUTED"] = 0] = "MUTED";
  NotificationLevel[NotificationLevel["REGULAR"] = 1] = "REGULAR";
  NotificationLevel[NotificationLevel["TRACKING"] = 2] = "TRACKING";
  NotificationLevel[NotificationLevel["WATCHING"] = 3] = "WATCHING";
  return NotificationLevel;
}(NotificationLevel || {});
Object.assign(__ds_scope, { unwrap, CategoryPermission, NotificationLevel });
})(); } catch (e) { __ds_ns.__errors.push({ path: "uploads/CATEGORIES_TYPES.ts", error: String((e && e.message) || e) }); }

// uploads/HUB_PAGE_TYPES.ts
try { (() => {
/**
 * TypeScript types for Hub Page (category detail + topic list)
 * Based on ListController + CategoriesController
 */
// ============================================================================
// HUB CATEGORY (from CategorySerializer)
// ============================================================================
// ============================================================================
// TOPIC LIST (from TopicListSerializer)
// ============================================================================
// ============================================================================
// API RESPONSES
// ============================================================================
// ============================================================================
// COMBINED HUB PAGE STATE
// ============================================================================
// ============================================================================
// REQUEST PARAMETERS
// ============================================================================
// ============================================================================
// NOTIFICATION LEVEL UPDATE
// ============================================================================
// ============================================================================
// ENUMS
// ============================================================================
var TopicFilter = /*#__PURE__*/function (TopicFilter) {
  TopicFilter["LATEST"] = "latest";
  TopicFilter["HOT"] = "hot";
  TopicFilter["TOP"] = "top";
  TopicFilter["BOOKMARKS"] = "bookmarks";
  TopicFilter["WATCHING"] = "watching";
  TopicFilter["TRACKING"] = "tracking";
  return TopicFilter;
}(TopicFilter || {});
var TopPeriod = /*#__PURE__*/function (TopPeriod) {
  TopPeriod["ALL"] = "all";
  TopPeriod["YEARLY"] = "yearly";
  TopPeriod["MONTHLY"] = "monthly";
  TopPeriod["WEEKLY"] = "weekly";
  TopPeriod["DAILY"] = "daily";
  return TopPeriod;
}(TopPeriod || {}); // NotificationLevel and CategoryPermission are defined in CATEGORIES_TYPES.ts.
// Re-export them here so both modules share a single definition.
// ============================================================================
// UTILITY TYPES
// ============================================================================
// unwrap is defined in CATEGORIES_TYPES.ts; re-export the single definition.
Object.assign(__ds_scope, { TopicFilter, TopPeriod, NotificationLevel: __ds_scope.NotificationLevel, CategoryPermission: __ds_scope.CategoryPermission, unwrap: __ds_scope.unwrap });
})(); } catch (e) { __ds_ns.__errors.push({ path: "uploads/HUB_PAGE_TYPES.ts", error: String((e && e.message) || e) }); }

// user-profile-app.jsx
try { (() => {
/* user-profile-app.jsx — Shell, navigation, responsive layout */
const {
  useState,
  useEffect,
  useCallback,
  useMemo
} = React;
const {
  ProfileHero,
  SummarySection,
  ActivitySection,
  NotificationsSection,
  MessagesSection,
  BookmarksSection,
  PreferencesSection,
  Ic,
  Avatar,
  SectionLabel
} = window;

/* ── Surface mode detection ──────────────────────── */
function useSurfaceMode(forced) {
  var _s = useState('expanded');
  var mode = _s[0],
    setMode = _s[1];
  useEffect(function () {
    if (forced && forced !== 'auto') {
      setMode(forced);
      return;
    }
    function update() {
      var w = window.innerWidth;
      if (w >= 1280) setMode('expanded');else if (w >= 1024) setMode('compact-desktop');else if (w >= 768) setMode('rail');else setMode('touch');
    }
    update();
    window.addEventListener('resize', update);
    return function () {
      window.removeEventListener('resize', update);
    };
  }, [forced]);
  return mode;
}

/* ═══════════════════════════════════════════════════
   SIDEBAR (simplified Scriptorium sidebar)
   ═══════════════════════════════════════════════════ */
function Sidebar({
  mode,
  onNav,
  activeSection,
  showPrefs
}) {
  var isRail = mode === 'rail';
  var sidebarW = isRail ? 64 : mode === 'compact-desktop' ? 200 : 240;
  if (mode === 'touch') return null;
  return /*#__PURE__*/React.createElement("aside", {
    style: {
      width: sidebarW,
      minHeight: '100vh',
      background: 'var(--fomio-bg)',
      borderRight: '1px solid var(--fomio-border)',
      padding: isRail ? '20px 0' : '20px 16px',
      display: 'flex',
      flexDirection: 'column',
      gap: 4,
      boxSizing: 'border-box',
      flexShrink: 0,
      position: 'sticky',
      top: 0,
      alignSelf: 'start',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: isRail ? '0 0 16px' : '0 8px 20px',
      display: 'flex',
      alignItems: 'center',
      justifyContent: isRail ? 'center' : 'flex-start'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--fomio-serif)',
      fontWeight: 700,
      fontSize: isRail ? 20 : 24,
      fontStyle: 'italic',
      color: 'var(--fomio-fg)',
      letterSpacing: '-0.03em'
    }
  }, isRail ? 'f' : 'fomio'), !isRail && /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-block',
      width: 18,
      height: 3,
      background: 'var(--fomio-primary)',
      borderRadius: 2,
      marginLeft: 1,
      transform: 'translateY(4px)'
    }
  })), [{
    icon: 'M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z',
    label: 'Latest',
    active: false
  }, {
    icon: 'M11 19a8 8 0 1 0 0-16 8 8 0 0 0 0 16z M21 21l-4.35-4.35',
    label: 'Search',
    active: false
  }, {
    icon: 'M12 5v14 M5 12h14',
    label: 'New byte',
    active: false,
    accent: true
  }, {
    icon: 'M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z',
    label: 'Bookmarks',
    active: false
  }].map(function (item, i) {
    return /*#__PURE__*/React.createElement("div", {
      key: i,
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 12,
        padding: isRail ? '10px 0' : '8px 12px',
        borderRadius: 10,
        cursor: 'pointer',
        justifyContent: isRail ? 'center' : 'flex-start',
        color: item.accent ? 'var(--fomio-primary)' : item.active ? 'var(--fomio-fg)' : 'var(--fomio-fg-muted)',
        fontFamily: 'var(--fomio-sans)',
        fontSize: 14,
        fontWeight: item.active ? 600 : 500,
        transition: 'background 120ms'
      }
    }, /*#__PURE__*/React.createElement(Ic, {
      d: item.icon,
      size: 18,
      color: item.accent ? 'var(--fomio-primary)' : 'currentColor'
    }), !isRail && /*#__PURE__*/React.createElement("span", null, item.label));
  }), !isRail ? /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 'auto',
      paddingTop: 16,
      borderTop: '1px solid var(--fomio-border-soft)',
      display: 'flex',
      flexDirection: 'column',
      gap: 4
    }
  }, showPrefs && function () {
    var prefsActive = activeSection === 'preferences';
    return /*#__PURE__*/React.createElement("div", {
      role: "button",
      tabIndex: 0,
      onClick: function () {
        if (onNav) onNav('preferences');
      },
      onKeyDown: function (e) {
        if ((e.key === 'Enter' || e.key === ' ') && onNav) {
          e.preventDefault();
          onNav('preferences');
        }
      },
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 12,
        padding: '8px 12px',
        borderRadius: 10,
        cursor: 'pointer',
        background: prefsActive ? 'var(--fomio-primary-soft)' : 'transparent',
        color: prefsActive ? 'var(--fomio-primary)' : 'var(--fomio-fg-muted)',
        fontFamily: 'var(--fomio-sans)',
        fontSize: 14,
        fontWeight: prefsActive ? 600 : 500,
        transition: 'background 120ms, color 120ms',
        userSelect: 'none'
      }
    }, /*#__PURE__*/React.createElement(Ic, {
      d: "M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8z M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z",
      size: 18,
      color: prefsActive ? 'var(--fomio-primary)' : 'currentColor'
    }), /*#__PURE__*/React.createElement("span", null, "Preferences"));
  }(), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      padding: '8px 12px',
      borderRadius: 10,
      cursor: 'pointer',
      background: 'var(--fomio-surface)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 28,
      height: 28,
      borderRadius: '50%',
      background: '#D6C9A8',
      color: '#5C4A1E',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontFamily: 'var(--fomio-serif)',
      fontWeight: 700,
      fontSize: 11,
      fontStyle: 'italic'
    }
  }, "IZ"), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--fomio-sans)',
      fontSize: 13,
      fontWeight: 600,
      color: 'var(--fomio-fg)',
      overflow: 'hidden',
      textOverflow: 'ellipsis',
      whiteSpace: 'nowrap'
    }
  }, "Ismail Z."), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--fomio-sans)',
      fontSize: 11,
      color: 'var(--fomio-fg-muted)'
    }
  }, "@ismail")))) : showPrefs && function () {
    var prefsActive = activeSection === 'preferences';
    return /*#__PURE__*/React.createElement("div", {
      role: "button",
      tabIndex: 0,
      onClick: function () {
        if (onNav) onNav('preferences');
      },
      onKeyDown: function (e) {
        if ((e.key === 'Enter' || e.key === ' ') && onNav) {
          e.preventDefault();
          onNav('preferences');
        }
      },
      style: {
        marginTop: 'auto',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '10px 0',
        borderRadius: 10,
        cursor: 'pointer',
        background: prefsActive ? 'var(--fomio-primary-soft)' : 'transparent',
        color: prefsActive ? 'var(--fomio-primary)' : 'var(--fomio-fg-muted)',
        transition: 'background 120ms'
      }
    }, /*#__PURE__*/React.createElement(Ic, {
      d: "M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8z M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z",
      size: 18,
      color: prefsActive ? 'var(--fomio-primary)' : 'currentColor'
    }));
  }());
}

/* ═══════════════════════════════════════════════════
   MASTER PANE (profile section nav)
   ═══════════════════════════════════════════════════ */
function MasterPane({
  user,
  isSelf,
  activeSection,
  onNav,
  mode,
  unreadNotifs,
  unreadMsgs
}) {
  var sections = [{
    key: 'summary',
    icon: 'M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2',
    label: 'Summary'
  }, {
    key: 'activity',
    icon: 'M22 12h-4l-3 9L9 3l-3 9H2',
    label: 'Activity'
  }];
  if (isSelf) {
    sections.push({
      key: 'notifications',
      icon: 'M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9',
      label: 'Notifications',
      badge: unreadNotifs
    });
    sections.push({
      key: 'messages',
      icon: 'M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z M22 6l-10 7L2 6',
      label: 'Messages',
      badge: unreadMsgs
    });
  }
  sections.push({
    key: 'bookmarks',
    icon: 'M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z',
    label: 'Bookmarks'
  });
  if (isSelf) {
    sections.push({
      key: 'preferences',
      icon: 'M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8z',
      label: 'Preferences'
    });
  }
  var paneW = mode === 'compact-desktop' ? 220 : 260;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      width: paneW,
      minHeight: '100vh',
      borderRight: '1px solid var(--fomio-border)',
      padding: '24px 14px',
      boxSizing: 'border-box',
      flexShrink: 0,
      position: 'sticky',
      top: 0,
      alignSelf: 'start',
      display: 'flex',
      flexDirection: 'column',
      gap: 2,
      background: 'var(--fomio-bg)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12,
      padding: '4px 10px 20px',
      marginBottom: 4
    }
  }, /*#__PURE__*/React.createElement(Avatar, {
    user: user,
    size: 40
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--fomio-serif)',
      fontSize: 16,
      fontWeight: 700,
      color: 'var(--fomio-fg)',
      letterSpacing: '-0.01em',
      overflow: 'hidden',
      textOverflow: 'ellipsis',
      whiteSpace: 'nowrap'
    }
  }, user.name), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--fomio-sans)',
      fontSize: 12,
      color: 'var(--fomio-fg-muted)'
    }
  }, "@", user.username))), sections.map(function (s) {
    var isActive = s.key === activeSection;
    return /*#__PURE__*/React.createElement("div", {
      role: "button",
      tabIndex: 0,
      key: s.key,
      onClick: function () {
        onNav(s.key);
      },
      onKeyDown: function (e) {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          onNav(s.key);
        }
      },
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 10,
        padding: '9px 12px',
        borderRadius: 10,
        cursor: 'pointer',
        fontFamily: 'var(--fomio-sans)',
        fontSize: 14,
        fontWeight: isActive ? 600 : 500,
        color: isActive ? 'var(--fomio-primary)' : 'var(--fomio-fg-muted)',
        background: isActive ? 'var(--fomio-primary-soft)' : 'transparent',
        textAlign: 'left',
        width: '100%',
        boxSizing: 'border-box',
        transition: 'background 120ms, color 120ms',
        userSelect: 'none'
      }
    }, /*#__PURE__*/React.createElement(Ic, {
      d: s.icon,
      size: 17,
      color: isActive ? 'var(--fomio-primary)' : 'var(--fomio-fg-muted)'
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        flex: 1
      }
    }, s.label), s.badge && /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--fomio-mono)',
        fontSize: 11,
        fontWeight: 700,
        color: '#fff',
        background: 'var(--fomio-primary)',
        padding: '1px 6px',
        borderRadius: 9999,
        minWidth: 18,
        textAlign: 'center'
      }
    }, s.badge));
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 'auto',
      padding: '16px 12px 0',
      borderTop: '1px solid var(--fomio-border-soft)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--fomio-sans)',
      fontSize: 12,
      color: 'var(--fomio-fg-muted)',
      fontWeight: 500,
      display: 'flex',
      alignItems: 'center',
      gap: 6
    }
  }, /*#__PURE__*/React.createElement(Ic, {
    d: "M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z",
    size: 14
  }), " ", user.badgeCount, " badges"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--fomio-sans)',
      fontSize: 12,
      color: 'var(--fomio-fg-muted)',
      fontWeight: 500,
      display: 'flex',
      alignItems: 'center',
      gap: 6,
      marginTop: 6
    }
  }, /*#__PURE__*/React.createElement(Ic, {
    d: "M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2",
    size: 14
  }), " ", user.groups.join(', '))));
}

/* ═══════════════════════════════════════════════════
   DETACHED MENU (floating master-pane + content card)
   ═══════════════════════════════════════════════════ */
function DetachedMenu({
  user,
  isSelf,
  activeSection,
  onNav,
  mode,
  unreadNotifs,
  unreadMsgs,
  content,
  heroStyle
}) {
  var sections = [{
    key: 'summary',
    icon: 'M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2',
    label: 'Summary',
    sub: 'Overview, badges & stats'
  }, {
    key: 'activity',
    icon: 'M22 12h-4l-3 9L9 3l-3 9H2',
    label: 'Activity',
    sub: 'Bytes, replies & likes'
  }];
  if (isSelf) {
    sections.push({
      key: 'notifications',
      icon: 'M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9',
      label: 'Notifications',
      sub: 'Alerts & mentions',
      badge: unreadNotifs
    });
    sections.push({
      key: 'messages',
      icon: 'M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z M22 6l-10 7L2 6',
      label: 'Messages',
      sub: 'Direct messages',
      badge: unreadMsgs
    });
  }
  sections.push({
    key: 'bookmarks',
    icon: 'M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z',
    label: 'Bookmarks',
    sub: 'Saved bytes'
  });
  var isCompact = mode === 'compact-desktop';
  var listW = isCompact ? 280 : 324;
  var sectionTitle = activeSection.charAt(0).toUpperCase() + activeSection.slice(1);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0,
      display: 'flex',
      alignItems: 'flex-start',
      padding: isCompact ? '24px 24px 24px 16px' : '32px 44px 32px 28px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0,
      display: 'flex',
      background: 'var(--fomio-card)',
      border: '1px solid var(--fomio-border)',
      borderRadius: 26,
      boxShadow: '0 28px 64px -16px rgba(28,16,10,0.20), 0 8px 24px -10px rgba(28,16,10,0.10)',
      overflow: 'hidden',
      height: 'calc(100vh - 64px)',
      position: 'sticky',
      top: 32
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: listW,
      flexShrink: 0,
      borderRight: '1px solid var(--fomio-border-soft)',
      display: 'flex',
      flexDirection: 'column',
      background: 'var(--fomio-bg)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12,
      padding: '20px 16px 16px 22px',
      borderBottom: '1px solid var(--fomio-border-soft)'
    }
  }, /*#__PURE__*/React.createElement(Avatar, {
    user: user,
    size: 38
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--fomio-serif)',
      fontSize: 16,
      fontWeight: 700,
      fontStyle: 'italic',
      color: 'var(--fomio-fg)',
      letterSpacing: '-0.01em',
      overflow: 'hidden',
      textOverflow: 'ellipsis',
      whiteSpace: 'nowrap'
    }
  }, user.name), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--fomio-sans)',
      fontSize: 12,
      color: 'var(--fomio-fg-muted)'
    }
  }, "@", user.username)), /*#__PURE__*/React.createElement("button", {
    title: "Close",
    style: {
      width: 30,
      height: 30,
      borderRadius: 8,
      border: 'none',
      background: 'transparent',
      color: 'var(--fomio-fg-muted)',
      cursor: 'pointer',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement(Ic, {
    d: "M18 6L6 18 M6 6l12 12",
    size: 16,
    color: "currentColor"
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      overflowY: 'auto',
      padding: '10px 0'
    }
  }, sections.map(function (s) {
    var isActive = s.key === activeSection;
    return /*#__PURE__*/React.createElement("div", {
      role: "button",
      tabIndex: 0,
      key: s.key,
      onClick: function () {
        onNav(s.key);
      },
      onKeyDown: function (e) {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          onNav(s.key);
        }
      },
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 13,
        padding: '11px 13px',
        margin: '2px 12px',
        borderRadius: 14,
        cursor: 'pointer',
        background: isActive ? 'var(--fomio-primary-soft)' : 'transparent',
        transition: 'background 120ms',
        userSelect: 'none'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        width: 38,
        height: 38,
        borderRadius: 11,
        background: isActive ? 'color-mix(in oklab, var(--fomio-card) 55%, transparent)' : 'var(--fomio-surface)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        flexShrink: 0
      }
    }, /*#__PURE__*/React.createElement(Ic, {
      d: s.icon,
      size: 18,
      color: isActive ? 'var(--fomio-primary)' : 'var(--fomio-fg-muted)'
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        minWidth: 0
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--fomio-sans)',
        fontSize: 14,
        fontWeight: 700,
        color: isActive ? 'var(--fomio-primary)' : 'var(--fomio-fg)',
        lineHeight: 1.3,
        overflow: 'hidden',
        textOverflow: 'ellipsis',
        whiteSpace: 'nowrap'
      }
    }, s.label), /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--fomio-sans)',
        fontSize: 12,
        color: isActive ? 'color-mix(in oklab, var(--fomio-primary) 72%, transparent)' : 'var(--fomio-fg-muted)',
        lineHeight: 1.35,
        overflow: 'hidden',
        textOverflow: 'ellipsis',
        whiteSpace: 'nowrap'
      }
    }, s.sub)), s.badge ? /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--fomio-mono)',
        fontSize: 11,
        fontWeight: 700,
        color: '#fff',
        background: 'var(--fomio-primary)',
        padding: '1px 6px',
        borderRadius: 9999,
        minWidth: 18,
        textAlign: 'center',
        flexShrink: 0
      }
    }, s.badge) : /*#__PURE__*/React.createElement(Ic, {
      d: "M9 18l6-6-6-6",
      size: 15,
      color: isActive ? 'var(--fomio-primary)' : 'var(--fomio-fg-muted)'
    }));
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0,
      overflowY: 'auto',
      padding: isCompact ? '32px 32px' : '40px 48px'
    }
  }, activeSection === 'summary' ? /*#__PURE__*/React.createElement(ProfileHero, {
    user: user,
    isSelf: isSelf,
    heroStyle: heroStyle,
    isNarrow: isCompact
  }) : /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 24,
      paddingBottom: 16,
      borderBottom: '1px solid var(--fomio-border)'
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: 'var(--fomio-serif)',
      fontWeight: 700,
      fontSize: 24,
      letterSpacing: '-0.02em',
      color: 'var(--fomio-fg)',
      margin: 0
    }
  }, sectionTitle)), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: activeSection === 'summary' ? 32 : 0
    }
  }, content))));
}

/* ═══════════════════════════════════════════════════
   HORIZONTAL TABS NAV
   ═══════════════════════════════════════════════════ */
function TabsNav({
  isSelf,
  activeSection,
  onNav,
  unreadNotifs,
  unreadMsgs
}) {
  var tabs = [{
    key: 'summary',
    label: 'Summary'
  }, {
    key: 'activity',
    label: 'Activity'
  }];
  if (isSelf) {
    tabs.push({
      key: 'notifications',
      label: 'Notifications',
      badge: unreadNotifs
    });
    tabs.push({
      key: 'messages',
      label: 'Messages',
      badge: unreadMsgs
    });
  }
  tabs.push({
    key: 'bookmarks',
    label: 'Bookmarks'
  });
  if (isSelf) tabs.push({
    key: 'preferences',
    label: 'Preferences'
  });
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 0,
      borderBottom: '1px solid var(--fomio-border-soft)',
      marginBottom: 28,
      overflowX: 'auto',
      scrollbarWidth: 'none'
    }
  }, tabs.map(function (t) {
    var isActive = t.key === activeSection;
    return /*#__PURE__*/React.createElement("button", {
      key: t.key,
      onClick: function () {
        onNav(t.key);
      },
      style: {
        display: 'inline-flex',
        alignItems: 'center',
        gap: 6,
        height: 40,
        padding: '0 16px',
        background: 'transparent',
        border: 'none',
        borderBottom: isActive ? '2px solid var(--fomio-primary)' : '2px solid transparent',
        marginBottom: -1,
        cursor: 'pointer',
        fontFamily: 'var(--fomio-sans)',
        fontSize: 14,
        fontWeight: isActive ? 600 : 500,
        color: isActive ? 'var(--fomio-primary)' : 'var(--fomio-fg-muted)',
        whiteSpace: 'nowrap',
        transition: 'color 200ms, border-color 200ms'
      }
    }, t.label, t.badge && /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--fomio-mono)',
        fontSize: 10,
        fontWeight: 700,
        color: '#fff',
        background: 'var(--fomio-primary)',
        padding: '0 5px',
        borderRadius: 9999,
        minWidth: 16,
        height: 16,
        display: 'inline-flex',
        alignItems: 'center',
        justifyContent: 'center'
      }
    }, t.badge));
  }));
}

/* ═══════════════════════════════════════════════════
   TOUCH BOTTOM NAV
   ═══════════════════════════════════════════════════ */
function BottomNav() {
  var items = [{
    icon: 'M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z',
    label: 'Home'
  }, {
    icon: 'M11 19a8 8 0 1 0 0-16 8 8 0 0 0 0 16z M21 21l-4.35-4.35',
    label: 'Search'
  }, {
    icon: 'M12 5v14 M5 12h14',
    label: 'New'
  }, {
    icon: 'M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9',
    label: 'Alerts'
  }, {
    icon: 'M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2',
    label: 'Me',
    active: true
  }];
  return /*#__PURE__*/React.createElement("nav", {
    style: {
      position: 'fixed',
      bottom: 0,
      left: 0,
      right: 0,
      height: 56,
      background: 'var(--fomio-card)',
      borderTop: '1px solid var(--fomio-border)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-around',
      zIndex: 100,
      paddingBottom: 'env(safe-area-inset-bottom, 0px)'
    }
  }, items.map(function (item, i) {
    return /*#__PURE__*/React.createElement("div", {
      key: i,
      style: {
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        gap: 3,
        cursor: 'pointer',
        color: item.active ? 'var(--fomio-primary)' : 'var(--fomio-fg-muted)'
      }
    }, /*#__PURE__*/React.createElement(Ic, {
      d: item.icon,
      size: 20,
      color: "currentColor"
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--fomio-sans)',
        fontSize: 10,
        fontWeight: item.active ? 600 : 500
      }
    }, item.label));
  }));
}

/* ═══════════════════════════════════════════════════
   TOUCH STACK HEADER
   ═══════════════════════════════════════════════════ */
function TouchHeader({
  title,
  onBack
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12,
      padding: '12px 16px',
      borderBottom: '1px solid var(--fomio-border-soft)',
      background: 'var(--fomio-bg)',
      position: 'sticky',
      top: 0,
      zIndex: 50
    }
  }, onBack && /*#__PURE__*/React.createElement("button", {
    onClick: onBack,
    style: {
      background: 'none',
      border: 'none',
      cursor: 'pointer',
      padding: 0,
      display: 'flex',
      alignItems: 'center',
      color: 'var(--fomio-fg-muted)'
    }
  }, /*#__PURE__*/React.createElement(Ic, {
    d: "M19 12H5 M12 19l-7-7 7-7",
    size: 20
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--fomio-sans)',
      fontSize: 16,
      fontWeight: 700,
      color: 'var(--fomio-fg)',
      flex: 1
    }
  }, title));
}

/* ═══════════════════════════════════════════════════
   MAIN APP
   ═══════════════════════════════════════════════════ */
function UserProfileApp({
  tweaks
}) {
  var heroStyle = tweaks.heroStyle || 'editorial';
  var activityStyle = tweaks.activityStyle || 'timeline';
  var navStyle = tweaks.navStyle || 'master-pane';
  var viewMode = tweaks.viewMode || 'self';
  var forcedMode = tweaks.surfaceMode || 'auto';
  var isDark = tweaks.darkMode || false;
  var surfaceMode = useSurfaceMode(forcedMode);
  var isSelf = viewMode === 'self';
  var user = isSelf ? UP_DATA.self : UP_DATA.other;
  var data = UP_DATA;
  var _s = useState('summary');
  var section = _s[0],
    setSection = _s[1];

  /* Reset section when switching view mode (other-user hides self-only sections) */
  var prevViewRef = React.useRef(viewMode);
  useEffect(function () {
    if (prevViewRef.current !== viewMode) {
      prevViewRef.current = viewMode;
      var selfOnly = ['notifications', 'messages', 'preferences'];
      if (viewMode === 'other' && selfOnly.indexOf(section) !== -1) {
        setSection('summary');
      }
    }
  }, [viewMode, section]);
  var unreadNotifs = 2;
  var unreadMsgs = 1;
  useEffect(function () {
    document.documentElement.setAttribute('data-theme', isDark ? 'dark' : 'light');
  }, [isDark]);
  var isTouch = surfaceMode === 'touch';
  var useDetached = navStyle === 'detached' && !isTouch;
  var useMaster = navStyle === 'master-pane' && !isTouch;

  /* Section content */
  var content = null;
  if (section === 'summary') content = React.createElement(SummarySection, {
    user: user
  });else if (section === 'activity') content = React.createElement(ActivitySection, {
    items: data.activities,
    style: activityStyle,
    isSelf: isSelf,
    topics: data.createdTopics,
    reads: data.reads,
    drafts: data.drafts,
    pending: data.pending,
    bookmarks: data.bookmarks
  });else if (section === 'notifications') content = React.createElement(NotificationsSection, {
    items: data.notifications
  });else if (section === 'messages') content = React.createElement(MessagesSection, {
    items: data.messages
  });else if (section === 'bookmarks') content = React.createElement(BookmarksSection, {
    items: data.bookmarks
  });else if (section === 'preferences') content = React.createElement(PreferencesSection, {
    user: user
  });

  /* Touch layout */
  if (isTouch) {
    return /*#__PURE__*/React.createElement("div", {
      style: {
        minHeight: '100vh',
        background: 'var(--fomio-bg)',
        paddingBottom: 72
      }
    }, /*#__PURE__*/React.createElement(TouchHeader, {
      title: section === 'summary' ? user.name : section.charAt(0).toUpperCase() + section.slice(1),
      onBack: section !== 'summary' ? function () {
        setSection('summary');
      } : null
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        padding: '0 16px'
      }
    }, section === 'summary' && /*#__PURE__*/React.createElement(ProfileHero, {
      user: user,
      isSelf: isSelf,
      heroStyle: heroStyle,
      isNarrow: true
    }), section === 'summary' ? /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(TabsNav, {
      isSelf: isSelf,
      activeSection: section,
      onNav: setSection,
      unreadNotifs: unreadNotifs,
      unreadMsgs: unreadMsgs
    }), content) : /*#__PURE__*/React.createElement("div", {
      style: {
        paddingTop: 20
      }
    }, content)), /*#__PURE__*/React.createElement(BottomNav, null));
  }

  /* Detached floating menu layout */
  if (useDetached) {
    return /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        minHeight: '100vh',
        background: 'var(--fomio-surface)'
      }
    }, /*#__PURE__*/React.createElement(Sidebar, {
      mode: surfaceMode,
      onNav: setSection,
      activeSection: section,
      showPrefs: isSelf
    }), /*#__PURE__*/React.createElement(DetachedMenu, {
      user: user,
      isSelf: isSelf,
      activeSection: section,
      onNav: setSection,
      mode: surfaceMode,
      unreadNotifs: unreadNotifs,
      unreadMsgs: unreadMsgs,
      content: content,
      heroStyle: heroStyle
    }));
  }

  /* Desktop / rail layout */
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      minHeight: '100vh',
      background: 'var(--fomio-bg)'
    }
  }, /*#__PURE__*/React.createElement(Sidebar, {
    mode: surfaceMode
  }), useMaster && /*#__PURE__*/React.createElement(MasterPane, {
    user: user,
    isSelf: isSelf,
    activeSection: section,
    onNav: setSection,
    mode: surfaceMode,
    unreadNotifs: unreadNotifs,
    unreadMsgs: unreadMsgs
  }), /*#__PURE__*/React.createElement("main", {
    style: {
      flex: 1,
      minWidth: 0,
      padding: surfaceMode === 'rail' ? '32px 24px' : '40px 48px',
      maxWidth: 780,
      boxSizing: 'border-box'
    }
  }, (!useMaster || section === 'summary') && /*#__PURE__*/React.createElement(ProfileHero, {
    user: user,
    isSelf: isSelf,
    heroStyle: useMaster ? heroStyle : heroStyle,
    isNarrow: surfaceMode === 'rail'
  }), !useMaster && /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 24
    }
  }, /*#__PURE__*/React.createElement(TabsNav, {
    isSelf: isSelf,
    activeSection: section,
    onNav: setSection,
    unreadNotifs: unreadNotifs,
    unreadMsgs: unreadMsgs
  })), useMaster && section !== 'summary' && /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 24,
      paddingBottom: 16,
      borderBottom: '1px solid var(--fomio-border)'
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: 'var(--fomio-serif)',
      fontWeight: 700,
      fontSize: 24,
      letterSpacing: '-0.02em',
      color: 'var(--fomio-fg)',
      margin: 0
    }
  }, section.charAt(0).toUpperCase() + section.slice(1))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: useMaster && section === 'summary' ? 32 : 0
    }
  }, content)));
}
window.UserProfileApp = UserProfileApp;
})(); } catch (e) { __ds_ns.__errors.push({ path: "user-profile-app.jsx", error: String((e && e.message) || e) }); }

// user-profile-data.js
try { (() => {
/* user-profile-data.js — Mock data for /u/user/* profile prototype */
window.UP_DATA = {
  self: {
    id: 1,
    username: 'ismail',
    name: 'Ismail Zabalawi',
    initials: 'IZ',
    avatarBg: '#D6C9A8',
    avatarFg: '#5C4A1E',
    title: 'Founder',
    bio: 'Building fomio — a quiet place for reading and writing. Previously at Notion, Stripe. I believe the best software gets out of your way.',
    location: 'San Francisco',
    website: 'ismail.fyi',
    websiteUrl: 'https://ismail.fyi',
    joinDate: '2024-01-15',
    lastSeen: '17 Jun 2026',
    lastPosted: '16 Jun 2026',
    isAdmin: true,
    isMod: false,
    trustLevel: 'Leader',
    profileViews: 2847,
    badgeCount: 12,
    groups: ['Team', 'Founders'],
    stats: {
      bytesWritten: 42,
      replies: 156,
      likesGiven: 89,
      likesReceived: 1247,
      daysVisited: 487,
      topicsEntered: 342,
      postsRead: 4891,
      timeReadHours: 248
    },
    topCategories: [{
      name: 'Essays',
      color: '#C44536',
      count: 18
    }, {
      name: 'Craft',
      color: '#6B6B72',
      count: 12
    }, {
      name: 'Quiet internet',
      color: '#2A6F4F',
      count: 8
    }, {
      name: 'Letters',
      color: '#8B6B4A',
      count: 4
    }],
    badges: [{
      name: 'First byte',
      glyph: '✎',
      date: 'Jan 2024'
    }, {
      name: 'Reader',
      glyph: '◉',
      date: 'Feb 2024'
    }, {
      name: 'Devotee',
      glyph: '◆',
      date: 'Jun 2025'
    }, {
      name: 'Empathetic',
      glyph: '♥',
      date: 'Dec 2025'
    }],
    topReplies: [{
      title: 'The case for chronological feeds',
      teret: 'Quiet internet',
      likes: 34
    }, {
      title: 'What nobody tells you about community moderation',
      teret: 'Craft',
      likes: 28
    }, {
      title: 'A defense of slow software',
      teret: 'Quiet internet',
      likes: 19
    }]
  },
  other: {
    id: 2,
    username: 'lena',
    name: 'Lena Marsh',
    initials: 'LM',
    avatarBg: '#B8C7B0',
    avatarFg: '#35472B',
    title: null,
    bio: 'Writer, reader, occasional gardener. I write about the internet we lost and the one we might build instead.',
    location: 'Portland, OR',
    website: 'lenamarsh.com',
    websiteUrl: 'https://lenamarsh.com',
    joinDate: '2024-03-22',
    lastSeen: '16 Jun 2026',
    lastPosted: '15 Jun 2026',
    isAdmin: false,
    isMod: false,
    trustLevel: 'Regular',
    profileViews: 1423,
    badgeCount: 8,
    groups: ['Writers guild'],
    stats: {
      bytesWritten: 67,
      replies: 234,
      likesGiven: 412,
      likesReceived: 2891,
      daysVisited: 523,
      topicsEntered: 891,
      postsRead: 12340,
      timeReadHours: 483
    },
    topCategories: [{
      name: 'Essays',
      color: '#C44536',
      count: 31
    }, {
      name: 'Quiet internet',
      color: '#2A6F4F',
      count: 22
    }, {
      name: 'Letters',
      color: '#8B6B4A',
      count: 9
    }, {
      name: 'Craft',
      color: '#6B6B72',
      count: 5
    }],
    badges: [{
      name: 'First byte',
      glyph: '✎',
      date: 'Mar 2024'
    }, {
      name: 'Devotee',
      glyph: '◆',
      date: 'Jan 2025'
    }, {
      name: 'Empathetic',
      glyph: '♥',
      date: 'Aug 2025'
    }],
    topReplies: [{
      title: 'On writing without an audience',
      teret: 'Essays',
      likes: 42
    }, {
      title: 'Why prose needs whitespace',
      teret: 'Craft',
      likes: 31
    }, {
      title: 'Against infinite scroll',
      teret: 'Essays',
      likes: 24
    }]
  },
  activities: [{
    type: 'topic',
    title: 'On writing without an audience',
    teret: 'Essays',
    teretColor: '#C44536',
    time: '3 days ago',
    excerpt: "There\u2019s a specific pleasure in opening an app and finding it unchanged \u2014 no new tab, no pulsing dot, no urgent nothing.",
    likes: 42,
    replies: 8
  }, {
    type: 'reply',
    title: 'The case for chronological feeds',
    teret: 'Quiet internet',
    teretColor: '#2A6F4F',
    time: '1 day ago',
    excerpt: 'A clock is a modest instrument. It doesn\u2019t know you, doesn\u2019t care what you\u2019ve read before.',
    replyTo: 'Jun Nakamura'
  }, {
    type: 'topic',
    title: 'Letters to no one',
    teret: 'Letters',
    teretColor: '#8B6B4A',
    time: '5 hours ago',
    excerpt: 'Notes from a year of writing things only I would read.',
    likes: 89,
    replies: 12
  }, {
    type: 'like',
    title: 'Why I stopped optimizing my morning',
    actor: 'Ada Reyes',
    teret: 'Craft',
    teretColor: '#6B6B72',
    time: '12 hours ago'
  }, {
    type: 'reply',
    title: 'A defense of slow software',
    teret: 'Quiet internet',
    teretColor: '#2A6F4F',
    time: '2 days ago',
    excerpt: 'Speed is a choice. So is patience.',
    replyTo: 'Marcus Chen'
  }, {
    type: 'topic',
    title: 'Reading as resistance',
    teret: 'Essays',
    teretColor: '#C44536',
    time: '4 days ago',
    excerpt: 'In an attention economy, sitting still with a paragraph is a radical act.',
    likes: 127,
    replies: 34
  }, {
    type: 'like',
    title: 'The last good website',
    actor: 'Jun Nakamura',
    teret: 'Quiet internet',
    teretColor: '#2A6F4F',
    time: '5 days ago'
  }, {
    type: 'reply',
    title: 'What nobody tells you about community moderation',
    teret: 'Craft',
    teretColor: '#6B6B72',
    time: '1 week ago',
    excerpt: 'The hard part isn\u2019t the rules. It\u2019s the silences between them.',
    replyTo: 'Sam Torres'
  }],
  /* /topics/created-by/:username.json → topic_list. Bytes (activity/topics) renders THIS,
     not the activity stream: title, category, posts/replies, views, last activity (bumped_at). */
  createdTopics: [{
    id: 482,
    title: 'On writing without an audience',
    teret: 'Essays',
    teretColor: '#C44536',
    replies: 8,
    views: 1240,
    likes: 42,
    posted: '3 days ago',
    activity: '5h ago',
    pinned: false,
    closed: false
  }, {
    id: 471,
    title: 'Letters to no one',
    teret: 'Letters',
    teretColor: '#8B6B4A',
    replies: 12,
    views: 3180,
    likes: 89,
    posted: '5 days ago',
    activity: '2h ago',
    pinned: true,
    closed: false
  }, {
    id: 455,
    title: 'Reading as resistance',
    teret: 'Essays',
    teretColor: '#C44536',
    replies: 34,
    views: 8920,
    likes: 127,
    posted: '1 week ago',
    activity: '1 day ago',
    pinned: false,
    closed: false
  }, {
    id: 449,
    title: 'A defense of slow software',
    teret: 'Quiet internet',
    teretColor: '#2A6F4F',
    replies: 19,
    views: 5470,
    likes: 76,
    posted: '2 weeks ago',
    activity: '3 days ago',
    pinned: false,
    closed: false
  }, {
    id: 431,
    title: 'The quiet internet manifesto',
    teret: 'Quiet internet',
    teretColor: '#2A6F4F',
    replies: 56,
    views: 14200,
    likes: 203,
    posted: '3 weeks ago',
    activity: '4 days ago',
    pinned: false,
    closed: true
  }, {
    id: 418,
    title: 'Notes on typography for screens',
    teret: 'Craft',
    teretColor: '#6B6B72',
    replies: 7,
    views: 2310,
    likes: 38,
    posted: '1 month ago',
    activity: '1 week ago',
    pinned: false,
    closed: false
  }, {
    id: 402,
    title: 'What I learned shipping a forum',
    teret: 'Craft',
    teretColor: '#6B6B72',
    replies: 23,
    views: 6650,
    likes: 94,
    posted: '1 month ago',
    activity: '2 weeks ago',
    pinned: false,
    closed: false
  }],
  reads: [{
    title: 'The future of small social',
    teret: 'Quiet internet',
    teretColor: '#2A6F4F',
    lastRead: '2h ago',
    postsRead: 14,
    total: 14
  }, {
    title: 'Why prose needs whitespace',
    teret: 'Craft',
    teretColor: '#6B6B72',
    lastRead: '5h ago',
    postsRead: 8,
    total: 12
  }, {
    title: 'Against infinite scroll',
    teret: 'Essays',
    teretColor: '#C44536',
    lastRead: 'Yesterday',
    postsRead: 23,
    total: 23
  }, {
    title: 'A typographer walks into a forum',
    teret: 'Craft',
    teretColor: '#6B6B72',
    lastRead: '2 days ago',
    postsRead: 5,
    total: 19
  }, {
    title: 'On the ethics of recommendation',
    teret: 'Essays',
    teretColor: '#C44536',
    lastRead: '4 days ago',
    postsRead: 31,
    total: 31
  }],
  drafts: [{
    title: 'Notes toward a slower feed',
    teret: 'Quiet internet',
    teretColor: '#2A6F4F',
    excerpt: 'What if the default state of an app was rest? A draft I keep returning to\u2026',
    saved: '1h ago',
    type: 'topic'
  }, {
    title: 'Re: The case for chronological feeds',
    teret: null,
    teretColor: null,
    excerpt: 'You\u2019re right that a clock doesn\u2019t flatter anyone. But I\u2019d push back on\u2026',
    saved: '3 days ago',
    type: 'reply',
    replyTo: 'Jun Nakamura'
  }, {
    title: '(untitled)',
    teret: null,
    teretColor: null,
    excerpt: 'The thing about writing in public is that the public is mostly imaginary.',
    saved: '1 week ago',
    type: 'topic'
  }],
  pending: [{
    title: 'A reply on community norms',
    teret: 'Craft',
    teretColor: '#6B6B72',
    excerpt: 'Submitted for review \u2014 awaiting moderator approval before it appears.',
    submitted: '6h ago',
    replyTo: 'Sam Torres'
  }, {
    title: 'First post in Letters',
    teret: 'Letters',
    teretColor: '#8B6B4A',
    excerpt: 'New members\u2019 first posts are held until approved. This is in the queue.',
    submitted: '2 days ago',
    replyTo: null
  }],
  notifications: [{
    type: 'reply',
    title: 'The case for chronological feeds',
    user: 'Jun Nakamura',
    time: '2h',
    read: false,
    excerpt: 'Completely agree about the clock metaphor\u2026'
  }, {
    type: 'like',
    title: 'On writing without an audience',
    user: 'Ada Reyes',
    time: '4h',
    read: false,
    count: 3
  }, {
    type: 'mention',
    title: 'Building in public \u2014 week 47',
    user: 'Marcus Chen',
    time: '1d',
    read: true,
    excerpt: '@ismail\u2019s point about slow software resonates\u2026'
  }, {
    type: 'reply',
    title: 'Letters to no one',
    user: 'Priya Sharma',
    time: '1d',
    read: true,
    excerpt: 'This is exactly why I started writing here.'
  }, {
    type: 'badge',
    title: 'Earned \u201cDevotee\u201d',
    user: null,
    time: '3d',
    read: true
  }, {
    type: 'like',
    title: 'Reading as resistance',
    user: 'Various',
    time: '4d',
    read: true,
    count: 12
  }, {
    type: 'reply',
    title: 'A defense of slow software',
    user: 'Sam Torres',
    time: '5d',
    read: true,
    excerpt: 'The tension between speed and craft\u2026'
  }],
  messages: [{
    participants: ['Ada Reyes'],
    title: 'Collaboration on the quiet internet series',
    last: 'I\u2019d love to co-write something about this. Maybe a back-and-forth format?',
    time: '2h',
    unread: true
  }, {
    participants: ['Jun Nakamura'],
    title: 'Feed algorithm research',
    last: 'Found that paper you mentioned \u2014 sending the link.',
    time: '1d',
    unread: false
  }, {
    participants: ['Marcus Chen', 'Sam Torres'],
    title: 'Moderation guidelines draft',
    last: 'Updated section 3 with the new language. Take a look when you can.',
    time: '3d',
    unread: false
  }, {
    participants: ['Priya Sharma'],
    title: 'Welcome to fomio',
    last: 'Thanks! Still finding my way around. The Essays teret is wonderful.',
    time: '1w',
    unread: false
  }],
  bookmarks: [{
    title: 'The future of small social',
    teret: 'Quiet internet',
    teretColor: '#2A6F4F',
    author: 'Jun Nakamura',
    time: '2d ago',
    reminder: null
  }, {
    title: 'Why prose needs whitespace',
    teret: 'Craft',
    teretColor: '#6B6B72',
    author: 'Ada Reyes',
    time: '1w ago',
    reminder: 'Tomorrow'
  }, {
    title: 'Against infinite scroll',
    teret: 'Essays',
    teretColor: '#C44536',
    author: 'Marcus Chen',
    time: '2w ago',
    reminder: null
  }, {
    title: 'A typographer walks into a forum',
    teret: 'Craft',
    teretColor: '#6B6B72',
    author: 'Sam Torres',
    time: '3w ago',
    reminder: null
  }]
};
window.UP_HELPERS = {
  fmtK: function (n) {
    return n >= 1000 ? (n / 1000).toFixed(1).replace(/\.0$/, '') + 'k' : String(n);
  },
  joinLabel: function (iso) {
    var d = new Date(iso);
    return d.toLocaleDateString(undefined, {
      month: 'long',
      year: 'numeric'
    });
  },
  notifIcon: function (type) {
    var map = {
      reply: 'M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z',
      like: 'M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z',
      mention: 'M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zm0 5a3 3 0 1 1 0 6 3 3 0 0 1 0-6z',
      badge: 'M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z'
    };
    return map[type] || map.reply;
  },
  activityIcon: function (type) {
    var map = {
      topic: 'M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z',
      reply: 'M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z',
      like: 'M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z'
    };
    return map[type] || map.topic;
  }
};
})(); } catch (e) { __ds_ns.__errors.push({ path: "user-profile-data.js", error: String((e && e.message) || e) }); }

// user-profile-panels.jsx
try { (() => {
/* user-profile-panels.jsx — Activity, Notifications, Messages, Bookmarks, Preferences panels */
const {
  Ic,
  Avatar,
  TeretBadge,
  SectionLabel
} = window;

/* ═══════════════════════════════════════════════════
   ACTIVITY — Timeline style
   ═══════════════════════════════════════════════════ */
function ActivityTimeline({
  items
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column'
    }
  }, items.map(function (item, i) {
    var iconPath = UP_HELPERS.activityIcon(item.type);
    var typeLabel = item.type === 'topic' ? 'Created a byte' : item.type === 'reply' ? 'Replied' : 'Liked';
    return /*#__PURE__*/React.createElement("div", {
      key: i,
      style: {
        display: 'flex',
        gap: 14,
        padding: '16px 0',
        borderBottom: '1px solid var(--fomio-border-soft)',
        cursor: 'pointer',
        transition: 'background 120ms'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        width: 32,
        height: 32,
        borderRadius: 8,
        background: item.type === 'topic' ? 'var(--fomio-primary-soft)' : 'var(--fomio-surface)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        flexShrink: 0
      }
    }, /*#__PURE__*/React.createElement(Ic, {
      d: iconPath,
      size: 15,
      color: item.type === 'topic' ? 'var(--fomio-primary)' : 'var(--fomio-fg-muted)'
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        minWidth: 0
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 8,
        marginBottom: 6,
        overflow: 'hidden'
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--fomio-sans)',
        fontSize: 12,
        fontWeight: 500,
        color: 'var(--fomio-fg-muted)',
        flexShrink: 0
      }
    }, typeLabel), /*#__PURE__*/React.createElement(TeretBadge, {
      name: item.teret,
      color: item.teretColor
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--fomio-sans)',
        fontSize: 12,
        color: 'var(--fomio-fg-muted)',
        marginLeft: 'auto',
        flexShrink: 0
      }
    }, item.time)), /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--fomio-serif)',
        fontSize: 16,
        fontWeight: 700,
        color: 'var(--fomio-fg)',
        letterSpacing: '-0.01em',
        lineHeight: 1.3
      }
    }, item.title), item.excerpt && /*#__PURE__*/React.createElement("p", {
      style: {
        fontFamily: 'var(--fomio-serif)',
        fontSize: 14,
        lineHeight: 1.55,
        color: 'var(--fomio-fg-muted)',
        margin: '6px 0 0',
        overflow: 'hidden',
        textOverflow: 'ellipsis',
        display: '-webkit-box',
        WebkitLineClamp: 2,
        WebkitBoxOrient: 'vertical'
      }
    }, item.excerpt), item.type === 'reply' && item.replyTo && /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--fomio-sans)',
        fontSize: 12,
        color: 'var(--fomio-fg-muted)',
        marginTop: 4,
        display: 'inline-flex',
        alignItems: 'center',
        gap: 4
      }
    }, /*#__PURE__*/React.createElement(Ic, {
      d: "M9 10l-5 5 5 5",
      size: 12
    }), " replying to ", item.replyTo), item.type === 'topic' && (item.likes > 0 || item.replies > 0) && /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        gap: 14,
        marginTop: 8,
        fontFamily: 'var(--fomio-sans)',
        fontSize: 12,
        color: 'var(--fomio-fg-muted)',
        fontWeight: 500
      }
    }, item.likes > 0 && /*#__PURE__*/React.createElement("span", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 4
      }
    }, /*#__PURE__*/React.createElement(Ic, {
      d: "M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z",
      size: 13
    }), item.likes), item.replies > 0 && /*#__PURE__*/React.createElement("span", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 4
      }
    }, /*#__PURE__*/React.createElement(Ic, {
      d: "M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z",
      size: 13
    }), item.replies)), item.type === 'like' && item.actor && /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--fomio-sans)',
        fontSize: 12,
        color: 'var(--fomio-fg-muted)',
        marginTop: 4,
        display: 'block'
      }
    }, "by ", item.actor)));
  }));
}

/* ═══════════════════════════════════════════════════
   ACTIVITY — Card style
   ═══════════════════════════════════════════════════ */
function ActivityCards({
  items
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 12
    }
  }, items.map(function (item, i) {
    if (item.type === 'like') {
      return /*#__PURE__*/React.createElement("div", {
        key: i,
        style: {
          display: 'flex',
          alignItems: 'center',
          gap: 12,
          padding: '12px 16px',
          background: 'var(--fomio-surface)',
          borderRadius: 12,
          fontFamily: 'var(--fomio-sans)',
          fontSize: 13,
          color: 'var(--fomio-fg-muted)',
          cursor: 'pointer'
        }
      }, /*#__PURE__*/React.createElement(Ic, {
        d: "M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z",
        size: 14,
        color: "var(--fomio-primary)"
      }), /*#__PURE__*/React.createElement("span", null, "Liked ", /*#__PURE__*/React.createElement("strong", {
        style: {
          color: 'var(--fomio-fg)',
          fontWeight: 600
        }
      }, item.title)), /*#__PURE__*/React.createElement("span", {
        style: {
          marginLeft: 'auto',
          fontSize: 12,
          flexShrink: 0
        }
      }, item.time));
    }
    return /*#__PURE__*/React.createElement("div", {
      key: i,
      style: {
        background: 'var(--fomio-card)',
        border: '1px solid var(--fomio-border)',
        borderRadius: 18,
        padding: '20px 22px',
        cursor: 'pointer',
        transition: 'border-color 200ms, box-shadow 200ms'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 8,
        marginBottom: 10,
        flexWrap: 'wrap'
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--fomio-sans)',
        fontSize: 12,
        fontWeight: 500,
        color: 'var(--fomio-fg-muted)'
      }
    }, item.type === 'topic' ? 'Byte' : 'Reply'), /*#__PURE__*/React.createElement(TeretBadge, {
      name: item.teret,
      color: item.teretColor
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--fomio-sans)',
        fontSize: 12,
        color: 'var(--fomio-fg-muted)',
        marginLeft: 'auto'
      }
    }, item.time)), /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--fomio-serif)',
        fontSize: 18,
        fontWeight: 700,
        color: 'var(--fomio-fg)',
        letterSpacing: '-0.015em',
        lineHeight: 1.25,
        marginBottom: item.excerpt ? 8 : 0
      }
    }, item.title), item.excerpt && /*#__PURE__*/React.createElement("p", {
      style: {
        fontFamily: 'var(--fomio-serif)',
        fontSize: 15,
        lineHeight: 1.55,
        color: 'var(--fomio-fg-secondary)',
        margin: 0,
        overflow: 'hidden',
        textOverflow: 'ellipsis',
        display: '-webkit-box',
        WebkitLineClamp: 2,
        WebkitBoxOrient: 'vertical'
      }
    }, item.excerpt), item.type === 'reply' && item.replyTo && /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--fomio-sans)',
        fontSize: 12,
        color: 'var(--fomio-fg-muted)',
        marginTop: 10,
        display: 'flex',
        alignItems: 'center',
        gap: 4
      }
    }, /*#__PURE__*/React.createElement(Ic, {
      d: "M9 10l-5 5 5 5",
      size: 12
    }), " replying to ", item.replyTo), item.type === 'topic' && (item.likes > 0 || item.replies > 0) && /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        gap: 16,
        marginTop: 12,
        fontFamily: 'var(--fomio-sans)',
        fontSize: 13,
        color: 'var(--fomio-fg-muted)',
        fontWeight: 500
      }
    }, item.likes > 0 && /*#__PURE__*/React.createElement("span", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 5
      }
    }, /*#__PURE__*/React.createElement(Ic, {
      d: "M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z",
      size: 14
    }), item.likes), item.replies > 0 && /*#__PURE__*/React.createElement("span", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 5
      }
    }, /*#__PURE__*/React.createElement(Ic, {
      d: "M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z",
      size: 14
    }), item.replies)));
  }));
}

/* ═══════════════════════════════════════════════════
   ACTIVITY — Read (recently read topics)
   ═══════════════════════════════════════════════════ */
function ActivityReads({
  items
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column'
    }
  }, items.map(function (r, i) {
    var done = r.postsRead >= r.total;
    var pct = Math.round(r.postsRead / r.total * 100);
    return /*#__PURE__*/React.createElement("div", {
      key: i,
      style: {
        display: 'flex',
        gap: 14,
        padding: '16px 0',
        borderBottom: '1px solid var(--fomio-border-soft)',
        cursor: 'pointer'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        width: 32,
        height: 32,
        borderRadius: 8,
        background: 'var(--fomio-surface)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        flexShrink: 0
      }
    }, /*#__PURE__*/React.createElement(Ic, {
      d: "M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z",
      size: 15,
      color: "var(--fomio-fg-muted)"
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        minWidth: 0
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--fomio-serif)',
        fontSize: 16,
        fontWeight: 700,
        color: 'var(--fomio-fg)',
        letterSpacing: '-0.01em',
        lineHeight: 1.3,
        overflow: 'hidden',
        textOverflow: 'ellipsis',
        whiteSpace: 'nowrap'
      }
    }, r.title), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 8,
        marginTop: 6
      }
    }, /*#__PURE__*/React.createElement(TeretBadge, {
      name: r.teret,
      color: r.teretColor
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--fomio-sans)',
        fontSize: 12,
        color: 'var(--fomio-fg-muted)'
      }
    }, r.postsRead, " / ", r.total, " read"), /*#__PURE__*/React.createElement("span", {
      style: {
        opacity: 0.35
      }
    }, "\xB7"), /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--fomio-sans)',
        fontSize: 12,
        color: 'var(--fomio-fg-muted)'
      }
    }, r.lastRead)), /*#__PURE__*/React.createElement("div", {
      style: {
        marginTop: 8,
        height: 4,
        borderRadius: 2,
        background: 'var(--fomio-border-soft)',
        overflow: 'hidden'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        width: pct + '%',
        height: '100%',
        background: done ? 'var(--fomio-success, #2A6F4F)' : 'var(--fomio-primary)',
        borderRadius: 2
      }
    }))));
  }));
}

/* ═══════════════════════════════════════════════════
   ACTIVITY — Drafts
   ═══════════════════════════════════════════════════ */
function ActivityDrafts({
  items
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column'
    }
  }, items.map(function (d, i) {
    return /*#__PURE__*/React.createElement("div", {
      key: i,
      style: {
        display: 'flex',
        gap: 14,
        padding: '16px 0',
        borderBottom: '1px solid var(--fomio-border-soft)',
        cursor: 'pointer'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        width: 32,
        height: 32,
        borderRadius: 8,
        background: 'var(--fomio-surface)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        flexShrink: 0
      }
    }, /*#__PURE__*/React.createElement(Ic, {
      d: "M12 20h9 M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4z",
      size: 14,
      color: "var(--fomio-fg-muted)"
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        minWidth: 0
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 8,
        marginBottom: 4
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--fomio-sans)',
        fontSize: 12,
        fontWeight: 500,
        color: 'var(--fomio-fg-muted)'
      }
    }, d.type === 'topic' ? 'Draft byte' : 'Draft reply'), d.teret && /*#__PURE__*/React.createElement(TeretBadge, {
      name: d.teret,
      color: d.teretColor
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--fomio-sans)',
        fontSize: 12,
        color: 'var(--fomio-fg-muted)',
        marginLeft: 'auto',
        flexShrink: 0
      }
    }, "saved ", d.saved)), /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--fomio-serif)',
        fontSize: 16,
        fontWeight: 700,
        color: 'var(--fomio-fg)',
        letterSpacing: '-0.01em',
        lineHeight: 1.3,
        fontStyle: d.title === '(untitled)' ? 'italic' : 'normal',
        opacity: d.title === '(untitled)' ? 0.6 : 1
      }
    }, d.title), d.excerpt && /*#__PURE__*/React.createElement("p", {
      style: {
        fontFamily: 'var(--fomio-serif)',
        fontSize: 14,
        lineHeight: 1.55,
        color: 'var(--fomio-fg-muted)',
        margin: '6px 0 0',
        overflow: 'hidden',
        textOverflow: 'ellipsis',
        display: '-webkit-box',
        WebkitLineClamp: 2,
        WebkitBoxOrient: 'vertical'
      }
    }, d.excerpt), d.type === 'reply' && d.replyTo && /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--fomio-sans)',
        fontSize: 12,
        color: 'var(--fomio-fg-muted)',
        marginTop: 4,
        display: 'inline-flex',
        alignItems: 'center',
        gap: 4
      }
    }, /*#__PURE__*/React.createElement(Ic, {
      d: "M9 10l-5 5 5 5",
      size: 12
    }), " replying to ", d.replyTo)));
  }));
}

/* ═══════════════════════════════════════════════════
   ACTIVITY — Pending (awaiting approval)
   ═══════════════════════════════════════════════════ */
function ActivityPending({
  items
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column'
    }
  }, items.map(function (p, i) {
    return /*#__PURE__*/React.createElement("div", {
      key: i,
      style: {
        display: 'flex',
        gap: 14,
        padding: '16px 0',
        borderBottom: '1px solid var(--fomio-border-soft)'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        width: 32,
        height: 32,
        borderRadius: 8,
        background: 'color-mix(in oklab, var(--fomio-warning) 12%, transparent)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        flexShrink: 0
      }
    }, /*#__PURE__*/React.createElement(Ic, {
      d: "M12 6v6l4 2 M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20z",
      size: 15,
      color: "var(--fomio-warning)"
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        minWidth: 0
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 8,
        marginBottom: 4
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--fomio-sans)',
        fontSize: 11,
        fontWeight: 600,
        color: 'var(--fomio-warning)',
        background: 'color-mix(in oklab, var(--fomio-warning) 10%, transparent)',
        padding: '2px 8px',
        borderRadius: 9999
      }
    }, "Awaiting approval"), p.teret && /*#__PURE__*/React.createElement(TeretBadge, {
      name: p.teret,
      color: p.teretColor
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--fomio-sans)',
        fontSize: 12,
        color: 'var(--fomio-fg-muted)',
        marginLeft: 'auto',
        flexShrink: 0
      }
    }, p.submitted)), /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--fomio-serif)',
        fontSize: 16,
        fontWeight: 700,
        color: 'var(--fomio-fg)',
        letterSpacing: '-0.01em',
        lineHeight: 1.3
      }
    }, p.title), p.excerpt && /*#__PURE__*/React.createElement("p", {
      style: {
        fontFamily: 'var(--fomio-serif)',
        fontSize: 14,
        lineHeight: 1.55,
        color: 'var(--fomio-fg-muted)',
        margin: '6px 0 0'
      }
    }, p.excerpt), p.replyTo && /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--fomio-sans)',
        fontSize: 12,
        color: 'var(--fomio-fg-muted)',
        marginTop: 4,
        display: 'inline-flex',
        alignItems: 'center',
        gap: 4
      }
    }, /*#__PURE__*/React.createElement(Ic, {
      d: "M9 10l-5 5 5 5",
      size: 12
    }), " replying to ", p.replyTo)));
  }));
}

/* ═══════════════════════════════════════════════════
   ACTIVITY — Bookmarks (within activity stream)
   ═══════════════════════════════════════════════════ */
function ActivityBookmarks({
  items
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column'
    }
  }, items.map(function (b, i) {
    return /*#__PURE__*/React.createElement("div", {
      key: i,
      style: {
        display: 'flex',
        gap: 14,
        padding: '16px 0',
        borderBottom: '1px solid var(--fomio-border-soft)',
        cursor: 'pointer'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        width: 32,
        height: 32,
        borderRadius: 8,
        background: 'var(--fomio-surface)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        flexShrink: 0
      }
    }, /*#__PURE__*/React.createElement(Ic, {
      d: "M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z",
      size: 15,
      color: "var(--fomio-fg-muted)"
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        minWidth: 0
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--fomio-serif)',
        fontSize: 16,
        fontWeight: 700,
        color: 'var(--fomio-fg)',
        letterSpacing: '-0.01em',
        lineHeight: 1.3,
        overflow: 'hidden',
        textOverflow: 'ellipsis',
        whiteSpace: 'nowrap'
      }
    }, b.title), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 8,
        marginTop: 6,
        overflow: 'hidden'
      }
    }, /*#__PURE__*/React.createElement(TeretBadge, {
      name: b.teret,
      color: b.teretColor
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--fomio-sans)',
        fontSize: 12,
        color: 'var(--fomio-fg-muted)',
        flexShrink: 0
      }
    }, b.author), /*#__PURE__*/React.createElement("span", {
      style: {
        opacity: 0.35,
        flexShrink: 0
      }
    }, "\xB7"), /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--fomio-sans)',
        fontSize: 12,
        color: 'var(--fomio-fg-muted)',
        flexShrink: 0
      }
    }, b.time))), b.reminder && /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--fomio-sans)',
        fontSize: 11,
        fontWeight: 600,
        color: 'var(--fomio-warning)',
        background: 'color-mix(in oklab, var(--fomio-warning) 10%, transparent)',
        padding: '3px 8px',
        borderRadius: 9999,
        flexShrink: 0,
        alignSelf: 'center'
      }
    }, b.reminder));
  }));
}

/* ═══════════════════════════════════════════════════
   ACTIVITY — Bytes (topic_list from /topics/created-by/:username)
   A real Discourse topic list: title + category, replies, views, last activity.
   ═══════════════════════════════════════════════════ */
function fmtCount(n) {
  if (n >= 1000) {
    var k = n / 1000;
    return (k >= 10 ? Math.round(k) : k.toFixed(1).replace(/\.0$/, '')) + 'k';
  }
  return String(n);
}
function ActivityTopics({
  items
}) {
  var head = {
    fontFamily: 'var(--fomio-sans)',
    fontSize: 11,
    fontWeight: 600,
    letterSpacing: '0.04em',
    textTransform: 'uppercase',
    color: 'var(--fomio-fg-muted)'
  };
  var metricCell = {
    fontFamily: 'var(--fomio-mono)',
    fontSize: 13,
    fontWeight: 600,
    color: 'var(--fomio-fg-secondary)',
    textAlign: 'right',
    whiteSpace: 'nowrap',
    fontVariantNumeric: 'tabular-nums'
  };
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "fomio-topics-head",
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 64px 64px 96px',
      gap: 16,
      alignItems: 'center',
      padding: '0 4px 10px',
      borderBottom: '1px solid var(--fomio-border)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: head
  }, "Byte"), /*#__PURE__*/React.createElement("span", {
    style: Object.assign({}, head, {
      textAlign: 'right'
    })
  }, "Replies"), /*#__PURE__*/React.createElement("span", {
    style: Object.assign({}, head, {
      textAlign: 'right'
    })
  }, "Views"), /*#__PURE__*/React.createElement("span", {
    style: Object.assign({}, head, {
      textAlign: 'right'
    })
  }, "Activity")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column'
    }
  }, items.map(function (t) {
    return /*#__PURE__*/React.createElement("div", {
      key: t.id,
      className: "fomio-topic-row",
      style: {
        display: 'grid',
        gridTemplateColumns: '1fr 64px 64px 96px',
        gap: 16,
        alignItems: 'center',
        padding: '14px 4px',
        borderBottom: '1px solid var(--fomio-border-soft)',
        cursor: 'pointer'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        minWidth: 0
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 8
      }
    }, t.pinned && /*#__PURE__*/React.createElement(Ic, {
      d: "M12 17v5 M9 10.76a2 2 0 0 1-1.11 1.79l-1.78.9A2 2 0 0 0 5 15.24V16a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-.76a2 2 0 0 0-1.11-1.79l-1.78-.9A2 2 0 0 1 15 10.76V7a1 1 0 0 1 1-1 2 2 0 0 0 0-4H8a2 2 0 0 0 0 4 1 1 0 0 1 1 1z",
      size: 13,
      color: "var(--fomio-primary)"
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--fomio-serif)',
        fontSize: 16,
        fontWeight: 700,
        color: 'var(--fomio-fg)',
        letterSpacing: '-0.01em',
        lineHeight: 1.3,
        overflow: 'hidden',
        textOverflow: 'ellipsis',
        whiteSpace: 'nowrap'
      }
    }, t.title), t.closed && /*#__PURE__*/React.createElement(Ic, {
      d: "M18 8h1a4 4 0 0 1 0 8h-1 M2 8h13v9a4 4 0 0 1-4 4H6a4 4 0 0 1-4-4z M6 1v3 M10 1v3 M14 1v3",
      size: 12,
      color: "var(--fomio-fg-muted)"
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 8,
        marginTop: 6
      }
    }, /*#__PURE__*/React.createElement(TeretBadge, {
      name: t.teret,
      color: t.teretColor
    }), /*#__PURE__*/React.createElement("span", {
      className: "fomio-topic-meta-mobile",
      style: {
        display: 'none',
        fontFamily: 'var(--fomio-sans)',
        fontSize: 12,
        color: 'var(--fomio-fg-muted)'
      }
    }, fmtCount(t.replies), " replies \xB7 ", fmtCount(t.views), " views \xB7 ", t.activity))), /*#__PURE__*/React.createElement("span", {
      className: "fomio-topic-metric",
      style: metricCell
    }, fmtCount(t.replies)), /*#__PURE__*/React.createElement("span", {
      className: "fomio-topic-metric",
      style: metricCell
    }, fmtCount(t.views)), /*#__PURE__*/React.createElement("span", {
      className: "fomio-topic-metric",
      style: Object.assign({}, metricCell, {
        fontFamily: 'var(--fomio-sans)',
        fontWeight: 500,
        color: 'var(--fomio-fg-muted)'
      })
    }, t.activity));
  })));
}
function ActivitySection({
  items,
  style: actStyle,
  isSelf,
  topics,
  reads,
  drafts,
  pending,
  bookmarks
}) {
  /* Tabs mirror native Discourse userActivity routes.
     All=filter 4,5 · Bytes=topics/created-by · Replies=filter 5 · Likes given=filter 1.
     Read, Drafts, Pending, Bookmarks are self-only (conditional in native nav). */
  var tabs = [{
    key: 'all',
    label: 'All'
  }, {
    key: 'topics',
    label: 'Bytes'
  }, {
    key: 'replies',
    label: 'Replies'
  }, {
    key: 'likes',
    label: 'Likes given'
  }];
  if (isSelf) {
    tabs.push({
      key: 'read',
      label: 'Read'
    });
    tabs.push({
      key: 'drafts',
      label: 'Drafts',
      count: (drafts || []).length
    });
    tabs.push({
      key: 'pending',
      label: 'Pending',
      count: (pending || []).length
    });
    tabs.push({
      key: 'bookmarks',
      label: 'Bookmarks'
    });
  }
  var _s = React.useState('all');
  var activeTab = _s[0],
    setTab = _s[1];

  /* Reset to All if active tab disappears (e.g. switching to another user's profile) */
  React.useEffect(function () {
    if (!tabs.some(function (t) {
      return t.key === activeTab;
    })) setTab('all');
  }, [isSelf]);
  var streamTab = activeTab === 'all' || activeTab === 'replies' || activeTab === 'likes';
  var filtered = !streamTab ? [] : activeTab === 'all' ? items : items.filter(function (it) {
    if (activeTab === 'replies') return it.type === 'reply';
    if (activeTab === 'likes') return it.type === 'like';
    return true;
  });
  function renderBody() {
    if (activeTab === 'topics') {
      return topics && topics.length ? /*#__PURE__*/React.createElement(ActivityTopics, {
        items: topics
      }) : /*#__PURE__*/React.createElement(Empty, {
        label: "No bytes published yet."
      });
    }
    if (activeTab === 'read') {
      return reads && reads.length ? /*#__PURE__*/React.createElement(ActivityReads, {
        items: reads
      }) : /*#__PURE__*/React.createElement(Empty, {
        label: "Nothing read yet."
      });
    }
    if (activeTab === 'drafts') {
      return drafts && drafts.length ? /*#__PURE__*/React.createElement(ActivityDrafts, {
        items: drafts
      }) : /*#__PURE__*/React.createElement(Empty, {
        label: "No drafts saved."
      });
    }
    if (activeTab === 'pending') {
      return pending && pending.length ? /*#__PURE__*/React.createElement(ActivityPending, {
        items: pending
      }) : /*#__PURE__*/React.createElement(Empty, {
        label: "Nothing awaiting approval."
      });
    }
    if (activeTab === 'bookmarks') {
      return bookmarks && bookmarks.length ? /*#__PURE__*/React.createElement(ActivityBookmarks, {
        items: bookmarks
      }) : /*#__PURE__*/React.createElement(Empty, {
        label: "No bookmarks yet."
      });
    }
    if (filtered.length === 0) return /*#__PURE__*/React.createElement(Empty, {
      label: "No activity in this filter yet."
    });
    return actStyle === 'cards' ? /*#__PURE__*/React.createElement(ActivityCards, {
      items: filtered
    }) : /*#__PURE__*/React.createElement(ActivityTimeline, {
      items: filtered
    });
  }
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 0,
      borderBottom: '1px solid var(--fomio-border-soft)',
      marginBottom: 20,
      overflowX: 'auto',
      scrollbarWidth: 'none'
    }
  }, tabs.map(function (t) {
    var isActive = t.key === activeTab;
    return /*#__PURE__*/React.createElement("button", {
      key: t.key,
      onClick: function () {
        setTab(t.key);
      },
      style: {
        display: 'inline-flex',
        alignItems: 'center',
        gap: 6,
        height: 32,
        padding: '0 12px',
        background: 'transparent',
        border: 'none',
        borderBottom: isActive ? '2px solid var(--fomio-primary)' : '2px solid transparent',
        marginBottom: -1,
        cursor: 'pointer',
        fontFamily: 'var(--fomio-sans)',
        fontSize: 13,
        fontWeight: isActive ? 600 : 500,
        color: isActive ? 'var(--fomio-primary)' : 'var(--fomio-fg-muted)',
        whiteSpace: 'nowrap',
        transition: 'color 200ms, border-color 200ms',
        flexShrink: 0
      }
    }, t.label, t.count > 0 && /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--fomio-mono)',
        fontSize: 10,
        fontWeight: 700,
        color: isActive ? 'var(--fomio-primary)' : 'var(--fomio-fg-muted)',
        background: isActive ? 'var(--fomio-primary-soft)' : 'var(--fomio-surface)',
        padding: '1px 6px',
        borderRadius: 9999
      }
    }, t.count));
  })), renderBody());
}
function Empty({
  label
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'center',
      padding: '48px 24px',
      fontFamily: 'var(--fomio-serif)',
      color: 'var(--fomio-fg-muted)',
      fontStyle: 'italic'
    }
  }, label);
}

/* ═══════════════════════════════════════════════════
   NOTIFICATIONS
   ═══════════════════════════════════════════════════ */
function NotificationsSection({
  items
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      marginBottom: 16
    }
  }, /*#__PURE__*/React.createElement(SectionLabel, {
    text: "Recent"
  }), /*#__PURE__*/React.createElement("button", {
    style: {
      fontFamily: 'var(--fomio-sans)',
      fontSize: 12,
      fontWeight: 600,
      color: 'var(--fomio-primary)',
      background: 'none',
      border: 'none',
      cursor: 'pointer',
      padding: 0
    }
  }, "Mark all read")), items.map(function (n, i) {
    return /*#__PURE__*/React.createElement("div", {
      key: i,
      style: {
        display: 'flex',
        gap: 12,
        padding: '14px 0',
        borderBottom: '1px solid var(--fomio-border-soft)',
        cursor: 'pointer',
        opacity: n.read ? 0.7 : 1
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        width: 32,
        height: 32,
        borderRadius: 8,
        background: !n.read ? 'var(--fomio-primary-soft)' : 'var(--fomio-surface)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        flexShrink: 0
      }
    }, /*#__PURE__*/React.createElement(Ic, {
      d: UP_HELPERS.notifIcon(n.type),
      size: 15,
      color: !n.read ? 'var(--fomio-primary)' : 'var(--fomio-fg-muted)'
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        minWidth: 0
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--fomio-sans)',
        fontSize: 14,
        fontWeight: n.read ? 500 : 600,
        color: 'var(--fomio-fg)',
        lineHeight: 1.4
      }
    }, n.user && /*#__PURE__*/React.createElement("span", null, n.user, " "), /*#__PURE__*/React.createElement("span", {
      style: {
        fontWeight: 400,
        color: 'var(--fomio-fg-muted)'
      }
    }, n.type === 'reply' ? 'replied to' : n.type === 'like' ? 'liked' : n.type === 'mention' ? 'mentioned you in' : n.type === 'badge' ? '' : '', " "), n.title, n.count && n.count > 1 && /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--fomio-mono)',
        fontSize: 11,
        color: 'var(--fomio-fg-muted)',
        marginLeft: 4
      }
    }, "+", n.count - 1)), n.excerpt && /*#__PURE__*/React.createElement("p", {
      style: {
        fontFamily: 'var(--fomio-serif)',
        fontSize: 13,
        lineHeight: 1.5,
        color: 'var(--fomio-fg-muted)',
        margin: '4px 0 0',
        overflow: 'hidden',
        textOverflow: 'ellipsis',
        whiteSpace: 'nowrap'
      }
    }, n.excerpt)), /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--fomio-sans)',
        fontSize: 12,
        color: 'var(--fomio-fg-muted)',
        flexShrink: 0,
        marginTop: 2
      }
    }, n.time), !n.read && /*#__PURE__*/React.createElement("span", {
      style: {
        width: 8,
        height: 8,
        borderRadius: '50%',
        background: 'var(--fomio-primary)',
        flexShrink: 0,
        marginTop: 6
      }
    }));
  }));
}

/* ═══════════════════════════════════════════════════
   MESSAGES
   ═══════════════════════════════════════════════════ */
function MessagesSection({
  items
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      marginBottom: 16
    }
  }, /*#__PURE__*/React.createElement(SectionLabel, {
    text: "Inbox"
  }), /*#__PURE__*/React.createElement("button", {
    style: {
      fontFamily: 'var(--fomio-sans)',
      fontSize: 12,
      fontWeight: 600,
      color: 'var(--fomio-primary)',
      background: 'none',
      border: 'none',
      cursor: 'pointer',
      padding: 0,
      display: 'flex',
      alignItems: 'center',
      gap: 4
    }
  }, /*#__PURE__*/React.createElement(Ic, {
    d: "M12 5v14 M5 12h14",
    size: 13,
    color: "var(--fomio-primary)"
  }), " New message")), items.map(function (m, i) {
    return /*#__PURE__*/React.createElement("div", {
      key: i,
      style: {
        display: 'flex',
        gap: 14,
        padding: '16px 0',
        borderBottom: '1px solid var(--fomio-border-soft)',
        cursor: 'pointer'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        width: 36,
        height: 36,
        borderRadius: '50%',
        background: m.unread ? 'var(--fomio-primary)' : '#C9BBD4',
        color: m.unread ? '#fff' : '#4B3566',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        fontFamily: 'var(--fomio-serif)',
        fontWeight: 700,
        fontSize: 14,
        fontStyle: 'italic',
        flexShrink: 0
      }
    }, m.participants[0].charAt(0)), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        minWidth: 0
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'baseline',
        gap: 8
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--fomio-sans)',
        fontSize: 14,
        fontWeight: m.unread ? 700 : 600,
        color: 'var(--fomio-fg)',
        overflow: 'hidden',
        textOverflow: 'ellipsis',
        whiteSpace: 'nowrap',
        minWidth: 0
      }
    }, m.participants.join(', ')), /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--fomio-sans)',
        fontSize: 12,
        color: 'var(--fomio-fg-muted)',
        marginLeft: 'auto',
        flexShrink: 0
      }
    }, m.time)), /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--fomio-serif)',
        fontSize: 14,
        fontWeight: m.unread ? 600 : 400,
        color: 'var(--fomio-fg)',
        marginTop: 3,
        overflow: 'hidden',
        textOverflow: 'ellipsis',
        whiteSpace: 'nowrap'
      }
    }, m.title), /*#__PURE__*/React.createElement("p", {
      style: {
        fontFamily: 'var(--fomio-serif)',
        fontSize: 13,
        color: 'var(--fomio-fg-muted)',
        margin: '4px 0 0',
        overflow: 'hidden',
        textOverflow: 'ellipsis',
        whiteSpace: 'nowrap'
      }
    }, m.last)), m.unread && /*#__PURE__*/React.createElement("span", {
      style: {
        width: 8,
        height: 8,
        borderRadius: '50%',
        background: 'var(--fomio-primary)',
        flexShrink: 0,
        marginTop: 8
      }
    }));
  }));
}

/* ═══════════════════════════════════════════════════
   BOOKMARKS
   ═══════════════════════════════════════════════════ */
function BookmarksSection({
  items
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column'
    }
  }, /*#__PURE__*/React.createElement(SectionLabel, {
    text: "Saved"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 16
    }
  }, items.map(function (b, i) {
    return /*#__PURE__*/React.createElement("div", {
      key: i,
      style: {
        display: 'flex',
        gap: 14,
        padding: '14px 0',
        borderBottom: '1px solid var(--fomio-border-soft)',
        cursor: 'pointer'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        width: 32,
        height: 32,
        borderRadius: 8,
        background: 'var(--fomio-surface)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        flexShrink: 0
      }
    }, /*#__PURE__*/React.createElement(Ic, {
      d: "M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z",
      size: 15,
      color: "var(--fomio-fg-muted)"
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        minWidth: 0
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--fomio-serif)',
        fontSize: 15,
        fontWeight: 600,
        color: 'var(--fomio-fg)',
        overflow: 'hidden',
        textOverflow: 'ellipsis',
        whiteSpace: 'nowrap'
      }
    }, b.title), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 8,
        marginTop: 4,
        fontFamily: 'var(--fomio-sans)',
        fontSize: 12,
        color: 'var(--fomio-fg-muted)',
        overflow: 'hidden'
      }
    }, /*#__PURE__*/React.createElement(TeretBadge, {
      name: b.teret,
      color: b.teretColor
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        flexShrink: 0
      }
    }, b.author), /*#__PURE__*/React.createElement("span", {
      style: {
        opacity: 0.35,
        flexShrink: 0
      }
    }, "\xB7"), /*#__PURE__*/React.createElement("span", {
      style: {
        flexShrink: 0
      }
    }, b.time))), b.reminder && /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--fomio-sans)',
        fontSize: 11,
        fontWeight: 600,
        color: 'var(--fomio-warning)',
        background: 'color-mix(in oklab, var(--fomio-warning) 10%, transparent)',
        padding: '3px 8px',
        borderRadius: 9999,
        flexShrink: 0,
        alignSelf: 'center'
      }
    }, b.reminder));
  })));
}

/* ═══════════════════════════════════════════════════
   PREFERENCES (simplified visual)
   ═══════════════════════════════════════════════════ */
function PreferencesSection({
  user
}) {
  var groups = [{
    label: 'Account',
    items: [{
      k: 'Username',
      v: '@' + user.username
    }, {
      k: 'Name',
      v: user.name
    }, {
      k: 'Title',
      v: user.title || '\u2014'
    }]
  }, {
    label: 'Profile',
    items: [{
      k: 'Bio',
      v: user.bio ? user.bio.substring(0, 60) + '\u2026' : '\u2014'
    }, {
      k: 'Location',
      v: user.location || '\u2014'
    }, {
      k: 'Website',
      v: user.website || '\u2014'
    }]
  }, {
    label: 'Notifications',
    items: [{
      k: 'Email on reply',
      v: 'Always'
    }, {
      k: 'Email on mention',
      v: 'Only when away'
    }, {
      k: 'Email digest',
      v: 'Weekly'
    }]
  }];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 32
    }
  }, groups.map(function (g, gi) {
    return /*#__PURE__*/React.createElement("section", {
      key: gi
    }, /*#__PURE__*/React.createElement(SectionLabel, {
      text: g.label
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        marginTop: 12
      }
    }, g.items.map(function (item, ii) {
      return /*#__PURE__*/React.createElement("div", {
        key: ii,
        style: {
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          padding: '14px 0',
          borderBottom: ii < g.items.length - 1 ? '1px solid var(--fomio-border-soft)' : 'none'
        }
      }, /*#__PURE__*/React.createElement("span", {
        style: {
          fontFamily: 'var(--fomio-sans)',
          fontSize: 14,
          fontWeight: 500,
          color: 'var(--fomio-fg)'
        }
      }, item.k), /*#__PURE__*/React.createElement("span", {
        style: {
          fontFamily: 'var(--fomio-sans)',
          fontSize: 14,
          color: 'var(--fomio-fg-muted)',
          textAlign: 'right',
          maxWidth: '60%',
          overflow: 'hidden',
          textOverflow: 'ellipsis',
          whiteSpace: 'nowrap'
        }
      }, item.v));
    })));
  }));
}
Object.assign(window, {
  ActivitySection,
  ActivityTimeline,
  ActivityCards,
  ActivityTopics,
  ActivityReads,
  ActivityDrafts,
  ActivityPending,
  ActivityBookmarks,
  Empty,
  NotificationsSection,
  MessagesSection,
  BookmarksSection,
  PreferencesSection
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "user-profile-panels.jsx", error: String((e && e.message) || e) }); }

// user-profile-ui.jsx
try { (() => {
/* user-profile-ui.jsx — Hero variants + Summary section for /u/user/* prototype */
const {
  useState,
  useEffect,
  useRef,
  useMemo
} = React;

/* ── Helpers ─────────────────────────────────────── */
function Ic({
  d,
  size = 16,
  color = 'currentColor',
  style: s
}) {
  return React.createElement('svg', {
    width: size,
    height: size,
    viewBox: '0 0 24 24',
    fill: 'none',
    stroke: color,
    strokeWidth: 2,
    strokeLinecap: 'round',
    strokeLinejoin: 'round',
    style: {
      display: 'block',
      flexShrink: 0,
      ...s
    }
  }, React.createElement('path', {
    d
  }));
}
function Avatar({
  user,
  size = 48
}) {
  const fs = Math.round(size * 0.38);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      width: size,
      height: size,
      borderRadius: '50%',
      background: user.avatarBg,
      color: user.avatarFg,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontFamily: 'var(--fomio-serif)',
      fontWeight: 700,
      fontSize: fs,
      fontStyle: 'italic',
      flexShrink: 0,
      letterSpacing: '-0.02em'
    }
  }, user.initials);
}
function TeretBadge({
  name,
  color
}) {
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 5,
      padding: '3px 10px',
      borderRadius: 9999,
      fontFamily: 'var(--fomio-sans)',
      fontWeight: 700,
      fontSize: 10.5,
      letterSpacing: '0.06em',
      textTransform: 'uppercase',
      background: color ? `${color}18` : 'var(--fomio-primary-soft)',
      color: color || 'var(--fomio-primary-dark)'
    }
  }, name);
}
function StatBlock({
  value,
  label
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 2
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--fomio-serif)',
      fontWeight: 700,
      fontSize: 22,
      lineHeight: 1.1,
      letterSpacing: '-0.02em',
      color: 'var(--fomio-fg)'
    }
  }, value), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--fomio-sans)',
      fontWeight: 500,
      fontSize: 11,
      letterSpacing: '0.04em',
      textTransform: 'uppercase',
      color: 'var(--fomio-fg-muted)'
    }
  }, label));
}

/* ═══════════════════════════════════════════════════
   HERO VARIANT A — Editorial
   ═══════════════════════════════════════════════════ */
function ProfileHeroEditorial({
  user,
  isSelf,
  compact
}) {
  const {
    fmtK,
    joinLabel
  } = UP_HELPERS;
  return /*#__PURE__*/React.createElement("header", {
    style: {
      padding: compact ? '32px 0 28px' : '48px 0 40px',
      borderBottom: '1px solid var(--fomio-border)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-start',
      gap: compact ? 16 : 24,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(Avatar, {
    user: user,
    size: compact ? 56 : 72
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 200
    }
  }, (user.title || user.isAdmin) && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--fomio-sans)',
      fontSize: 10.5,
      fontWeight: 700,
      letterSpacing: '0.06em',
      textTransform: 'uppercase',
      color: user.isAdmin ? 'var(--fomio-primary)' : 'var(--fomio-fg-muted)',
      marginBottom: 6,
      display: 'flex',
      alignItems: 'center',
      gap: 6
    }
  }, user.isAdmin && /*#__PURE__*/React.createElement(Ic, {
    d: "M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z",
    size: 12,
    color: "var(--fomio-primary)"
  }), user.title || (user.isAdmin ? 'fomio admin' : '')), /*#__PURE__*/React.createElement("h1", {
    style: {
      fontFamily: 'var(--fomio-serif)',
      fontWeight: 700,
      fontSize: compact ? 28 : 36,
      lineHeight: 1.15,
      letterSpacing: '-0.03em',
      color: 'var(--fomio-fg)',
      margin: '0 0 6px'
    }
  }, user.name), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--fomio-sans)',
      fontSize: 13,
      fontWeight: 500,
      color: 'var(--fomio-fg-muted)',
      display: 'flex',
      gap: 8,
      alignItems: 'center',
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--fomio-fg-secondary)'
    }
  }, "@", user.username), user.location && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("span", {
    style: {
      opacity: 0.35
    }
  }, "\xB7"), /*#__PURE__*/React.createElement("span", null, user.location)), user.website && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("span", {
    style: {
      opacity: 0.35
    }
  }, "\xB7"), /*#__PURE__*/React.createElement("a", {
    href: user.websiteUrl,
    style: {
      color: 'var(--fomio-primary)',
      textDecoration: 'none'
    }
  }, user.website)))), isSelf ? /*#__PURE__*/React.createElement("button", {
    style: {
      fontFamily: 'var(--fomio-sans)',
      fontSize: 13,
      fontWeight: 600,
      padding: '8px 20px',
      borderRadius: 9999,
      border: '1px solid var(--fomio-border)',
      background: 'transparent',
      color: 'var(--fomio-fg)',
      cursor: 'pointer',
      whiteSpace: 'nowrap',
      marginTop: 4
    }
  }, "Edit profile") : /*#__PURE__*/React.createElement("button", {
    style: {
      fontFamily: 'var(--fomio-sans)',
      fontSize: 13,
      fontWeight: 600,
      padding: '8px 20px',
      borderRadius: 9999,
      border: 'none',
      background: 'var(--fomio-primary)',
      color: '#fff',
      cursor: 'pointer',
      whiteSpace: 'nowrap',
      marginTop: 4
    }
  }, "Message")), user.bio && /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--fomio-serif)',
      fontSize: 16,
      lineHeight: 1.65,
      color: 'var(--fomio-fg-secondary)',
      maxWidth: 600,
      margin: '20px 0 0',
      fontStyle: 'italic'
    }
  }, user.bio), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: compact ? 24 : 36,
      marginTop: 24,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(StatBlock, {
    value: user.stats.bytesWritten,
    label: "bytes"
  }), /*#__PURE__*/React.createElement(StatBlock, {
    value: user.stats.replies,
    label: "replies"
  }), /*#__PURE__*/React.createElement(StatBlock, {
    value: fmtK(user.stats.likesReceived),
    label: "received"
  }), /*#__PURE__*/React.createElement(StatBlock, {
    value: fmtK(user.stats.likesGiven),
    label: "given"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      marginTop: 16,
      fontFamily: 'var(--fomio-sans)',
      fontSize: 12,
      fontWeight: 500,
      color: 'var(--fomio-fg-muted)'
    }
  }, /*#__PURE__*/React.createElement("span", null, "On fomio since ", joinLabel(user.joinDate)), user.groups.length > 0 && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("span", {
    style: {
      opacity: 0.35
    }
  }, "\xB7"), user.groups.map(function (g, i) {
    return /*#__PURE__*/React.createElement("span", {
      key: i,
      style: {
        background: 'var(--fomio-surface)',
        padding: '2px 8px',
        borderRadius: 9999,
        fontSize: 11,
        fontWeight: 600
      }
    }, g);
  }))));
}

/* ═══════════════════════════════════════════════════
   HERO VARIANT B — Compact
   ═══════════════════════════════════════════════════ */
function ProfileHeroCompact({
  user,
  isSelf
}) {
  const {
    fmtK
  } = UP_HELPERS;
  return /*#__PURE__*/React.createElement("header", {
    style: {
      padding: '24px 0',
      borderBottom: '1px solid var(--fomio-border)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement(Avatar, {
    user: user,
    size: 44
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'baseline',
      gap: 8,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--fomio-serif)',
      fontWeight: 700,
      fontSize: 20,
      letterSpacing: '-0.02em',
      color: 'var(--fomio-fg)'
    }
  }, user.name), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--fomio-sans)',
      fontSize: 13,
      fontWeight: 500,
      color: 'var(--fomio-fg-muted)'
    }
  }, "@", user.username), user.isAdmin && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--fomio-sans)',
      fontSize: 10,
      fontWeight: 700,
      letterSpacing: '0.06em',
      textTransform: 'uppercase',
      color: 'var(--fomio-primary)',
      background: 'var(--fomio-primary-soft)',
      padding: '2px 7px',
      borderRadius: 9999
    }
  }, "admin")), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--fomio-sans)',
      fontSize: 12,
      fontWeight: 500,
      color: 'var(--fomio-fg-muted)',
      display: 'flex',
      gap: 12,
      marginTop: 4,
      flexWrap: 'wrap',
      alignItems: 'center'
    }
  }, user.location && /*#__PURE__*/React.createElement("span", null, user.location), /*#__PURE__*/React.createElement("span", null, user.stats.bytesWritten, " bytes"), /*#__PURE__*/React.createElement("span", null, fmtK(user.stats.likesReceived), " received"))), isSelf ? /*#__PURE__*/React.createElement("button", {
    style: {
      fontFamily: 'var(--fomio-sans)',
      fontSize: 12,
      fontWeight: 600,
      padding: '6px 16px',
      borderRadius: 9999,
      border: '1px solid var(--fomio-border)',
      background: 'transparent',
      color: 'var(--fomio-fg)',
      cursor: 'pointer',
      whiteSpace: 'nowrap'
    }
  }, "Edit") : /*#__PURE__*/React.createElement("button", {
    style: {
      fontFamily: 'var(--fomio-sans)',
      fontSize: 12,
      fontWeight: 600,
      padding: '6px 16px',
      borderRadius: 9999,
      border: 'none',
      background: 'var(--fomio-primary)',
      color: '#fff',
      cursor: 'pointer',
      whiteSpace: 'nowrap'
    }
  }, "Message")), user.bio && /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--fomio-serif)',
      fontSize: 14,
      lineHeight: 1.55,
      color: 'var(--fomio-fg-muted)',
      margin: '12px 0 0 60px',
      fontStyle: 'italic',
      maxWidth: 520
    }
  }, user.bio));
}

/* ═══════════════════════════════════════════════════
   HERO VARIANT C — Card
   ═══════════════════════════════════════════════════ */
function ProfileHeroCard({
  user,
  isSelf
}) {
  const {
    fmtK,
    joinLabel
  } = UP_HELPERS;
  return /*#__PURE__*/React.createElement("header", {
    style: {
      background: 'var(--fomio-card)',
      border: '1px solid var(--fomio-border)',
      borderRadius: 18,
      padding: '28px 28px 24px',
      marginBottom: 24
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 20,
      alignItems: 'flex-start'
    }
  }, /*#__PURE__*/React.createElement(Avatar, {
    user: user,
    size: 64
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement("h1", {
    style: {
      fontFamily: 'var(--fomio-serif)',
      fontWeight: 700,
      fontSize: 24,
      letterSpacing: '-0.02em',
      color: 'var(--fomio-fg)',
      margin: 0,
      lineHeight: 1.2
    }
  }, user.name), user.isAdmin && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--fomio-sans)',
      fontSize: 10,
      fontWeight: 700,
      letterSpacing: '0.06em',
      textTransform: 'uppercase',
      color: 'var(--fomio-primary)',
      background: 'var(--fomio-primary-soft)',
      padding: '2px 7px',
      borderRadius: 9999
    }
  }, "admin")), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--fomio-sans)',
      fontSize: 13,
      fontWeight: 500,
      color: 'var(--fomio-fg-muted)',
      display: 'flex',
      gap: 8,
      marginTop: 4,
      alignItems: 'center',
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement("span", null, "@", user.username), /*#__PURE__*/React.createElement("span", {
    style: {
      opacity: 0.35
    }
  }, "\xB7"), /*#__PURE__*/React.createElement("span", null, "On fomio since ", joinLabel(user.joinDate))), user.bio && /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--fomio-serif)',
      fontSize: 15,
      lineHeight: 1.6,
      color: 'var(--fomio-fg-secondary)',
      margin: '14px 0 0',
      maxWidth: 520
    }
  }, user.bio), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      marginTop: 14,
      flexWrap: 'wrap'
    }
  }, user.location && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--fomio-sans)',
      fontSize: 12,
      fontWeight: 500,
      color: 'var(--fomio-fg-muted)',
      display: 'flex',
      alignItems: 'center',
      gap: 4
    }
  }, /*#__PURE__*/React.createElement(Ic, {
    d: "M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z M12 7a3 3 0 1 0 0 6 3 3 0 0 0 0-6z",
    size: 13
  }), user.location), user.website && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--fomio-sans)',
      fontSize: 12,
      fontWeight: 500
    }
  }, /*#__PURE__*/React.createElement("a", {
    href: user.websiteUrl,
    style: {
      color: 'var(--fomio-primary)',
      textDecoration: 'none',
      display: 'flex',
      alignItems: 'center',
      gap: 4
    }
  }, /*#__PURE__*/React.createElement(Ic, {
    d: "M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20z M2 12h20 M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10A15.3 15.3 0 0 1 12 2z",
    size: 13
  }), user.website))))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      marginTop: 20,
      paddingTop: 20,
      borderTop: '1px solid var(--fomio-border-soft)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 28
    }
  }, /*#__PURE__*/React.createElement(StatBlock, {
    value: user.stats.bytesWritten,
    label: "bytes"
  }), /*#__PURE__*/React.createElement(StatBlock, {
    value: user.stats.replies,
    label: "replies"
  }), /*#__PURE__*/React.createElement(StatBlock, {
    value: fmtK(user.stats.likesReceived),
    label: "received"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8
    }
  }, isSelf ? /*#__PURE__*/React.createElement("button", {
    style: {
      fontFamily: 'var(--fomio-sans)',
      fontSize: 13,
      fontWeight: 600,
      padding: '8px 20px',
      borderRadius: 9999,
      border: '1px solid var(--fomio-border)',
      background: 'transparent',
      color: 'var(--fomio-fg)',
      cursor: 'pointer'
    }
  }, "Edit profile") : /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("button", {
    style: {
      fontFamily: 'var(--fomio-sans)',
      fontSize: 13,
      fontWeight: 600,
      padding: '8px 20px',
      borderRadius: 9999,
      border: 'none',
      background: 'var(--fomio-primary)',
      color: '#fff',
      cursor: 'pointer'
    }
  }, "Message"), /*#__PURE__*/React.createElement("button", {
    style: {
      fontFamily: 'var(--fomio-sans)',
      fontSize: 13,
      fontWeight: 600,
      padding: '8px 16px',
      borderRadius: 9999,
      border: '1px solid var(--fomio-border)',
      background: 'transparent',
      color: 'var(--fomio-fg)',
      cursor: 'pointer',
      display: 'flex',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement(Ic, {
    d: "M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8 M16 6l-4-4-4 4 M12 2v13",
    size: 14
  }))))));
}

/* ═══════════════════════════════════════════════════
   HERO ROUTER
   ═══════════════════════════════════════════════════ */
function ProfileHero({
  user,
  isSelf,
  heroStyle,
  isNarrow
}) {
  if (heroStyle === 'compact') return /*#__PURE__*/React.createElement(ProfileHeroCompact, {
    user: user,
    isSelf: isSelf
  });
  if (heroStyle === 'card') return /*#__PURE__*/React.createElement(ProfileHeroCard, {
    user: user,
    isSelf: isSelf
  });
  return /*#__PURE__*/React.createElement(ProfileHeroEditorial, {
    user: user,
    isSelf: isSelf,
    compact: isNarrow
  });
}

/* ═══════════════════════════════════════════════════
   SUMMARY SECTION
   ═══════════════════════════════════════════════════ */
function SummarySection({
  user
}) {
  const {
    fmtK
  } = UP_HELPERS;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 40
    }
  }, /*#__PURE__*/React.createElement("section", null, /*#__PURE__*/React.createElement(SectionLabel, {
    text: "Reading & engagement"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fill, minmax(130px, 1fr))',
      gap: 16,
      marginTop: 16
    }
  }, [{
    v: user.stats.daysVisited,
    l: 'days visited'
  }, {
    v: fmtK(user.stats.postsRead),
    l: 'posts read'
  }, {
    v: fmtK(user.stats.topicsEntered),
    l: 'topics entered'
  }, {
    v: user.stats.timeReadHours + 'h',
    l: 'time read'
  }].map(function (s, i) {
    return /*#__PURE__*/React.createElement("div", {
      key: i,
      style: {
        background: 'var(--fomio-card)',
        border: '1px solid var(--fomio-border-soft)',
        borderRadius: 12,
        padding: '16px 18px'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--fomio-serif)',
        fontWeight: 700,
        fontSize: 20,
        letterSpacing: '-0.02em',
        color: 'var(--fomio-fg)'
      }
    }, s.v), /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--fomio-sans)',
        fontWeight: 500,
        fontSize: 11,
        letterSpacing: '0.04em',
        textTransform: 'uppercase',
        color: 'var(--fomio-fg-muted)',
        marginTop: 4
      }
    }, s.l));
  }))), /*#__PURE__*/React.createElement("section", null, /*#__PURE__*/React.createElement(SectionLabel, {
    text: "Top terets"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 10,
      marginTop: 16
    }
  }, user.topCategories.map(function (cat, i) {
    var max = user.topCategories[0].count;
    return /*#__PURE__*/React.createElement("div", {
      key: i,
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 12
      }
    }, /*#__PURE__*/React.createElement(TeretBadge, {
      name: cat.name,
      color: cat.color
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        height: 4,
        background: 'var(--fomio-surface)',
        borderRadius: 2,
        overflow: 'hidden'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        height: '100%',
        width: cat.count / max * 100 + '%',
        background: cat.color,
        borderRadius: 2,
        opacity: 0.6
      }
    })), /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--fomio-mono)',
        fontSize: 12,
        color: 'var(--fomio-fg-muted)',
        minWidth: 24,
        textAlign: 'right'
      }
    }, cat.count));
  }))), /*#__PURE__*/React.createElement("section", null, /*#__PURE__*/React.createElement(SectionLabel, {
    text: "Top replies"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 12
    }
  }, user.topReplies.map(function (r, i) {
    return /*#__PURE__*/React.createElement("div", {
      key: i,
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 12,
        padding: '12px 0',
        borderBottom: i < user.topReplies.length - 1 ? '1px solid var(--fomio-border-soft)' : 'none',
        cursor: 'pointer'
      }
    }, /*#__PURE__*/React.createElement(Ic, {
      d: "M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z",
      size: 14,
      color: "var(--fomio-fg-muted)"
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--fomio-mono)',
        fontSize: 12,
        color: 'var(--fomio-fg-muted)',
        minWidth: 24
      }
    }, r.likes), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        minWidth: 0
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--fomio-serif)',
        fontSize: 15,
        fontWeight: 600,
        color: 'var(--fomio-fg)',
        overflow: 'hidden',
        textOverflow: 'ellipsis',
        whiteSpace: 'nowrap'
      }
    }, r.title), /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--fomio-sans)',
        fontSize: 12,
        color: 'var(--fomio-fg-muted)',
        marginTop: 1
      }
    }, r.teret)));
  }))), /*#__PURE__*/React.createElement("section", null, /*#__PURE__*/React.createElement(SectionLabel, {
    text: 'Badges \u00b7 ' + user.badgeCount
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 10,
      marginTop: 16,
      flexWrap: 'wrap'
    }
  }, user.badges.map(function (b, i) {
    return /*#__PURE__*/React.createElement("div", {
      key: i,
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 8,
        background: 'var(--fomio-card)',
        border: '1px solid var(--fomio-border-soft)',
        borderRadius: 12,
        padding: '10px 14px',
        cursor: 'pointer'
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 16
      }
    }, b.glyph), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--fomio-sans)',
        fontSize: 13,
        fontWeight: 600,
        color: 'var(--fomio-fg)'
      }
    }, b.name), /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--fomio-sans)',
        fontSize: 11,
        color: 'var(--fomio-fg-muted)'
      }
    }, b.date)));
  }))));
}
function SectionLabel({
  text
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--fomio-sans)',
      fontSize: 11,
      fontWeight: 700,
      letterSpacing: '0.06em',
      textTransform: 'uppercase',
      color: 'var(--fomio-fg-muted)'
    },
    dangerouslySetInnerHTML: {
      __html: text
    }
  });
}

/* Export all to window */
Object.assign(window, {
  Ic,
  Avatar,
  TeretBadge,
  StatBlock,
  ProfileHero,
  ProfileHeroEditorial,
  ProfileHeroCompact,
  ProfileHeroCard,
  SummarySection,
  SectionLabel
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "user-profile-ui.jsx", error: String((e && e.message) || e) }); }

__ds_ns.CategoryPermission = __ds_scope.CategoryPermission;

__ds_ns.NotificationLevel = __ds_scope.NotificationLevel;

__ds_ns.TopicFilter = __ds_scope.TopicFilter;

__ds_ns.TopPeriod = __ds_scope.TopPeriod;

})();

# Fomio Design System

An algorithm-free, premium social blogging sanctuary built around privacy. Fomio is a community reading and writing platform — you post **Bytes** (topics) to **Terets** (subcategories) within **Hubs**. No gamification, no ML feeds, no dopamine hooks. Chronological, calm, unhurried.

The product spans three surfaces, all backed by a Discourse forum:

| Surface | Stack | Role |
|---|---|---|
| **Mobile app** | Expo + React Native + NativeWind | Primary consumer experience |
| **Web theme** (Scriptorium) | Discourse theme (SCSS + Handlebars) | Editorial web reading/writing |
| **CLI / TUI** | Node + Ink | Power-user terminal interface |

## Sources this system was derived from

- **Codebase:** `Fomio/` monorepo — `packages/design-tokens/tokens.js` is the canonical source of truth; mobile (`tailwind.config.js` + `components/ui/*`) and CLI (`apps/cli/src/tui`) consume it directly. `DESIGN_TOKENS.md` and `DESIGN_SYSTEM_AUDIT.md` document the guarantees.
- **Brand:** `uploads/Brand Guideline.pdf` + wordmark variants (`fomio-01..04.png` — terracotta-arc, mono, white).

---

## Content fundamentals

**Voice.** Editorial, calm, direct. Second person. Short sentences. Zero hype, no exclamation points, no emoji in product copy. Product name is always lowercase: `fomio`. Writing is called "craft"; the product is a "sanctuary"; the villain is "the algorithm".

**Casing.** Sentence case for UI ("Mark all read", "Create byte", "Latest"). Never Title Case.

**Domain nouns.** Byte (post), Teret (subcategory), Hub (category group), Scriptorium (web theme brand name).

**Copy examples** from the codebase:
- Empty state CTA: "Create byte" (not "Create Your First Post!")
- Filter chips: "Latest", "Hot", "Unread"
- Gated feature nudge: "Log in to use Unread"
- Confirm dialog action: "Mark all notifications as read" → "Mark Read"
- CLI help row: `q quit · / search · j/k nav · ↵ open`

**Emoji.** Never in UI. The mobile codebase parses Discourse emoji shortcodes (`:fire:`) in *user content* only.

---

## Visual foundations

### Through-line
Warm cream + terracotta + serif. Everything leans **editorial** — think literary magazine, not consumer social. The logo is an italic serif wordmark with a single terracotta arc under "mio" (Italian for "mine"). That arc is the only decorative flourish the brand permits.

### Color
- **Palette is intentionally tiny.** One cream background, one white card, one terracotta accent, one near-black text, one muted grey.
- **Terracotta `#C44536` is the only chromatic accent.** Primary CTAs, focus rings, active chips, links, unread dots. Solid fills only — never gradients, never tinted backgrounds.
- **No pure black or pure white on web/dark.** The spec forbids it. Mobile overrides to AMOLED true-black — a deliberate platform divergence.
- **Two dark modes.** Web/Discourse uses warm brown (`#1a1917`). Mobile uses AMOLED (`#000`). Both ship here.

### Type
- **Lora (serif)** — body, titles, display, reading surfaces.
- **Raleway (sans)** — labels, nav, metadata, buttons, chips.
- **Space Mono** — code and CLI.
- Heading tracking tight (`-0.02em`). Label tracking wide (`+0.04em`) uppercase.
- Body reading measure caps at `680px`.

### Shape language
- Cards: **18px radius** (dedicated `card` token).
- Buttons: **pill (9999px)**. Primary 48h, secondary 40h.
- Inputs: 12px radius, 40h.
- Else: sm/md/lg ladder 8 / 12 / 16.

### Depth
- **Flat first.** Borders + color changes, not shadows.
- When a shadow *is* used: `0 24px 80px -36px rgba(0,0,0,0.14)` (landing / story panels only).
- Mobile tab bar uses BlurView over translucent surface — a rare exception.
- Dark mode: no shadows; states shift border color instead.

### Animation
- Mostly none. The spec is explicit: "no confetti, animations, or gradient backgrounds."
- Permitted: 200ms crossfade on theme toggle; spring tab transitions; `FadeIn.delay(i * 50).duration(300)` stagger on lists.
- Default easing: `cubic-bezier(0.22, 0.61, 0.36, 1)`.

### States
- Hover → `primary-dark` (#9E3326) or `0 1px 3px rgba(0,0,0,0.1)` card lift (light only).
- Focus → 2px terracotta ring.
- Disabled → `opacity: 0.5` (light), `0.6` (dark).

### Density
- Card padding 16–24px. Section gaps 24–48px. Body line-height **1.65** (reading-first).

---

## Iconography

- **Mobile: Phosphor Icons** (`phosphor-react-native`). `regular` weight inactive, `fill` active. Sizes 20 / 22 / 24 / 26.
  - Home=House, Search=MagnifyingGlass, Compose=Plus, Notifications=Bell, Profile=User, Mark-read=CheckCircle, Reply=ChatCircle, Like=Heart, Views=Eye.
- **Web:** FontAwesome (Discourse default) or Material Symbols Outlined. Lucide is an acceptable Phosphor fallback.
- **CLI:** ASCII glyphs only. `›` cursor, `│` selected metadata, `·` separator, `♥` likes, `⊙` pinned, `─` rule, `@user` cyan.
- **Emoji:** never in UI.

Brand marks in `assets/`: `logo-wordmark-accent.png` (primary), `-mono.png`, `-white.png`, `-white-accent.png`, `app-icon.png`, `app-adaptive-icon.png`, `favicon.png`, `splash-icon-light/dark.png`.

If an icon is missing: substitute from Lucide and flag it.

---

## Index

```
├── README.md                   ← this file
├── SKILL.md                    ← cross-compatible Agent Skill manifest
├── colors_and_type.css         ← canonical CSS vars + @font-face + semantic classes
├── fonts/                      ← Lora · Raleway · Space Mono TTFs (12 files)
├── assets/                     ← logos, app icons, splash, favicons
├── preview/                    ← Design System tab cards
│   ├── colors.html
│   ├── type.html
│   ├── spacing.html
│   ├── components.html
│   └── brand.html
└── ui_kits/
    ├── mobile/index.html       ← Expo iOS screens (feed · byte · compose · alerts, light + AMOLED)
    ├── web/index.html          ← Scriptorium Discourse theme (hub feed + reading view)
    └── cli/index.html          ← Ink TUI recreation (feed · byte · compose · search)
```

### Caveats

- **Dark mode forks intentionally.** Web = warm brown; Mobile = AMOLED. Both ship; pick by platform.
- **Spacing forks intentionally.** Web `md/lg/xl = 12/16/24`, Mobile `md/lg/xl = 16/24/32`. The token file flags this as "do not unify without a cross-platform audit."
- No slide template is produced — the source repo has none. Use `colors_and_type.css` for any future slide work.
- The Brand Guideline PDF was cross-referenced against the codebase tokens (its stated source of truth) rather than parsed byte-level.
